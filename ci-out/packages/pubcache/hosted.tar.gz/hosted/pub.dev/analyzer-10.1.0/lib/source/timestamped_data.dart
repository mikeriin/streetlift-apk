// Copyright (c) 2025, the Dart project authors. Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

export 'package:_fe_analyzer_shared/src/base/timestamped_data.dart'
    show TimestampedData;
