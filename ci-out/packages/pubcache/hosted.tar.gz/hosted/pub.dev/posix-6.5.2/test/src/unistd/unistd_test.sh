#!/bin/bash
echo $EUID