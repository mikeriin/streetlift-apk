// Catalogue de WODs : recherche + panneau de filtres déroulant, multi-sélection
// par catégorie (statut, format, niveau, durée, matériel, source).
import 'package:flutter/material.dart';

import 'arsenal_screen.dart' show WodTile;
import 'app_theme.dart';
import 'ui.dart';
import 'store.dart';
import 'wod_generator.dart';
import 'wod_models.dart';

class _Filters {
  String status = 'all'; // all | unlocked | affordable | locked
  final Set<String> types = {};
  final Set<int> bands = {}; // 1: 1-3 · 2: 4-6 · 3: 7-8 · 4: 9-10
  final Set<String> durs = {}; // short | mid | long
  final Set<String> equips = {}; // pdc | barre | lest | erg | kb
  final Set<String> sources = {}; // curated | generated | mine

  int get count =>
      (status == 'all' ? 0 : 1) +
      types.length +
      bands.length +
      durs.length +
      equips.length +
      sources.length;

  void clear() {
    status = 'all';
    types.clear();
    bands.clear();
    durs.clear();
    equips.clear();
    sources.clear();
  }

  _Filters copy() =>
      _Filters()
        ..status = status
        ..types.addAll(types)
        ..bands.addAll(bands)
        ..durs.addAll(durs)
        ..equips.addAll(equips)
        ..sources.addAll(sources);

  bool match(Wod w, String q) {
    if (status == 'unlocked' && !store.unlocked(w)) return false;
    if (status == 'locked' && store.unlocked(w)) return false;
    if (status == 'affordable' &&
        (store.unlocked(w) || store.wodCost(w) > store.credits)) {
      return false;
    }
    if (types.isNotEmpty && !types.contains(w.type)) return false;
    if (bands.isNotEmpty) {
      final l = w.level;
      final b =
          l <= 3
              ? 1
              : l <= 6
              ? 2
              : l <= 8
              ? 3
              : 4;
      if (!bands.contains(b)) return false;
    }
    if (durs.isNotEmpty) {
      final estimate = store.wodEstimate(w);
      if (estimate.elapsed.high <= 0 ||
          (estimate.partial &&
              estimate.clock == null &&
              estimate.observed == null)) {
        return false;
      }
      final m = estimate.elapsed.midpoint / 60;
      final d =
          m < 15
              ? 'short'
              : m <= 30
              ? 'mid'
              : 'long';
      if (!durs.contains(d)) return false;
    }
    if (equips.isNotEmpty) {
      final eq = equipmentOf(w);
      final ok = equips.any(
        (e) =>
            e == 'pdc'
                ? (eq.length == 1 && eq.contains('pdc'))
                : eq.contains(e),
      );
      if (!ok) return false;
    }
    if (sources.isNotEmpty) {
      final gen = store.isGenerated(w), cat = store.isCatalog(w);
      final s =
          gen
              ? 'generated'
              : cat
              ? 'curated'
              : 'mine';
      if (!sources.contains(s)) return false;
    }
    if (q.trim().isNotEmpty) {
      final t = q.trim().toLowerCase();
      if (!w.name.toLowerCase().contains(t) &&
          !w.lines.any((l) => l.toLowerCase().contains(t)) &&
          !w.source.toLowerCase().contains(t)) {
        return false;
      }
    }
    return true;
  }
}

const _statusLabels = {
  'all': 'Tous',
  'unlocked': 'Débloqués',
  'affordable': 'Abordables',
  'locked': 'Verrouillés',
};
const _bandLabels = {
  1: 'Niv. 1-3',
  2: 'Niv. 4-6',
  3: 'Niv. 7-8',
  4: 'Niv. 9-10',
};
const _durLabels = {
  'short': '< 15 min',
  'mid': '15-30 min',
  'long': '> 30 min',
};
const _equipLabels = {
  'pdc': 'Poids de corps seul',
  'barre': 'Barre',
  'lest': 'Lest',
  'erg': 'Erg',
  'kb': 'KB / wall ball',
  'box': 'Box',
  'corde': 'Corde',
};
const _sourceLabels = {'curated': 'Sélection', 'generated': 'Séries Kalis'};

class WodCatalogScreen extends StatefulWidget {
  const WodCatalogScreen({super.key});
  @override
  State<WodCatalogScreen> createState() => _WodCatalogScreenState();
}

class _WodCatalogScreenState extends State<WodCatalogScreen> {
  final f = _Filters();
  String q = '';
  final searchCtl = TextEditingController();
  @override
  void dispose() {
    searchCtl.dispose();
    super.dispose();
  }

  List<Wod> _list() =>
      store.wods.where((w) => store.isCatalog(w) && f.match(w, q)).toList()
        ..sort((a, b) {
          final ua = store.unlocked(a) ? 0 : 1, ub = store.unlocked(b) ? 0 : 1;
          if (ua != ub) return ua.compareTo(ub);
          if (a.level != b.level) return a.level.compareTo(b.level);
          return a.name.compareTo(b.name);
        });

  Future<void> _openFilters() async {
    final draft = f.copy();
    final applied = await showModalBottomSheet<_Filters>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder:
          (ctx) => StatefulBuilder(
            builder: (ctx, setSheet) {
              final n =
                  store.wods
                      .where((w) => store.isCatalog(w) && draft.match(w, q))
                      .length;
              Widget chips<T>(Map<T, String> labels, Set<T> sel) => Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final e in labels.entries)
                    FilterChip(
                      label: Text(e.value),
                      selected: sel.contains(e.key),
                      showCheckmark: false,
                      labelStyle: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        color: sel.contains(e.key) ? SL.steel : SL.dim,
                      ),
                      selectedColor: SL.steel.withValues(alpha: 0.18),
                      backgroundColor: SL.card,
                      side: BorderSide(
                        color: sel.contains(e.key) ? SL.steel : SL.formBorder,
                      ),
                      onSelected:
                          (v) => setSheet(
                            () => v ? sel.add(e.key) : sel.remove(e.key),
                          ),
                    ),
                ],
              );
              Widget section(String t, Widget child) => Padding(
                padding: const EdgeInsets.fromLTRB(
                  KSpace.page,
                  KControl.formGap,
                  KSpace.page,
                  0,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      t,
                      style: TextStyle(
                        color: SL.dim,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0,
                      ),
                    ),
                    const SizedBox(height: 8),
                    child,
                  ],
                ),
              );
              return DraggableScrollableSheet(
                expand: false,
                initialChildSize: 0.8,
                maxChildSize: 0.95,
                builder:
                    (ctx, ctl) => Column(
                      children: [
                        Expanded(
                          child: ListView(
                            controller: ctl,
                            padding: const EdgeInsets.only(bottom: 12),
                            children: [
                              Padding(
                                padding: const EdgeInsets.fromLTRB(
                                  KSpace.page,
                                  0,
                                  KSpace.page,
                                  0,
                                ),
                                child: Row(
                                  children: [
                                    const Text(
                                      'Filtres',
                                      style: TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 15,
                                      ),
                                    ),
                                    const Spacer(),
                                    TextButton(
                                      onPressed: () => setSheet(draft.clear),
                                      child: const Text('Réinitialiser'),
                                    ),
                                  ],
                                ),
                              ),
                              section(
                                'Accès',
                                Wrap(
                                  spacing: 6,
                                  runSpacing: 6,
                                  children: [
                                    for (final e in _statusLabels.entries)
                                      ChoiceChip(
                                        label: Text(e.value),
                                        selected: draft.status == e.key,
                                        showCheckmark: false,
                                        labelStyle: TextStyle(
                                          fontSize: 12.5,
                                          fontWeight: FontWeight.w700,
                                          color:
                                              draft.status == e.key
                                                  ? SL.steel
                                                  : SL.dim,
                                        ),
                                        selectedColor: SL.steel.withValues(
                                          alpha: 0.18,
                                        ),
                                        backgroundColor: SL.card,
                                        side: BorderSide(
                                          color:
                                              draft.status == e.key
                                                  ? SL.steel
                                                  : SL.formBorder,
                                        ),
                                        onSelected:
                                            (_) => setSheet(
                                              () => draft.status = e.key,
                                            ),
                                      ),
                                  ],
                                ),
                              ),
                              section('Format', chips(wodTypes, draft.types)),
                              section(
                                'Difficulté',
                                chips(_bandLabels, draft.bands),
                              ),
                              section(
                                'Durée estimée',
                                chips(_durLabels, draft.durs),
                              ),
                              section(
                                'Matériel',
                                chips(_equipLabels, draft.equips),
                              ),
                              section(
                                'Source',
                                chips(_sourceLabels, draft.sources),
                              ),
                            ],
                          ),
                        ),
                        KBottomActions(
                          child: FilledButton(
                            onPressed: () => Navigator.pop(ctx, draft),
                            child: Text('Voir $n WOD${n > 1 ? 's' : ''}'),
                          ),
                        ),
                      ],
                    ),
              );
            },
          ),
    );
    if (applied != null && mounted) {
      setState(() {
        f
          ..status = applied.status
          ..types.clear()
          ..types.addAll(applied.types)
          ..bands.clear()
          ..bands.addAll(applied.bands)
          ..durs.clear()
          ..durs.addAll(applied.durs)
          ..equips.clear()
          ..equips.addAll(applied.equips)
          ..sources.clear()
          ..sources.addAll(applied.sources);
      });
    }
  }

  List<(String, VoidCallback)> _active() => [
    if (f.status != 'all') (_statusLabels[f.status]!, () => f.status = 'all'),
    for (final t in f.types) (wodTypes[t] ?? t, () => f.types.remove(t)),
    for (final b in f.bands) (_bandLabels[b]!, () => f.bands.remove(b)),
    for (final d in f.durs) (_durLabels[d]!, () => f.durs.remove(d)),
    for (final e in f.equips) (_equipLabels[e]!, () => f.equips.remove(e)),
    for (final s in f.sources) (_sourceLabels[s]!, () => f.sources.remove(s)),
  ];

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final list = _list();
        final active = _active();
        return KScreen(
          appBar: AppBar(
            title: Text('WODs · ${list.length}'),
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: TextButton.icon(
                  style: TextButton.styleFrom(
                    foregroundColor: f.count > 0 ? SL.steel : SL.text,
                  ),
                  onPressed: _openFilters,
                  icon: Icon(
                    f.count > 0 ? Icons.filter_alt : Icons.filter_alt_outlined,
                    size: 20,
                  ),
                  label: Text(f.count > 0 ? 'Filtres · ${f.count}' : 'Filtres'),
                ),
              ),
            ],
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  KSpace.page,
                  8,
                  KSpace.page,
                  8,
                ),
                child: Row(
                  children: [
                    Icon(Icons.toll_rounded, color: SL.steel, size: 22),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        '${store.credits} crédit${store.credits > 1 ? 's' : ''} disponible${store.credits > 1 ? 's' : ''}',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: KSpace.page),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Gagne des crédits en progressant. Achète un WOD, rejoue-le à volonté.',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  KSpace.page,
                  8,
                  KSpace.page,
                  8,
                ),
                child: KSearch(
                  controller: searchCtl,
                  hint: 'Rechercher un WOD ou un mouvement',
                  onChanged: (v) => setState(() => q = v),
                ),
              ),
              if (active.isNotEmpty)
                SizedBox(
                  height: 64,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(
                      horizontal: KSpace.page,
                    ),
                    children: [
                      for (final (label, remove) in active)
                        Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: InputChip(
                            label: Text(label),
                            labelStyle: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: SL.steel,
                            ),
                            backgroundColor: SL.steel.withValues(alpha: 0.14),
                            side: BorderSide(
                              color: SL.steel.withValues(alpha: 0.5),
                            ),
                            deleteIconColor: SL.steel,
                            onDeleted: () => setState(remove),
                          ),
                        ),
                      TextButton(
                        onPressed: () => setState(f.clear),
                        child: const Text(
                          'Tout effacer',
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
              Expanded(
                child:
                    list.isEmpty
                        ? KList(
                          children: [
                            KEmpty(
                              icon: Icons.search_off,
                              title: 'Aucun WOD trouvé',
                              message:
                                  'Essaie un autre terme ou élargis les filtres.',
                              action: 'Réinitialiser',
                              onAction:
                                  () => setState(() {
                                    f.clear();
                                    searchCtl.clear();
                                    q = '';
                                  }),
                            ),
                          ],
                        )
                        : ListView.separated(
                          padding: KSpace.content,
                          keyboardDismissBehavior:
                              ScrollViewKeyboardDismissBehavior.onDrag,
                          separatorBuilder:
                              (_, __) => const SizedBox(height: 12),
                          itemCount: list.length,
                          itemBuilder:
                              (_, i) => WodTile(
                                key: ValueKey(list[i].id),
                                wod: list[i],
                              ),
                        ),
              ),
            ],
          ),
        );
      },
    );
  }
}
