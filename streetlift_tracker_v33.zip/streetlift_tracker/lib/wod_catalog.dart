// Catalogue de WODs : recherche + panneau de filtres déroulant, multi-sélection
// par catégorie (statut, format, niveau, durée, matériel, source).
import 'package:flutter/material.dart';

import 'arsenal_screen.dart' show WodTile;
import 'main.dart';
import 'store.dart';
import 'wod_generator.dart';
import 'wod_models.dart';

class _Filters {
  String status = 'all'; // all | unlocked | affordable | locked
  final Set<String> types = {};
  final Set<int> bands = {}; // 1: 1-3 · 2: 4-6 · 3: 7-8 · 4: 9-10
  final Set<String> durs = {}; // short | mid | long
  final Set<String> equips = {}; // pdc | barre | lest | erg | kb
  final Set<String> sources = {}; // curated | generated | mine

  int get count => (status == 'all' ? 0 : 1) + types.length + bands.length + durs.length + equips.length + sources.length;

  void clear() {
    status = 'all';
    types.clear();
    bands.clear();
    durs.clear();
    equips.clear();
    sources.clear();
  }

  _Filters copy() => _Filters()
    ..status = status
    ..types.addAll(types)
    ..bands.addAll(bands)
    ..durs.addAll(durs)
    ..equips.addAll(equips)
    ..sources.addAll(sources);

  bool match(Wod w, String q) {
    if (status == 'unlocked' && !store.unlocked(w)) return false;
    if (status == 'locked' && store.unlocked(w)) return false;
    if (status == 'affordable' && (store.unlocked(w) || store.wodCost(w) > store.credits)) return false;
    if (types.isNotEmpty && !types.contains(w.type)) return false;
    if (bands.isNotEmpty) {
      final l = w.level;
      final b = l <= 3 ? 1 : l <= 6 ? 2 : l <= 8 ? 3 : 4;
      if (!bands.contains(b)) return false;
    }
    if (durs.isNotEmpty) {
      final m = store.wodStats(w).minutes;
      final d = m < 15 ? 'short' : m <= 30 ? 'mid' : 'long';
      if (!durs.contains(d)) return false;
    }
    if (equips.isNotEmpty) {
      final eq = equipmentOf(w);
      final ok = equips.any((e) => e == 'pdc' ? (eq.length == 1 && eq.contains('pdc')) : eq.contains(e));
      if (!ok) return false;
    }
    if (sources.isNotEmpty) {
      final gen = store.isGenerated(w), cat = store.isCatalog(w);
      final s = gen ? 'generated' : cat ? 'curated' : 'mine';
      if (!sources.contains(s)) return false;
    }
    if (q.trim().isNotEmpty) {
      final t = q.trim().toLowerCase();
      if (!w.name.toLowerCase().contains(t) && !w.lines.any((l) => l.toLowerCase().contains(t)) && !w.source.toLowerCase().contains(t)) return false;
    }
    return true;
  }
}

const _statusLabels = {'all': 'Tous', 'unlocked': 'Débloqués', 'affordable': 'Abordables', 'locked': 'Verrouillés'};
const _bandLabels = {1: 'Niv. 1-3', 2: 'Niv. 4-6', 3: 'Niv. 7-8', 4: 'Niv. 9-10'};
const _durLabels = {'short': '< 15 min', 'mid': '15-30 min', 'long': '> 30 min'};
const _equipLabels = {'pdc': 'Poids de corps seul', 'barre': 'Barre', 'lest': 'Lest', 'erg': 'Erg', 'kb': 'KB / wall ball', 'box': 'Box', 'corde': 'Corde'};
const _sourceLabels = {'curated': 'Sélection', 'generated': 'Générés', 'mine': 'Les miens'};

class WodCatalogScreen extends StatefulWidget {
  const WodCatalogScreen({super.key});
  @override
  State<WodCatalogScreen> createState() => _WodCatalogScreenState();
}

class _WodCatalogScreenState extends State<WodCatalogScreen> {
  final f = _Filters();
  String q = '';

  List<Wod> _list() => store.wods.where((w) => f.match(w, q)).toList()
    ..sort((a, b) {
      final ua = store.unlocked(a) ? 0 : 1, ub = store.unlocked(b) ? 0 : 1;
      if (ua != ub) return ua.compareTo(ub);
      if (a.level != b.level) return a.level.compareTo(b.level);
      return a.name.compareTo(b.name);
    });

  Future<void> _openFilters() async {
    final draft = f.copy();
    final applied = await showModalBottomSheet<_Filters>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          final n = store.wods.where((w) => draft.match(w, q)).length;
          Widget chips<T>(Map<T, String> labels, Set<T> sel) => Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final e in labels.entries)
                    FilterChip(
                      label: Text(e.value),
                      selected: sel.contains(e.key),
                      showCheckmark: false,
                      labelStyle: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: sel.contains(e.key) ? SL.steel : SL.dim),
                      selectedColor: SL.steel.withOpacity(0.18),
                      backgroundColor: SL.card,
                      side: BorderSide(color: sel.contains(e.key) ? SL.steel : SL.formBorder),
                      onSelected: (v) => setSheet(() => v ? sel.add(e.key) : sel.remove(e.key)),
                    ),
                ],
              );
          Widget section(String t, Widget child) => Padding(
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(t, style: TextStyle(color: SL.dim, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.6)),
                    const SizedBox(height: 8),
                    child,
                  ],
                ),
              );
          return DraggableScrollableSheet(
            expand: false,
            initialChildSize: 0.8,
            maxChildSize: 0.95,
            builder: (ctx, ctl) => Column(
              children: [
                Expanded(
                  child: ListView(
                    controller: ctl,
                    padding: const EdgeInsets.only(bottom: 12),
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                        child: Row(
                          children: [
                            const Text('FILTRES', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
                            const Spacer(),
                            TextButton(onPressed: () => setSheet(draft.clear), child: const Text('Réinitialiser')),
                          ],
                        ),
                      ),
                      section(
                        'STATUT',
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            for (final e in _statusLabels.entries)
                              ChoiceChip(
                                label: Text(e.value),
                                selected: draft.status == e.key,
                                showCheckmark: false,
                                labelStyle: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: draft.status == e.key ? SL.steel : SL.dim),
                                selectedColor: SL.steel.withOpacity(0.18),
                                backgroundColor: SL.card,
                                side: BorderSide(color: draft.status == e.key ? SL.steel : SL.formBorder),
                                onSelected: (_) => setSheet(() => draft.status = e.key),
                              ),
                          ],
                        ),
                      ),
                      section('FORMAT', chips(wodTypes, draft.types)),
                      section('NIVEAU', chips(_bandLabels, draft.bands)),
                      section('DURÉE ESTIMÉE', chips(_durLabels, draft.durs)),
                      section('MATÉRIEL', chips(_equipLabels, draft.equips)),
                      section('SOURCE', chips(_sourceLabels, draft.sources)),
                    ],
                  ),
                ),
                SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
                    child: FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: SL.steel, foregroundColor: SL.onAccent, minimumSize: const Size.fromHeight(50)),
                      onPressed: () => Navigator.pop(ctx, draft),
                      child: Text('Voir $n WOD${n > 1 ? 's' : ''}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
    if (applied != null) {
      setState(() {
        f
          ..status = applied.status
          ..types.clear()
          ..types.addAll(applied.types)
          ..bands.clear()
          ..bands.addAll(applied.bands)
          ..durs.clear()
          ..durs.addAll(applied.durs)
          ..equips.clear()
          ..equips.addAll(applied.equips)
          ..sources.clear()
          ..sources.addAll(applied.sources);
      });
    }
  }

  List<(String, VoidCallback)> _active() => [
        if (f.status != 'all') (_statusLabels[f.status]!, () => f.status = 'all'),
        for (final t in f.types) (wodTypes[t] ?? t, () => f.types.remove(t)),
        for (final b in f.bands) (_bandLabels[b]!, () => f.bands.remove(b)),
        for (final d in f.durs) (_durLabels[d]!, () => f.durs.remove(d)),
        for (final e in f.equips) (_equipLabels[e]!, () => f.equips.remove(e)),
        for (final s in f.sources) (_sourceLabels[s]!, () => f.sources.remove(s)),
      ];

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final list = _list();
        final active = _active();
        return Scaffold(
          appBar: AppBar(
            title: Text('CATALOGUE · ${list.length}'),
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: TextButton.icon(
                  style: TextButton.styleFrom(foregroundColor: f.count > 0 ? SL.steel : SL.text),
                  onPressed: _openFilters,
                  icon: Icon(f.count > 0 ? Icons.filter_alt : Icons.filter_alt_outlined, size: 20),
                  label: Text(f.count > 0 ? 'Filtres · ${f.count}' : 'Filtres', style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
            ],
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 6),
                child: TextField(
                  textAlign: TextAlign.left,
                  decoration: InputDecoration(
                    hintText: 'Rechercher un WOD ou un mouvement',
                    prefixIcon: Icon(Icons.search, color: SL.dim),
                    suffixIcon: q.isEmpty ? null : IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => setState(() => q = '')),
                  ),
                  onChanged: (v) => setState(() => q = v),
                ),
              ),
              if (active.isNotEmpty)
                SizedBox(
                  height: 38,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    children: [
                      for (final (label, remove) in active)
                        Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: InputChip(
                            label: Text(label),
                            labelStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: SL.steel),
                            backgroundColor: SL.steel.withOpacity(0.14),
                            side: BorderSide(color: SL.steel.withOpacity(0.5)),
                            deleteIconColor: SL.steel,
                            onDeleted: () => setState(remove),
                          ),
                        ),
                      TextButton(onPressed: () => setState(f.clear), child: const Text('Tout effacer', style: TextStyle(fontSize: 12))),
                    ],
                  ),
                ),
              Expanded(
                child: list.isEmpty
                    ? Center(child: Text('Aucun WOD ne correspond à ces filtres.', style: TextStyle(color: SL.dim)))
                    : ListView.builder(
                        padding: const EdgeInsets.only(top: 4, bottom: 24),
                        itemCount: list.length,
                        itemBuilder: (_, i) => WodTile(key: ValueKey(list[i].id), wod: list[i]),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}
