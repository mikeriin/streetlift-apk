// Catalogue de WODs : recherche + filtres (statut, format, niveau, matériel, durée, source).
import 'package:flutter/material.dart';

import 'arsenal_screen.dart' show WodTile;
import 'main.dart';
import 'store.dart';
import 'wod_generator.dart';
import 'wod_models.dart';

class WodCatalogScreen extends StatefulWidget {
  const WodCatalogScreen({super.key});
  @override
  State<WodCatalogScreen> createState() => _WodCatalogScreenState();
}

class _WodCatalogScreenState extends State<WodCatalogScreen> {
  String q = '';
  String status = 'all'; // all | unlocked | affordable | locked
  String? type;
  int? band; // 1: niv 1-3 · 2: 4-6 · 3: 7-8 · 4: 9-10
  String? equip; // pdc | barre | lest | erg | kb
  String? dur; // short | mid | long
  String? source; // curated | generated | mine

  bool _match(Wod w) {
    if (status == 'unlocked' && !store.unlocked(w)) return false;
    if (status == 'locked' && store.unlocked(w)) return false;
    if (status == 'affordable' && (store.unlocked(w) || store.wodCost(w) > store.credits)) return false;
    if (type != null && w.type != type) return false;
    if (band != null) {
      final l = w.level;
      final ok = band == 1 ? l <= 3 : band == 2 ? (l >= 4 && l <= 6) : band == 3 ? (l >= 7 && l <= 8) : l >= 9;
      if (!ok) return false;
    }
    if (equip != null) {
      final eq = equipmentOf(w);
      if (equip == 'pdc' ? !(eq.length == 1 && eq.contains('pdc')) : !eq.contains(equip)) return false;
    }
    if (dur != null) {
      final m = store.wodStats(w).minutes;
      final ok = dur == 'short' ? m < 15 : dur == 'mid' ? (m >= 15 && m <= 30) : m > 30;
      if (!ok) return false;
    }
    if (source != null) {
      final gen = store.isGenerated(w), cat = store.isCatalog(w);
      final ok = source == 'generated' ? gen : source == 'curated' ? (cat && !gen) : !cat;
      if (!ok) return false;
    }
    if (q.trim().isNotEmpty) {
      final t = q.trim().toLowerCase();
      if (!w.name.toLowerCase().contains(t) && !w.lines.any((l) => l.toLowerCase().contains(t)) && !w.source.toLowerCase().contains(t)) return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final list = store.wods.where(_match).toList()
          ..sort((a, b) {
            final ua = store.unlocked(a) ? 0 : 1, ub = store.unlocked(b) ? 0 : 1;
            if (ua != ub) return ua.compareTo(ub);
            if (a.level != b.level) return a.level.compareTo(b.level);
            return a.name.compareTo(b.name);
          });
        return Scaffold(
          appBar: AppBar(title: Text('CATALOGUE · ${list.length}')),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 6),
                child: TextField(
                  textAlign: TextAlign.left,
                  decoration: InputDecoration(
                    hintText: 'Rechercher un WOD ou un mouvement',
                    prefixIcon: Icon(Icons.search, color: SL.dim),
                    suffixIcon: q.isEmpty ? null : IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => setState(() => q = '')),
                  ),
                  onChanged: (v) => setState(() => q = v),
                ),
              ),
              _FilterRow(children: [
                _chip('Tous', status == 'all', () => status = 'all'),
                _chip('Débloqués', status == 'unlocked', () => status = 'unlocked'),
                _chip('Abordables', status == 'affordable', () => status = 'affordable'),
                _chip('Verrouillés', status == 'locked', () => status = 'locked'),
              ]),
              _FilterRow(children: [
                for (final e in wodTypes.entries) _chip(e.value, type == e.key, () => type = type == e.key ? null : e.key),
              ]),
              _FilterRow(children: [
                _chip('Niv. 1-3', band == 1, () => band = band == 1 ? null : 1),
                _chip('Niv. 4-6', band == 2, () => band = band == 2 ? null : 2),
                _chip('Niv. 7-8', band == 3, () => band = band == 3 ? null : 3),
                _chip('Niv. 9-10', band == 4, () => band = band == 4 ? null : 4),
                _chip('< 15 min', dur == 'short', () => dur = dur == 'short' ? null : 'short'),
                _chip('15-30 min', dur == 'mid', () => dur = dur == 'mid' ? null : 'mid'),
                _chip('> 30 min', dur == 'long', () => dur = dur == 'long' ? null : 'long'),
              ]),
              _FilterRow(children: [
                _chip('Poids de corps', equip == 'pdc', () => equip = equip == 'pdc' ? null : 'pdc'),
                _chip('Barre', equip == 'barre', () => equip = equip == 'barre' ? null : 'barre'),
                _chip('Lest', equip == 'lest', () => equip = equip == 'lest' ? null : 'lest'),
                _chip('Erg', equip == 'erg', () => equip = equip == 'erg' ? null : 'erg'),
                _chip('KB / wall ball', equip == 'kb', () => equip = equip == 'kb' ? null : 'kb'),
                _chip('Sélection', source == 'curated', () => source = source == 'curated' ? null : 'curated'),
                _chip('Générés', source == 'generated', () => source = source == 'generated' ? null : 'generated'),
                _chip('Les miens', source == 'mine', () => source = source == 'mine' ? null : 'mine'),
              ]),
              Expanded(
                child: list.isEmpty
                    ? Center(child: Text('Aucun WOD ne correspond à ces filtres.', style: TextStyle(color: SL.dim)))
                    : ListView.builder(
                        padding: const EdgeInsets.only(top: 4, bottom: 24),
                        itemCount: list.length,
                        itemBuilder: (_, i) => WodTile(key: ValueKey(list[i].id), wod: list[i]),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _chip(String label, bool sel, VoidCallback toggle) => Padding(
        padding: const EdgeInsets.only(right: 6),
        child: ChoiceChip(
          label: Text(label),
          selected: sel,
          showCheckmark: false,
          labelStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: sel ? SL.steel : SL.dim),
          selectedColor: SL.steel.withOpacity(0.18),
          backgroundColor: SL.card,
          side: BorderSide(color: sel ? SL.steel : SL.formBorder),
          onSelected: (_) => setState(toggle),
        ),
      );
}

class _FilterRow extends StatelessWidget {
  final List<Widget> children;
  const _FilterRow({required this.children});
  @override
  Widget build(BuildContext context) => SizedBox(
        height: 40,
        child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: children),
      );
}
