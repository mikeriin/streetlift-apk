// Store global : Pilotage éditable + journal de séances, persistés localement.
// Les calculs de charge reproduisent exactement les formules du classeur v3.3.
import 'dart:async';
import 'dart:convert';
import 'dart:io' show gzip;
import 'dart:math' show max;
import 'dart:ui' show Color;

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';
import 'wod_generator.dart';
import 'wod_models.dart';

class SetEntry {
  String kg;
  String reps;
  String rir;
  String v; // vitesse (VBT), lifts principaux
  bool done;
  SetEntry({this.kg = '', this.reps = '', this.rir = '', this.v = '', this.done = false});

  Map<String, dynamic> toJson() =>
      {'kg': kg, 'reps': reps, 'rir': rir, 'v': v, 'done': done};
  SetEntry.fromJson(Map<String, dynamic> j)
      : kg = j['kg'] as String? ?? '',
        reps = j['reps'] as String? ?? '',
        rir = j['rir'] as String? ?? '',
        v = j['v'] as String? ?? '',
        done = j['done'] as bool? ?? false;
}

class ExerciseLog {
  List<SetEntry> sets;
  String note;
  bool? showKg; // null = règle automatique
  bool? showRir;
  bool? showV;
  ExerciseLog({List<SetEntry>? sets, this.note = '', this.showKg, this.showRir, this.showV})
      : sets = sets ?? [];

  void addSet() => sets.add(SetEntry());
  bool removeLastSet() {
    if (sets.length <= 1 || sets.last.done) return false;
    sets.removeLast();
    return true;
  }

  Map<String, dynamic> toJson() => {
        'sets': sets.map((s) => s.toJson()).toList(),
        'note': note,
        'showKg': showKg,
        'showRir': showRir,
        'showV': showV,
      };
  ExerciseLog.fromJson(Map<String, dynamic> j)
      : sets = ((j['sets'] as List?) ?? [])
            .map((s) => SetEntry.fromJson(s as Map<String, dynamic>))
            .toList(),
        note = j['note'] as String? ?? '',
        showKg = j['showKg'] as bool?,
        showRir = j['showRir'] as bool?,
        showV = j['showV'] as bool?;
}

class SessionLog {
  bool done;
  String? finishedAt; // ISO
  String? title; // libellé lisible (ex. « S8 · J1 » ou nom de séance perso)
  Map<String, ExerciseLog> ex;
  SessionLog(
      {this.done = false, this.finishedAt, this.title, Map<String, ExerciseLog>? ex})
      : ex = ex ?? {};

  Map<String, dynamic> toJson() => {
        'done': done,
        'finishedAt': finishedAt,
        'title': title,
        'ex': ex.map((k, v) => MapEntry(k, v.toJson())),
      };
  SessionLog.fromJson(Map<String, dynamic> j)
      : done = j['done'] as bool? ?? false,
        finishedAt = j['finishedAt'] as String?,
        title = j['title'] as String?,
        ex = ((j['ex'] as Map<String, dynamic>?) ?? {}).map((k, v) =>
            MapEntry(k, ExerciseLog.fromJson(v as Map<String, dynamic>)));
}

// ===================== RÉGLAGES =====================

class AppSettings {
  int defaultRest; // s, appliqué quand l'exercice n'a pas de repos
  bool autoTimer; // lancer le repos à la validation d'une série
  bool sound;
  bool vibration;
  int prepSec; // décompte « prêt » avant EMOM/AMRAP/HIIT
  bool rpe; // afficher RPE au lieu de RIR
  bool lb; // afficher les charges en livres
  bool prefill; // pré-remplir la charge suggérée
  bool wakelock; // écran allumé pendant la séance
  String theme; // system | dark | light
  bool trackRir; // colonne RIR/RPE affichée par défaut
  bool trackVelocity; // colonne vitesse (VBT) affichée par défaut sur les lifts
  bool notifOn; // rappel quotidien de la séance du jour
  int notifHour;
  int notifMinute;
  bool notifSkipRest; // pas de rappel les jours de repos

  AppSettings(
      {this.defaultRest = 90,
      this.autoTimer = true,
      this.sound = true,
      this.vibration = true,
      this.prepSec = 5,
      this.rpe = false,
      this.lb = false,
      this.prefill = true,
      this.wakelock = true,
      this.theme = 'system',
      this.trackRir = false,
      this.trackVelocity = false,
      this.notifOn = false,
      this.notifHour = 7,
      this.notifMinute = 30,
      this.notifSkipRest = true});

  Map<String, dynamic> toJson() => {
        'defaultRest': defaultRest,
        'autoTimer': autoTimer,
        'sound': sound,
        'vibration': vibration,
        'prepSec': prepSec,
        'rpe': rpe,
        'lb': lb,
        'prefill': prefill,
        'wakelock': wakelock,
        'theme': theme,
        'trackRir': trackRir,
        'trackVelocity': trackVelocity,
        'notifOn': notifOn,
        'notifHour': notifHour,
        'notifMinute': notifMinute,
        'notifSkipRest': notifSkipRest,
      };
  AppSettings.fromJson(Map<String, dynamic> j)
      : defaultRest = j['defaultRest'] as int? ?? 90,
        autoTimer = j['autoTimer'] as bool? ?? true,
        sound = j['sound'] as bool? ?? true,
        vibration = j['vibration'] as bool? ?? true,
        prepSec = j['prepSec'] as int? ?? 5,
        rpe = j['rpe'] as bool? ?? false,
        lb = j['lb'] as bool? ?? false,
        prefill = j['prefill'] as bool? ?? true,
        wakelock = j['wakelock'] as bool? ?? true,
        theme = j['theme'] as String? ?? 'system',
        trackRir = j['trackRir'] as bool? ?? false,
        trackVelocity = j['trackVelocity'] as bool? ?? false,
        notifOn = j['notifOn'] as bool? ?? false,
        notifHour = j['notifHour'] as int? ?? 7,
        notifMinute = j['notifMinute'] as int? ?? 30,
        notifSkipRest = j['notifSkipRest'] as bool? ?? true;
}

// ===================== SÉANCES PERSONNALISÉES =====================

/// Modes d'exécution disponibles pour les séances personnalisées.
class ExecMode {
  final String id;
  final String label;
  final String desc;
  final List<String> fields; // paramètres à afficher dans l'éditeur
  const ExecMode(this.id, this.label, this.desc, this.fields);
}

const execModes = <ExecMode>[
  ExecMode('classic', 'Classique', 'Séries × répétitions, repos entre les séries.',
      ['series', 'reps']),
  ExecMode('myo', 'Myo-reps',
      'Série d\u2019activation proche de l\u2019échec, puis mini-séries avec micro-repos.',
      ['actReps', 'miniReps', 'minis', 'intra']),
  ExecMode('cluster', 'Cluster',
      'Chaque série est découpée en mini-blocs séparés de quelques secondes.',
      ['series', 'miniReps', 'minis', 'intra']),
  ExecMode('emom', 'EMOM',
      'Un bloc de travail au top de chaque intervalle (Every Minute On the Minute).',
      ['rounds', 'interval', 'reps']),
  ExecMode('amrap', 'AMRAP',
      'Un maximum de travail dans la durée fixée (As Many Reps As Possible).',
      ['duree']),
  ExecMode('iso', 'Isométrie',
      'Tenues statiques chronométrées (holds, gainage, overcoming iso).',
      ['series', 'hold']),
  ExecMode('hiit', 'Intervalles',
      'Alternance effort/repos chronométrée (HIIT, Tabata).',
      ['rounds', 'work', 'restI']),
  ExecMode('pyramide', 'Pyramide',
      'Répétitions croissantes ou décroissantes, ex. 12-10-8-6.',
      ['pyr']),
];

ExecMode modeById(String id) =>
    execModes.firstWhere((m) => m.id == id, orElse: () => execModes.first);

String _newUid() => DateTime.now().microsecondsSinceEpoch.toRadixString(36);

class CustomExercise {
  String uid; // stable : les logs y restent rattachés même après réordonnancement
  String name;
  String mode; // id ExecMode
  Map<String, dynamic> p; // paramètres du mode
  double? kg;
  int? rest; // s
  String note;
  CustomExercise(
      {String? uid,
      required this.name,
      this.mode = 'classic',
      Map<String, dynamic>? p,
      this.kg,
      this.rest,
      this.note = ''})
      : uid = uid ?? _newUid(),
        p = p ?? {};

  Map<String, dynamic> toJson() => {
        'uid': uid,
        'name': name,
        'mode': mode,
        'p': p,
        'kg': kg,
        'rest': rest,
        'note': note
      };
  CustomExercise.fromJson(Map<String, dynamic> j)
      : uid = j['uid'] as String? ?? _newUid(),
        name = j['name'] as String,
        mode = j['mode'] as String? ?? 'classic',
        p = Map<String, dynamic>.from(j['p'] as Map? ?? {}),
        kg = j['kg'] == null ? null : (j['kg'] as num).toDouble(),
        rest = j['rest'] as int?,
        note = j['note'] as String? ?? '';

  int _pi(String k, int d) => (p[k] as num?)?.toInt() ?? d;
  String _ps(String k, String d) {
    final v = p[k];
    return v is String && v.trim().isNotEmpty ? v : d;
  }

  /// Libellé « Séries × Reps » selon le mode.
  String setsText() {
    switch (mode) {
      case 'myo':
        return '1×${_pi('actReps', 12)} puis ${_pi('minis', 4)}×(${_pi('miniReps', 4)}) · ${_pi('intra', 15)} s intra';
      case 'cluster':
        return '${_pi('series', 4)}×(${_pi('minis', 3)}×${_pi('miniReps', 2)}) · ${_pi('intra', 20)} s intra';
      case 'emom':
        return 'EMOM ${_pi('rounds', 10)}×${_pi('interval', 60)} s · ${_pi('reps', 5)} reps';
      case 'amrap':
        return 'AMRAP ${_pi('duree', 8)} min';
      case 'iso':
        return '${_pi('series', 3)}×${_pi('hold', 30)} s';
      case 'hiit':
        return '${_pi('rounds', 8)}× (${_pi('work', 30)} s effort / ${_pi('restI', 30)} s repos)';
      case 'pyramide':
        return _ps('pyr', '12-10-8-6');
      default:
        return '${_pi('series', 4)}×${_pi('reps', 8)}';
    }
  }

  int forcedSets() {
    switch (mode) {
      case 'myo':
        return 1 + _pi('minis', 4);
      case 'cluster':
        return _pi('series', 4);
      case 'emom':
      case 'amrap':
      case 'hiit':
        return 1;
      case 'iso':
        return _pi('series', 3);
      case 'pyramide':
        return _ps('pyr', '12-10-8-6').split(RegExp(r'[-/ ]+')).length;
      default:
        return _pi('series', 4);
    }
  }

  Map<String, dynamic>? timerSpec() {
    switch (mode) {
      case 'emom':
        return {'type': 'emom', 'rounds': _pi('rounds', 10), 'interval': _pi('interval', 60)};
      case 'amrap':
        return {'type': 'amrap', 'sec': _pi('duree', 8) * 60};
      case 'hiit':
        return {'type': 'hiit', 'rounds': _pi('rounds', 8), 'work': _pi('work', 30), 'rest': _pi('restI', 30)};
      case 'iso':
        return {'type': 'hold', 'sec': _pi('hold', 30)};
      case 'cluster':
        return {'type': 'hold', 'sec': _pi('intra', 20)};
    }
    return null;
  }

  Exercise toExercise(int index) {
    final m = modeById(mode);
    return Exercise.manual(
      id: 'CU-$uid',
      name: name,
      setsText: setsText(),
      intensity: mode == 'classic' ? '' : m.label,
      kg: kg,
      rest: rest == null ? '' : (rest! >= 60 ? '${rest! ~/ 60} min' : '$rest s'),
      restSec: rest,
      cue: note.isEmpty ? m.desc : note,
      forcedSets: forcedSets(),
      timer: timerSpec(),
    );
  }
}

class CustomSession {
  String id; // numérique unique (clé de journal S0-J<id>)
  String name;
  List<CustomExercise> items;
  CustomSession({required this.id, required this.name, List<CustomExercise>? items})
      : items = items ?? [];

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'items': items.map((e) => e.toJson()).toList()};
  CustomSession.fromJson(Map<String, dynamic> j)
      : id = j['id'] as String,
        name = j['name'] as String,
        items = ((j['items'] as List?) ?? [])
            .map((e) => CustomExercise.fromJson(e as Map<String, dynamic>))
            .toList();

  /// Adaptateur vers le runner de séance existant (semaine 0 = perso).
  WeekPlan toWeekPlan() {
    final exs = <Exercise>[];
    for (var i = 0; i < items.length; i++) {
      exs.add(items[i].toExercise(i));
    }
    return WeekPlan.manual(
      n: 0,
      block: name,
      color: const Color(0xFF4FA3C7),
      days: [DayPlan.manual(j: int.parse(id), title: name, exercises: exs)],
    );
  }
}

/// Nature de la saisie d'un exercice, déduite des données.
class LogSpec {
  final String kind; // reps | repsMax | hold | holdMax | duration | interval | emom | amrap
  final int? seconds; // tenue (hold) ou durée totale (duration / emom)
  final int? intra; // micro-repos myo-reps / clusters
  final bool myo;
  final bool cluster;
  final String rowPrefix; // M (myo) · C (cluster) · É (échelle) · R (round) · T (test)
  const LogSpec(this.kind,
      {this.seconds,
      this.intra,
      this.myo = false,
      this.cluster = false,
      this.rowPrefix = ''});
  bool get timed => kind == 'hold' || kind == 'holdMax' || kind == 'duration';
}

class AppStore extends ChangeNotifier {
  late final Program program;
  late final SharedPreferences _prefs;

  /// Valeurs Pilotage éditables : PdC (B4), 1RM (B8-B11), max reps (B16-B20),
  /// charges de référence accessoires (B25-B45).
  final Map<String, double> values = {};

  /// Reps de référence des accessoires (colonne D, non éditable).
  final Map<String, int> refReps = {};

  final Map<String, SessionLog> logs = {};

  /// Incrémenté à chaque reset pour forcer le rafraîchissement des champs.
  int pilotageEpoch = 0;

  AppSettings settings = AppSettings();

  /// Ne change qu'au changement de thème : évite de reconstruire MaterialApp
  /// à chaque notification du store.
  final ValueNotifier<String> themeMode = ValueNotifier<String>('system');
  final List<Map<String, dynamic>> dbExercises = []; // base embarquée
  final List<Map<String, dynamic>> userExercises = []; // ajoutés par l'utilisateur
  final List<CustomSession> customSessions = [];
  final List<Wod> wods = [];

  static const _kPilotage = 'pilotage_v1';
  static const _kLogs = 'logs_v1';
  static const _kSettings = 'settings_v1';
  static const _kCustom = 'custom_sessions_v1';
  static const _kUserEx = 'user_exercises_v1';
  static const _kWodsLegacy = 'wods_v1'; // ancien format (catalogue entier dupliqué)
  static const _kWodsUser = 'wods_user_v2'; // WODs créés par l'utilisateur
  static const _kWodsDel = 'wods_del_v2'; // ids de WODs préchargés supprimés
  static const _kWodsEdit = 'wods_edit_v2'; // id préchargé → définition modifiée
  static const _kWodResults = 'wod_results_v2'; // id → résultats (compressé)
  static const _kSeedV = 'wods_seed_v';
  static const _kLastLevel = 'level_seen';
  static const _kUnlocked = 'unlocked_wods_v1';
  static const _kCreditsV = 'credits_v';

  /// WODs déverrouillés : id → crédits payés (0 = offert par la migration).
  final Map<String, int> unlockedWods = {};

  Future<void> init() async {
    program = Program.fromJson(jsonDecode(await _loadGz('assets/programme_v33.json.gz')) as Map<String, dynamic>);
    _prefs = await SharedPreferences.getInstance();

    // Défauts depuis le JSON du classeur.
    final p = program.pilotage;
    values['B4'] = p.bodyweight;
    for (final l in p.mainLifts) {
      values[l.ref] = l.oneRm;
    }
    for (final m in p.repMax) {
      values[m.ref] = m.max;
    }
    for (final a in p.accessories) {
      values[a.ref] = a.refLoad;
      refReps[a.ref] = a.refReps;
    }

    // Écrase avec les valeurs sauvegardées.
    final sp = _prefs.getString(_kPilotage);
    if (sp != null) {
      final m = jsonDecode(sp) as Map<String, dynamic>;
      m.forEach((k, v) => values[k] = (v as num).toDouble());
    }
    final sl = _unpack(_prefs.getString(_kLogs));
    if (sl != null) {
      final m = jsonDecode(sl) as Map<String, dynamic>;
      m.forEach((k, v) =>
          logs[k] = SessionLog.fromJson(v as Map<String, dynamic>));
    }

    // Base d'exercices embarquée (gzip) + exercices utilisateur.
    for (final e in jsonDecode(await _loadGz('assets/exercises_db.json.gz')) as List) {
      dbExercises.add(Map<String, dynamic>.from(e as Map));
    }
    final su = _prefs.getString(_kUserEx);
    if (su != null) {
      for (final e in jsonDecode(su) as List) {
        userExercises.add(Map<String, dynamic>.from(e as Map));
      }
    }
    final ss = _prefs.getString(_kSettings);
    if (ss != null) {
      settings = AppSettings.fromJson(jsonDecode(ss) as Map<String, dynamic>);
    }
    themeMode.value = settings.theme;
    final sc = _prefs.getString(_kCustom);
    if (sc != null) {
      for (final e in jsonDecode(sc) as List) {
        customSessions.add(CustomSession.fromJson(e as Map<String, dynamic>));
      }
    }
    _loadWods();
    _lastLevel = _prefs.getInt(_kLastLevel) ?? level;
    final su2 = _prefs.getString(_kUnlocked);
    if (su2 != null) {
      (jsonDecode(su2) as Map<String, dynamic>).forEach((k, v) => unlockedWods[k] = (v as num).toInt());
    }
    if ((_prefs.getInt(_kCreditsV) ?? 0) < 2) {
      // v2 : tous les WODs préchargés se gagnent — les accès offerts par l'ancienne
      // migration sont retirés (les déverrouillages payés en crédits sont conservés).
      unlockedWods.removeWhere((k, v) => v == 0);
      _prefs.setInt(_kCreditsV, 2);
      _saveUnlocked();
    }
  }

  // ---------- Crédits de déverrouillage ----------
  void _saveUnlocked() => _prefs.setString(_kUnlocked, jsonEncode(unlockedWods));

  /// Coût d'un WOD : niveaux 1-3 → 1 crédit, 4-6 → 2, 7-10 → 3. Tous les WODs
  /// préchargés se débloquent ; seuls ceux créés par l'utilisateur sont libres.
  /// Coût selon le niveau (déciles) : 1-3 → 1 crédit, 4-6 → 2, 7-8 → 3, 9-10 → 4.
  int wodCost(Wod w) {
    if (w.id.startsWith('w')) return 0;
    if (w.level <= 3) return 1;
    if (w.level <= 6) return 2;
    if (w.level <= 8) return 3;
    return 4;
  }

  /// 1 crédit de départ + 1 par niveau gagné, +1 bonus aux niveaux 5 et 10.
  int creditsForLevel(int l) => l + (l >= 5 ? 1 : 0) + (l >= 10 ? 1 : 0);
  int get creditsEarned => creditsForLevel(level);
  int get creditsSpent => unlockedWods.values.fold(0, (a, b) => a + b);
  int get credits => creditsEarned - creditsSpent;

  bool unlockWod(Wod w) {
    if (unlocked(w)) return true;
    final c = wodCost(w);
    if (credits < c) return false;
    unlockedWods[w.id] = c;
    _saveUnlocked();
    notifyListeners();
    return true;
  }

  // ---------- Aperçu d'un WOD : volume, charge de travail, muscles ----------
  static final _splitRe = RegExp(r'\s*(?:\+|·|,|/| et )\s*');
  static final _partRe = RegExp(r'''^(\d+(?:[.,]\d+)?)\s*(km|m|min|s|"|'|″|′)?(?![A-Za-zÀ-ÿ])\s*(.*)$''');
  static final _ladderRe = RegExp(r'^(\d+(?:-\d+){2,})\s+(.*)$');

  /// Volume total d'une ligne (reps et mètres) et charge, hors multiplicateur de rounds.
  List<({int reps, int meters, String text})> _parseLine(Wod w, String line) {
    final out = <({int reps, int meters, String text})>[];
    final lad = _ladderRe.firstMatch(line.trim());
    if (lad != null) {
      final sum = lad.group(1)!.split('-').map(int.parse).fold(0, (a, b) => a + b);
      out.add((reps: sum, meters: 0, text: lad.group(2)!));
      return out;
    }
    var any = false;
    for (final raw in line.split(_splitRe)) {
      final part = raw.trim();
      if (part.isEmpty) continue;
      final m = _partRe.firstMatch(part);
      if (m == null) continue;
      any = true;
      final n = double.parse(m.group(1)!.replaceAll(',', '.'));
      final unit = m.group(2);
      final text = m.group(3) ?? '';
      if (unit == 'm') {
        out.add((reps: 0, meters: n.round(), text: text.isEmpty ? 'run' : text));
      } else if (unit == 'km') {
        out.add((reps: 0, meters: (n * 1000).round(), text: text.isEmpty ? 'run' : text));
      } else if (unit != null && unit != 'm' && unit != 'km') {
        continue; // durée (min, s, ″, ′), pas un volume
      } else if (RegExp(r'^(rest|repos)').hasMatch(text.toLowerCase())) {
        continue;
      } else {
        out.add((reps: n.round(), meters: 0, text: text));
      }
    }
    if (!any && RegExp(r'\bmax\b').hasMatch(line.toLowerCase())) {
      out.add((reps: 15, meters: 0, text: line.replaceAll(RegExp(r'(?i)max( de)?'), '').trim()));
      any = true;
    }
    if (!any && w.scheme.isNotEmpty) {
      // schéma type « 21-15-9 » ou « 1-2-3-…-15 » appliqué à chaque ligne-mouvement
      final nums = RegExp(r'\d+').allMatches(w.scheme).map((m) => int.parse(m.group(0)!)).toList();
      var sum = 0;
      if (w.scheme.contains('…') && nums.length >= 2) {
        final a = nums.first, b = nums.last;
        for (var i = a; i <= b; i++) {
          sum += i;
        }
      } else {
        sum = nums.fold(0, (x, y) => x + y);
      }
      if (sum > 0) out.add((reps: sum, meters: 0, text: line));
    }
    return out;
  }

  int _roundsOf(Wod w) => (w.type == 'rounds' || w.type == 'emom') && w.rounds > 0 ? w.rounds : 1;

  // ---------- Charge de travail : modèle de points ----------
  // Points par répétition selon le type de mouvement (poids de corps, barre,
  // skills, implements), majorés par le lest, l'enchaînement de mouvements qui
  // sollicitent la même chaîne, les contraintes (unbroken), le format (rounds,
  // repos, AMRAP, EMOM) et les distances. Seul le total est affiché.
  static const _moves = <(String, double, String, bool)>[
    // (motif, points par rep ou par 100 m, catégorie, poids de corps)
    (r'muscle.?up', 4.5, 'pull', true),
    (r'hspu|handstand', 3.2, 'push', true),
    (r'wall walk', 3.5, 'push', true),
    (r'dragon', 3.0, 'core', true),
    (r'pistol', 2.2, 'legs', true),
    (r'front lever|planche', 5.0, 'pull', true),
    (r'burpee.{0,12}(box|over|broad|plate)', 2.2, 'meta', true),
    (r'devil press', 2.5, 'meta', false),
    (r'burpee', 1.7, 'meta', true),
    (r'snatch|clean|thruster', 2.0, 'meta', false),
    (r'toes.?to.?bar|t2b', 1.5, 'core', true),
    (r'rows? barre|ring row|row(s)? aux anneaux', 0.9, 'pull', true),
    (r'pull.?up|chin.?up|traction', 1.7, 'pull', true),
    (r'\bdip', 1.4, 'push', true),
    (r'archer|diamond|pike|d[ée]clin', 1.3, 'push', true),
    (r'push.?up|pompe', 1.0, 'push', true),
    (r'wall.?ball', 1.1, 'meta', false),
    (r'kettlebell|kb swing|swing', 0.9, 'meta', false),
    (r'goblet', 1.0, 'legs', false),
    (r'sandbag lunge', 1.2, 'legs', false),
    (r'box jump|squat jump|jumping lunge|saut', 0.9, 'legs', true),
    (r'lunge|fente|step.?up|step.?over', 0.5, 'legs', true),
    (r'squat', 0.5, 'legs', true),
    (r'double.?under', 0.25, 'meta', true),
    (r'mountain climber|jumping jack|plank|shoulder tap', 0.4, 'core', true),
    (r'sit.?up|v.?up|hollow|leg raise|crunch|abdo', 0.5, 'core', true),
    (r'farmer|carry', 12.0, 'carry', false),
    (r'\bcal\b', 1.0, 'erg', false),
    (r'\brun\b|course|sprint|footing', 7.5, 'erg', true),
    (r'\brow\b|rameur', 6.0, 'erg', false),
    (r'ski', 6.0, 'erg', false),
    (r'bike|erg\b|v[ée]lo', 2.0, 'erg', false),
  ];

  /// Secondes par répétition (ou par 100 m) — durée estimée et rounds d'AMRAP.
  static const _secs = <(String, double)>[
    (r'muscle.?up|front lever|planche', 5.0),
    (r'hspu|handstand|wall walk|dragon', 4.0),
    (r'burpee|devil', 4.0),
    (r'pull.?up|chin.?up|traction|toes|t2b|pistol', 3.0),
    (r'wall.?ball|snatch|clean|thruster', 3.0),
    (r'\bdip|archer|diamond|pike|goblet|sandbag', 2.5),
    (r'push.?up|pompe|box jump|squat jump|jumping|swing|kettlebell', 2.0),
    (r'double.?under', 0.5),
    (r'\bcal\b', 4.0),
    (r'farmer|carry', 40.0),
    (r'\brun\b|course|sprint|footing|\brow\b|rameur|ski', 25.0),
    (r'bike|erg\b|v[ée]lo', 12.0),
  ];

  /// (points par unité, catégorie, poids de corps) pour un texte de mouvement.
  (double, String, bool) _movePoints(String text) {
    final l = text.toLowerCase();
    for (final (re, pts, cat, bw) in _moves) {
      if (RegExp(re).hasMatch(l)) return (pts, cat, bw);
    }
    return (0.8, 'meta', true);
  }

  double _moveSeconds(String text) {
    final l = text.toLowerCase();
    for (final (re, sec) in _secs) {
      if (RegExp(re).hasMatch(l)) return sec;
    }
    return 1.5; // squats, fentes, sit-ups, gainage…
  }

  static final _multRe = RegExp(r'^\s*(\d+)\s*[×x]\s*\(');

  double _lineSeconds(Wod w, String line) {
    var t = 0.0;
    for (final p in _parseLine(w, line)) {
      final sec = _moveSeconds(p.text);
      t += p.meters > 0 ? p.meters / 100 * (sec >= 12 ? sec : 25) : p.reps * sec;
    }
    final mult = _multRe.firstMatch(line);
    if (mult != null) t *= int.parse(mult.group(1)!);
    return t + 5; // transition
  }

  /// Points d'une ligne (un round) : lest, enchaînement, contraintes, multiplicateur « 3 × (…) ».
  double _linePoints(Wod w, String line, String? prevCat, void Function(String) setPrevCat) {
    var total = 0.0;
    final parts = _parseLine(w, line);
    var cat = prevCat;
    for (final p in parts) {
      final (pts, category, bw) = _movePoints(p.text);
      var v = p.meters > 0 ? p.meters / 100 * pts : p.reps * pts;
      if (p.meters > 0 && category != 'erg' && category != 'carry') v = p.meters / 20 * pts; // burpees broad jump, fentes en mètres
      final kg = RegExp(r'(\d+(?:[.,]\d+)?)\s*kg').firstMatch(p.text.toLowerCase());
      if (kg != null && bw) v *= 1 + double.parse(kg.group(1)!.replaceAll(',', '.')) / 40; // lest sur un mouvement au poids de corps
      if (cat != null && cat == category && category != 'erg') v *= 1.15; // même chaîne enchaînée
      cat = category;
      total += v;
    }
    if (parts.length >= 3) total *= 1.10; // complexe enchaîné sans pause
    if (RegExp(r'unbroken|sans pause|enchaîn').hasMatch(line.toLowerCase())) total *= 1.2;
    final mult = _multRe.firstMatch(line);
    if (mult != null) total *= int.parse(mult.group(1)!);
    setPrevCat(cat ?? '');
    return total;
  }

  ({int points, int minutes, String level}) wodStats(Wod w) {
    final cached = _statsCache[w.id];
    if (cached != null && !w.id.startsWith('w')) return cached;
    final st = _computeStats(w);
    if (!w.id.startsWith('w')) _statsCache[w.id] = st;
    return st;
  }

  ({int points, int minutes, String level}) _computeStats(Wod w) {
    String? prev;
    final perLine = <double>[];
    var roundSec = 0.0;
    for (final line in w.lines) {
      perLine.add(_linePoints(w, line, prev, (c) => prev = c.isEmpty ? null : c));
      roundSec += _lineSeconds(w, line);
    }
    final roundPts = perLine.fold(0.0, (a, b) => a + b);
    double total;
    int minutes;
    if (w.type == 'amrap') {
      final rounds = max(1.0, w.minutes * 60 / max(20.0, roundSec + 10));
      total = roundPts * rounds * 1.1;
      minutes = w.minutes;
    } else if (w.type == 'emom') {
      final ranged = <double>[];
      var anyRange = false, rotation = false;
      for (var i = 0; i < w.lines.length; i++) {
        final l = w.lines[i].toLowerCase();
        final m = RegExp(r'min\s*(\d+)\s*-\s*(\d+)').firstMatch(l);
        if (m != null) {
          anyRange = true;
          ranged.add(perLine[i] * (int.parse(m.group(2)!) - int.parse(m.group(1)!) + 1));
        } else {
          if (RegExp(r'^min\s*\d+\s*,').hasMatch(l) || l.contains('altern')) rotation = true;
          ranged.add(perLine[i]);
        }
      }
      if (anyRange) {
        total = ranged.fold(0.0, (a, b) => a + b);
      } else if (rotation) {
        total = roundPts * (w.rounds / w.lines.length.clamp(1, 99));
      } else {
        total = roundPts * w.rounds; // tout à chaque intervalle
      }
      total *= 1.15; // horloge fixe, aucun repos choisi
      minutes = ((w.rounds * w.interval) / 60).round();
    } else {
      final r = (w.type == 'rounds' && w.rounds > 0) ? w.rounds : 1;
      total = roundPts * r * (w.scheme.isNotEmpty ? 1.1 : 1.0);
      if (r > 1) total *= w.restSec == 0 ? 1.08 : (w.restSec >= 90 ? 0.95 : 1.0);
      minutes = ((roundSec * r + (r - 1) * w.restSec) / 60).round().clamp(1, 240);
      if (w.minutes > 0 && minutes > w.minutes) minutes = w.minutes;
    }
    final pts = total.round();
    final lvl = pts < 200
        ? 'Légère'
        : pts < 400
            ? 'Modérée'
            : pts < 700
                ? 'Élevée'
                : 'Très élevée';
    return (points: pts, minutes: minutes, level: lvl);
  }

  /// Sollicitation musculaire d'un WOD (mêmes clés que la carte hebdomadaire).
  Map<String, double> wodMuscles(Wod w) {
    final out = <String, double>{for (final g in muscleGroups) g: 0};
    final r = _roundsOf(w).toDouble();
    for (final line in w.lines) {
      for (final p in _parseLine(w, line)) {
        final gs = groupsFor(p.text);
        final vol = (p.reps + p.meters / 20).toDouble() * r;
        for (var i = 0; i < gs.length; i++) {
          out[gs[i]] = (out[gs[i]] ?? 0) + vol * (i == 0 ? 1.0 : 0.6);
        }
      }
    }
    return out;
  }

  // ---------- Progression (XP, niveaux, déverrouillage) ----------
  int _lastLevel = 1;

  /// XP dérivée des données (rien à synchroniser) : séance programme 100,
  /// séance perso 60, score de WOD 80, record personnel +40.
  int get xp {
    var x = 0;
    for (final e in logs.entries) {
      if (!e.value.done) continue;
      x += e.key.startsWith('S0-') ? 60 : 100;
    }
    for (final w in wods) {
      final best = w.best();
      for (final r in w.results) {
        x += 80;
        if (identical(r, best)) x += 40;
      }
    }
    return x;
  }

  /// XP nécessaire pour passer du niveau l au niveau l+1 (150, 200, 250…).
  static int needFor(int l) => 150 + 50 * (l - 1);

  int get level {
    var lvl = 1;
    var acc = 0;
    while (xp >= acc + needFor(lvl)) {
      acc += needFor(lvl);
      lvl++;
    }
    return lvl;
  }

  /// XP déjà acquise dans le niveau courant, et XP requise pour le suivant.
  ({int inLevel, int need}) get levelProgress {
    var lvl = 1;
    var acc = 0;
    final x = xp;
    while (x >= acc + needFor(lvl)) {
      acc += needFor(lvl);
      lvl++;
    }
    return (inLevel: x - acc, need: needFor(lvl));
  }

  bool unlocked(Wod w) => wodCost(w) == 0 || unlockedWods.containsKey(w.id);

  /// Si le niveau a monté depuis la dernière vérification : (ancien, nouveau,
  /// crédits gagnés), sinon null. À appeler après une séance ou un score.
  ({int from, int to, int credits})? consumeLevelUp() {
    final now = level;
    if (now <= _lastLevel) return null;
    final from = _lastLevel;
    _lastLevel = now;
    _prefs.setInt(_kLastLevel, now);
    return (from: from, to: now, credits: creditsForLevel(now) - creditsForLevel(from));
  }

  // ---------- WODs ----------
  // Le catalogue préchargé vit dans le code ; on ne persiste que les WODs créés,
  // les suppressions, les modifications d'un préchargé et les résultats.
  /// Catalogue complet : sélection (préchargés) + WODs générés, jusqu'à 500.
  List<Wod> catalogWods() {
    final seeds = allSeedWods();
    return [...seeds, ...generateWods(generatedCount(seeds.length))];
  }

  late final Map<String, Wod> _seedDefaults = {for (final w in catalogWods()) w.id: w};

  /// Définition comparable (sans résultats ni niveau, qui est recalculé).
  static String _defJson(Wod w) {
    final j = w.toJson()..remove('results')..remove('level');
    return jsonEncode(j);
  }

  bool isCatalog(Wod w) => _seedDefaults.containsKey(w.id);
  bool isGenerated(Wod w) => w.id.startsWith('gen');

  void _loadWods() {
    wods.clear();
    final legacy = _prefs.getString(_kWodsLegacy);
    if (legacy != null) {
      _migrateLegacyWods(legacy);
      _prefs.remove(_kWodsLegacy);
    }
    final deleted = ((jsonDecode(_prefs.getString(_kWodsDel) ?? '[]') as List).map((e) => e.toString())).toSet();
    final edits = jsonDecode(_prefs.getString(_kWodsEdit) ?? '{}') as Map<String, dynamic>;
    final results = jsonDecode(_unpack(_prefs.getString(_kWodResults)) ?? '{}') as Map<String, dynamic>;
    for (final seed in _seedDefaults.values) {
      if (deleted.contains(seed.id)) continue;
      final w = edits.containsKey(seed.id) ? Wod.fromJson(edits[seed.id] as Map<String, dynamic>) : Wod.fromJson(seed.toJson());
      w.results = _resultsOf(results, w.id);
      wods.add(w);
    }
    for (final e in jsonDecode(_prefs.getString(_kWodsUser) ?? '[]') as List) {
      final w = Wod.fromJson(e as Map<String, dynamic>);
      w.results = _resultsOf(results, w.id);
      wods.insert(0, w);
    }
    _prefs.setInt(_kSeedV, 4);
    _rankDifficulty();
  }

  // ---------- Difficulté automatique (déciles du catalogue) ----------
  List<double> _levelCuts = const [];
  final Map<String, ({int points, int minutes, String level})> _statsCache = {};

  double difficultyScore(Wod w) => wodStats(w).points.toDouble();

  /// Classe tout le catalogue par déciles de score → niveau 1-10, et applique le
  /// même barème aux WODs de l'utilisateur.
  void _rankDifficulty() {
    final scores = [for (final w in wods) if (isCatalog(w)) difficultyScore(w)]..sort();
    if (scores.length >= 10) {
      _levelCuts = [for (var k = 1; k < 10; k++) scores[(scores.length * k / 10).floor()]];
    }
    for (final w in wods) {
      w.level = levelFor(w);
    }
  }

  int levelFor(Wod w) {
    if (_levelCuts.isEmpty) return w.level;
    final sc = difficultyScore(w);
    var lvl = 1;
    for (final c in _levelCuts) {
      if (sc >= c) lvl++;
    }
    return lvl.clamp(1, 10);
  }

  List<WodResult> _resultsOf(Map<String, dynamic> all, String id) =>
      ((all[id] as List?) ?? []).map((r) => WodResult.fromJson(r as Map<String, dynamic>)).toList();

  /// Ancien format : liste complète (catalogue + perso + résultats) → nouveau format.
  void _migrateLegacyWods(String raw) {
    final old = (jsonDecode(raw) as List).map((e) => Wod.fromJson(e as Map<String, dynamic>)).toList();
    final present = old.map((w) => w.id).toSet();
    final known = [for (var k = 1; k <= 30; k++) 'seed$k']; // fournées 1 et 2 uniquement
    final deleted = [for (final id in known) if (!present.contains(id)) id];
    final user = <Map<String, dynamic>>[];
    final edits = <String, dynamic>{};
    final results = <String, dynamic>{};
    for (final w in old) {
      if (w.results.isNotEmpty) results[w.id] = w.results.map((r) => r.toJson()).toList();
      final seed = _seedDefaults[w.id];
      if (seed == null) {
        user.add(w.toJson()..remove('results'));
      } else {
        if (w.level == 1 && seed.level != 1) w.level = seed.level; // niveaux de la fournée 2
        if (_defJson(w) != _defJson(seed)) edits[w.id] = w.toJson()..remove('results');
      }
    }
    _prefs.setString(_kWodsDel, jsonEncode(deleted));
    _prefs.setString(_kWodsEdit, jsonEncode(edits));
    _prefs.setString(_kWodsUser, jsonEncode(user));
    _prefs.setString(_kWodResults, _pack(jsonEncode(results)));
  }

  void _saveWods() {
    final user = <Map<String, dynamic>>[];
    final edits = <String, dynamic>{};
    final present = wods.map((w) => w.id).toSet();
    for (final w in wods) {
      final seed = _seedDefaults[w.id];
      if (seed == null) {
        user.add(w.toJson()..remove('results'));
      } else if (_defJson(w) != _defJson(seed)) {
        edits[w.id] = w.toJson()..remove('results');
      }
    }
    final deleted = [for (final id in _seedDefaults.keys) if (!present.contains(id)) id];
    _prefs.setString(_kWodsUser, jsonEncode(user));
    _prefs.setString(_kWodsEdit, jsonEncode(edits));
    _prefs.setString(_kWodsDel, jsonEncode(deleted));
    _saveWodResults();
    notifyListeners();
  }

  void _saveWodResults() {
    final results = <String, dynamic>{
      for (final w in wods) if (w.results.isNotEmpty) w.id: w.results.map((r) => r.toJson()).toList()
    };
    _prefs.setString(_kWodResults, _pack(jsonEncode(results)));
  }

  // ---------- Compression des gros blobs (gzip + base64) ----------
  static String _pack(String s) => s.length < 1500 ? s : 'gz:${base64Encode(gzip.encode(utf8.encode(s)))}';
  static String? _unpack(String? s) {
    if (s == null) return null;
    if (!s.startsWith('gz:')) return s;
    return utf8.decode(gzip.decode(base64Decode(s.substring(3))));
  }

  static Future<String> _loadGz(String asset) async {
    final data = await rootBundle.load(asset);
    return utf8.decode(gzip.decode(data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes)));
  }

  String newWodId() => 'w${DateTime.now().millisecondsSinceEpoch}';

  void upsertWod(Wod w) {
    _statsCache.remove(w.id);
    final i = wods.indexWhere((x) => x.id == w.id);
    if (i >= 0) {
      wods[i] = w;
    } else {
      wods.insert(0, w);
    }
    w.level = levelFor(w);
    _saveWods();
  }

  void deleteWod(Wod w) {
    wods.removeWhere((x) => x.id == w.id);
    _saveWods();
  }

  void duplicateWod(Wod w) {
    final c = Wod.fromJson(w.toJson());
    c.id = newWodId();
    c.name = '${w.name} (copie)';
    c.results = [];
    wods.insert(0, c);
    _saveWods();
  }

  void addWodResult(Wod w, WodResult r) {
    w.results.add(r);
    _saveWodResults();
    notifyListeners();
  }

  void deleteWodResult(Wod w, WodResult r) {
    w.results.remove(r);
    _saveWodResults();
    notifyListeners();
  }

  // ---------- Réglages ----------
  void saveSettings() {
    _prefs.setString(_kSettings, jsonEncode(settings.toJson()));
    if (themeMode.value != settings.theme) themeMode.value = settings.theme;
    notifyListeners();
  }

  String get effortLabel => settings.rpe ? 'RPE' : 'RIR';

  // ---------- Base d'exercices ----------
  List<Map<String, dynamic>>? _allEx;
  List<Map<String, dynamic>> get allExercises => _allEx ??= [...dbExercises, ...userExercises];

  void addUserExercise(String name, String group, String equip) {
    userExercises.add({'n': name, 'g': group, 'eq': equip});
    _allEx = null;
    _prefs.setString(_kUserEx, jsonEncode(userExercises));
    notifyListeners();
  }

  // ---------- Séances personnalisées ----------
  void _saveCustom() {
    _prefs.setString(
        _kCustom, jsonEncode(customSessions.map((s) => s.toJson()).toList()));
    notifyListeners();
  }

  String newSessionId() =>
      (DateTime.now().millisecondsSinceEpoch % 1000000000).toString();

  void upsertSession(CustomSession s) {
    final i = customSessions.indexWhere((x) => x.id == s.id);
    if (i >= 0) {
      customSessions[i] = s;
    } else {
      customSessions.add(s);
    }
    _saveCustom();
  }

  void deleteSession(CustomSession s) {
    customSessions.removeWhere((x) => x.id == s.id);
    logs.remove('S0-J${s.id}');
    _saveCustom();
    saveLogs(immediate: true);
  }

  void duplicateSession(CustomSession s) {
    final copy = CustomSession.fromJson(s.toJson());
    copy.id = newSessionId();
    copy.name = '${s.name} (copie)';
    customSessions.add(copy);
    _saveCustom();
  }

  // ---------- Export / import ----------
  String exportAll() => jsonEncode({
        'kalisTrack': 1,
        'pilotage': values,
        'logs': logs.map((k, v) => MapEntry(k, v.toJson())),
        'settings': settings.toJson(),
        'custom': customSessions.map((s) => s.toJson()).toList(),
        'userExercises': userExercises,
        'wods': wods.map((w) => w.toJson()).toList(),
        'unlocked': unlockedWods,
        'format': 2,
      });

  bool importAll(String raw) {
    try {
      final m = jsonDecode(raw) as Map<String, dynamic>;
      if (m['kalisTrack'] != 1) return false;
      (m['pilotage'] as Map<String, dynamic>)
          .forEach((k, v) => values[k] = (v as num).toDouble());
      logs.clear();
      (m['logs'] as Map<String, dynamic>).forEach(
          (k, v) => logs[k] = SessionLog.fromJson(v as Map<String, dynamic>));
      settings = AppSettings.fromJson(m['settings'] as Map<String, dynamic>);
      customSessions
        ..clear()
        ..addAll(((m['custom'] as List?) ?? [])
            .map((e) => CustomSession.fromJson(e as Map<String, dynamic>)));
      userExercises
        ..clear()
        ..addAll(((m['userExercises'] as List?) ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map)));
      if (m['wods'] != null) {
        wods
          ..clear()
          ..addAll((m['wods'] as List)
              .map((e) => Wod.fromJson(e as Map<String, dynamic>)));
        _rankDifficulty();
        _saveWods();
      }
      if (m['unlocked'] != null) {
        unlockedWods.clear();
        (m['unlocked'] as Map<String, dynamic>).forEach((k, v) => unlockedWods[k] = (v as num).toInt());
        _saveUnlocked();
      }
      _prefs.setString(_kPilotage, jsonEncode(values));
      _prefs.setString(_kUserEx, jsonEncode(userExercises));
      saveSettings();
      _saveCustom();
      saveLogs(immediate: true);
      return true;
    } catch (_) {
      return false;
    }
  }

  // ---------- Pilotage ----------
  void setValue(String ref, double v) {
    values[ref] = v;
    _prefs.setString(_kPilotage, jsonEncode(values));
    notifyListeners();
  }

  void resetPilotage() {
    pilotageEpoch++;
    final p = program.pilotage;
    values['B4'] = p.bodyweight;
    for (final l in p.mainLifts) {
      values[l.ref] = l.oneRm;
    }
    for (final m in p.repMax) {
      values[m.ref] = m.max;
    }
    for (final a in p.accessories) {
      values[a.ref] = a.refLoad;
    }
    _prefs.setString(_kPilotage, jsonEncode(values));
    notifyListeners();
  }

  // ---------- Calculs (répliques des formules Excel) ----------
  double _round(double x, double step) => (x / step).round() * step;

  /// Charge suggérée en kg, ou null si non applicable.
  double? loadFor(Exercise e) {
    final s = e.load;
    switch (s.type) {
      case 'fixed':
        return s.kg;
      case 'system':
        final pdc = values['B4']!;
        final rm = values[s.ref!] ?? 0;
        final raw = (pdc + rm) * s.pct! - pdc;
        final r = _round(raw, 2.5);
        return r < 0 ? 0.0 : r;
      case 'barbell':
        return _round(values['B11']! * s.pct!, 2.5);
      case 'acc':
        final ref = values[s.ref!] ?? 0;
        final rr = refReps[s.ref!] ?? 10;
        final raw = ref * (1 + (rr + 2) / 30) / (1 + (s.dayReps! + 2) / 30);
        return _round(raw, s.step!);
      default:
        return null;
    }
  }

  String loadLabel(Exercise e) {
    final kg = loadFor(e);
    if (kg == null) return '—';
    if (kg <= 0) return 'PdC';
    if (settings.lb) {
      final lb = kg * 2.20462;
      return '${lb.toStringAsFixed(lb == lb.roundToDouble() ? 0 : 1)}\u00A0lb';
    }
    final t = kg == kg.roundToDouble()
        ? kg.toInt().toString()
        : kg.toStringAsFixed(1).replaceAll('.', ',');
    return '$t\u00A0kg';
  }

  /// Rendu de la colonne « Séries × Reps » (les volumes suivent tes maxima).
  String setsLabel(Exercise e) {
    final s = e.sets;
    if (s.type == 'volume') {
      final ref = values[s.ref!] ?? 0;
      final n = (s.coef! * ref / s.div!).round();
      return '${s.prefix}$n${s.suffix}';
    }
    return s.value ?? '';
  }

  /// Nombre de lignes de séries à afficher dans le logger.
  int setCount(Exercise e) {
    if (e.forcedSets != null) return e.forcedSets!;
    final txt = setsLabel(e);
    final low = txt.toLowerCase().trim();
    if (e.interval != null) return 1;
    if (low.startsWith('emom')) return 1;
    if (RegExp(r'^(\d+)(?:-(\d+))?\s*min$').hasMatch(low)) return 1;
    final myo = RegExp(r'puis\s*(\d+)\s*[×x]').firstMatch(txt);
    if (myo != null) return 1 + int.parse(myo.group(1)!);
    if (low.contains('montée')) return 6; // 3 paliers de montée + 3 tentatives
    final lead =
        RegExp(r'^(\d+)\s*(?:[×x]|rounds?|échelles?)').firstMatch(low);
    if (lead != null) return int.parse(lead.group(1)!);
    return 1;
  }

  // ---------- Affichage ----------
  /// Titre court + sous-titre : « POMPES PDC — SÉRIES LONGUES — ENCHAÎNÉ… »
  /// → (« Pompes PdC », « séries longues · enchaîné après les dips »).
  (String, String) splitName(String name) {
    final parts = name.split(RegExp(r'\s+—\s+'));
    final title = parts.first.trim();
    final rest = parts.skip(1).map((p) => p.trim()).where((p) => p.isNotEmpty).join(' · ');
    return (title, rest);
  }

  /// Colonne kg : lestable (charge suggérée > 0 ou « lesté » dans le nom)
  /// ou déjà renseignée, sauf préférence explicite de l'exercice.
  bool showKgFor(Exercise e, ExerciseLog log) {
    if (log.showKg != null) return log.showKg!;
    if (log.sets.any((s) => s.kg.trim().isNotEmpty)) return true;
    final kg = loadFor(e);
    if (kg != null && kg > 0) return true;
    return e.name.toLowerCase().contains('lest');
  }

  bool showRirFor(ExerciseLog log) =>
      log.showRir ?? (settings.trackRir || log.sets.any((s) => s.rir.trim().isNotEmpty));

  bool showVFor(Exercise e, ExerciseLog log) =>
      log.showV ?? ((settings.trackVelocity && e.main) || log.sets.any((s) => s.v.trim().isNotEmpty));

  /// Dernière performance loggée pour le même exercice (même jour, semaine
  /// précédente ayant un journal) — programme uniquement.
  ({int week, ExerciseLog log})? previousLog(int week, int j, Exercise e) {
    if (week <= 1 || week > program.weeks.length) return null;
    final title = splitName(e.name).$1.toLowerCase();
    for (var w = week - 1; w >= 1; w--) {
      final sl = logs[sessionKey(w, j)];
      if (sl == null) continue;
      final day = program.week(w).day(j);
      if (day == null) continue;
      for (final px in day.exercises) {
        if (splitName(px.name).$1.toLowerCase() != title) continue;
        final l = sl.ex[px.id];
        if (l != null && l.sets.any((s) => s.done)) return (week: w, log: l);
      }
    }
    return null;
  }

  /// Résumé compact d'un journal : « 10 kg × 3 · 3 · 3 » ou « 39 · 37 · 35 ».
  String summarize(ExerciseLog l, {bool kg = true}) {
    final done = l.sets.where((s) => s.done).toList();
    if (done.isEmpty) return '';
    final kgs = done.map((s) => s.kg.trim()).where((k) => k.isNotEmpty).toSet();
    final reps = done.map((s) => s.reps.trim().isEmpty ? '–' : s.reps.trim()).join(' · ');
    if (kg && kgs.length == 1) return '${kgs.first}\u00A0kg × $reps';
    if (kg && kgs.length > 1) {
      return done.map((s) => '${s.kg.trim().isEmpty ? 'PdC' : '${s.kg.trim()}\u00A0kg'}×${s.reps.trim()}').join(' · ');
    }
    return reps;
  }

  // ---------- Groupes musculaires ----------
  static final List<(RegExp, List<String>)> _kw = [
    (RegExp(r'muscle.?up'), ['dos', 'pectoraux', 'triceps']),
    (RegExp(r'traction|pull.?up|chin.?up|row|tirage|face pull|dead.?hang|scapul|lat'), ['dos', 'biceps']),
    (RegExp(r'\bdip'), ['pectoraux', 'triceps']),
    (RegExp(r'pompe|push.?up|hspu|handstand|pike|développé|bench|press'), ['pectoraux', 'triceps', 'épaules']),
    (RegExp(r'squat|fente|lunge|pistol|box jump|step.?up|leg extension|presse'), ['quadriceps', 'fessiers']),
    (RegExp(r'soulevé|deadlift|rdl|hip thrust|nordic|leg curl|good morning'), ['ischios', 'fessiers']),
    (RegExp(r'burpee'), ['pectoraux', 'quadriceps', 'gainage']),
    (RegExp(r'sit.?up|abdo|hollow|gainage|plank|planche \(|leg raise|toes|crunch|ab wheel|pallof|dragon|l-sit|v-sit|superman'), ['gainage']),
    (RegExp(r'\brun\b|course|sprint|row(er|ing machine)|rameur|bike|ski|corde|jump|mountain'), ['mollets', 'quadriceps']),
    (RegExp(r'curl'), ['biceps', 'avant-bras']),
    (RegExp(r'triceps|extension|kickback'), ['triceps']),
    (RegExp(r'élévation|rotation|oiseau|ytw|pull-apart|dislocation|shoulder|épaule|militaire'), ['épaules']),
    (RegExp(r'poignet|wrist|farmer|false grip|hang'), ['avant-bras']),
    (RegExp(r'mollet|calf'), ['mollets']),
    (RegExp(r'front lever|planche|skin the cat|atr|wall walk'), ['dos', 'épaules', 'gainage']),
  ];

  static const muscleGroups = ['pectoraux', 'épaules', 'biceps', 'triceps', 'avant-bras', 'gainage', 'dos', 'quadriceps', 'ischios', 'fessiers', 'mollets'];

  /// Groupes travaillés par un exercice (base d'exercices, puis mots-clés).
  List<String> groupsFor(String name) {
    final t = splitName(name).$1.toLowerCase();
    for (final e in allExercises) {
      if ((e['n'] as String).toLowerCase() == t) {
        final gs = (e['g'] as String).split(',').map((g) => g.trim()).where(muscleGroups.contains).toList();
        if (gs.isNotEmpty) return gs;
        break;
      }
    }
    for (final (re, gs) in _kw) {
      if (re.hasMatch(t)) return gs;
    }
    return const [];
  }

  /// Séries validées par groupe musculaire depuis le lundi de la semaine en
  /// cours (programme + séances perso + WODs). 1 série = 1 point réparti :
  /// 1,0 sur le groupe principal, 0,6 sur les secondaires.
  Map<String, double> weeklyMuscles([DateTime? at]) {
    final now = at ?? DateTime.now();
    final monday = DateTime(now.year, now.month, now.day).subtract(Duration(days: now.weekday - 1));
    final out = <String, double>{for (final g in muscleGroups) g: 0};
    void add(List<String> gs, double sets) {
      for (var i = 0; i < gs.length; i++) {
        out[gs[i]] = (out[gs[i]] ?? 0) + sets * (i == 0 ? 1.0 : 0.6);
      }
    }
    final wk = program.weekFor(now);
    for (final d in program.week(wk).days) {
      final sl = logs[sessionKey(wk, d.j)];
      if (sl == null) continue;
      for (final ex in d.exercises) {
        final l = sl.ex[ex.id];
        if (l == null) continue;
        final n = l.sets.where((x) => x.done).length;
        if (n > 0) add(groupsFor(ex.name), n.toDouble());
      }
    }
    for (final e in logs.entries) {
      if (!e.key.startsWith('S0-') || !e.value.done || e.value.finishedAt == null) continue;
      final at = DateTime.tryParse(e.value.finishedAt!);
      if (at == null || at.isBefore(monday)) continue;
      final id = e.key.substring(4);
      final cs = customSessions.where((c) => c.id == id).toList();
      if (cs.isEmpty) continue;
      for (final it in cs.first.items) {
        final l = e.value.ex['CU-${it.uid}'];
        if (l == null) continue;
        final n = l.sets.where((x) => x.done).length;
        if (n > 0) add(groupsFor(it.name), n.toDouble());
      }
    }
    for (final w in wods) {
      for (final r in w.results) {
        final at = DateTime.tryParse(r.at);
        if (at == null || at.isBefore(monday)) continue;
        final rounds = w.type == 'rounds' && w.rounds > 0 ? w.rounds : (r.rounds ?? 1).clamp(1, 50);
        for (final line in w.lines) {
          add(groupsFor(line), 0.5 * rounds);
        }
      }
    }
    return out;
  }

  // ---------- Nature de la saisie ----------
  LogSpec logSpec(Exercise e) {
    final low = setsLabel(e).toLowerCase().trim();
    final nm = e.name.toLowerCase();
    final tp = e.tempo.toLowerCase();
    final tm = e.timer;
    if (tm != null) {
      switch (tm['type'] as String) {
        case 'hiit':
          return const LogSpec('interval');
        case 'emom':
          return LogSpec('emom',
              seconds: (tm['rounds'] as int) * (tm['interval'] as int));
        case 'amrap':
          return LogSpec('amrap', seconds: tm['sec'] as int);
        case 'hold':
          if (low.contains('intra')) {
            return LogSpec('reps',
                intra: tm['sec'] as int, cluster: true, rowPrefix: 'C');
          }
          return LogSpec('hold', seconds: tm['sec'] as int);
      }
    }
    if (e.interval != null) return const LogSpec('interval');
    final emom = RegExp(r'^emom\s*(\d+)\s*min').firstMatch(low);
    if (emom != null) {
      return LogSpec('emom', seconds: int.parse(emom.group(1)!) * 60);
    }
    if (low.contains('cluster')) {
      final mi = RegExp(r'\((\d+)\s*s intra\)').firstMatch(low);
      return LogSpec('reps',
          intra: mi == null ? 30 : int.parse(mi.group(1)!),
          cluster: true,
          rowPrefix: 'C');
    }
    if (low.contains('puis')) {
      return LogSpec('reps', intra: e.restSec ?? 10, myo: true, rowPrefix: 'M');
    }
    final hold = RegExp(r'^\d+\s*[×x]\s*(\d+)(?:-(\d+))?\s*s\b').firstMatch(low);
    if (hold != null) {
      return LogSpec('hold', seconds: int.parse(hold.group(2) ?? hold.group(1)!));
    }
    if (low.contains('max')) {
      final iso = tp.contains('isom') ||
          nm.contains('hang') ||
          nm.contains('hold') ||
          nm.contains('tenue');
      return LogSpec(iso ? 'holdMax' : 'repsMax');
    }
    final dur = RegExp(r'^(\d+)(?:-(\d+))?\s*min$').firstMatch(low);
    if (dur != null) {
      return LogSpec('duration',
          seconds: int.parse(dur.group(2) ?? dur.group(1)!) * 60);
    }
    if (low.contains('échelle')) return const LogSpec('reps', rowPrefix: 'É');
    if (low.contains('round')) return const LogSpec('reps', rowPrefix: 'R');
    if (low.contains('montée')) return const LogSpec('reps', rowPrefix: 'T');
    return const LogSpec('reps');
  }

  /// Reps prévues par ligne de série, déduites du libellé (null = pas de cible).
  /// « 5×4 » → 4 · « 3×12-15 » → 12 · « 4 × 17 reps » → 17 · myo : activation puis
  /// minis · clusters : reps par cluster · pyramide « 12-10-8-6 » · échelles « de 7 à 1 »
  /// → 28 · montée en singles → 1 · EMOM 12 min × 5 reps → 60.
  List<int?> plannedReps(Exercise e, LogSpec sp, int n) {
    final low = setsLabel(e).toLowerCase().trim();
    final out = List<int?>.filled(n, null);
    int? num(RegExp r, {int g = 1}) {
      final m = r.firstMatch(low);
      return m == null ? null : int.tryParse(m.group(g)!);
    }

    if (sp.kind == 'emom') {
      final c = RegExp(r'emom\s*(\d+)\s*[×x]\s*\d+\s*s.*?(\d+)\s*reps').firstMatch(low);
      final m = RegExp(r'(\d+)\s*min.*?(\d+)\s*reps').firstMatch(low);
      final mm = c ?? m;
      if (mm != null && n > 0) {
        out[0] = int.parse(mm.group(1)!) * int.parse(mm.group(2)!);
      }
      return out;
    }
    if (sp.kind != 'reps') return out;
    if (sp.myo) {
      final act = num(RegExp(r'^1\s*[×x]\s*(\d+)'));
      final mini = num(RegExp(r'puis\s*\d+\s*[×x]\s*\(?(\d+)'));
      for (var i = 0; i < n; i++) {
        out[i] = i == 0 ? act : mini;
      }
      return out;
    }
    if (sp.cluster) {
      final cm = RegExp(r'\((\d+)\s*[×x]\s*(\d+)\)').firstMatch(low);
      if (cm != null) {
        return List.filled(n, int.parse(cm.group(1)!) * int.parse(cm.group(2)!));
      }
      return List.filled(n, num(RegExp(r'^\d+\s*[×x]\s*(\d+)')));
    }
    if (RegExp(r'^\d+(?:\s*-\s*\d+){2,}$').hasMatch(low)) {
      final parts = low.split(RegExp(r'\s*-\s*')).map(int.tryParse).toList();
      for (var i = 0; i < n; i++) {
        out[i] = i < parts.length ? parts[i] : parts.last;
      }
      return out;
    }
    final lad = num(RegExp(r'de\s*(\d+)\s*à\s*1'));
    if (lad != null) return List.filled(n, lad * (lad + 1) ~/ 2);
    if (low.contains('montée')) return List.filled(n, 1);
    final std = num(RegExp(r'^\d+\s*[×x]\s*(\d+)'));
    if (std != null) return List.filled(n, std);
    return out;
  }

  /// Libellé de la ligne de série (Act / M1… · C1… · É1… · R1… · Mont./Tent.).
  String setLabel(LogSpec sp, int i) {
    if (sp.myo) return i == 0 ? 'Act' : 'M$i';
    switch (sp.rowPrefix) {
      case 'C':
        return 'C${i + 1}';
      case 'É':
        return 'É${i + 1}';
      case 'R':
        return 'R${i + 1}';
      case 'T':
        return i < 3 ? 'Mo${i + 1}' : 'T${i - 2}';
    }
    return '${i + 1}';
  }

  /// Repos à lancer après la série i (null = aucun chrono automatique).
  int? restAfterSet(Exercise e, LogSpec sp, int i, int total) {
    final r = e.rest.toLowerCase();
    if (r.contains('après') || r.contains('au total')) return null;
    final def = settings.defaultRest > 0 ? settings.defaultRest : null;
    if (sp.myo) return i < total - 1 ? sp.intra : def;
    return e.restSec ?? def;
  }

  /// Regroupe les exercices enchaînés (ex. dips → pompes) sur une même page.
  List<List<Exercise>> groups(DayPlan d) {
    final out = <List<Exercise>>[];
    var i = 0;
    while (i < d.exercises.length) {
      final e = d.exercises[i];
      if (i + 1 < d.exercises.length &&
          d.exercises[i + 1].name.toLowerCase().contains('enchaîn')) {
        out.add([e, d.exercises[i + 1]]);
        i += 2;
      } else {
        out.add([e]);
        i += 1;
      }
    }
    return out;
  }

  // ---------- Journal ----------
  String sessionKey(int week, int j) => 'S$week-J$j';

  SessionLog sessionLog(int week, int j) =>
      logs.putIfAbsent(sessionKey(week, j), () => SessionLog());

  ExerciseLog exLog(int week, int j, Exercise e) {
    final s = sessionLog(week, j);
    return s.ex.putIfAbsent(e.id, () {
      final n = setCount(e);
      return ExerciseLog(sets: List.generate(n, (_) => SetEntry()));
    });
  }

  Timer? _saveT;

  /// Persistance différée (600 ms) : l'encodage JSON du journal complet ne
  /// tourne plus sur le thread d'interface à chaque coche ou frappe.
  void saveLogs({bool immediate = false}) {
    _saveT?.cancel();
    if (immediate) {
      _flushLogs();
    } else {
      _saveT = Timer(const Duration(milliseconds: 600), _flushLogs);
    }
    notifyListeners();
  }

  void _flushLogs() {
    _saveT?.cancel();
    _saveT = null;
    _prefs.setString(_kLogs, _pack(jsonEncode(logs.map((k, v) => MapEntry(k, v.toJson())))));
  }

  /// À appeler quand l'app passe en arrière-plan.
  void flush() => _flushLogs();

  /// Efface tout l'historique d'une séance : séries, notes, statut « fait ».
  void clearSession(int week, int j) {
    logs.remove(sessionKey(week, j));
    saveLogs(immediate: true);
  }

  void markSessionDone(int week, int j, bool done, {String? title}) {
    final s = sessionLog(week, j);
    s.done = done;
    s.finishedAt = done ? DateTime.now().toIso8601String() : null;
    if (title != null) s.title = title;
    saveLogs(immediate: true);
  }

  bool isDone(int week, int j) => logs[sessionKey(week, j)]?.done ?? false;

  int get completedCount => logs.values.where((s) => s.done).length;
}

/// Singleton global — simple et suffisant pour cette app.
final AppStore store = AppStore();
