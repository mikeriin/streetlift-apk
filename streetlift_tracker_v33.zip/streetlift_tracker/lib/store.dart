// Store global : Pilotage éditable + journal de séances, persistés localement.
// Les calculs de charge reproduisent exactement les formules du classeur v3.3.
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class SetEntry {
  String kg;
  String reps;
  String rir;
  String v; // vitesse (VBT), lifts principaux
  bool done;
  SetEntry({this.kg = '', this.reps = '', this.rir = '', this.v = '', this.done = false});

  Map<String, dynamic> toJson() =>
      {'kg': kg, 'reps': reps, 'rir': rir, 'v': v, 'done': done};
  SetEntry.fromJson(Map<String, dynamic> j)
      : kg = j['kg'] as String? ?? '',
        reps = j['reps'] as String? ?? '',
        rir = j['rir'] as String? ?? '',
        v = j['v'] as String? ?? '',
        done = j['done'] as bool? ?? false;
}

class ExerciseLog {
  List<SetEntry> sets;
  String note;
  ExerciseLog({List<SetEntry>? sets, this.note = ''}) : sets = sets ?? [];

  Map<String, dynamic> toJson() =>
      {'sets': sets.map((s) => s.toJson()).toList(), 'note': note};
  ExerciseLog.fromJson(Map<String, dynamic> j)
      : sets = ((j['sets'] as List?) ?? [])
            .map((s) => SetEntry.fromJson(s as Map<String, dynamic>))
            .toList(),
        note = j['note'] as String? ?? '';
}

class SessionLog {
  bool done;
  String? finishedAt; // ISO
  Map<String, ExerciseLog> ex;
  SessionLog({this.done = false, this.finishedAt, Map<String, ExerciseLog>? ex})
      : ex = ex ?? {};

  Map<String, dynamic> toJson() => {
        'done': done,
        'finishedAt': finishedAt,
        'ex': ex.map((k, v) => MapEntry(k, v.toJson())),
      };
  SessionLog.fromJson(Map<String, dynamic> j)
      : done = j['done'] as bool? ?? false,
        finishedAt = j['finishedAt'] as String?,
        ex = ((j['ex'] as Map<String, dynamic>?) ?? {}).map((k, v) =>
            MapEntry(k, ExerciseLog.fromJson(v as Map<String, dynamic>)));
}

class AppStore extends ChangeNotifier {
  late final Program program;
  late final SharedPreferences _prefs;

  /// Valeurs Pilotage éditables : PdC (B4), 1RM (B8-B11), max reps (B16-B20),
  /// charges de référence accessoires (B25-B45).
  final Map<String, double> values = {};

  /// Reps de référence des accessoires (colonne D, non éditable).
  final Map<String, int> refReps = {};

  final Map<String, SessionLog> logs = {};

  /// Incrémenté à chaque reset pour forcer le rafraîchissement des champs.
  int pilotageEpoch = 0;

  static const _kPilotage = 'pilotage_v1';
  static const _kLogs = 'logs_v1';

  Future<void> init() async {
    final raw = await rootBundle.loadString('assets/programme_v33.json');
    program = Program.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    _prefs = await SharedPreferences.getInstance();

    // Défauts depuis le JSON du classeur.
    final p = program.pilotage;
    values['B4'] = p.bodyweight;
    for (final l in p.mainLifts) {
      values[l.ref] = l.oneRm;
    }
    for (final m in p.repMax) {
      values[m.ref] = m.max;
    }
    for (final a in p.accessories) {
      values[a.ref] = a.refLoad;
      refReps[a.ref] = a.refReps;
    }

    // Écrase avec les valeurs sauvegardées.
    final sp = _prefs.getString(_kPilotage);
    if (sp != null) {
      final m = jsonDecode(sp) as Map<String, dynamic>;
      m.forEach((k, v) => values[k] = (v as num).toDouble());
    }
    final sl = _prefs.getString(_kLogs);
    if (sl != null) {
      final m = jsonDecode(sl) as Map<String, dynamic>;
      m.forEach((k, v) =>
          logs[k] = SessionLog.fromJson(v as Map<String, dynamic>));
    }
  }

  // ---------- Pilotage ----------
  void setValue(String ref, double v) {
    values[ref] = v;
    _prefs.setString(_kPilotage, jsonEncode(values));
    notifyListeners();
  }

  void resetPilotage() {
    pilotageEpoch++;
    final p = program.pilotage;
    values['B4'] = p.bodyweight;
    for (final l in p.mainLifts) {
      values[l.ref] = l.oneRm;
    }
    for (final m in p.repMax) {
      values[m.ref] = m.max;
    }
    for (final a in p.accessories) {
      values[a.ref] = a.refLoad;
    }
    _prefs.setString(_kPilotage, jsonEncode(values));
    notifyListeners();
  }

  // ---------- Calculs (répliques des formules Excel) ----------
  double _round(double x, double step) => (x / step).round() * step;

  /// Charge suggérée en kg, ou null si non applicable.
  double? loadFor(Exercise e) {
    final s = e.load;
    switch (s.type) {
      case 'fixed':
        return s.kg;
      case 'system':
        final pdc = values['B4']!;
        final rm = values[s.ref!] ?? 0;
        final raw = (pdc + rm) * s.pct! - pdc;
        final r = _round(raw, 2.5);
        return r < 0 ? 0.0 : r;
      case 'barbell':
        return _round(values['B11']! * s.pct!, 2.5);
      case 'acc':
        final ref = values[s.ref!] ?? 0;
        final rr = refReps[s.ref!] ?? 10;
        final raw = ref * (1 + (rr + 2) / 30) / (1 + (s.dayReps! + 2) / 30);
        return _round(raw, s.step!);
      default:
        return null;
    }
  }

  String loadLabel(Exercise e) {
    final kg = loadFor(e);
    if (kg == null) return '—';
    if (kg <= 0) return 'PdC';
    final t = kg == kg.roundToDouble()
        ? kg.toInt().toString()
        : kg.toStringAsFixed(1).replaceAll('.', ',');
    return '$t kg';
  }

  /// Rendu de la colonne « Séries × Reps » (les volumes suivent tes maxima).
  String setsLabel(Exercise e) {
    final s = e.sets;
    if (s.type == 'volume') {
      final ref = values[s.ref!] ?? 0;
      final n = (s.coef! * ref / s.div!).round();
      return '${s.prefix}$n${s.suffix}';
    }
    return s.value ?? '';
  }

  /// Nombre de lignes de séries à afficher dans le logger.
  int setCount(Exercise e) {
    final txt = setsLabel(e);
    if (e.interval != null) return 1;
    final myo = RegExp(r'puis\s*(\d+)\s*[×x]').firstMatch(txt);
    final lead = RegExp(r'^(\d+)\s*[×x]').firstMatch(txt);
    if (myo != null) {
      return 1 + int.parse(myo.group(1)!);
    }
    if (lead != null) return int.parse(lead.group(1)!);
    return 1;
  }

  // ---------- Journal ----------
  String sessionKey(int week, int j) => 'S$week-J$j';

  SessionLog sessionLog(int week, int j) =>
      logs.putIfAbsent(sessionKey(week, j), () => SessionLog());

  ExerciseLog exLog(int week, int j, Exercise e) {
    final s = sessionLog(week, j);
    return s.ex.putIfAbsent(e.id, () {
      final n = setCount(e);
      return ExerciseLog(sets: List.generate(n, (_) => SetEntry()));
    });
  }

  void saveLogs() {
    _prefs.setString(
        _kLogs, jsonEncode(logs.map((k, v) => MapEntry(k, v.toJson()))));
    notifyListeners();
  }

  void markSessionDone(int week, int j, bool done) {
    final s = sessionLog(week, j);
    s.done = done;
    s.finishedAt = done ? DateTime.now().toIso8601String() : null;
    saveLogs();
  }

  bool isDone(int week, int j) => logs[sessionKey(week, j)]?.done ?? false;

  int get completedCount => logs.values.where((s) => s.done).length;
}

/// Singleton global — simple et suffisant pour cette app.
final AppStore store = AppStore();
