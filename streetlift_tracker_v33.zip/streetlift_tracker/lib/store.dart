// Store global : Pilotage éditable + journal de séances, persistés localement.
// Les calculs de charge reproduisent exactement les formules du classeur v3.3.
import 'dart:async';
import 'dart:convert';
import 'dart:ui' show Color;

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';
import 'wod_models.dart';

class SetEntry {
  String kg;
  String reps;
  String rir;
  String v; // vitesse (VBT), lifts principaux
  bool done;
  SetEntry({this.kg = '', this.reps = '', this.rir = '', this.v = '', this.done = false});

  Map<String, dynamic> toJson() =>
      {'kg': kg, 'reps': reps, 'rir': rir, 'v': v, 'done': done};
  SetEntry.fromJson(Map<String, dynamic> j)
      : kg = j['kg'] as String? ?? '',
        reps = j['reps'] as String? ?? '',
        rir = j['rir'] as String? ?? '',
        v = j['v'] as String? ?? '',
        done = j['done'] as bool? ?? false;
}

class ExerciseLog {
  List<SetEntry> sets;
  String note;
  bool? showKg; // null = règle automatique
  bool? showRir;
  bool? showV;
  ExerciseLog({List<SetEntry>? sets, this.note = '', this.showKg, this.showRir, this.showV})
      : sets = sets ?? [];

  void addSet() => sets.add(SetEntry());
  bool removeLastSet() {
    if (sets.length <= 1 || sets.last.done) return false;
    sets.removeLast();
    return true;
  }

  Map<String, dynamic> toJson() => {
        'sets': sets.map((s) => s.toJson()).toList(),
        'note': note,
        'showKg': showKg,
        'showRir': showRir,
        'showV': showV,
      };
  ExerciseLog.fromJson(Map<String, dynamic> j)
      : sets = ((j['sets'] as List?) ?? [])
            .map((s) => SetEntry.fromJson(s as Map<String, dynamic>))
            .toList(),
        note = j['note'] as String? ?? '',
        showKg = j['showKg'] as bool?,
        showRir = j['showRir'] as bool?,
        showV = j['showV'] as bool?;
}

class SessionLog {
  bool done;
  String? finishedAt; // ISO
  String? title; // libellé lisible (ex. « S8 · J1 » ou nom de séance perso)
  Map<String, ExerciseLog> ex;
  SessionLog(
      {this.done = false, this.finishedAt, this.title, Map<String, ExerciseLog>? ex})
      : ex = ex ?? {};

  Map<String, dynamic> toJson() => {
        'done': done,
        'finishedAt': finishedAt,
        'title': title,
        'ex': ex.map((k, v) => MapEntry(k, v.toJson())),
      };
  SessionLog.fromJson(Map<String, dynamic> j)
      : done = j['done'] as bool? ?? false,
        finishedAt = j['finishedAt'] as String?,
        title = j['title'] as String?,
        ex = ((j['ex'] as Map<String, dynamic>?) ?? {}).map((k, v) =>
            MapEntry(k, ExerciseLog.fromJson(v as Map<String, dynamic>)));
}

// ===================== RÉGLAGES =====================

class AppSettings {
  int defaultRest; // s, appliqué quand l'exercice n'a pas de repos
  bool autoTimer; // lancer le repos à la validation d'une série
  bool sound;
  bool vibration;
  int prepSec; // décompte « prêt » avant EMOM/AMRAP/HIIT
  bool rpe; // afficher RPE au lieu de RIR
  bool lb; // afficher les charges en livres
  bool prefill; // pré-remplir la charge suggérée
  bool wakelock; // écran allumé pendant la séance
  String theme; // system | dark | light
  bool trackRir; // colonne RIR/RPE affichée par défaut
  bool trackVelocity; // colonne vitesse (VBT) affichée par défaut sur les lifts
  bool notifOn; // rappel quotidien de la séance du jour
  int notifHour;
  int notifMinute;
  bool notifSkipRest; // pas de rappel les jours de repos

  AppSettings(
      {this.defaultRest = 90,
      this.autoTimer = true,
      this.sound = true,
      this.vibration = true,
      this.prepSec = 5,
      this.rpe = false,
      this.lb = false,
      this.prefill = true,
      this.wakelock = true,
      this.theme = 'system',
      this.trackRir = false,
      this.trackVelocity = false,
      this.notifOn = false,
      this.notifHour = 7,
      this.notifMinute = 30,
      this.notifSkipRest = true});

  Map<String, dynamic> toJson() => {
        'defaultRest': defaultRest,
        'autoTimer': autoTimer,
        'sound': sound,
        'vibration': vibration,
        'prepSec': prepSec,
        'rpe': rpe,
        'lb': lb,
        'prefill': prefill,
        'wakelock': wakelock,
        'theme': theme,
        'trackRir': trackRir,
        'trackVelocity': trackVelocity,
        'notifOn': notifOn,
        'notifHour': notifHour,
        'notifMinute': notifMinute,
        'notifSkipRest': notifSkipRest,
      };
  AppSettings.fromJson(Map<String, dynamic> j)
      : defaultRest = j['defaultRest'] as int? ?? 90,
        autoTimer = j['autoTimer'] as bool? ?? true,
        sound = j['sound'] as bool? ?? true,
        vibration = j['vibration'] as bool? ?? true,
        prepSec = j['prepSec'] as int? ?? 5,
        rpe = j['rpe'] as bool? ?? false,
        lb = j['lb'] as bool? ?? false,
        prefill = j['prefill'] as bool? ?? true,
        wakelock = j['wakelock'] as bool? ?? true,
        theme = j['theme'] as String? ?? 'system',
        trackRir = j['trackRir'] as bool? ?? false,
        trackVelocity = j['trackVelocity'] as bool? ?? false,
        notifOn = j['notifOn'] as bool? ?? false,
        notifHour = j['notifHour'] as int? ?? 7,
        notifMinute = j['notifMinute'] as int? ?? 30,
        notifSkipRest = j['notifSkipRest'] as bool? ?? true;
}

// ===================== SÉANCES PERSONNALISÉES =====================

/// Modes d'exécution disponibles pour les séances personnalisées.
class ExecMode {
  final String id;
  final String label;
  final String desc;
  final List<String> fields; // paramètres à afficher dans l'éditeur
  const ExecMode(this.id, this.label, this.desc, this.fields);
}

const execModes = <ExecMode>[
  ExecMode('classic', 'Classique', 'Séries × répétitions, repos entre les séries.',
      ['series', 'reps']),
  ExecMode('myo', 'Myo-reps',
      'Série d\u2019activation proche de l\u2019échec, puis mini-séries avec micro-repos.',
      ['actReps', 'miniReps', 'minis', 'intra']),
  ExecMode('cluster', 'Cluster',
      'Chaque série est découpée en mini-blocs séparés de quelques secondes.',
      ['series', 'miniReps', 'minis', 'intra']),
  ExecMode('emom', 'EMOM',
      'Un bloc de travail au top de chaque intervalle (Every Minute On the Minute).',
      ['rounds', 'interval', 'reps']),
  ExecMode('amrap', 'AMRAP',
      'Un maximum de travail dans la durée fixée (As Many Reps As Possible).',
      ['duree']),
  ExecMode('iso', 'Isométrie',
      'Tenues statiques chronométrées (holds, gainage, overcoming iso).',
      ['series', 'hold']),
  ExecMode('hiit', 'Intervalles',
      'Alternance effort/repos chronométrée (HIIT, Tabata).',
      ['rounds', 'work', 'restI']),
  ExecMode('pyramide', 'Pyramide',
      'Répétitions croissantes ou décroissantes, ex. 12-10-8-6.',
      ['pyr']),
];

ExecMode modeById(String id) =>
    execModes.firstWhere((m) => m.id == id, orElse: () => execModes.first);

String _newUid() => DateTime.now().microsecondsSinceEpoch.toRadixString(36);

class CustomExercise {
  String uid; // stable : les logs y restent rattachés même après réordonnancement
  String name;
  String mode; // id ExecMode
  Map<String, dynamic> p; // paramètres du mode
  double? kg;
  int? rest; // s
  String note;
  CustomExercise(
      {String? uid,
      required this.name,
      this.mode = 'classic',
      Map<String, dynamic>? p,
      this.kg,
      this.rest,
      this.note = ''})
      : uid = uid ?? _newUid(),
        p = p ?? {};

  Map<String, dynamic> toJson() => {
        'uid': uid,
        'name': name,
        'mode': mode,
        'p': p,
        'kg': kg,
        'rest': rest,
        'note': note
      };
  CustomExercise.fromJson(Map<String, dynamic> j)
      : uid = j['uid'] as String? ?? _newUid(),
        name = j['name'] as String,
        mode = j['mode'] as String? ?? 'classic',
        p = Map<String, dynamic>.from(j['p'] as Map? ?? {}),
        kg = j['kg'] == null ? null : (j['kg'] as num).toDouble(),
        rest = j['rest'] as int?,
        note = j['note'] as String? ?? '';

  int _pi(String k, int d) => (p[k] as num?)?.toInt() ?? d;
  String _ps(String k, String d) {
    final v = p[k];
    return v is String && v.trim().isNotEmpty ? v : d;
  }

  /// Libellé « Séries × Reps » selon le mode.
  String setsText() {
    switch (mode) {
      case 'myo':
        return '1×${_pi('actReps', 12)} puis ${_pi('minis', 4)}×(${_pi('miniReps', 4)}) · ${_pi('intra', 15)} s intra';
      case 'cluster':
        return '${_pi('series', 4)}×(${_pi('minis', 3)}×${_pi('miniReps', 2)}) · ${_pi('intra', 20)} s intra';
      case 'emom':
        return 'EMOM ${_pi('rounds', 10)}×${_pi('interval', 60)} s · ${_pi('reps', 5)} reps';
      case 'amrap':
        return 'AMRAP ${_pi('duree', 8)} min';
      case 'iso':
        return '${_pi('series', 3)}×${_pi('hold', 30)} s';
      case 'hiit':
        return '${_pi('rounds', 8)}× (${_pi('work', 30)} s effort / ${_pi('restI', 30)} s repos)';
      case 'pyramide':
        return _ps('pyr', '12-10-8-6');
      default:
        return '${_pi('series', 4)}×${_pi('reps', 8)}';
    }
  }

  int forcedSets() {
    switch (mode) {
      case 'myo':
        return 1 + _pi('minis', 4);
      case 'cluster':
        return _pi('series', 4);
      case 'emom':
      case 'amrap':
      case 'hiit':
        return 1;
      case 'iso':
        return _pi('series', 3);
      case 'pyramide':
        return _ps('pyr', '12-10-8-6').split(RegExp(r'[-/ ]+')).length;
      default:
        return _pi('series', 4);
    }
  }

  Map<String, dynamic>? timerSpec() {
    switch (mode) {
      case 'emom':
        return {'type': 'emom', 'rounds': _pi('rounds', 10), 'interval': _pi('interval', 60)};
      case 'amrap':
        return {'type': 'amrap', 'sec': _pi('duree', 8) * 60};
      case 'hiit':
        return {'type': 'hiit', 'rounds': _pi('rounds', 8), 'work': _pi('work', 30), 'rest': _pi('restI', 30)};
      case 'iso':
        return {'type': 'hold', 'sec': _pi('hold', 30)};
      case 'cluster':
        return {'type': 'hold', 'sec': _pi('intra', 20)};
    }
    return null;
  }

  Exercise toExercise(int index) {
    final m = modeById(mode);
    return Exercise.manual(
      id: 'CU-$uid',
      name: name,
      setsText: setsText(),
      intensity: mode == 'classic' ? '' : m.label,
      kg: kg,
      rest: rest == null ? '' : (rest! >= 60 ? '${rest! ~/ 60} min' : '$rest s'),
      restSec: rest,
      cue: note.isEmpty ? m.desc : note,
      forcedSets: forcedSets(),
      timer: timerSpec(),
    );
  }
}

class CustomSession {
  String id; // numérique unique (clé de journal S0-J<id>)
  String name;
  List<CustomExercise> items;
  CustomSession({required this.id, required this.name, List<CustomExercise>? items})
      : items = items ?? [];

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'items': items.map((e) => e.toJson()).toList()};
  CustomSession.fromJson(Map<String, dynamic> j)
      : id = j['id'] as String,
        name = j['name'] as String,
        items = ((j['items'] as List?) ?? [])
            .map((e) => CustomExercise.fromJson(e as Map<String, dynamic>))
            .toList();

  /// Adaptateur vers le runner de séance existant (semaine 0 = perso).
  WeekPlan toWeekPlan() {
    final exs = <Exercise>[];
    for (var i = 0; i < items.length; i++) {
      exs.add(items[i].toExercise(i));
    }
    return WeekPlan.manual(
      n: 0,
      block: name,
      color: const Color(0xFF4FA3C7),
      days: [DayPlan.manual(j: int.parse(id), title: name, exercises: exs)],
    );
  }
}

/// Nature de la saisie d'un exercice, déduite des données.
class LogSpec {
  final String kind; // reps | repsMax | hold | holdMax | duration | interval | emom | amrap
  final int? seconds; // tenue (hold) ou durée totale (duration / emom)
  final int? intra; // micro-repos myo-reps / clusters
  final bool myo;
  final bool cluster;
  final String rowPrefix; // M (myo) · C (cluster) · É (échelle) · R (round) · T (test)
  const LogSpec(this.kind,
      {this.seconds,
      this.intra,
      this.myo = false,
      this.cluster = false,
      this.rowPrefix = ''});
  bool get timed => kind == 'hold' || kind == 'holdMax' || kind == 'duration';
}

class AppStore extends ChangeNotifier {
  late final Program program;
  late final SharedPreferences _prefs;

  /// Valeurs Pilotage éditables : PdC (B4), 1RM (B8-B11), max reps (B16-B20),
  /// charges de référence accessoires (B25-B45).
  final Map<String, double> values = {};

  /// Reps de référence des accessoires (colonne D, non éditable).
  final Map<String, int> refReps = {};

  final Map<String, SessionLog> logs = {};

  /// Incrémenté à chaque reset pour forcer le rafraîchissement des champs.
  int pilotageEpoch = 0;

  AppSettings settings = AppSettings();

  /// Ne change qu'au changement de thème : évite de reconstruire MaterialApp
  /// à chaque notification du store.
  final ValueNotifier<String> themeMode = ValueNotifier<String>('system');
  final List<Map<String, dynamic>> dbExercises = []; // base embarquée
  final List<Map<String, dynamic>> userExercises = []; // ajoutés par l'utilisateur
  final List<CustomSession> customSessions = [];
  final List<Wod> wods = [];

  static const _kPilotage = 'pilotage_v1';
  static const _kLogs = 'logs_v1';
  static const _kSettings = 'settings_v1';
  static const _kCustom = 'custom_sessions_v1';
  static const _kUserEx = 'user_exercises_v1';
  static const _kWods = 'wods_v1';
  static const _kSeedV = 'wods_seed_v';
  static const _kLastLevel = 'level_seen';

  Future<void> init() async {
    final raw = await rootBundle.loadString('assets/programme_v33.json');
    program = Program.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    _prefs = await SharedPreferences.getInstance();

    // Défauts depuis le JSON du classeur.
    final p = program.pilotage;
    values['B4'] = p.bodyweight;
    for (final l in p.mainLifts) {
      values[l.ref] = l.oneRm;
    }
    for (final m in p.repMax) {
      values[m.ref] = m.max;
    }
    for (final a in p.accessories) {
      values[a.ref] = a.refLoad;
      refReps[a.ref] = a.refReps;
    }

    // Écrase avec les valeurs sauvegardées.
    final sp = _prefs.getString(_kPilotage);
    if (sp != null) {
      final m = jsonDecode(sp) as Map<String, dynamic>;
      m.forEach((k, v) => values[k] = (v as num).toDouble());
    }
    final sl = _prefs.getString(_kLogs);
    if (sl != null) {
      final m = jsonDecode(sl) as Map<String, dynamic>;
      m.forEach((k, v) =>
          logs[k] = SessionLog.fromJson(v as Map<String, dynamic>));
    }

    // Base d'exercices embarquée + exercices utilisateur.
    final dbRaw = await rootBundle.loadString('assets/exercises_db.json');
    for (final e in jsonDecode(dbRaw) as List) {
      dbExercises.add(Map<String, dynamic>.from(e as Map));
    }
    final su = _prefs.getString(_kUserEx);
    if (su != null) {
      for (final e in jsonDecode(su) as List) {
        userExercises.add(Map<String, dynamic>.from(e as Map));
      }
    }
    final ss = _prefs.getString(_kSettings);
    if (ss != null) {
      settings = AppSettings.fromJson(jsonDecode(ss) as Map<String, dynamic>);
    }
    themeMode.value = settings.theme;
    final sc = _prefs.getString(_kCustom);
    if (sc != null) {
      for (final e in jsonDecode(sc) as List) {
        customSessions.add(CustomSession.fromJson(e as Map<String, dynamic>));
      }
    }
    final sw = _prefs.getString(_kWods);
    if (sw != null) {
      for (final e in jsonDecode(sw) as List) {
        wods.add(Wod.fromJson(e as Map<String, dynamic>));
      }
    } else {
      wods.addAll(seedWods()); // premier lancement : les 19 WODs en stock
    }
    // Fournée 2 : niveaux des WODs d'origine + nouveaux WODs (sans réimporter
    // ceux que l'utilisateur a supprimés).
    final seedV = _prefs.getInt(_kSeedV) ?? (sw == null ? 0 : 1);
    if (seedV < 2) {
      for (final w in wods) {
        final lv = seedLevels[w.id];
        if (lv != null && w.level == 1) w.level = lv;
      }
      final ids = wods.map((w) => w.id).toSet();
      for (final n in seedWodsV2()) {
        if (!ids.contains(n.id)) wods.add(n);
      }
      _prefs.setInt(_kSeedV, 2);
      _saveWods();
    }
    _lastLevel = _prefs.getInt(_kLastLevel) ?? level;
  }

  // ---------- Progression (XP, niveaux, déverrouillage) ----------
  int _lastLevel = 1;

  /// XP dérivée des données (rien à synchroniser) : séance programme 100,
  /// séance perso 60, score de WOD 80, record personnel +40.
  int get xp {
    var x = 0;
    for (final e in logs.entries) {
      if (!e.value.done) continue;
      x += e.key.startsWith('S0-') ? 60 : 100;
    }
    for (final w in wods) {
      final best = w.best();
      for (final r in w.results) {
        x += 80;
        if (identical(r, best)) x += 40;
      }
    }
    return x;
  }

  /// XP nécessaire pour passer du niveau l au niveau l+1 (150, 200, 250…).
  static int needFor(int l) => 150 + 50 * (l - 1);

  int get level {
    var lvl = 1;
    var acc = 0;
    while (xp >= acc + needFor(lvl)) {
      acc += needFor(lvl);
      lvl++;
    }
    return lvl;
  }

  /// XP déjà acquise dans le niveau courant, et XP requise pour le suivant.
  ({int inLevel, int need}) get levelProgress {
    var lvl = 1;
    var acc = 0;
    final x = xp;
    while (x >= acc + needFor(lvl)) {
      acc += needFor(lvl);
      lvl++;
    }
    return (inLevel: x - acc, need: needFor(lvl));
  }

  bool unlocked(Wod w) => w.level <= level;

  /// Si le niveau a monté depuis la dernière vérification : (ancien, nouveau,
  /// WODs déverrouillés), sinon null. À appeler après une séance ou un score.
  ({int from, int to, List<Wod> unlockedWods})? consumeLevelUp() {
    final now = level;
    if (now <= _lastLevel) return null;
    final from = _lastLevel;
    _lastLevel = now;
    _prefs.setInt(_kLastLevel, now);
    final uw = wods.where((w) => w.level > from && w.level <= now).toList();
    return (from: from, to: now, unlockedWods: uw);
  }

  // ---------- WODs ----------
  void _saveWods() {
    _prefs.setString(_kWods, jsonEncode(wods.map((w) => w.toJson()).toList()));
    notifyListeners();
  }

  String newWodId() => 'w${DateTime.now().millisecondsSinceEpoch}';

  void upsertWod(Wod w) {
    final i = wods.indexWhere((x) => x.id == w.id);
    if (i >= 0) {
      wods[i] = w;
    } else {
      wods.insert(0, w);
    }
    _saveWods();
  }

  void deleteWod(Wod w) {
    wods.removeWhere((x) => x.id == w.id);
    _saveWods();
  }

  void duplicateWod(Wod w) {
    final c = Wod.fromJson(w.toJson());
    c.id = newWodId();
    c.name = '${w.name} (copie)';
    c.results = [];
    wods.insert(0, c);
    _saveWods();
  }

  void addWodResult(Wod w, WodResult r) {
    w.results.add(r);
    _saveWods();
  }

  void deleteWodResult(Wod w, WodResult r) {
    w.results.remove(r);
    _saveWods();
  }

  // ---------- Réglages ----------
  void saveSettings() {
    _prefs.setString(_kSettings, jsonEncode(settings.toJson()));
    if (themeMode.value != settings.theme) themeMode.value = settings.theme;
    notifyListeners();
  }

  String get effortLabel => settings.rpe ? 'RPE' : 'RIR';

  // ---------- Base d'exercices ----------
  List<Map<String, dynamic>> get allExercises =>
      [...dbExercises, ...userExercises];

  void addUserExercise(String name, String group, String equip) {
    userExercises.add({'n': name, 'g': group, 'eq': equip});
    _prefs.setString(_kUserEx, jsonEncode(userExercises));
    notifyListeners();
  }

  // ---------- Séances personnalisées ----------
  void _saveCustom() {
    _prefs.setString(
        _kCustom, jsonEncode(customSessions.map((s) => s.toJson()).toList()));
    notifyListeners();
  }

  String newSessionId() =>
      (DateTime.now().millisecondsSinceEpoch % 1000000000).toString();

  void upsertSession(CustomSession s) {
    final i = customSessions.indexWhere((x) => x.id == s.id);
    if (i >= 0) {
      customSessions[i] = s;
    } else {
      customSessions.add(s);
    }
    _saveCustom();
  }

  void deleteSession(CustomSession s) {
    customSessions.removeWhere((x) => x.id == s.id);
    logs.remove('S0-J${s.id}');
    _saveCustom();
    saveLogs(immediate: true);
  }

  void duplicateSession(CustomSession s) {
    final copy = CustomSession.fromJson(s.toJson());
    copy.id = newSessionId();
    copy.name = '${s.name} (copie)';
    customSessions.add(copy);
    _saveCustom();
  }

  // ---------- Export / import ----------
  String exportAll() => jsonEncode({
        'kalisTrack': 1,
        'pilotage': values,
        'logs': logs.map((k, v) => MapEntry(k, v.toJson())),
        'settings': settings.toJson(),
        'custom': customSessions.map((s) => s.toJson()).toList(),
        'userExercises': userExercises,
        'wods': wods.map((w) => w.toJson()).toList(),
      });

  bool importAll(String raw) {
    try {
      final m = jsonDecode(raw) as Map<String, dynamic>;
      if (m['kalisTrack'] != 1) return false;
      (m['pilotage'] as Map<String, dynamic>)
          .forEach((k, v) => values[k] = (v as num).toDouble());
      logs.clear();
      (m['logs'] as Map<String, dynamic>).forEach(
          (k, v) => logs[k] = SessionLog.fromJson(v as Map<String, dynamic>));
      settings = AppSettings.fromJson(m['settings'] as Map<String, dynamic>);
      customSessions
        ..clear()
        ..addAll(((m['custom'] as List?) ?? [])
            .map((e) => CustomSession.fromJson(e as Map<String, dynamic>)));
      userExercises
        ..clear()
        ..addAll(((m['userExercises'] as List?) ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map)));
      if (m['wods'] != null) {
        wods
          ..clear()
          ..addAll((m['wods'] as List)
              .map((e) => Wod.fromJson(e as Map<String, dynamic>)));
        _saveWods();
      }
      _prefs.setString(_kPilotage, jsonEncode(values));
      _prefs.setString(_kUserEx, jsonEncode(userExercises));
      saveSettings();
      _saveCustom();
      saveLogs(immediate: true);
      return true;
    } catch (_) {
      return false;
    }
  }

  // ---------- Pilotage ----------
  void setValue(String ref, double v) {
    values[ref] = v;
    _prefs.setString(_kPilotage, jsonEncode(values));
    notifyListeners();
  }

  void resetPilotage() {
    pilotageEpoch++;
    final p = program.pilotage;
    values['B4'] = p.bodyweight;
    for (final l in p.mainLifts) {
      values[l.ref] = l.oneRm;
    }
    for (final m in p.repMax) {
      values[m.ref] = m.max;
    }
    for (final a in p.accessories) {
      values[a.ref] = a.refLoad;
    }
    _prefs.setString(_kPilotage, jsonEncode(values));
    notifyListeners();
  }

  // ---------- Calculs (répliques des formules Excel) ----------
  double _round(double x, double step) => (x / step).round() * step;

  /// Charge suggérée en kg, ou null si non applicable.
  double? loadFor(Exercise e) {
    final s = e.load;
    switch (s.type) {
      case 'fixed':
        return s.kg;
      case 'system':
        final pdc = values['B4']!;
        final rm = values[s.ref!] ?? 0;
        final raw = (pdc + rm) * s.pct! - pdc;
        final r = _round(raw, 2.5);
        return r < 0 ? 0.0 : r;
      case 'barbell':
        return _round(values['B11']! * s.pct!, 2.5);
      case 'acc':
        final ref = values[s.ref!] ?? 0;
        final rr = refReps[s.ref!] ?? 10;
        final raw = ref * (1 + (rr + 2) / 30) / (1 + (s.dayReps! + 2) / 30);
        return _round(raw, s.step!);
      default:
        return null;
    }
  }

  String loadLabel(Exercise e) {
    final kg = loadFor(e);
    if (kg == null) return '—';
    if (kg <= 0) return 'PdC';
    if (settings.lb) {
      final lb = kg * 2.20462;
      return '${lb.toStringAsFixed(lb == lb.roundToDouble() ? 0 : 1)}\u00A0lb';
    }
    final t = kg == kg.roundToDouble()
        ? kg.toInt().toString()
        : kg.toStringAsFixed(1).replaceAll('.', ',');
    return '$t\u00A0kg';
  }

  /// Rendu de la colonne « Séries × Reps » (les volumes suivent tes maxima).
  String setsLabel(Exercise e) {
    final s = e.sets;
    if (s.type == 'volume') {
      final ref = values[s.ref!] ?? 0;
      final n = (s.coef! * ref / s.div!).round();
      return '${s.prefix}$n${s.suffix}';
    }
    return s.value ?? '';
  }

  /// Nombre de lignes de séries à afficher dans le logger.
  int setCount(Exercise e) {
    if (e.forcedSets != null) return e.forcedSets!;
    final txt = setsLabel(e);
    final low = txt.toLowerCase().trim();
    if (e.interval != null) return 1;
    if (low.startsWith('emom')) return 1;
    if (RegExp(r'^(\d+)(?:-(\d+))?\s*min$').hasMatch(low)) return 1;
    final myo = RegExp(r'puis\s*(\d+)\s*[×x]').firstMatch(txt);
    if (myo != null) return 1 + int.parse(myo.group(1)!);
    if (low.contains('montée')) return 6; // 3 paliers de montée + 3 tentatives
    final lead =
        RegExp(r'^(\d+)\s*(?:[×x]|rounds?|échelles?)').firstMatch(low);
    if (lead != null) return int.parse(lead.group(1)!);
    return 1;
  }

  // ---------- Affichage ----------
  /// Titre court + sous-titre : « POMPES PDC — SÉRIES LONGUES — ENCHAÎNÉ… »
  /// → (« Pompes PdC », « séries longues · enchaîné après les dips »).
  (String, String) splitName(String name) {
    final parts = name.split(RegExp(r'\s+—\s+'));
    final title = parts.first.trim();
    final rest = parts.skip(1).map((p) => p.trim()).where((p) => p.isNotEmpty).join(' · ');
    return (title, rest);
  }

  /// Colonne kg : lestable (charge suggérée > 0 ou « lesté » dans le nom)
  /// ou déjà renseignée, sauf préférence explicite de l'exercice.
  bool showKgFor(Exercise e, ExerciseLog log) {
    if (log.showKg != null) return log.showKg!;
    if (log.sets.any((s) => s.kg.trim().isNotEmpty)) return true;
    final kg = loadFor(e);
    if (kg != null && kg > 0) return true;
    return e.name.toLowerCase().contains('lest');
  }

  bool showRirFor(ExerciseLog log) =>
      log.showRir ?? (settings.trackRir || log.sets.any((s) => s.rir.trim().isNotEmpty));

  bool showVFor(Exercise e, ExerciseLog log) =>
      log.showV ?? ((settings.trackVelocity && e.main) || log.sets.any((s) => s.v.trim().isNotEmpty));

  /// Dernière performance loggée pour le même exercice (même jour, semaine
  /// précédente ayant un journal) — programme uniquement.
  ({int week, ExerciseLog log})? previousLog(int week, int j, Exercise e) {
    if (week <= 1 || week > program.weeks.length) return null;
    final title = splitName(e.name).$1.toLowerCase();
    for (var w = week - 1; w >= 1; w--) {
      final sl = logs[sessionKey(w, j)];
      if (sl == null) continue;
      final day = program.week(w).day(j);
      if (day == null) continue;
      for (final px in day.exercises) {
        if (splitName(px.name).$1.toLowerCase() != title) continue;
        final l = sl.ex[px.id];
        if (l != null && l.sets.any((s) => s.done)) return (week: w, log: l);
      }
    }
    return null;
  }

  /// Résumé compact d'un journal : « 10 kg × 3 · 3 · 3 » ou « 39 · 37 · 35 ».
  String summarize(ExerciseLog l, {bool kg = true}) {
    final done = l.sets.where((s) => s.done).toList();
    if (done.isEmpty) return '';
    final kgs = done.map((s) => s.kg.trim()).where((k) => k.isNotEmpty).toSet();
    final reps = done.map((s) => s.reps.trim().isEmpty ? '–' : s.reps.trim()).join(' · ');
    if (kg && kgs.length == 1) return '${kgs.first}\u00A0kg × $reps';
    if (kg && kgs.length > 1) {
      return done.map((s) => '${s.kg.trim().isEmpty ? 'PdC' : '${s.kg.trim()}\u00A0kg'}×${s.reps.trim()}').join(' · ');
    }
    return reps;
  }

  // ---------- Groupes musculaires ----------
  static final List<(RegExp, List<String>)> _kw = [
    (RegExp(r'muscle.?up'), ['dos', 'pectoraux', 'triceps']),
    (RegExp(r'traction|pull.?up|chin.?up|row|tirage|face pull|dead.?hang|scapul|lat'), ['dos', 'biceps']),
    (RegExp(r'\bdip'), ['pectoraux', 'triceps']),
    (RegExp(r'pompe|push.?up|hspu|handstand|pike|développé|bench|press'), ['pectoraux', 'triceps', 'épaules']),
    (RegExp(r'squat|fente|lunge|pistol|box jump|step.?up|leg extension|presse'), ['quadriceps', 'fessiers']),
    (RegExp(r'soulevé|deadlift|rdl|hip thrust|nordic|leg curl|good morning'), ['ischios', 'fessiers']),
    (RegExp(r'burpee'), ['pectoraux', 'quadriceps', 'gainage']),
    (RegExp(r'sit.?up|abdo|hollow|gainage|plank|planche \(|leg raise|toes|crunch|ab wheel|pallof|dragon|l-sit|v-sit|superman'), ['gainage']),
    (RegExp(r'\brun\b|course|sprint|row(er|ing machine)|rameur|bike|ski|corde|jump|mountain'), ['mollets', 'quadriceps']),
    (RegExp(r'curl'), ['biceps', 'avant-bras']),
    (RegExp(r'triceps|extension|kickback'), ['triceps']),
    (RegExp(r'élévation|rotation|oiseau|ytw|pull-apart|dislocation|shoulder|épaule|militaire'), ['épaules']),
    (RegExp(r'poignet|wrist|farmer|false grip|hang'), ['avant-bras']),
    (RegExp(r'mollet|calf'), ['mollets']),
    (RegExp(r'front lever|planche|skin the cat|atr|wall walk'), ['dos', 'épaules', 'gainage']),
  ];

  static const muscleGroups = ['pectoraux', 'épaules', 'biceps', 'triceps', 'avant-bras', 'gainage', 'dos', 'quadriceps', 'ischios', 'fessiers', 'mollets'];

  /// Groupes travaillés par un exercice (base d'exercices, puis mots-clés).
  List<String> groupsFor(String name) {
    final t = splitName(name).$1.toLowerCase();
    for (final e in allExercises) {
      if ((e['n'] as String).toLowerCase() == t) {
        final gs = (e['g'] as String).split(',').map((g) => g.trim()).where(muscleGroups.contains).toList();
        if (gs.isNotEmpty) return gs;
        break;
      }
    }
    for (final (re, gs) in _kw) {
      if (re.hasMatch(t)) return gs;
    }
    return const [];
  }

  /// Séries validées par groupe musculaire depuis le lundi de la semaine en
  /// cours (programme + séances perso + WODs). 1 série = 1 point réparti :
  /// 1,0 sur le groupe principal, 0,6 sur les secondaires.
  Map<String, double> weeklyMuscles([DateTime? at]) {
    final now = at ?? DateTime.now();
    final monday = DateTime(now.year, now.month, now.day).subtract(Duration(days: now.weekday - 1));
    final out = <String, double>{for (final g in muscleGroups) g: 0};
    void add(List<String> gs, double sets) {
      for (var i = 0; i < gs.length; i++) {
        out[gs[i]] = (out[gs[i]] ?? 0) + sets * (i == 0 ? 1.0 : 0.6);
      }
    }
    final wk = program.weekFor(now);
    for (final d in program.week(wk).days) {
      final sl = logs[sessionKey(wk, d.j)];
      if (sl == null) continue;
      for (final ex in d.exercises) {
        final l = sl.ex[ex.id];
        if (l == null) continue;
        final n = l.sets.where((x) => x.done).length;
        if (n > 0) add(groupsFor(ex.name), n.toDouble());
      }
    }
    for (final e in logs.entries) {
      if (!e.key.startsWith('S0-') || !e.value.done || e.value.finishedAt == null) continue;
      final at = DateTime.tryParse(e.value.finishedAt!);
      if (at == null || at.isBefore(monday)) continue;
      final id = e.key.substring(4);
      final cs = customSessions.where((c) => c.id == id).toList();
      if (cs.isEmpty) continue;
      for (final it in cs.first.items) {
        final l = e.value.ex['CU-${it.uid}'];
        if (l == null) continue;
        final n = l.sets.where((x) => x.done).length;
        if (n > 0) add(groupsFor(it.name), n.toDouble());
      }
    }
    for (final w in wods) {
      for (final r in w.results) {
        final at = DateTime.tryParse(r.at);
        if (at == null || at.isBefore(monday)) continue;
        final rounds = w.type == 'rounds' && w.rounds > 0 ? w.rounds : (r.rounds ?? 1).clamp(1, 50);
        for (final line in w.lines) {
          add(groupsFor(line), 0.5 * rounds);
        }
      }
    }
    return out;
  }

  // ---------- Nature de la saisie ----------
  LogSpec logSpec(Exercise e) {
    final low = setsLabel(e).toLowerCase().trim();
    final nm = e.name.toLowerCase();
    final tp = e.tempo.toLowerCase();
    final tm = e.timer;
    if (tm != null) {
      switch (tm['type'] as String) {
        case 'hiit':
          return const LogSpec('interval');
        case 'emom':
          return LogSpec('emom',
              seconds: (tm['rounds'] as int) * (tm['interval'] as int));
        case 'amrap':
          return LogSpec('amrap', seconds: tm['sec'] as int);
        case 'hold':
          if (low.contains('intra')) {
            return LogSpec('reps',
                intra: tm['sec'] as int, cluster: true, rowPrefix: 'C');
          }
          return LogSpec('hold', seconds: tm['sec'] as int);
      }
    }
    if (e.interval != null) return const LogSpec('interval');
    final emom = RegExp(r'^emom\s*(\d+)\s*min').firstMatch(low);
    if (emom != null) {
      return LogSpec('emom', seconds: int.parse(emom.group(1)!) * 60);
    }
    if (low.contains('cluster')) {
      final mi = RegExp(r'\((\d+)\s*s intra\)').firstMatch(low);
      return LogSpec('reps',
          intra: mi == null ? 30 : int.parse(mi.group(1)!),
          cluster: true,
          rowPrefix: 'C');
    }
    if (low.contains('puis')) {
      return LogSpec('reps', intra: e.restSec ?? 10, myo: true, rowPrefix: 'M');
    }
    final hold = RegExp(r'^\d+\s*[×x]\s*(\d+)(?:-(\d+))?\s*s\b').firstMatch(low);
    if (hold != null) {
      return LogSpec('hold', seconds: int.parse(hold.group(2) ?? hold.group(1)!));
    }
    if (low.contains('max')) {
      final iso = tp.contains('isom') ||
          nm.contains('hang') ||
          nm.contains('hold') ||
          nm.contains('tenue');
      return LogSpec(iso ? 'holdMax' : 'repsMax');
    }
    final dur = RegExp(r'^(\d+)(?:-(\d+))?\s*min$').firstMatch(low);
    if (dur != null) {
      return LogSpec('duration',
          seconds: int.parse(dur.group(2) ?? dur.group(1)!) * 60);
    }
    if (low.contains('échelle')) return const LogSpec('reps', rowPrefix: 'É');
    if (low.contains('round')) return const LogSpec('reps', rowPrefix: 'R');
    if (low.contains('montée')) return const LogSpec('reps', rowPrefix: 'T');
    return const LogSpec('reps');
  }

  /// Reps prévues par ligne de série, déduites du libellé (null = pas de cible).
  /// « 5×4 » → 4 · « 3×12-15 » → 12 · « 4 × 17 reps » → 17 · myo : activation puis
  /// minis · clusters : reps par cluster · pyramide « 12-10-8-6 » · échelles « de 7 à 1 »
  /// → 28 · montée en singles → 1 · EMOM 12 min × 5 reps → 60.
  List<int?> plannedReps(Exercise e, LogSpec sp, int n) {
    final low = setsLabel(e).toLowerCase().trim();
    final out = List<int?>.filled(n, null);
    int? num(RegExp r, {int g = 1}) {
      final m = r.firstMatch(low);
      return m == null ? null : int.tryParse(m.group(g)!);
    }

    if (sp.kind == 'emom') {
      final c = RegExp(r'emom\s*(\d+)\s*[×x]\s*\d+\s*s.*?(\d+)\s*reps').firstMatch(low);
      final m = RegExp(r'(\d+)\s*min.*?(\d+)\s*reps').firstMatch(low);
      final mm = c ?? m;
      if (mm != null && n > 0) {
        out[0] = int.parse(mm.group(1)!) * int.parse(mm.group(2)!);
      }
      return out;
    }
    if (sp.kind != 'reps') return out;
    if (sp.myo) {
      final act = num(RegExp(r'^1\s*[×x]\s*(\d+)'));
      final mini = num(RegExp(r'puis\s*\d+\s*[×x]\s*\(?(\d+)'));
      for (var i = 0; i < n; i++) {
        out[i] = i == 0 ? act : mini;
      }
      return out;
    }
    if (sp.cluster) {
      final cm = RegExp(r'\((\d+)\s*[×x]\s*(\d+)\)').firstMatch(low);
      if (cm != null) {
        return List.filled(n, int.parse(cm.group(1)!) * int.parse(cm.group(2)!));
      }
      return List.filled(n, num(RegExp(r'^\d+\s*[×x]\s*(\d+)')));
    }
    if (RegExp(r'^\d+(?:\s*-\s*\d+){2,}$').hasMatch(low)) {
      final parts = low.split(RegExp(r'\s*-\s*')).map(int.tryParse).toList();
      for (var i = 0; i < n; i++) {
        out[i] = i < parts.length ? parts[i] : parts.last;
      }
      return out;
    }
    final lad = num(RegExp(r'de\s*(\d+)\s*à\s*1'));
    if (lad != null) return List.filled(n, lad * (lad + 1) ~/ 2);
    if (low.contains('montée')) return List.filled(n, 1);
    final std = num(RegExp(r'^\d+\s*[×x]\s*(\d+)'));
    if (std != null) return List.filled(n, std);
    return out;
  }

  /// Libellé de la ligne de série (Act / M1… · C1… · É1… · R1… · Mont./Tent.).
  String setLabel(LogSpec sp, int i) {
    if (sp.myo) return i == 0 ? 'Act' : 'M$i';
    switch (sp.rowPrefix) {
      case 'C':
        return 'C${i + 1}';
      case 'É':
        return 'É${i + 1}';
      case 'R':
        return 'R${i + 1}';
      case 'T':
        return i < 3 ? 'Mo${i + 1}' : 'T${i - 2}';
    }
    return '${i + 1}';
  }

  /// Repos à lancer après la série i (null = aucun chrono automatique).
  int? restAfterSet(Exercise e, LogSpec sp, int i, int total) {
    final r = e.rest.toLowerCase();
    if (r.contains('après') || r.contains('au total')) return null;
    final def = settings.defaultRest > 0 ? settings.defaultRest : null;
    if (sp.myo) return i < total - 1 ? sp.intra : def;
    return e.restSec ?? def;
  }

  /// Regroupe les exercices enchaînés (ex. dips → pompes) sur une même page.
  List<List<Exercise>> groups(DayPlan d) {
    final out = <List<Exercise>>[];
    var i = 0;
    while (i < d.exercises.length) {
      final e = d.exercises[i];
      if (i + 1 < d.exercises.length &&
          d.exercises[i + 1].name.toLowerCase().contains('enchaîn')) {
        out.add([e, d.exercises[i + 1]]);
        i += 2;
      } else {
        out.add([e]);
        i += 1;
      }
    }
    return out;
  }

  // ---------- Journal ----------
  String sessionKey(int week, int j) => 'S$week-J$j';

  SessionLog sessionLog(int week, int j) =>
      logs.putIfAbsent(sessionKey(week, j), () => SessionLog());

  ExerciseLog exLog(int week, int j, Exercise e) {
    final s = sessionLog(week, j);
    return s.ex.putIfAbsent(e.id, () {
      final n = setCount(e);
      return ExerciseLog(sets: List.generate(n, (_) => SetEntry()));
    });
  }

  Timer? _saveT;

  /// Persistance différée (600 ms) : l'encodage JSON du journal complet ne
  /// tourne plus sur le thread d'interface à chaque coche ou frappe.
  void saveLogs({bool immediate = false}) {
    _saveT?.cancel();
    if (immediate) {
      _flushLogs();
    } else {
      _saveT = Timer(const Duration(milliseconds: 600), _flushLogs);
    }
    notifyListeners();
  }

  void _flushLogs() {
    _saveT?.cancel();
    _saveT = null;
    _prefs.setString(_kLogs, jsonEncode(logs.map((k, v) => MapEntry(k, v.toJson()))));
  }

  /// À appeler quand l'app passe en arrière-plan.
  void flush() => _flushLogs();

  /// Efface tout l'historique d'une séance : séries, notes, statut « fait ».
  void clearSession(int week, int j) {
    logs.remove(sessionKey(week, j));
    saveLogs(immediate: true);
  }

  void markSessionDone(int week, int j, bool done, {String? title}) {
    final s = sessionLog(week, j);
    s.done = done;
    s.finishedAt = done ? DateTime.now().toIso8601String() : null;
    if (title != null) s.title = title;
    saveLogs(immediate: true);
  }

  bool isDone(int week, int j) => logs[sessionKey(week, j)]?.done ?? false;

  int get completedCount => logs.values.where((s) => s.done).length;
}

/// Singleton global — simple et suffisant pour cette app.
final AppStore store = AppStore();
