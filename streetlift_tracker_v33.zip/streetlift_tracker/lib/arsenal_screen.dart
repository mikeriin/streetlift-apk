import 'package:flutter/material.dart';

import 'builder_screen.dart';
import 'main.dart';
import 'levelup.dart';
import 'session_screen.dart';
import 'store.dart';
import 'wod_models.dart';
import 'wod_preview.dart';
import 'wod_catalog.dart';
import 'wod_screen.dart' show WodRunScreen, wodColor;

/// Onglet Arsenal — séances à la carte et WODs à débloquer. Même grammaire que l'accueil.
class ArsenalScreen extends StatelessWidget {
  const ArsenalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final sessions = store.customSessions;
        final wods = store.wods;
        final unlockedWods = [
          for (final w in wods)
            if (store.unlocked(w)) w,
        ]..sort(
          (a, b) =>
              a.level != b.level
                  ? a.level.compareTo(b.level)
                  : a.name.compareTo(b.name),
        );
        return Scaffold(
          appBar: AppBar(title: const Text('ARSENAL')),
          body: ListView(
            padding: const EdgeInsets.only(bottom: 24),
            children: [
              _Banner(
                nSessions: sessions.length,
                nUnlocked: unlockedWods.length,
                nCatalog: wods.length,
              ),
              _SectionHeader(
                title: 'SÉANCES À LA CARTE',
                actionLabel: 'Nouvelle',
                actionIcon: Icons.add,
                onAction: () => newCustomSession(context),
              ),
              if (sessions.isEmpty)
                _EmptyTile(
                  text:
                      'Compose une séance : 172 exercices, 8 modes d\u2019exécution.',
                  onTap: () => newCustomSession(context),
                )
              else
                for (final s in sessions) _SessionTile(session: s),
              _SectionHeader(
                title: 'MES WODS',
                actionLabel: 'Catalogue',
                actionIcon: Icons.grid_view_rounded,
                onAction:
                    () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const WodCatalogScreen(),
                      ),
                    ),
              ),
              if (unlockedWods.isEmpty)
                _EmptyTile(
                  text:
                      'Aucun WOD débloqué — ouvre le catalogue et dépense tes crédits.',
                  onTap:
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const WodCatalogScreen(),
                        ),
                      ),
                )
              else
                for (final w in unlockedWods) WodTile(wod: w),
            ],
          ),
        );
      },
    );
  }
}

// ----------------------------- bannière ---------------------------------

class _Banner extends StatelessWidget {
  final int nSessions;
  final int nUnlocked;
  final int nCatalog;
  const _Banner({
    required this.nSessions,
    required this.nUnlocked,
    required this.nCatalog,
  });

  @override
  Widget build(BuildContext context) {
    final c = SL.steel;
    final lp = store.levelProgress;
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 4),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [c.withValues(alpha: 0.85), c.withValues(alpha: 0.45)],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white70, width: 2),
            ),
            child: Text(
              '${store.level}',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${store.credits} CRÉDIT${store.credits > 1 ? 'S' : ''}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '$nSessions séance${nSessions > 1 ? 's' : ''} · $nUnlocked / $nCatalog WODs débloqués',
                  style: const TextStyle(color: Colors.white70, fontSize: 12.5),
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(3),
                  child: LinearProgressIndicator(
                    value: lp.need == 0 ? 0 : lp.inLevel / lp.need,
                    minHeight: 5,
                    backgroundColor: SL.dot,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  'Niveau ${store.level + 1} dans ${lp.need - lp.inLevel} XP → +1 crédit',
                  style: const TextStyle(color: Colors.white70, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ----------------------------- sections ---------------------------------

class _SectionHeader extends StatelessWidget {
  final String title;
  final String actionLabel;
  final IconData actionIcon;
  final VoidCallback onAction;
  const _SectionHeader({
    required this.title,
    required this.actionLabel,
    this.actionIcon = Icons.add,
    required this.onAction,
  });

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(18, 16, 8, 2),
    child: Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              color: SL.dim,
              fontSize: 11.5,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.7,
            ),
          ),
        ),
        TextButton.icon(
          style: TextButton.styleFrom(
            foregroundColor: SL.steel,
            minimumSize: const Size(48, 40),
          ),
          onPressed: onAction,
          icon: Icon(actionIcon, size: 18),
          label: Text(
            actionLabel,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5),
          ),
        ),
      ],
    ),
  );
}

class _EmptyTile extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _EmptyTile({required this.text, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(14),
      side: BorderSide(color: SL.line),
    ),
    color: Colors.transparent,
    child: InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        child: Row(
          children: [
            Icon(Icons.add_circle_outline, color: SL.dot),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                text,
                style: TextStyle(color: SL.dim, fontSize: 12.5, height: 1.4),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

// ----------------------------- tuiles -----------------------------------
// Tap = ouvrir · appui long = actions (même convention que l'accueil).

class _Tile extends StatelessWidget {
  final Widget badge;
  final String title;
  final String subtitle;
  final String? tag;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  const _Tile({
    required this.badge,
    required this.title,
    required this.subtitle,
    this.tag,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      leading: SizedBox(width: 42, height: 42, child: badge),
      title: Text(
        title.toUpperCase(),
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
      ),
      subtitle: Text(
        subtitle,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: 12, color: SL.dim, height: 1.3),
      ),
      trailing:
          tag != null
              ? Text(
                tag!,
                style: TextStyle(
                  color:
                      tag!.contains('CRÉDIT') ? SL.inputYellow : SL.mainGreen,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                ),
              )
              : Icon(Icons.chevron_right, color: SL.dim),
      onTap: onTap,
      onLongPress: onLongPress,
    ),
  );
}

Widget _badge(Color c, Widget child) => Container(
  alignment: Alignment.center,
  decoration: BoxDecoration(
    color: c.withValues(alpha: 0.18),
    borderRadius: BorderRadius.circular(12),
  ),
  child: child,
);

/// Feuille d'actions commune (Lancer / Modifier / Dupliquer / Supprimer).
Future<void> _actions(
  BuildContext context,
  String name, {
  VoidCallback? preview,
  required VoidCallback run,
  required VoidCallback edit,
  required VoidCallback dup,
  required VoidCallback del,
}) {
  return showModalBottomSheet(
    context: context,
    builder:
        (ctx) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    name.toUpperCase(),
                    style: const TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              if (preview != null)
                ListTile(
                  leading: Icon(Icons.insights, color: SL.inputYellow),
                  title: const Text('Aperçu (volume, muscles)'),
                  onTap: () {
                    Navigator.pop(ctx);
                    preview();
                  },
                ),
              ListTile(
                leading: Icon(Icons.play_arrow_rounded, color: SL.mainGreen),
                title: const Text('Lancer'),
                onTap: () {
                  Navigator.pop(ctx);
                  run();
                },
              ),
              ListTile(
                leading: Icon(Icons.edit_outlined, color: SL.steel),
                title: const Text('Modifier'),
                onTap: () {
                  Navigator.pop(ctx);
                  edit();
                },
              ),
              ListTile(
                leading: Icon(Icons.copy_outlined, color: SL.dim),
                title: const Text('Dupliquer'),
                onTap: () {
                  Navigator.pop(ctx);
                  dup();
                },
              ),
              ListTile(
                leading: Icon(Icons.delete_outline, color: SL.danger),
                title: Text('Supprimer', style: TextStyle(color: SL.danger)),
                onTap: () {
                  Navigator.pop(ctx);
                  del();
                },
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
  );
}

Future<void> _confirmDelete(
  BuildContext context,
  String what,
  VoidCallback onConfirm,
) => showDialog(
  context: context,
  builder:
      (ctx) => AlertDialog(
        title: const Text('Supprimer ?'),
        content: Text('$what Action irréversible.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Annuler'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: SL.danger,
              foregroundColor: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(ctx);
              onConfirm();
            },
            child: const Text('Supprimer'),
          ),
        ],
      ),
);

class _SessionTile extends StatelessWidget {
  final CustomSession session;
  const _SessionTile({required this.session});

  Future<void> _run(BuildContext context) async {
    if (session.items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Cette séance est vide : ajoute des exercices.'),
        ),
      );
      return;
    }
    if (store.isDone(0, int.parse(session.id))) {
      final repeat = await showDialog<bool>(
        context: context,
        builder:
            (ctx) => AlertDialog(
              title: const Text('Séance déjà terminée'),
              content: const Text(
                'Recommencer conserve le résultat précédent dans Suivi et prépare de nouvelles séries.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('Consulter'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text('Nouvelle séance'),
                ),
              ],
            ),
      );
      if (repeat == null || !context.mounted) return;
      if (repeat) store.restartCustomSession(session);
    }
    if (!context.mounted) return;
    final wp = session.toWeekPlan();
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SessionScreen(week: wp, day: wp.days.first),
      ),
    );
    if (context.mounted) checkLevelUp(context);
  }

  void _edit(BuildContext context) => Navigator.push(
    context,
    MaterialPageRoute(
      builder:
          (_) =>
              SessionEditor(session: CustomSession.fromJson(session.toJson())),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final s = session;
    final modes = s.items
        .map((e) => modeById(e.mode).label)
        .toSet()
        .join(' · ');
    final done = store.isDone(0, int.tryParse(s.id) ?? -1);
    return _Tile(
      badge: _badge(
        SL.steel,
        Text(
          '${s.items.length}',
          style: TextStyle(
            color: SL.steel,
            fontWeight: FontWeight.w900,
            fontSize: 16,
          ),
        ),
      ),
      title: s.name,
      subtitle:
          '${s.items.length} exercice${s.items.length > 1 ? 's' : ''}${modes.isEmpty ? '' : ' · $modes'}',
      tag: done ? 'FAIT ✓' : null,
      onTap: () => _run(context),
      onLongPress:
          () => _actions(
            context,
            s.name,
            run: () => _run(context),
            edit: () => _edit(context),
            dup: () => store.duplicateSession(s),
            del:
                () => _confirmDelete(
                  context,
                  '« ${s.name} » et son historique seront effacés.',
                  () => store.deleteSession(s),
                ),
          ),
    );
  }
}

const _wodAbbr = {
  'fortime': 'FT',
  'rounds': 'RDS',
  'amrap': 'AMR',
  'emom': 'EMO',
  'routine': 'RTN',
};

class WodTile extends StatelessWidget {
  final Wod wod;
  const WodTile({super.key, required this.wod});

  void _run(BuildContext context) {
    if (!store.unlocked(wod)) {
      _preview(context);
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => WodRunScreen(wodId: wod.id)),
    );
  }

  void _preview(BuildContext context) => Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => WodPreviewScreen(wodId: wod.id)),
  );

  @override
  Widget build(BuildContext context) {
    final w = wod;
    final locked = !store.unlocked(w);
    final cost = store.wodCost(w);
    final c = locked ? SL.dim : wodColor(w.type);
    final best = w.best();
    final st = store.wodStats(w);
    final sub =
        '${w.typeLabel} · niv. ${w.level} · ${st.points} pts · ~${st.minutes} min${locked ? '' : ' · ${w.lines.take(2).join(' · ')}'}';
    return _Tile(
      badge: _badge(
        c,
        locked
            ? Icon(Icons.lock_outline, color: SL.dim, size: 20)
            : Text(
              _wodAbbr[w.type] ?? 'WOD',
              style: TextStyle(
                color: c,
                fontWeight: FontWeight.w900,
                fontSize: 11.5,
              ),
            ),
      ),
      title: w.name,
      subtitle: sub,
      tag: locked ? '$cost CRÉDIT${cost > 1 ? 'S' : ''}' : best?.score,
      onTap: () => _run(context),
      onLongPress:
          () => showModalBottomSheet(
            context: context,
            builder:
                (ctx) => SafeArea(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            w.name.toUpperCase(),
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ),
                      ListTile(
                        leading: Icon(Icons.insights, color: SL.inputYellow),
                        title: const Text(
                          'Aperçu : points, muscles, mouvements',
                        ),
                        onTap: () {
                          Navigator.pop(ctx);
                          _preview(context);
                        },
                      ),
                      if (!locked)
                        ListTile(
                          leading: Icon(
                            Icons.play_arrow_rounded,
                            color: SL.mainGreen,
                          ),
                          title: const Text('Lancer'),
                          onTap: () {
                            Navigator.pop(ctx);
                            _run(context);
                          },
                        ),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
          ),
    );
  }
}
