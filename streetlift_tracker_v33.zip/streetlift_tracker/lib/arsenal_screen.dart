import 'package:flutter/material.dart';

import 'builder_screen.dart';
import 'app_theme.dart';
import 'ui.dart';
import 'levelup.dart';
import 'session_screen.dart';
import 'store.dart';
import 'wod_models.dart';
import 'wod_preview.dart';
import 'wod_catalog.dart';
import 'wod_screen.dart' show WodRunScreen, wodColor;

/// Onglet Arsenal — séances à la carte et WODs à débloquer. Même grammaire que l'accueil.
class ArsenalScreen extends StatelessWidget {
  const ArsenalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final sessions = store.customSessions;
        final wods = store.wods;
        final unlockedWods = [
          for (final w in wods)
            if (store.unlocked(w)) w,
        ]..sort(
          (a, b) =>
              a.level != b.level
                  ? a.level.compareTo(b.level)
                  : a.name.compareTo(b.name),
        );
        return KScreen(
          appBar: const KTopBar(),
          body: KList(
            padding: KSpace.content,
            children: [
              const KPageIntro(
                'Arsenal',
                'Tes séances. Tes défis. Ton rythme.',
              ),
              const _Credits(),
              KActionRow(
                minButtonWidth: 160,
                children: [
                  FilledButton.icon(
                    onPressed: () => newCustomSession(context),
                    icon: const Icon(Icons.add),
                    label: const Text('Nouvelle séance'),
                  ),
                ],
              ),
              KSection(
                'Mes séances',
                subtitle:
                    sessions.isEmpty
                        ? 'Aucune séance enregistrée'
                        : '${sessions.length} séance${sessions.length > 1 ? 's' : ''} personnelle${sessions.length > 1 ? 's' : ''}',
              ),
              if (sessions.isEmpty)
                _EmptyTile(
                  title: 'Ta première séance',
                  action: 'Créer une séance',
                  text:
                      'Choisis tes exercices, leur mode d’exécution et les temps de repos.',
                  onTap: () => newCustomSession(context),
                )
              else
                for (final s in sessions) _SessionTile(session: s),
              _SectionHeader(
                title: 'Mes WODs',
                actionLabel: 'Catalogue',
                actionIcon: Icons.grid_view_rounded,
                onAction:
                    () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const WodCatalogScreen(),
                      ),
                    ),
              ),
              if (unlockedWods.isEmpty)
                _EmptyTile(
                  title: 'Ton premier WOD',
                  action: 'Ouvrir le catalogue',
                  text:
                      'Achète tes WODs avec les crédits gagnés en progressant. Chaque WOD reste ensuite disponible dans ton arsenal.',
                  onTap:
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const WodCatalogScreen(),
                        ),
                      ),
                )
              else
                for (final w in unlockedWods) WodTile(wod: w),
            ],
          ),
        );
      },
    );
  }
}

// ----------------------------- bannière ---------------------------------

class _Credits extends StatelessWidget {
  const _Credits();

  @override
  Widget build(BuildContext context) => KMenuTile(
    icon: Icons.toll_rounded,
    title: '${store.credits} crédit${store.credits > 1 ? 's' : ''} WOD',
    subtitle: 'À utiliser dans le catalogue',
    onTap:
        () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const WodCatalogScreen()),
        ),
  );
}

// ----------------------------- sections ---------------------------------

class _SectionHeader extends StatelessWidget {
  final String title;
  final String actionLabel;
  final IconData actionIcon;
  final VoidCallback onAction;
  const _SectionHeader({
    required this.title,
    required this.actionLabel,
    this.actionIcon = Icons.add,
    required this.onAction,
  });

  @override
  Widget build(BuildContext context) => KSection(
    title,
    actionLabel: actionLabel,
    actionIcon: actionIcon,
    onAction: onAction,
  );
}

class _EmptyTile extends StatelessWidget {
  final String text, title, action;
  final VoidCallback onTap;
  const _EmptyTile({
    required this.text,
    required this.onTap,
    required this.title,
    required this.action,
  });
  @override
  Widget build(BuildContext context) => KEmpty(
    icon: Icons.add_circle_outline,
    title: title,
    message: text,
    action: action,
    onAction: onTap,
  );
}

// ----------------------------- tuiles -----------------------------------
// Tap = ouvrir · appui long = actions (même convention que l'accueil).

class _Tile extends StatelessWidget {
  final Widget badge;
  final String title;
  final String subtitle;
  final String? tag;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  const _Tile({
    required this.badge,
    required this.title,
    required this.subtitle,
    this.tag,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) => KCard(
    onTap: onTap,
    onLongPress: onLongPress,
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(width: 36, height: 36, child: badge),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall,
              ),
              if (tag != null) ...[
                const SizedBox(height: 4),
                // Séance faite : validation en vert ; prix et record : accent.
                KBadge(
                  tag!.toLowerCase(),
                  color: tag!.contains('FAIT') ? SL.success : SL.accent,
                ),
              ],
            ],
          ),
        ),
        IconButton(
          tooltip: 'Actions pour $title',
          onPressed: onLongPress,
          icon: const Icon(Icons.more_vert),
        ),
      ],
    ),
  );
}

Widget _badge(Color c, Widget child) => Container(
  alignment: Alignment.center,
  decoration: BoxDecoration(
    color: c.withValues(alpha: 0.18),
    borderRadius: BorderRadius.circular(22),
  ),
  child: child,
);

/// Feuille d'actions commune (Lancer / Modifier / Dupliquer / Supprimer).
Future<void> _actions(
  BuildContext context,
  String name, {
  VoidCallback? preview,
  required VoidCallback run,
  required VoidCallback edit,
  required VoidCallback dup,
  required VoidCallback del,
}) {
  return showModalBottomSheet(
    context: context,
    builder:
        (ctx) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    name,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              if (preview != null)
                ListTile(
                  leading: Icon(Icons.insights, color: SL.dim),
                  title: const Text('Aperçu (volume, muscles)'),
                  onTap: () {
                    Navigator.pop(ctx);
                    preview();
                  },
                ),
              ListTile(
                leading: Icon(Icons.play_arrow_rounded, color: SL.accent),
                title: const Text('Lancer'),
                onTap: () {
                  Navigator.pop(ctx);
                  run();
                },
              ),
              ListTile(
                leading: Icon(Icons.edit_outlined, color: SL.dim),
                title: const Text('Modifier'),
                onTap: () {
                  Navigator.pop(ctx);
                  edit();
                },
              ),
              ListTile(
                leading: Icon(Icons.copy_outlined, color: SL.dim),
                title: const Text('Dupliquer'),
                onTap: () {
                  Navigator.pop(ctx);
                  dup();
                },
              ),
              ListTile(
                leading: Icon(Icons.delete_outline, color: SL.danger),
                title: Text('Supprimer', style: TextStyle(color: SL.danger)),
                onTap: () {
                  Navigator.pop(ctx);
                  del();
                },
              ),
              const SizedBox(height: 4),
            ],
          ),
        ),
  );
}

Future<void> _confirmDelete(
  BuildContext context,
  String what,
  VoidCallback onConfirm,
) => showDialog(
  context: context,
  builder:
      (ctx) => AlertDialog(
        title: const Text('Supprimer ?'),
        content: Text('$what Action irréversible.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Annuler'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: SL.action,
              foregroundColor: KPalette.light,
            ),
            onPressed: () {
              Navigator.pop(ctx);
              onConfirm();
            },
            child: const Text('Supprimer'),
          ),
        ],
      ),
);

class _SessionTile extends StatelessWidget {
  final CustomSession session;
  const _SessionTile({required this.session});

  Future<void> _run(BuildContext context) async {
    if (session.items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Cette séance est vide : ajoute des exercices.'),
        ),
      );
      return;
    }
    if (store.isDone(0, int.parse(session.id))) {
      final repeat = await showDialog<bool>(
        context: context,
        builder:
            (ctx) => AlertDialog(
              title: const Text('Séance déjà terminée'),
              content: const Text(
                'Recommencer conserve le résultat précédent dans STATS → Historique et prépare de nouvelles séries.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('Consulter'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text('Nouvelle séance'),
                ),
              ],
            ),
      );
      if (repeat == null || !context.mounted) return;
      if (repeat) store.restartCustomSession(session);
    }
    if (!context.mounted) return;
    final wp = session.toWeekPlan();
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SessionScreen(week: wp, day: wp.days.first),
      ),
    );
    if (context.mounted) checkLevelUp(context);
  }

  void _edit(BuildContext context) => Navigator.push(
    context,
    MaterialPageRoute(
      builder:
          (_) =>
              SessionEditor(session: CustomSession.fromJson(session.toJson())),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final s = session;
    final modes = s.items
        .map((e) => modeById(e.mode).label)
        .toSet()
        .join(' · ');
    final done = store.isDone(0, int.tryParse(s.id) ?? -1);
    return _Tile(
      badge: _badge(
        SL.accent,
        Text(
          '${s.items.length}',
          style: TextStyle(
            color: SL.accent,
            fontWeight: FontWeight.w700,
            fontSize: 16,
          ),
        ),
      ),
      title: s.name,
      subtitle:
          '${s.items.length} exercice${s.items.length > 1 ? 's' : ''}${modes.isEmpty ? '' : ' · $modes'}',
      tag: done ? 'FAIT ✓' : null,
      onTap: () => _run(context),
      onLongPress:
          () => _actions(
            context,
            s.name,
            run: () => _run(context),
            edit: () => _edit(context),
            dup: () => store.duplicateSession(s),
            del:
                () => _confirmDelete(
                  context,
                  '« ${s.name} » et son historique seront effacés.',
                  () => store.deleteSession(s),
                ),
          ),
    );
  }
}

const _wodAbbr = {
  'fortime': 'FT',
  'rounds': 'RDS',
  'amrap': 'AMR',
  'emom': 'EMO',
  'routine': 'RTN',
};

class WodTile extends StatelessWidget {
  final Wod wod;
  const WodTile({super.key, required this.wod});

  void _run(BuildContext context) {
    if (!store.unlocked(wod)) {
      _preview(context);
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => WodRunScreen(wodId: wod.id)),
    );
  }

  void _preview(BuildContext context) => Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => WodPreviewScreen(wodId: wod.id)),
  );

  @override
  Widget build(BuildContext context) {
    final w = wod;
    final locked = !store.unlocked(w);
    final cost = store.wodCost(w);
    final c = locked ? SL.dim : wodColor(w.type);
    final best = w.best();
    final estimate = store.wodEstimate(w);
    final sub =
        '${w.typeLabel} · niv. ${w.level} · ${estimate.durationLabel}${locked ? '' : ' · ${w.lines.take(2).join(' · ')}'}';
    return _Tile(
      badge: _badge(
        c,
        locked
            ? Icon(Icons.lock_outline, color: SL.dim, size: 20)
            : Text(
              _wodAbbr[w.type] ?? 'WOD',
              style: TextStyle(
                color: c,
                fontWeight: FontWeight.w700,
                fontSize: 11.5,
              ),
            ),
      ),
      title: w.name,
      subtitle: sub,
      tag: locked ? '$cost CRÉDIT${cost > 1 ? 'S' : ''}' : best?.score,
      onTap: () => _run(context),
      onLongPress:
          () => showModalBottomSheet(
            context: context,
            builder:
                (ctx) => SafeArea(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            w.name,
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ),
                      ListTile(
                        leading: Icon(Icons.insights, color: SL.dim),
                        title: const Text('Aperçu : volume, durée et muscles'),
                        onTap: () {
                          Navigator.pop(ctx);
                          _preview(context);
                        },
                      ),
                      if (!locked)
                        ListTile(
                          leading: Icon(
                            Icons.play_arrow_rounded,
                            color: SL.accent,
                          ),
                          title: const Text('Lancer'),
                          onTap: () {
                            Navigator.pop(ctx);
                            _run(context);
                          },
                        ),
                      const SizedBox(height: 4),
                    ],
                  ),
                ),
          ),
    );
  }
}
