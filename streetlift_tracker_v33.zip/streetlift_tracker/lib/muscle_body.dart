// Carte des groupes musculaires travaillés (silhouettes face / dos, façon Strava).
import 'package:flutter/material.dart';

import 'main.dart';

/// Couleur d'intensité : de l'acier (léger) au rouge (lourd).
Color heat(double t) {
  if (t <= 0) return SL.faint;
  final c = Color.lerp(SL.steel, SL.danger, t.clamp(0, 1))!;
  return c.withOpacity(0.55 + 0.45 * t.clamp(0, 1));
}

class MuscleHeatmap extends StatelessWidget {
  final Map<String, double> data;
  const MuscleHeatmap({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final max = data.values.fold<double>(0, (a, b) => b > a ? b : a);
    final t = {for (final e in data.entries) e.key: max == 0 ? 0.0 : e.value / max};
    return SizedBox(
      height: 270,
      child: Row(
        children: [
          Expanded(child: CustomPaint(painter: _BodyPainter(t, front: true), child: const SizedBox.expand())),
          Expanded(child: CustomPaint(painter: _BodyPainter(t, front: false), child: const SizedBox.expand())),
        ],
      ),
    );
  }
}

class _BodyPainter extends CustomPainter {
  final Map<String, double> t;
  final bool front;
  _BodyPainter(this.t, {required this.front});

  // Système de coordonnées : 120 × 250, centré horizontalement.
  @override
  void paint(Canvas canvas, Size size) {
    final s = (size.height / 250).clamp(0.0, size.width / 120);
    canvas.save();
    canvas.translate((size.width - 120 * s) / 2, (size.height - 250 * s) / 2);
    canvas.scale(s);

    final base = Paint()..color = SL.faint;
    final edge = Paint()
      ..color = SL.dot
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    // ---- silhouette ----
    final body = Path();
    body.addOval(Rect.fromCircle(center: const Offset(60, 22), radius: 13)); // tête
    body.addRRect(RRect.fromRectAndRadius(const Rect.fromLTRB(54, 33, 66, 46), const Radius.circular(4))); // cou
    body.addRRect(RRect.fromRectAndRadius(const Rect.fromLTRB(36, 44, 84, 122), const Radius.circular(14))); // tronc
    for (final x in [18.0, 86.0]) {
      body.addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x, 50, 16, 42), const Radius.circular(8))); // bras
      body.addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 1, 92, 15, 40), const Radius.circular(7))); // avant-bras
      body.addOval(Rect.fromLTWH(x - 2, 131, 16, 12)); // main
    }
    for (final x in [39.0, 62.0]) {
      body.addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x, 120, 19, 62), const Radius.circular(9))); // cuisse
      body.addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x + 2, 182, 15, 54), const Radius.circular(7))); // mollet
      body.addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x + 1, 236, 17, 9), const Radius.circular(4))); // pied
    }
    canvas.drawPath(body, base);
    canvas.drawPath(body, edge);

    // ---- régions ----
    void region(String g, Path p) {
      final v = t[g] ?? 0;
      if (v <= 0) return;
      canvas.drawPath(p, Paint()..color = heat(v));
    }
    Path oval(Rect r) => Path()..addOval(r);
    Path rr(Rect r, double rad) => Path()..addRRect(RRect.fromRectAndRadius(r, Radius.circular(rad)));

    // épaules et avant-bras : visibles des deux côtés
    region('épaules', oval(const Rect.fromLTWH(27, 44, 18, 16))..addOval(const Rect.fromLTWH(75, 44, 18, 16)));
    region('avant-bras', rr(const Rect.fromLTWH(18, 95, 13, 34), 6)..addRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(89, 95, 13, 34), const Radius.circular(6))));
    if (front) {
      region('pectoraux', rr(const Rect.fromLTWH(40, 52, 19, 20), 8)..addRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(61, 52, 19, 20), const Radius.circular(8))));
      region('biceps', rr(const Rect.fromLTWH(20, 58, 12, 30), 6)..addRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(88, 58, 12, 30), const Radius.circular(6))));
      region('gainage', rr(const Rect.fromLTWH(47, 76, 26, 42), 8));
      region('quadriceps', rr(const Rect.fromLTWH(41, 124, 15, 54), 7)..addRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(64, 124, 15, 54), const Radius.circular(7))));
    } else {
      region('dos', rr(const Rect.fromLTWH(40, 50, 40, 24), 8)..addRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(38, 76, 20, 34), const Radius.circular(8)))..addRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(62, 76, 20, 34), const Radius.circular(8))));
      region('triceps', rr(const Rect.fromLTWH(20, 58, 12, 30), 6)..addRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(88, 58, 12, 30), const Radius.circular(6))));
      region('fessiers', rr(const Rect.fromLTWH(42, 116, 17, 22), 8)..addRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(61, 116, 17, 22), const Radius.circular(8))));
      region('ischios', rr(const Rect.fromLTWH(41, 140, 15, 40), 7)..addRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(64, 140, 15, 40), const Radius.circular(7))));
      region('mollets', rr(const Rect.fromLTWH(43, 186, 13, 40), 6)..addRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(64, 186, 13, 40), const Radius.circular(6))));
    }

    // libellé
    final tp = TextPainter(
      text: TextSpan(text: front ? 'FACE' : 'DOS', style: TextStyle(color: SL.dim, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, Offset(60 - tp.width / 2, 246 - tp.height + 4));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _BodyPainter old) => old.t != t || old.front != front;
}
