// Carte des groupes musculaires — atlas vectoriel anatomique v2 (40 muscles par face).
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'main.dart';
import 'muscle_atlas.dart';

/// Rampe de chaleur : jaune (léger) → rouge (intense), dans la charte.
Color heat(double t) {
  final v = t.clamp(0.0, 1.0);
  if (v <= 0) return SL.faint;
  final mid = Color.lerp(SL.inputYellow, const Color(0xFFE8873A), (v * 2).clamp(0.0, 1.0))!;
  return v < 0.5 ? mid : Color.lerp(const Color(0xFFE8873A), SL.danger, (v - 0.5) * 2)!;
}

/// Parseur minimal des chemins générés (commandes absolues M, C, Z).
Path _svgPath(String d) {
  final p = Path();
  final tk = d.split(' ').where((s) => s.isNotEmpty).toList();
  var i = 0;
  double n() => double.parse(tk[i++]);
  while (i < tk.length) {
    final c = tk[i++];
    if (c == 'M') {
      p.moveTo(n(), n());
    } else if (c == 'C') {
      p.cubicTo(n(), n(), n(), n(), n(), n());
    } else if (c == 'Z') {
      p.close();
    }
  }
  return p;
}

final Path _silhouette = _svgPath(atlasSilhouette);
final Path _head = _svgPath(atlasHead);
final List<(String, Path)> _front = [for (final e in atlasFront) (e.$1, _svgPath(e.$3))];
final List<(String, Path)> _back = [for (final e in atlasBack) (e.$1, _svgPath(e.$3))];

class MuscleHeatmap extends StatelessWidget {
  final Map<String, double> data;
  final double height;
  final bool labels;
  const MuscleHeatmap({super.key, required this.data, this.height = 300, this.labels = true});

  @override
  Widget build(BuildContext context) {
    final max = data.values.fold<double>(0, (a, b) => b > a ? b : a);
    final t = {for (final e in data.entries) e.key: max == 0 ? 0.0 : e.value / max};
    return SizedBox(
      height: height,
      child: Row(
        children: [
          Expanded(child: CustomPaint(painter: _BodyPainter(t, front: true, labels: labels), child: const SizedBox.expand())),
          Expanded(child: CustomPaint(painter: _BodyPainter(t, front: false, labels: labels), child: const SizedBox.expand())),
        ],
      ),
    );
  }
}

class _BodyPainter extends CustomPainter {
  final Map<String, double> t;
  final bool front;
  final bool labels;
  _BodyPainter(this.t, {required this.front, required this.labels});

  @override
  void paint(Canvas canvas, Size size) {
    final s = (size.height / 420).clamp(0.0, size.width / 200);
    canvas.save();
    canvas.translate((size.width - 200 * s) / 2, (size.height - 420 * s) / 2);
    canvas.scale(s);

    final dark = SL.dark;
    final skin = Paint()..color = dark ? const Color(0xFF262E36) : const Color(0xFFD9E0E6);
    final restMuscle = Paint()..color = dark ? const Color(0xFF3C4650) : const Color(0xFFC3CCD3);
    final sep = Paint()
      ..color = SL.bg
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;

    canvas.drawPath(_silhouette, skin);
    canvas.drawPath(_head, skin);

    final muscles = front ? _front : _back;
    // 1) halo doux sous les muscles chauds
    for (final (g, p) in muscles) {
      final v = t[g] ?? 0;
      if (v <= 0.05) continue;
      canvas.drawPath(
        p,
        Paint()
          ..color = heat(v).withOpacity(0.35 * v)
          ..maskFilter = ui.MaskFilter.blur(ui.BlurStyle.normal, 5 + 6 * v),
      );
    }
    // 2) muscles : gris défini ou couleur de chaleur, séparés par un fin trait
    for (final (g, p) in muscles) {
      final v = t[g] ?? 0;
      canvas.drawPath(p, v <= 0 ? restMuscle : (Paint()..color = heat(v)));
      canvas.drawPath(p, sep);
    }
    // 3) léger relief : reflet supérieur sur chaque muscle
    for (final (g, p) in muscles) {
      final v = t[g] ?? 0;
      final b = p.getBounds();
      final shader = ui.Gradient.linear(
        b.topCenter,
        b.bottomCenter,
        [Colors.white.withOpacity(v > 0 ? 0.28 : 0.12), Colors.transparent, Colors.black.withOpacity(v > 0 ? 0.16 : 0.08)],
        const [0.0, 0.55, 1.0],
      );
      canvas.drawPath(p, Paint()..shader = shader);
    }

    if (labels) {
      final tp = TextPainter(
        text: TextSpan(text: front ? 'FACE' : 'DOS', style: TextStyle(color: SL.dim, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(100 - tp.width / 2, 404));
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _BodyPainter old) => old.t != t || old.front != front || old.labels != labels;
}

/// Légende : groupes classés, puce colorée selon l'intensité relative.
class MuscleLegend extends StatelessWidget {
  final Map<String, double> data;
  const MuscleLegend({super.key, required this.data});
  @override
  Widget build(BuildContext context) {
    final ranked = data.entries.where((e) => e.value > 0).toList()..sort((a, b) => b.value.compareTo(a.value));
    if (ranked.isEmpty) return const SizedBox.shrink();
    final max = ranked.first.value;
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: [
        for (final e in ranked)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: BoxDecoration(color: SL.faint, borderRadius: BorderRadius.circular(8)),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 8, height: 8, decoration: BoxDecoration(color: heat(e.value / max), shape: BoxShape.circle)),
                const SizedBox(width: 6),
                Text('${e.key[0].toUpperCase()}${e.key.substring(1)}', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: SL.text)),
              ],
            ),
          ),
      ],
    );
  }
}
