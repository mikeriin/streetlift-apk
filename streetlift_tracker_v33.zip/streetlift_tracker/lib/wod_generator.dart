// Générateur déterministe de WODs : aucune donnée stockée, le catalogue se
// recalcule à l'identique à chaque lancement (Random à graine fixe par index).
// Les WODs générés s'inspirent des formats et mouvements présents dans l'app.
import 'dart:math';

import 'wod_models.dart';

class _Mv {
  final String n; // libellé
  final int tier; // difficulté d'accès 1-10
  final int base; // reps de base au tier 5
  final Set<String> eq; // pdc · barre · lest · erg · kb · box · corde
  const _Mv(this.n, this.tier, this.base, this.eq);
}

const _pull = [
  _Mv('rows barre basse', 1, 12, {'barre'}),
  _Mv('pull-ups', 2, 8, {'barre'}),
  _Mv('chin-ups', 2, 8, {'barre'}),
  _Mv('toes-to-bar', 3, 10, {'barre'}),
  _Mv('tractions lestées 10 kg', 6, 5, {'barre', 'lest'}),
  _Mv('muscle-ups', 7, 3, {'barre'}),
  _Mv('tractions lestées 20 kg', 8, 4, {'barre', 'lest'}),
];
const _push = [
  _Mv('push-ups', 1, 15, {'pdc'}),
  _Mv('diamond push-ups', 3, 12, {'pdc'}),
  _Mv('dips', 3, 10, {'barre'}),
  _Mv('pike push-ups', 3, 10, {'pdc'}),
  _Mv('archer push-ups', 5, 8, {'pdc'}),
  _Mv('dips lestés 10 kg', 6, 6, {'barre', 'lest'}),
  _Mv('HSPU', 7, 5, {'pdc'}),
  _Mv('dips lestés 20 kg', 8, 5, {'barre', 'lest'}),
];
const _legs = [
  _Mv('air squats', 1, 20, {'pdc'}),
  _Mv('walking lunges', 1, 16, {'pdc'}),
  _Mv('squat jumps', 2, 12, {'pdc'}),
  _Mv('box jumps', 2, 12, {'box'}),
  _Mv('jumping lunges', 3, 14, {'pdc'}),
  _Mv('goblet squats 24 kg', 4, 12, {'kb'}),
  _Mv('sandbag lunges 20 kg', 5, 12, {'kb'}),
  _Mv('pistol squats', 6, 6, {'pdc'}),
];
const _core = [
  _Mv('sit-ups', 1, 20, {'pdc'}),
  _Mv('plank shoulder taps', 1, 20, {'pdc'}),
  _Mv('hollow rocks', 2, 15, {'pdc'}),
  _Mv('V-ups', 3, 12, {'pdc'}),
  _Mv('leg raises', 3, 12, {'barre'}),
  _Mv('dragon flags', 7, 5, {'pdc'}),
];
const _meta = [
  _Mv('mountain climbers', 1, 30, {'pdc'}),
  _Mv('burpees', 2, 10, {'pdc'}),
  _Mv('kettlebell swings 24 kg', 3, 15, {'kb'}),
  _Mv('wall balls 6 kg', 3, 15, {'kb'}),
  _Mv('double-unders', 3, 30, {'corde'}),
  _Mv('burpees over the box', 4, 8, {'box'}),
  _Mv('devil press 2×15 kg', 6, 8, {'kb'}),
];
const _dist = [
  _Mv('200 m run', 1, 200, {'run'}),
  _Mv('250 m row', 2, 250, {'erg'}),
  _Mv('400 m run', 2, 400, {'run'}),
  _Mv('500 m row', 3, 500, {'erg'}),
  _Mv('500 m skierg', 3, 500, {'erg'}),
  _Mv('15 cal bike', 3, 15, {'erg'}),
  _Mv('50 m farmer carry 2×24 kg', 4, 50, {'kb'}),
];

const _names = [
  'Sentinelle', 'Bastion', 'Vigie', 'Rafale', 'Garde', 'Éclaireur', 'Rempart', 'Assaut', 'Colonne', 'Bivouac',
  'Tarmac', 'Corvée', 'Réveil', 'Hydra', 'Atlas', 'Titan', 'Cobra', 'Viper', 'Enclume', 'Forge',
  'Sierra', 'Tango', 'Kilo', 'Delta', 'Bravo', 'Écho', 'Foxtrot', 'Lima', 'Oscar', 'Romeo',
  'Zulu', 'Alpha', 'Charlie', 'Golf', 'Hotel', 'India', 'Juliett', 'Mike', 'Papa', 'Quebec',
  'Uniform', 'Victor', 'Whiskey', 'Yankee', 'Meute', 'Bunker', 'Casemate', 'Guérite', 'Merlon', 'Barbacane',
];

/// Nombre de WODs générés pour compléter le catalogue à 500.
int generatedCount(int curated) => (500 - curated).clamp(0, 500);

/// Génère `count` WODs distincts (déduplication sur format + mouvements).
List<Wod> generateWods(int count) {
  final out = <Wod>[];
  final seen = <String>{};
  var i = 0;
  while (out.length < count && i < count * 4) {
    final w = generateWod(i++);
    if (seen.add('${w.type}|${w.scheme}|${w.lines.join('|')}')) out.add(w);
  }
  return out;
}

Wod generateWod(int i) {
  final r = Random(7919 * i + 104729);
  final tier = 1 + (i % 10); // 1..10 répartis uniformément
  final family = i % 6; // format
  int pick(List<_Mv> pool, Set<String> used) {
    final ok = [for (var k = 0; k < pool.length; k++) if (pool[k].tier <= tier + 1 && pool[k].tier >= (tier - 5).clamp(1, 10) && !used.contains(pool[k].n)) k];
    final cands = ok.isEmpty ? [for (var k = 0; k < pool.length; k++) if (pool[k].tier <= tier + 1) k] : ok;
    return cands[r.nextInt(cands.length)];
  }

  // volume : tier 1 ≈ 60 % de la base, tier 10 ≈ 170 %
  int reps(_Mv m, [double mult = 1]) {
    final f = 0.6 + (tier - 1) * 0.12;
    return max(1, (m.base * f * mult).round());
  }

  String line(_Mv m, [double mult = 1]) {
    if (m.eq.contains('run') || m.eq.contains('erg')) return m.n; // distance fixe
    return '${reps(m, mult)} ${m.n}';
  }

  final used = <String>{};
  _Mv take(List<_Mv> pool) {
    final m = pool[pick(pool, used)];
    used.add(m.n);
    return m;
  }

  final name = '${_names[i % _names.length]} ${(i ~/ _names.length + 1).toString().padLeft(2, '0')}';
  final id = 'gen$i';
  switch (family) {
    case 0: // rounds for time
      final n = 3 + r.nextInt(3) + (tier >= 7 ? 1 : 0);
      final pool = [take(_pull), take(_push), take(_legs), if (r.nextBool()) take(_core) else take(_meta)];
      return Wod(id: id, name: name, type: 'rounds', rounds: n, restSec: tier <= 3 ? 60 : 0, source: 'kalis',
          lines: [for (final m in pool) line(m)], notes: 'Rounds réguliers : garde de la marge sur le premier.');
    case 1: // chipper for time
      final pool = [take(_meta), take(_pull), take(_push), take(_legs), take(_core), take(_meta)];
      return Wod(id: id, name: name, type: 'fortime', source: 'kalis',
          lines: [for (final m in pool) line(m, 2.0)], minutes: 12 + tier * 2, notes: 'Chipper : chaque mouvement une seule fois, dans l\u2019ordre.');
    case 2: // ladder
      final schemes = ['21-15-9', '15-12-9', '10-8-6-4-2', '12-9-6', '20-16-12-8-4'];
      final scheme = schemes[r.nextInt(schemes.length)];
      final pool = [take(_pull), take(_push), if (tier >= 4) take(_meta) else take(_legs)];
      return Wod(id: id, name: name, type: 'fortime', scheme: scheme, source: 'kalis',
          lines: [for (final m in pool) m.n], notes: 'Schéma $scheme de chaque mouvement, enchaîné.');
    case 3: // amrap
      final min = 8 + 2 * r.nextInt(5) + (tier >= 6 ? 4 : 0);
      final pool = [take(_meta), take(_push), take(_legs), if (tier >= 3) take(_pull)];
      return Wod(id: id, name: name, type: 'amrap', minutes: min, source: 'kalis',
          lines: [for (final m in pool) line(m, 0.6)], notes: 'Rythme tenable dès le premier round ; score = rounds + reps.');
    case 4: // emom
      final rounds = 10 + 2 * r.nextInt(4) + (tier >= 7 ? 4 : 0);
      final pool = [take(_pull), take(_push), take(_legs)];
      return Wod(id: id, name: name, type: 'emom', rounds: rounds, interval: 60, source: 'kalis',
          lines: [for (var k = 0; k < pool.length; k++) 'min ${k + 1}, ${k + 4}, ${k + 7}… : ${line(pool[k], 0.5)}'],
          notes: 'Un mouvement par minute, en rotation. Si une minute déborde, réduis de 2 reps.');
    default: // routine : blocs enchaînés avec repos
      final a = take(_pull), b = take(_push), c = take(_legs), d = take(_dist);
      final sets = 3 + (tier >= 5 ? 1 : 0);
      return Wod(id: id, name: name, type: 'routine', restSec: 90, source: 'kalis',
          lines: ['$sets × (${line(a, 0.7)} + ${line(b, 0.7)}) · repos 90 s', '$sets × (${line(c, 0.9)} + ${d.n}) · repos 90 s', 'Finisher : ${line(_meta[1], 1.0)}'],
          notes: 'Routine en blocs : qualité d\u2019exécution avant la vitesse.');
  }
}

/// Étiquettes de matériel d'un WOD, déduites des mouvements.
Set<String> equipmentOf(Wod w) {
  final t = w.lines.join(' ').toLowerCase();
  final eq = <String>{};
  if (RegExp(r'\brow\b|skierg|bike|erg\b|cal ').hasMatch(t)) eq.add('erg');
  if (RegExp(r'\bm run\b|m course|sprint|footing').hasMatch(t)) eq.add('run');
  if (RegExp(r'pull|chin|muscle|dip|toes|leg raise|rows barre|traction').hasMatch(t)) eq.add('barre');
  if (RegExp(r'\d\s*kg|lest|gilet').hasMatch(t)) eq.add('lest');
  if (RegExp(r'kettlebell|kb|wall ball|goblet|sandbag|farmer|devil|snatch|halt[eè]re|dumb').hasMatch(t)) eq.add('kb');
  if (RegExp(r'\bbox\b|step-over|plate').hasMatch(t)) eq.add('box');
  if (RegExp(r'double-under|corde').hasMatch(t)) eq.add('corde');
  if (eq.isEmpty) eq.add('pdc');
  return eq;
}
