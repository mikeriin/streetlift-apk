import 'package:flutter/material.dart';

import 'main.dart';
import 'session_screen.dart';
import 'store.dart';

// ===================== LISTE DES SÉANCES PERSO =====================
// Corps seul (le Scaffold et le FAB appartiennent à l'onglet Perso).

void newCustomSession(BuildContext context) => Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => SessionEditor(session: CustomSession(id: store.newSessionId(), name: ''))));

/// État vide uniforme : icône, titre, explication, action.
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  final String action;
  final VoidCallback onAction;
  const EmptyState({super.key, required this.icon, required this.title, required this.text, required this.action, required this.onAction});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(32, 0, 32, 80),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 56, color: SL.dot),
              const SizedBox(height: 14),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text(text, textAlign: TextAlign.center, style: TextStyle(color: SL.dim, height: 1.5, fontSize: 13.5)),
              const SizedBox(height: 18),
              FilledButton.tonal(onPressed: onAction, child: Text(action, style: const TextStyle(fontWeight: FontWeight.w800))),
            ],
          ),
        ),
      );
}

// ===================== ÉDITEUR DE SÉANCE =====================

class SessionEditor extends StatefulWidget {
  final CustomSession session;
  const SessionEditor({super.key, required this.session});
  @override
  State<SessionEditor> createState() => _SessionEditorState();
}

class _SessionEditorState extends State<SessionEditor> {
  late CustomSession s;
  late TextEditingController nameCtl;

  @override
  void initState() {
    super.initState();
    s = widget.session;
    nameCtl = TextEditingController(text: s.name);
  }

  @override
  void dispose() {
    nameCtl.dispose();
    super.dispose();
  }

  void _save() {
    s.name = nameCtl.text.trim();
    if (s.name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Donne un nom à la séance.')));
      return;
    }
    if (s.items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Ajoute au moins un exercice.')));
      return;
    }
    store.upsertSession(s);
    Navigator.pop(context);
  }

  Future<void> _addExercise() async {
    final name = await pickExercise(context);
    if (name == null || !mounted) return;
    final ex = CustomExercise(name: name);
    final ok = await editParams(context, ex);
    if (ok == true) setState(() => s.items.add(ex));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ÉDITEUR DE SÉANCE'),
        actions: [
          IconButton(onPressed: _save, icon: Icon(Icons.check, color: SL.mainGreen)),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 4),
            child: TextField(
              controller: nameCtl,
              textAlign: TextAlign.left,
              decoration:
                  const InputDecoration(labelText: 'Nom de la séance'),
            ),
          ),
          Expanded(
            child: ReorderableListView(
              padding: const EdgeInsets.only(bottom: 90),
              onReorder: (a, b) => setState(() {
                if (b > a) b--;
                final it = s.items.removeAt(a);
                s.items.insert(b, it);
              }),
              children: [
                for (var i = 0; i < s.items.length; i++)
                  Card(
                    key: ValueKey('it$i-${s.items[i].name}'),
                    child: ListTile(
                      title: Text(s.items[i].name,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 14)),
                      subtitle: Text(
                        '${modeById(s.items[i].mode).label} · ${s.items[i].setsText()}'
                        '${s.items[i].kg != null ? ' · ${s.items[i].kg} kg' : ''}'
                        '${s.items[i].rest != null ? ' · repos ${s.items[i].rest} s' : ''}',
                        style: const TextStyle(fontSize: 12),
                      ),
                      onTap: () async {
                        final ok = await editParams(context, s.items[i]);
                        if (ok == true) setState(() {});
                      },
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.close, size: 20, color: SL.dim),
                            onPressed: () =>
                                setState(() => s.items.removeAt(i)),
                          ),
                          Icon(Icons.drag_handle, color: SL.dim),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: SL.inputYellow,
        foregroundColor: SL.onAccent,
        icon: const Icon(Icons.add),
        label: const Text('Ajouter un exercice',
            style: TextStyle(fontWeight: FontWeight.w800)),
        onPressed: _addExercise,
      ),
    );
  }
}

// ===================== SÉLECTEUR D'EXERCICES =====================

Future<String?> pickExercise(BuildContext context) {
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: SL.surface,
    builder: (ctx) => const _ExercisePicker(),
  );
}

class _ExercisePicker extends StatefulWidget {
  const _ExercisePicker();
  @override
  State<_ExercisePicker> createState() => _ExercisePickerState();
}

class _ExercisePickerState extends State<_ExercisePicker> {
  String q = '';
  String group = '';

  @override
  Widget build(BuildContext context) {
    final groups = <String>{};
    for (final e in store.allExercises) {
      for (final g in (e['g'] as String).split(',')) {
        groups.add(g.trim());
      }
    }
    final gl = groups.toList()..sort();
    final ql = q.trim().toLowerCase();
    final list = store.allExercises.where((e) {
      final okQ = ql.isEmpty || (e['n'] as String).toLowerCase().contains(ql);
      final okG = group.isEmpty || (e['g'] as String).contains(group);
      return okQ && okG;
    }).toList();
    final exact =
        list.any((e) => (e['n'] as String).toLowerCase() == ql);

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.82,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
              child: TextField(
                autofocus: false,
                textAlign: TextAlign.left,
                decoration: InputDecoration(
                    labelText: 'Rechercher un exercice',
                    prefixIcon: Icon(Icons.search, color: SL.dim)),
                onChanged: (v) => setState(() => q = v),
              ),
            ),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: ChoiceChip(
                      label: const Text('tous'),
                      selected: group.isEmpty,
                      onSelected: (_) => setState(() => group = ''),
                    ),
                  ),
                  for (final g in gl)
                    Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: ChoiceChip(
                        label: Text(g),
                        selected: group == g,
                        onSelected: (_) =>
                            setState(() => group = group == g ? '' : g),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 4),
            Expanded(
              child: ListView(
                children: [
                  if (ql.isNotEmpty && !exact)
                    ListTile(
                      leading:
                          Icon(Icons.add_circle, color: SL.inputYellow),
                      title: Text('Créer « ${q.trim()} »',
                          style:
                              const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: const Text('Ajouter à ta base d\u2019exercices',
                          style: TextStyle(fontSize: 12)),
                      onTap: () {
                        store.addUserExercise(q.trim(), 'divers', '—');
                        Navigator.pop(context, q.trim());
                      },
                    ),
                  for (final e in list)
                    ListTile(
                      dense: true,
                      title: Text(e['n'] as String,
                          style: const TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 14)),
                      subtitle: Text('${e['g']} · ${e['eq']}',
                          style:
                              TextStyle(fontSize: 11.5, color: SL.dim)),
                      onTap: () => Navigator.pop(context, e['n'] as String),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ===================== PARAMÈTRES DE MODE =====================

const _fieldLabels = {
  'series': 'Séries',
  'reps': 'Reps',
  'actReps': 'Reps activation',
  'miniReps': 'Reps / mini',
  'minis': 'Mini-séries',
  'intra': 'Repos intra (s)',
  'rounds': 'Rounds',
  'interval': 'Intervalle (s)',
  'duree': 'Durée (min)',
  'hold': 'Tenue (s)',
  'work': 'Effort (s)',
  'restI': 'Repos interv. (s)',
  'pyr': 'Schéma (12-10-8-6)',
};

const _fieldDefaults = {
  'series': 4, 'reps': 8, 'actReps': 12, 'miniReps': 4, 'minis': 4,
  'intra': 20, 'rounds': 8, 'interval': 60, 'duree': 8, 'hold': 30,
  'work': 30, 'restI': 30,
};

Future<bool?> editParams(BuildContext context, CustomExercise ex) {
  return showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: SL.surface,
    builder: (ctx) => _ParamSheet(ex: ex),
  );
}

class _ParamSheet extends StatefulWidget {
  final CustomExercise ex;
  const _ParamSheet({required this.ex});
  @override
  State<_ParamSheet> createState() => _ParamSheetState();
}

class _ParamSheetState extends State<_ParamSheet> {
  late String mode;
  final ctls = <String, TextEditingController>{};
  late TextEditingController kgCtl, restCtl, noteCtl;

  @override
  void initState() {
    super.initState();
    mode = widget.ex.mode;
    kgCtl = TextEditingController(
        text: widget.ex.kg == null ? '' : '${widget.ex.kg}');
    restCtl = TextEditingController(
        text: widget.ex.rest == null ? '' : '${widget.ex.rest}');
    noteCtl = TextEditingController(text: widget.ex.note);
  }

  TextEditingController _ctl(String f) {
    return ctls.putIfAbsent(f, () {
      final v = widget.ex.p[f];
      final d = f == 'pyr' ? '12-10-8-6' : '${_fieldDefaults[f]}';
      return TextEditingController(text: v == null ? d : '$v');
    });
  }

  void _apply() {
    widget.ex.mode = mode;
    final m = modeById(mode);
    widget.ex.p = {};
    for (final f in m.fields) {
      final t = _ctl(f).text.trim();
      if (f == 'pyr') {
        widget.ex.p[f] = t.isEmpty ? '12-10-8-6' : t;
      } else {
        widget.ex.p[f] = int.tryParse(t) ?? _fieldDefaults[f]!;
      }
    }
    widget.ex.kg = double.tryParse(kgCtl.text.replaceAll(',', '.'));
    widget.ex.rest = int.tryParse(restCtl.text);
    widget.ex.note = noteCtl.text.trim();
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final m = modeById(mode);
    return Padding(
      padding: EdgeInsets.only(
          left: 14,
          right: 14,
          top: 14,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.ex.name.toUpperCase(),
                style: const TextStyle(
                    fontWeight: FontWeight.w900, fontSize: 15)),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: mode,
              dropdownColor: SL.card,
              decoration:
                  const InputDecoration(labelText: 'Mode d\u2019exécution'),
              items: [
                for (final em in execModes)
                  DropdownMenuItem(value: em.id, child: Text(em.label)),
              ],
              onChanged: (v) => setState(() => mode = v ?? 'classic'),
            ),
            const SizedBox(height: 6),
            Text(m.desc,
                style: TextStyle(color: SL.dim, fontSize: 12, height: 1.35)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final f in m.fields)
                  SizedBox(
                    width: f == 'pyr'
                        ? double.infinity
                        : (MediaQuery.of(context).size.width - 44) / 2,
                    child: TextField(
                      controller: _ctl(f),
                      keyboardType: f == 'pyr'
                          ? TextInputType.text
                          : TextInputType.number,
                      decoration:
                          InputDecoration(labelText: _fieldLabels[f]),
                    ),
                  ),
                SizedBox(
                  width: (MediaQuery.of(context).size.width - 44) / 2,
                  child: TextField(
                    controller: kgCtl,
                    keyboardType: const TextInputType.numberWithOptions(
                        decimal: true),
                    decoration: const InputDecoration(
                        labelText: 'Charge (kg, optionnel)'),
                  ),
                ),
                SizedBox(
                  width: (MediaQuery.of(context).size.width - 44) / 2,
                  child: TextField(
                    controller: restCtl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                        labelText: 'Repos entre séries (s)'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            TextField(
              controller: noteCtl,
              textAlign: TextAlign.left,
              decoration: const InputDecoration(labelText: 'Consigne (optionnel)'),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                style: FilledButton.styleFrom(
                    backgroundColor: SL.mainGreen,
                    foregroundColor: SL.onAccent,
                    padding: const EdgeInsets.symmetric(vertical: 13)),
                onPressed: _apply,
                child: const Text('Valider',
                    style: TextStyle(fontWeight: FontWeight.w800)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
