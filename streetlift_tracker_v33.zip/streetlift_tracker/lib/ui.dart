import 'package:flutter/material.dart';
import 'app_theme.dart';

/// Règles partagées par tous les écrans : espacements, surfaces et actions.
class KSpace {
  static const double page = 12, gap = 6, radius = 12, maxWidth = 840;
  static const content = EdgeInsets.fromLTRB(page, 4, page, 16);
}

class KContent extends StatelessWidget {
  final Widget child;
  const KContent({super.key, required this.child});
  @override
  Widget build(BuildContext context) => SafeArea(
    top: false,
    child: Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: KSpace.maxWidth),
        child: SizedBox(width: double.infinity, child: child),
      ),
    ),
  );
}

class KScreen extends StatelessWidget {
  final PreferredSizeWidget? appBar;
  final Widget? body, bottomNavigationBar, floatingActionButton;
  final FloatingActionButtonLocation? floatingActionButtonLocation;
  final bool resizeToAvoidBottomInset;
  const KScreen({
    super.key,
    this.appBar,
    this.body,
    this.bottomNavigationBar,
    this.floatingActionButton,
    this.floatingActionButtonLocation,
    this.resizeToAvoidBottomInset = true,
  });
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: appBar,
    resizeToAvoidBottomInset: resizeToAvoidBottomInset,
    body: body == null ? null : KContent(child: body!),
    bottomNavigationBar: bottomNavigationBar,
    floatingActionButton: floatingActionButton,
    floatingActionButtonLocation: floatingActionButtonLocation,
  );
}

class KList extends StatelessWidget {
  final List<Widget> children;
  final EdgeInsetsGeometry padding;
  final ScrollController? controller;
  final double gap;
  const KList({
    super.key,
    required this.children,
    this.padding = KSpace.content,
    this.controller,
    this.gap = KSpace.gap,
  });
  @override
  Widget build(BuildContext context) => ListView.separated(
    controller: controller,
    padding: padding,
    keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
    itemCount: children.length,
    separatorBuilder: (_, __) => SizedBox(height: gap),
    itemBuilder: (_, i) => children[i],
  );
}

class KCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? accent, color;
  final VoidCallback? onTap, onLongPress;
  const KCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    this.accent,
    this.color,
    this.onTap,
    this.onLongPress,
  });
  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final highlighted = accent != null || color != null;
    return Material(
      color: color ?? c.surfaceContainerLow,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(highlighted ? 14 : KSpace.radius),
        side:
            dark || highlighted
                ? BorderSide.none
                : BorderSide(color: c.outlineVariant),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        child: DecoratedBox(
          decoration: BoxDecoration(
            border:
                accent == null
                    ? null
                    : Border(left: BorderSide(color: accent!, width: 3)),
          ),
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

class KSection extends StatelessWidget {
  final String title;
  final String? subtitle, actionLabel;
  final VoidCallback? onAction;
  final IconData actionIcon;
  final double topPadding;
  const KSection(
    this.title, {
    super.key,
    this.subtitle,
    this.actionLabel,
    this.onAction,
    this.actionIcon = Icons.chevron_right,
    this.topPadding = 6,
  });
  @override
  Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.only(top: topPadding),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                title.toUpperCase(),
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                  letterSpacing: .7,
                ),
              ),
            ),
            if (actionLabel != null) ...[
              const SizedBox(width: 8),
              Flexible(
                child: TextButton.icon(
                  onPressed: onAction,
                  icon: Icon(actionIcon, size: 18),
                  label: Text(actionLabel!),
                ),
              ),
            ],
          ],
        ),
        if (subtitle != null) ...[
          const SizedBox(height: 4),
          Text(subtitle!, style: Theme.of(context).textTheme.bodySmall),
        ],
      ],
    ),
  );
}

class KBadge extends StatelessWidget {
  final String text;
  final Color? color;
  final IconData? icon;
  const KBadge(this.text, {super.key, this.color, this.icon});
  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).colorScheme.onSurfaceVariant;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: c.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 15, color: c),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: Text(
              text,
              style: TextStyle(
                color: c,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class KEmpty extends StatelessWidget {
  final IconData icon;
  final String title, message;
  final String? action;
  final VoidCallback? onAction;
  const KEmpty({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.action,
    this.onAction,
  });
  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(KSpace.radius),
        side: BorderSide(color: c.outlineVariant),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onAction,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: c.onSurfaceVariant, size: 22),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 2),
                    Text(message, style: Theme.of(context).textTheme.bodySmall),
                    if (action != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        action!,
                        style: TextStyle(
                          color: c.primary,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              if (onAction != null)
                Padding(
                  padding: const EdgeInsets.only(left: 6),
                  child: Icon(Icons.chevron_right, color: c.primary, size: 20),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class KSearch extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final ValueChanged<String> onChanged;
  const KSearch({
    super.key,
    required this.controller,
    required this.hint,
    required this.onChanged,
  });
  @override
  Widget build(BuildContext context) =>
      ValueListenableBuilder<TextEditingValue>(
        valueListenable: controller,
        builder:
            (context, value, _) => TextField(
              controller: controller,
              textInputAction: TextInputAction.search,
              onChanged: onChanged,
              decoration: InputDecoration(
                hintText: hint,
                prefixIcon: const Icon(Icons.search),
                suffixIcon:
                    value.text.isEmpty
                        ? null
                        : IconButton(
                          tooltip: 'Effacer la recherche',
                          icon: const Icon(Icons.close),
                          onPressed: () {
                            controller.clear();
                            onChanged('');
                          },
                        ),
              ),
            ),
      );
}

/// Les actions voisines partagent largeur et axe central. Elles passent en colonne
/// seulement lorsque la largeur ou la taille du texte l'exige.
class KActionRow extends StatelessWidget {
  final List<Widget> children;
  final double minButtonWidth;
  const KActionRow({
    super.key,
    required this.children,
    this.minButtonWidth = 140,
  });

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final scale = (MediaQuery.textScalerOf(context).scale(13) / 13).clamp(
        1.0,
        double.infinity,
      );
      final stacked =
          constraints.maxWidth <
          children.length * minButtonWidth * scale +
              (children.length - 1) * KControl.gap;
      if (stacked) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (var i = 0; i < children.length; i++) ...[
              if (i > 0) const SizedBox(height: KControl.gap),
              children[i],
            ],
          ],
        );
      }
      return Row(
        children: [
          for (var i = 0; i < children.length; i++) ...[
            if (i > 0) const SizedBox(width: KControl.gap),
            Expanded(child: children[i]),
          ],
        ],
      );
    },
  );
}

/// Une grille de formulaire : deux colonnes égales, ou une sur écran étroit.
class KFieldGrid extends StatelessWidget {
  final List<Widget> children;
  const KFieldGrid({super.key, required this.children});

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final scale = (MediaQuery.textScalerOf(context).scale(15) / 15).clamp(
        1.0,
        double.infinity,
      );
      final paired =
          children.length > 1 &&
          constraints.maxWidth >= 296 * scale + KControl.gap;
      final width =
          paired
              ? (constraints.maxWidth - KControl.gap) / 2
              : constraints.maxWidth;
      return Wrap(
        spacing: KControl.gap,
        runSpacing: KControl.formGap,
        children: [
          for (final child in children) SizedBox(width: width, child: child),
        ],
      );
    },
  );
}

class KBottomActions extends StatelessWidget {
  final Widget child;
  const KBottomActions({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Material(
    color: Theme.of(context).colorScheme.surface,
    child: SafeArea(
      top: false,
      child: Center(
        heightFactor: 1,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: KSpace.maxWidth),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(KSpace.page, 4, KSpace.page, 6),
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: KControl.height),
              child: Align(
                heightFactor: 1,
                child: SizedBox(width: double.infinity, child: child),
              ),
            ),
          ),
        ),
      ),
    ),
  );
}

/// Partageable entre l'accueil, les listes, le suivi et le parcours de niveaux.
class KProgressCard extends StatelessWidget {
  final int level, credits, inLevel, need;
  final String rank;
  final VoidCallback? onTap;
  final bool detailed;
  const KProgressCard({
    super.key,
    required this.level,
    required this.credits,
    required this.inLevel,
    required this.need,
    required this.rank,
    this.onTap,
    this.detailed = false,
  });
  @override
  Widget build(BuildContext context) => KBanner(
    onTap: onTap,
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 44,
          height: 44,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: .18),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white70, width: 2),
          ),
          child: Text(
            '$level',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$credits CRÉDIT${credits > 1 ? 'S' : ''}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  letterSpacing: .5,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                'Niveau $level · $rank',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(3),
                child: LinearProgressIndicator(
                  minHeight: 4,
                  value: need == 0 ? 0 : (inLevel / need).clamp(0.0, 1.0),
                  color: Colors.white,
                  backgroundColor: Colors.white.withValues(alpha: .2),
                  semanticsLabel: 'Progression du niveau',
                  semanticsValue: '$inLevel sur $need XP',
                ),
              ),
              const SizedBox(height: 4),
              Text(
                detailed
                    ? '$inLevel / $need XP · ${need - inLevel} XP avant le niveau ${level + 1}'
                    : 'Niveau ${level + 1} dans ${need - inLevel} XP',
                style: const TextStyle(color: Colors.white, fontSize: 11.5),
              ),
            ],
          ),
        ),
        if (onTap != null)
          const Padding(
            padding: EdgeInsets.only(left: 6),
            child: Tooltip(
              message: 'Ma progression',
              child: Icon(Icons.chevron_right, color: Colors.white, size: 20),
            ),
          ),
      ],
    ),
  );
}

/// Bandeaux de la DA 1.6, avec un fond suffisamment soutenu en thème clair.
class KBanner extends StatelessWidget {
  final Color? color;
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry padding;
  const KBanner({
    super.key,
    this.color,
    required this.child,
    this.onTap,
    this.padding = const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
  });
  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    final base = color ?? c.primary;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final colors =
        dark
            ? [base.withValues(alpha: .85), base.withValues(alpha: .45)]
            : [
              Color.lerp(base, Colors.black, .22)!,
              Color.lerp(base, Colors.black, .38)!,
            ];
    return Material(
      color: c.surfaceContainerLow,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: Ink(
        decoration: BoxDecoration(gradient: LinearGradient(colors: colors)),
        child: InkWell(
          onTap: onTap,
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}
