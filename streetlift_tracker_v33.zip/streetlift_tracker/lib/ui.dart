import 'package:flutter/material.dart';

/// Règles partagées par tous les écrans : espacements, surfaces et actions.
class KSpace {
  static const double page = 12, gap = 10, radius = 14, maxWidth = 840;
  static const content = EdgeInsets.fromLTRB(page, 4, page, 24);
}

class KContent extends StatelessWidget {
  final Widget child;
  const KContent({super.key, required this.child});
  @override
  Widget build(BuildContext context) => SafeArea(
    top: false,
    child: Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: KSpace.maxWidth),
        child: SizedBox(width: double.infinity, child: child),
      ),
    ),
  );
}

class KScreen extends StatelessWidget {
  final PreferredSizeWidget? appBar;
  final Widget? body, bottomNavigationBar, floatingActionButton;
  final FloatingActionButtonLocation? floatingActionButtonLocation;
  final bool resizeToAvoidBottomInset;
  const KScreen({
    super.key,
    this.appBar,
    this.body,
    this.bottomNavigationBar,
    this.floatingActionButton,
    this.floatingActionButtonLocation,
    this.resizeToAvoidBottomInset = true,
  });
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: appBar,
    resizeToAvoidBottomInset: resizeToAvoidBottomInset,
    body: body == null ? null : KContent(child: body!),
    bottomNavigationBar: bottomNavigationBar,
    floatingActionButton: floatingActionButton,
    floatingActionButtonLocation: floatingActionButtonLocation,
  );
}

class KList extends StatelessWidget {
  final List<Widget> children;
  final EdgeInsetsGeometry padding;
  final ScrollController? controller;
  const KList({
    super.key,
    required this.children,
    this.padding = KSpace.content,
    this.controller,
  });
  @override
  Widget build(BuildContext context) => ListView.separated(
    controller: controller,
    padding: padding,
    keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
    itemCount: children.length,
    separatorBuilder: (_, __) => const SizedBox(height: KSpace.gap),
    itemBuilder: (_, i) => children[i],
  );
}

class KCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? accent;
  final VoidCallback? onTap, onLongPress;
  const KCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.accent,
    this.onTap,
    this.onLongPress,
  });
  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Material(
      color: c.surfaceContainerLow,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(
          accent == null ? KSpace.radius : 16,
        ),
        side:
            dark || accent != null
                ? BorderSide.none
                : BorderSide(color: c.outlineVariant),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        child: DecoratedBox(
          decoration: BoxDecoration(
            border:
                accent == null
                    ? null
                    : Border(left: BorderSide(color: accent!, width: 4)),
          ),
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

class KSection extends StatelessWidget {
  final String title;
  final String? subtitle, actionLabel;
  final VoidCallback? onAction;
  final IconData actionIcon;
  final double topPadding;
  const KSection(
    this.title, {
    super.key,
    this.subtitle,
    this.actionLabel,
    this.onAction,
    this.actionIcon = Icons.chevron_right,
    this.topPadding = 10,
  });
  @override
  Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.only(top: topPadding),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                title.toUpperCase(),
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                  letterSpacing: .7,
                ),
              ),
            ),
            if (actionLabel != null) ...[
              const SizedBox(width: 8),
              Flexible(
                child: TextButton.icon(
                  onPressed: onAction,
                  icon: Icon(actionIcon, size: 18),
                  label: Text(actionLabel!),
                ),
              ),
            ],
          ],
        ),
        if (subtitle != null) ...[
          const SizedBox(height: 4),
          Text(subtitle!, style: Theme.of(context).textTheme.bodySmall),
        ],
      ],
    ),
  );
}

class KBadge extends StatelessWidget {
  final String text;
  final Color? color;
  final IconData? icon;
  const KBadge(this.text, {super.key, this.color, this.icon});
  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).colorScheme.onSurfaceVariant;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: c.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 15, color: c),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: Text(
              text,
              style: TextStyle(
                color: c,
                fontSize: 11,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class KEmpty extends StatelessWidget {
  final IconData icon;
  final String title, message;
  final String? action;
  final VoidCallback? onAction;
  const KEmpty({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.action,
    this.onAction,
  });
  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(KSpace.radius),
        side: BorderSide(color: c.outlineVariant),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(icon, color: c.onSurfaceVariant, size: 24),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        message,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (action != null)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(onPressed: onAction, child: Text(action!)),
              ),
          ],
        ),
      ),
    );
  }
}

class KSearch extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final ValueChanged<String> onChanged;
  const KSearch({
    super.key,
    required this.controller,
    required this.hint,
    required this.onChanged,
  });
  @override
  Widget build(BuildContext context) =>
      ValueListenableBuilder<TextEditingValue>(
        valueListenable: controller,
        builder:
            (context, value, _) => TextField(
              controller: controller,
              textInputAction: TextInputAction.search,
              onChanged: onChanged,
              decoration: InputDecoration(
                hintText: hint,
                prefixIcon: const Icon(Icons.search),
                suffixIcon:
                    value.text.isEmpty
                        ? null
                        : IconButton(
                          tooltip: 'Effacer la recherche',
                          icon: const Icon(Icons.close),
                          onPressed: () {
                            controller.clear();
                            onChanged('');
                          },
                        ),
              ),
            ),
      );
}

class KBottomActions extends StatelessWidget {
  final Widget child;
  const KBottomActions({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Material(
    color: Theme.of(context).colorScheme.surface,
    child: SafeArea(
      top: false,
      child: Center(
        heightFactor: 1,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: KSpace.maxWidth),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(KSpace.page, 8, KSpace.page, 12),
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 48),
              child: SizedBox(width: double.infinity, child: child),
            ),
          ),
        ),
      ),
    ),
  );
}

/// Partageable entre l'accueil, les listes, le suivi et le parcours de niveaux.
class KProgressCard extends StatelessWidget {
  final int level, credits, inLevel, need;
  final String rank;
  final VoidCallback? onTap;
  final bool detailed;
  const KProgressCard({
    super.key,
    required this.level,
    required this.credits,
    required this.inLevel,
    required this.need,
    required this.rank,
    this.onTap,
    this.detailed = false,
  });
  @override
  Widget build(BuildContext context) => KBanner(
    onTap: onTap,
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 52,
          height: 52,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: .18),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white70, width: 2),
          ),
          child: Text(
            '$level',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$credits CRÉDIT${credits > 1 ? 'S' : ''}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: .5,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                'Niveau $level · $rank',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(3),
                child: LinearProgressIndicator(
                  minHeight: 5,
                  value: need == 0 ? 0 : (inLevel / need).clamp(0.0, 1.0),
                  color: Colors.white,
                  backgroundColor: Colors.white.withValues(alpha: .2),
                  semanticsLabel: 'Progression du niveau',
                  semanticsValue: '$inLevel sur $need XP',
                ),
              ),
              const SizedBox(height: 5),
              Text(
                detailed
                    ? '$inLevel / $need XP · ${need - inLevel} XP avant le niveau ${level + 1}'
                    : 'Niveau ${level + 1} dans ${need - inLevel} XP',
                style: const TextStyle(color: Colors.white, fontSize: 11.5),
              ),
              if (onTap != null)
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Ma progression',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      Icon(Icons.chevron_right, color: Colors.white, size: 18),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    ),
  );
}

/// Bandeaux de la DA 1.6, avec un fond suffisamment soutenu en thème clair.
class KBanner extends StatelessWidget {
  final Color? color;
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry padding;
  const KBanner({
    super.key,
    this.color,
    required this.child,
    this.onTap,
    this.padding = const EdgeInsets.all(14),
  });
  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    final base = color ?? c.primary;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final colors =
        dark
            ? [base.withValues(alpha: .85), base.withValues(alpha: .45)]
            : [
              Color.lerp(base, Colors.black, .22)!,
              Color.lerp(base, Colors.black, .38)!,
            ];
    return Material(
      color: c.surfaceContainerLow,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: Ink(
        decoration: BoxDecoration(gradient: LinearGradient(colors: colors)),
        child: InkWell(
          onTap: onTap,
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}
