import 'package:flutter/material.dart';

import 'main.dart';
import 'store.dart';

class PilotageScreen extends StatelessWidget {
  const PilotageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = store.program.pilotage;
    return Scaffold(
      appBar: AppBar(
        title: const Text('PILOTAGE'),
        actions: [
          IconButton(
            tooltip: 'Rétablir les valeurs du classeur',
            icon: const Icon(Icons.restore),
            onPressed: () => showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                backgroundColor: SL.surface,
                title: const Text('Rétablir les défauts ?'),
                content: const Text(
                    'Toutes les valeurs reviennent à celles du classeur v3.3. Tes séances enregistrées ne bougent pas.'),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('Annuler')),
                  FilledButton(
                      onPressed: () {
                        store.resetPilotage();
                        Navigator.pop(ctx);
                      },
                      child: const Text('Rétablir')),
                ],
              ),
            ),
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            const _SectionTitle(
                'Les cellules jaunes du classeur. Modifie ici : toutes les charges et tous les volumes se recalculent.'),
            _NumTile(
              label: 'Poids de corps',
              refCell: 'B4',
              unit: 'kg',
              subtitle: 'Base du poids système (PdC + lest)',
            ),
            const _SectionTitle('1RM DE TRAVAIL'),
            for (final l in p.mainLifts)
              _NumTile(
                label: l.name,
                refCell: l.ref,
                unit: l.unit,
                subtitle: 'Cible 12 mois : ${_n(l.target)} ${l.unit}',
              ),
            const _SectionTitle('MAXIMA DE REPS AU POIDS DE CORPS'),
            for (final m in p.repMax)
              _NumTile(
                label: m.name,
                refCell: m.ref,
                unit: 'reps',
                subtitle: 'Cible 12 mois : ${_n(m.target)} reps — pilote le volume J4/J5/J6',
              ),
            const _SectionTitle('CHARGES DE RÉFÉRENCE — ACCESSOIRES'),
            for (final a in p.accessories)
              _NumTile(
                label: a.name,
                refCell: a.ref,
                unit: 'kg',
                subtitle:
                    'Réf. ${a.refReps} reps · ${a.note.isEmpty ? 'double progression' : a.note}',
              ),
          ],
        ),
      ),
    );
  }
}

String _n(double v) =>
    v == v.roundToDouble() ? v.toInt().toString() : v.toString();

class _SectionTitle extends StatelessWidget {
  final String t;
  const _SectionTitle(this.t);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 6),
        child: Text(t,
            style: const TextStyle(
                color: SL.dim,
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.6)),
      );
}

class _NumTile extends StatelessWidget {
  final String label;
  final String refCell;
  final String unit;
  final String subtitle;
  const _NumTile(
      {required this.label,
      required this.refCell,
      required this.unit,
      required this.subtitle});

  @override
  Widget build(BuildContext context) {
    final v = store.values[refCell] ?? 0;
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 14)),
                  const SizedBox(height: 2),
                  Text(subtitle,
                      style: const TextStyle(color: SL.dim, fontSize: 11.5)),
                ],
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: 86,
              child: TextFormField(
                key: ValueKey('$refCell-${store.pilotageEpoch}'),
                initialValue: _n(v),
                textAlign: TextAlign.center,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                style: const TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 16),
                decoration: InputDecoration(suffixText: unit == 'reps' ? '' : 'kg'),
                onFieldSubmitted: (t) {
                  final d = double.tryParse(t.replaceAll(',', '.'));
                  if (d != null) store.setValue(refCell, d);
                },
                onTapOutside: (_) =>
                    FocusManager.instance.primaryFocus?.unfocus(),
                onChanged: (t) {
                  final d = double.tryParse(t.replaceAll(',', '.'));
                  if (d != null) store.setValue(refCell, d);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
