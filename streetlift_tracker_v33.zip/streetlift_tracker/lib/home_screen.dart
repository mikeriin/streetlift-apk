import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';
import 'estimate_view.dart';
import 'levelup.dart';
import 'models.dart';
import 'muscle_body.dart';
import 'session_history.dart';
import 'session_screen.dart';
import 'store.dart';
import 'ui.dart';

class HomeScreen extends StatefulWidget {
  final DateTime? referenceDate;
  const HomeScreen({super.key, this.referenceDate});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late int week;
  DateTime get now => widget.referenceDate ?? DateTime.now();
  @override
  void initState() {
    super.initState();
    week = store.program.weekFor(now);
  }

  final ScrollController _scroll = ScrollController();
  double _swipe = 0;

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  void _selectWeek(int value) {
    final next = value.clamp(1, store.program.weeks.length);
    if (next == week) return;
    setState(() => week = next);
    if (_scroll.hasClients) _scroll.jumpTo(0);
  }

  Future<void> _pickWeek() async {
    final selected = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder:
          (context) => DraggableScrollableSheet(
            expand: false,
            initialChildSize: .75,
            maxChildSize: .95,
            builder:
                (context, controller) => ListView.builder(
                  controller: controller,
                  itemCount: store.program.weeks.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) {
                      return const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Choisir une semaine',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      );
                    }
                    final w = store.program.weeks[i - 1];
                    final done =
                        w.days.where((d) => store.isDone(w.n, d.j)).length;
                    return ListTile(
                      selected: w.n == week,
                      leading: CircleAvatar(child: Text('${w.n}')),
                      title: Text('Semaine ${w.n} · ${w.dates}'),
                      subtitle: Text(
                        w.n == store.program.weekFor(now)
                            ? '${w.block} · Semaine actuelle'
                            : w.block,
                      ),
                      trailing: Text('$done / ${w.days.length}'),
                      onTap: () => Navigator.pop(context, w.n),
                    );
                  },
                ),
          ),
    );
    if (selected != null && mounted) _selectWeek(selected);
  }

  Future<void> _weekDetails(WeekPlan w) => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder:
        (sheetContext) => DraggableScrollableSheet(
          expand: false,
          initialChildSize: .7,
          maxChildSize: .94,
          builder:
              (context, controller) => KList(
                controller: controller,
                children: [
                  Text(
                    'Semaine ${w.n}',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  Text(w.dates.replaceAll('→', ' au ')),
                  Text(w.block, style: TextStyle(color: SL.steel)),
                  if (w.days.first.cycle.isNotEmpty) Text(w.days.first.cycle),
                  Text(
                    '${w.days.where((d) => store.isDone(w.n, d.j)).length} / ${w.days.length} journées validées',
                  ),
                  const KSection('Séances de la semaine'),
                  for (final d in w.days)
                    KCard(
                      padding: EdgeInsets.zero,
                      child: ListTile(
                        leading: Text('J${d.j}'),
                        title: Text(d.title),
                        subtitle: Text(
                          d.exercises.isEmpty
                              ? 'Récupération'
                              : '${d.exercises.length} exercices · ${store.dayEstimate(d).durationLabel}',
                        ),
                        trailing: Icon(
                          store.isDone(w.n, d.j)
                              ? Icons.check_circle_outline
                              : Icons.chevron_right,
                          size: 18,
                        ),
                        onTap: () {
                          Navigator.pop(sheetContext);
                          _open(w, d);
                        },
                      ),
                    ),
                  if (w.n != store.program.weekFor(now))
                    TextButton(
                      onPressed: () {
                        Navigator.pop(sheetContext);
                        _selectWeek(store.program.weekFor(now));
                      },
                      child: const Text('Revenir à la semaine actuelle'),
                    ),
                  TextButton.icon(
                    onPressed: () async {
                      Navigator.pop(sheetContext);
                      await _pickWeek();
                    },
                    icon: const Icon(Icons.calendar_month_outlined),
                    label: const Text('Choisir une semaine'),
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(sheetContext),
                    child: const Text('Fermer'),
                  ),
                ],
              ),
        ),
  );

  Future<void> _open(WeekPlan w, DayPlan d) async {
    final log = store.logs[store.sessionKey(w.n, d.j)];
    await Navigator.push<void>(
      context,
      MaterialPageRoute(
        builder:
            (_) =>
                log?.done == true
                    ? SessionHistoryScreen(log: log!, week: w, day: d)
                    : SessionScreen(week: w, day: d),
      ),
    );
    if (mounted) checkLevelUp(context);
  }

  void _summary(WeekPlan w, DayPlan d) {
    final done = store.isDone(w.n, d.j);
    final estimate = store.dayEstimate(d);
    final overview = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(d.title, style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Text(
          done ? 'Séance effectuée' : 'Séance à faire',
          style: TextStyle(color: done ? SL.mainGreen : SL.dim),
        ),
        const SizedBox(height: 8),
        if (d.exercises.isEmpty)
          const Text('Repos et récupération · GtG suspendu')
        else
          Row(
            children: [
              Expanded(child: Text('${d.exercises.length} exercices')),
              SizedBox(
                width: 110,
                child: MuscleHeatmap(
                  data: store.plannedMuscles(estimate),
                  height: 110,
                  labels: false,
                ),
              ),
            ],
          ),
      ],
    );
    if (d.exercises.isEmpty) {
      showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        builder:
            (context) => SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Résumé · S${w.n} · J${d.j}',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 14),
                  overview,
                ],
              ),
            ),
      );
    } else {
      showEstimate(
        context,
        'Résumé · S${w.n} · J${d.j}',
        estimate,
        overview: overview,
      );
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      final w = store.program.week(week), current = store.program.weekFor(now);
      final colors = ProgrammeColors.of(context);
      final today =
          store.program.containsDate(now) && current == week
              ? store.program.dayFor(now)
              : -1;
      final completed = w.days.where((d) => store.isDone(w.n, d.j)).length;
      Widget card(DayPlan d) => _DayCard(
        week: w,
        day: d,
        isToday: d.j == today,
        done: store.isDone(w.n, d.j),
        onOpen: () => _open(w, d),
        onSummary: () => _summary(w, d),
      );
      return KScreen(
        appBar: const KTopBar(leading: LevelPill()),
        body: GestureDetector(
          key: const ValueKey('programme-weeks'),
          behavior: HitTestBehavior.opaque,
          onHorizontalDragStart: (_) => _swipe = 0,
          onHorizontalDragUpdate: (details) => _swipe += details.delta.dx,
          onHorizontalDragEnd: (details) {
            final velocity = details.primaryVelocity ?? 0;
            if (_swipe.abs() < 48 && velocity.abs() < 300) return;
            final direction = _swipe.abs() >= 48 ? _swipe : velocity;
            _selectWeek(week + (direction < 0 ? 1 : -1));
          },
          child: KList(
            key: const PageStorageKey('programme-scroll'),
            controller: _scroll,
            children: [
              const KPageIntro(
                'Programme',
                'Une séance à la fois. Toujours plus loin.',
              ),
              KCard(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
                child: Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          tooltip: 'Semaine précédente',
                          onPressed:
                              week > 1 ? () => _selectWeek(week - 1) : null,
                          icon: const Icon(Icons.chevron_left_rounded),
                        ),
                        Expanded(
                          child: InkWell(
                            onTap: _pickWeek,
                            borderRadius: BorderRadius.circular(14),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Flexible(
                                        child: Text(
                                          'Semaine $week',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style:
                                              Theme.of(
                                                context,
                                              ).textTheme.titleMedium,
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      Icon(
                                        Icons.keyboard_arrow_down_rounded,
                                        size: 18,
                                        color: SL.dim,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    w.dates.replaceAll('→', ' – '),
                                    textAlign: TextAlign.center,
                                    style:
                                        Theme.of(context).textTheme.bodySmall,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        IconButton(
                          tooltip: 'Semaine suivante',
                          onPressed:
                              week < store.program.weeks.length
                                  ? () => _selectWeek(week + 1)
                                  : null,
                          icon: const Icon(Icons.chevron_right_rounded),
                        ),
                      ],
                    ),
                    _WeekSlider(
                      week: week,
                      count: store.program.weeks.length,
                      color: colors.accent,
                      onChanged: _selectWeek,
                      onDetails: () => _weekDetails(w),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              '$completed / ${w.days.length} journées validées',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ),
                          if (week != current)
                            TextButton(
                              onPressed: () => _selectWeek(current),
                              child: const Text('Aujourd’hui'),
                            )
                          else
                            Icon(
                              Icons.calendar_today_rounded,
                              size: 15,
                              color: SL.steel,
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              if (today != -1) ...[
                const KSection('Aujourd’hui'),
                card(w.days.firstWhere((d) => d.j == today)),
              ],
              KSection(
                'Cette semaine',
                subtitle: w.block,
                actionLabel: 'Détails',
                onAction: () => _weekDetails(w),
              ),
              for (final d in w.days)
                if (d.j != today) card(d),
            ],
          ),
        ),
      );
    },
  );
}

/// Appui court : détails. Glissement, clavier et lecteur d'écran : semaine.
class _WeekSlider extends StatefulWidget {
  final int week, count;
  final Color color;
  final ValueChanged<int> onChanged;
  final VoidCallback onDetails;
  const _WeekSlider({
    required this.week,
    required this.count,
    required this.color,
    required this.onChanged,
    required this.onDetails,
  });
  @override
  State<_WeekSlider> createState() => _WeekSliderState();
}

class _WeekSliderState extends State<_WeekSlider> {
  final FocusNode _focus = FocusNode();
  bool _focused = false;
  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  void _step(int delta) =>
      widget.onChanged((widget.week + delta).clamp(1, widget.count));

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      const target = 48.0;
      final fraction =
          widget.count <= 1 ? 0.0 : (widget.week - 1) / (widget.count - 1);
      final rtl = Directionality.of(context) == TextDirection.rtl;
      final trackWidth = constraints.maxWidth - target;
      void drag(Offset point) {
        if (widget.count <= 1 || trackWidth <= 0) return;
        final x = ((point.dx - target / 2) / trackWidth).clamp(0.0, 1.0);
        widget.onChanged(1 + ((rtl ? 1 - x : x) * (widget.count - 1)).round());
      }

      return Semantics(
        slider: true,
        label: 'Progression du programme',
        value: 'Semaine ${widget.week} sur ${widget.count}',
        increasedValue:
            widget.week < widget.count
                ? 'Semaine ${widget.week + 1} sur ${widget.count}'
                : null,
        decreasedValue:
            widget.week > 1
                ? 'Semaine ${widget.week - 1} sur ${widget.count}'
                : null,
        onIncrease: widget.week < widget.count ? () => _step(1) : null,
        onDecrease: widget.week > 1 ? () => _step(-1) : null,
        onTap: widget.onDetails,
        onTapHint: 'Afficher le détail de la semaine',
        excludeSemantics: true,
        child: Focus(
          focusNode: _focus,
          onFocusChange: (value) => setState(() => _focused = value),
          onKeyEvent: (_, event) {
            if (event is! KeyDownEvent && event is! KeyRepeatEvent) {
              return KeyEventResult.ignored;
            }
            final key = event.logicalKey;
            if (key == LogicalKeyboardKey.arrowRight) {
              _step(rtl ? -1 : 1);
            } else if (key == LogicalKeyboardKey.arrowLeft) {
              _step(rtl ? 1 : -1);
            } else if (key == LogicalKeyboardKey.home) {
              widget.onChanged(1);
            } else if (key == LogicalKeyboardKey.end) {
              widget.onChanged(widget.count);
            } else if (key == LogicalKeyboardKey.enter ||
                key == LogicalKeyboardKey.space) {
              widget.onDetails();
            } else {
              return KeyEventResult.ignored;
            }
            return KeyEventResult.handled;
          },
          child: GestureDetector(
            key: const ValueKey('week-slider'),
            behavior: HitTestBehavior.opaque,
            onTap: () {
              _focus.requestFocus();
              widget.onDetails();
            },
            onHorizontalDragStart: (details) {
              _focus.requestFocus();
              drag(details.localPosition);
            },
            onHorizontalDragUpdate: (details) => drag(details.localPosition),
            child: SizedBox(
              height: target,
              child: Stack(
                children: [
                  Positioned(
                    left: target / 2 - 2,
                    right: target / 2 - 2,
                    top: 22,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        for (var i = 1; i <= widget.count; i++)
                          Container(
                            width: 4,
                            height: 4,
                            decoration: BoxDecoration(
                              color: i <= widget.week ? widget.color : SL.dot,
                              shape: BoxShape.circle,
                            ),
                          ),
                      ],
                    ),
                  ),
                  PositionedDirectional(
                    start: target / 2,
                    top: 22.5,
                    width: trackWidth * fraction,
                    height: 3,
                    child: ColoredBox(color: widget.color),
                  ),
                  PositionedDirectional(
                    start: trackWidth * fraction,
                    top: 0,
                    width: target,
                    height: target,
                    child: Center(
                      child: Container(
                        constraints: const BoxConstraints(
                          minWidth: 32,
                          minHeight: 20,
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: widget.color,
                          borderRadius: BorderRadius.circular(20),
                          border:
                              _focused
                                  ? Border.all(color: SL.text, width: 1.5)
                                  : null,
                        ),
                        child: Text(
                          'S${widget.week}',
                          key: const ValueKey('selected-week'),
                          maxLines: 1,
                          textAlign: TextAlign.center,
                          textScaler: MediaQuery.textScalerOf(
                            context,
                          ).clamp(maxScaleFactor: 1.5),
                          style: TextStyle(
                            fontSize: 11,
                            height: 1.1,
                            fontWeight: FontWeight.w700,
                            color: ProgrammeColors.of(context).onAccent,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    },
  );
}

class _DayCard extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  final bool isToday, done;
  final VoidCallback onOpen, onSummary;
  const _DayCard({
    required this.week,
    required this.day,
    required this.isToday,
    required this.done,
    required this.onOpen,
    required this.onSummary,
  });

  @override
  Widget build(BuildContext context) {
    final recovery = day.exercises.isEmpty;
    final estimate = isToday && !recovery ? store.dayEstimate(day) : null;
    final foreground = isToday ? Colors.white : SL.text;
    final secondary = isToday ? const Color(0xFFE8CCD4) : SL.dim;
    return Semantics(
      button: true,
      selected: isToday,
      onTapHint: done ? 'Afficher l’historique' : 'Ouvrir la séance',
      onLongPressHint: 'Afficher le résumé',
      child: KCard(
        key: ValueKey('programme-day-${day.j}'),
        color: isToday ? SL.bordeaux : SL.card,
        onTap: onOpen,
        onLongPress: onSummary,
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 40,
                  height: 44,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color:
                        isToday
                            ? Colors.white.withValues(alpha: .12)
                            : SL.faint,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    'J${day.j}',
                    style: TextStyle(
                      color: foreground,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        day.title.toUpperCase(),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: foreground,
                          fontSize: isToday ? 16 : 13,
                          fontWeight: FontWeight.w700,
                          height: 1.3,
                        ),
                      ),
                      if (!isToday) ...[
                        const SizedBox(height: 4),
                        Text(
                          done
                              ? 'Terminée'
                              : recovery
                              ? 'Repos & récupération'
                              : '${day.exercises.length} exercices',
                          style: TextStyle(
                            color: done ? SL.mainGreen : secondary,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Icon(
                  done
                      ? Icons.check_circle_rounded
                      : Icons.chevron_right_rounded,
                  size: 20,
                  color: done && !isToday ? SL.mainGreen : secondary,
                  semanticLabel: done ? 'Séance effectuée' : 'Séance à faire',
                ),
              ],
            ),
            if (isToday && recovery) ...[
              const SizedBox(height: 18),
              Text(
                'Prends le temps de récupérer.',
                style: TextStyle(
                  color: foreground,
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Repos et récupération · GtG suspendu',
                style: TextStyle(color: secondary),
              ),
            ],
            if (estimate != null) ...[
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          alignment: Alignment.centerLeft,
                          child: Text(
                            estimate.durationLabel,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.w600,
                              letterSpacing: -1,
                              fontFeatures: [FontFeature.tabularFigures()],
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Estimé · repos inclus',
                          style: TextStyle(color: secondary, fontSize: 11),
                        ),
                        const SizedBox(height: 14),
                        Text(
                          '${day.exercises.length} exercices',
                          style: TextStyle(
                            color: foreground,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${estimate.sets.round()} séries · ${estimate.volumeLabel}',
                          style: TextStyle(color: secondary, fontSize: 12),
                        ),
                        if (estimate.partial)
                          Text(
                            'Volume partiel',
                            style: TextStyle(color: secondary, fontSize: 10),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: MediaQuery.sizeOf(context).width < 350 ? 104 : 126,
                    child: MuscleHeatmap(
                      data: store.plannedMuscles(estimate),
                      height: 150,
                      labels: false,
                      tint: const Color(0xFFF1C3CE),
                      glow: false,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: SL.bordeaux,
                      ),
                      onPressed: onOpen,
                      icon: Icon(
                        done ? Icons.history_rounded : Icons.play_arrow_rounded,
                      ),
                      label: Text(done ? 'Voir la séance' : 'Ouvrir la séance'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    tooltip: 'Résumé de la séance',
                    onPressed: onSummary,
                    icon: const Icon(
                      Icons.insights_rounded,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
