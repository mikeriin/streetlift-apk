import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';
import 'estimate_view.dart';
import 'levelup.dart';
import 'models.dart';
import 'muscle_body.dart';
import 'session_history.dart';
import 'session_screen.dart';
import 'program_start.dart';
import 'store.dart';
import 'ui.dart';
import 'motion.dart';

/// Ouvre une journée du programme (accueil ou notification de rappel) : son
/// historique si elle est faite, sinon la séance. Le bilan s'affiche depuis
/// la fin de séance ; au retour, le navigateur vérifie un niveau gagné hors
/// bilan (jour de repos validé…) : ce contexte reste valable même si l'écran
/// d'origine a été reconstruit entre-temps.
Future<void> openProgramDay(NavigatorState nav, WeekPlan w, DayPlan d) async {
  final log = store.logs[store.sessionKey(w.n, d.j)];
  final root = nav.context;
  await nav.push<void>(
    MaterialPageRoute(
      builder:
          (_) =>
              log?.done == true
                  ? SessionHistoryScreen(log: log!, week: w, day: d)
                  : SessionScreen(week: w, day: d),
    ),
  );
  if (root.mounted) checkLevelUp(root);
}

class HomeScreen extends StatefulWidget {
  final DateTime? referenceDate;
  const HomeScreen({super.key, this.referenceDate});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late int week;
  DateTime get now => widget.referenceDate ?? DateTime.now();
  @override
  void initState() {
    super.initState();
    week = store.program.weekFor(now);
  }

  final ScrollController _scroll = ScrollController();
  double _swipe = 0;

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  void _selectWeek(int value) {
    final next = value.clamp(1, store.program.weeks.length);
    if (next == week) return;
    setState(() => week = next);
    if (_scroll.hasClients) _scroll.jumpTo(0);
  }

  Future<void> _pickWeek() async {
    final selected = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder:
          (context) => DraggableScrollableSheet(
            expand: false,
            initialChildSize: .75,
            maxChildSize: .95,
            builder:
                (context, controller) => ListView.builder(
                  controller: controller,
                  itemCount: store.program.weeks.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) {
                      return const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Choisir une semaine',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      );
                    }
                    final w = store.program.weeks[i - 1];
                    final done =
                        w.days.where((d) => store.isDone(w.n, d.j)).length;
                    return ListTile(
                      selected: w.n == week,
                      leading: CircleAvatar(child: Text('${w.n}')),
                      title: Text(
                        'Semaine ${w.n} · ${store.program.weekDates(w.n)}',
                      ),
                      subtitle: Text(
                        store.program.containsDate(now) &&
                                w.n == store.program.weekFor(now)
                            ? '${w.block} · Semaine actuelle'
                            : w.block,
                      ),
                      trailing: Text('$done / ${w.days.length}'),
                      onTap: () => Navigator.pop(context, w.n),
                    );
                  },
                ),
          ),
    );
    if (selected != null && mounted) _selectWeek(selected);
  }

  Future<void> _weekDetails(WeekPlan w) => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder:
        (sheetContext) => DraggableScrollableSheet(
          expand: false,
          initialChildSize: .7,
          maxChildSize: .94,
          builder:
              (context, controller) => KList(
                controller: controller,
                children: [
                  Text(
                    'Semaine ${w.n}',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  Text(store.program.weekDates(w.n).replaceAll('→', ' au ')),
                  Text(w.block, style: TextStyle(color: SL.accent)),
                  if (w.days.first.cycle.isNotEmpty) Text(w.days.first.cycle),
                  Text(
                    '${w.days.where((d) => store.isDone(w.n, d.j)).length} / ${w.days.length} journées validées',
                  ),
                  const KSection('Séances de la semaine'),
                  for (final d in w.days)
                    KCard(
                      padding: EdgeInsets.zero,
                      child: ListTile(
                        leading: Text('J${d.j}'),
                        title: Text(d.title),
                        subtitle: Text(
                          d.exercises.isEmpty
                              ? 'Récupération'
                              : '${d.exercises.length} exercices · ${store.dayEstimate(d).durationLabel}',
                        ),
                        trailing: Icon(
                          store.isDone(w.n, d.j)
                              ? Icons.check_circle_outline
                              : Icons.chevron_right,
                          size: 18,
                        ),
                        onTap: () {
                          Navigator.pop(sheetContext);
                          _open(w, d);
                        },
                      ),
                    ),
                  if (store.program.containsDate(now) &&
                      w.n != store.program.weekFor(now))
                    TextButton(
                      onPressed: () {
                        Navigator.pop(sheetContext);
                        _selectWeek(store.program.weekFor(now));
                      },
                      child: const Text('Revenir à la semaine actuelle'),
                    ),
                  TextButton.icon(
                    onPressed: () async {
                      Navigator.pop(sheetContext);
                      await _pickWeek();
                    },
                    icon: const Icon(Icons.calendar_month_outlined),
                    label: const Text('Choisir une semaine'),
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(sheetContext),
                    child: const Text('Fermer'),
                  ),
                ],
              ),
        ),
  );

  Future<void> _open(WeekPlan w, DayPlan d) =>
      openProgramDay(Navigator.of(context), w, d);

  void _summary(WeekPlan w, DayPlan d) {
    final done = store.isDone(w.n, d.j);
    final estimate = store.dayEstimate(d);
    final overview = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(d.title, style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Text(
          done ? 'Séance effectuée' : 'Séance à faire',
          style: TextStyle(color: done ? SL.success : SL.dim),
        ),
        const SizedBox(height: 8),
        if (d.exercises.isEmpty)
          const Text('Repos et récupération · GtG suspendu')
        else
          Row(
            children: [
              Expanded(child: Text('${d.exercises.length} exercices')),
              SizedBox(
                width: 110,
                child: MuscleHeatmap(
                  data: store.plannedMuscles(estimate),
                  height: 110,
                  labels: false,
                ),
              ),
            ],
          ),
      ],
    );
    if (d.exercises.isEmpty) {
      showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        builder:
            (context) => SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Résumé · S${w.n} · J${d.j}',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 14),
                  overview,
                ],
              ),
            ),
      );
    } else {
      showEstimate(
        context,
        'Résumé · S${w.n} · J${d.j}',
        estimate,
        overview: overview,
      );
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      final w = store.program.week(week), current = store.program.weekFor(now);
      final colors = ProgrammeColors.of(context);
      final today =
          store.program.containsDate(now) && current == week
              ? store.program.dayFor(now)
              : -1;
      Widget card(DayPlan d) => _DayCard(
        week: w,
        day: d,
        isToday: d.j == today,
        done: store.isDone(w.n, d.j),
        onOpen: () => _open(w, d),
        onSummary: () => _summary(w, d),
      );
      return KScreen(
        appBar: const KTopBar(leading: LevelPill()),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: KSpace.page),
              child: _WeekSlider(
                week: week,
                count: store.program.weeks.length,
                color: colors.slider,
                onChanged: _selectWeek,
                onDetails: () => _weekDetails(w),
                onChoose: _pickWeek,
              ),
            ),
            Expanded(
              child: GestureDetector(
                key: const ValueKey('programme-weeks'),
                behavior: HitTestBehavior.opaque,
                onHorizontalDragStart: (_) => _swipe = 0,
                onHorizontalDragUpdate: (details) => _swipe += details.delta.dx,
                onHorizontalDragEnd: (details) {
                  final velocity = details.primaryVelocity ?? 0;
                  if (_swipe.abs() < 48 && velocity.abs() < 300) return;
                  final direction = _swipe.abs() >= 48 ? _swipe : velocity;
                  _selectWeek(week + (direction < 0 ? 1 : -1));
                },
                child: KContentTransition(
                  key: const ValueKey('week-transition'),
                  position: week,
                  child: KList(
                    key: const PageStorageKey('programme-scroll'),
                    controller: _scroll,
                    gap: MediaQuery.sizeOf(context).height < 800 ? 4 : 8,
                    padding: const EdgeInsets.fromLTRB(
                      KSpace.page,
                      8,
                      KSpace.page,
                      12,
                    ),
                    children: [
                      // Dans la liste : lisible à 200 % sans écraser les
                      // journées (départ à choisir, à venir, terminé).
                      if (ProgramStartBanner.visible(store.program, now))
                        ProgramStartBanner(now: now, padding: EdgeInsets.zero),
                      for (final d in w.days) card(d),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    },
  );
}

/// Appui court : détails ; long : choix. Glissement et clavier : semaine.
class _WeekSlider extends StatefulWidget {
  final int week, count;
  final Color color;
  final ValueChanged<int> onChanged;
  final VoidCallback onDetails, onChoose;
  const _WeekSlider({
    required this.week,
    required this.count,
    required this.color,
    required this.onChanged,
    required this.onDetails,
    required this.onChoose,
  });
  @override
  State<_WeekSlider> createState() => _WeekSliderState();
}

class _WeekSliderState extends State<_WeekSlider> {
  final FocusNode _focus = FocusNode();
  bool _focused = false;
  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  void _step(int delta) =>
      widget.onChanged((widget.week + delta).clamp(1, widget.count));

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      const target = 48.0;
      final fraction =
          widget.count <= 1 ? 0.0 : (widget.week - 1) / (widget.count - 1);
      final rtl = Directionality.of(context) == TextDirection.rtl;
      final trackWidth = constraints.maxWidth - target;
      void drag(Offset point) {
        if (widget.count <= 1 || trackWidth <= 0) return;
        final x = ((point.dx - target / 2) / trackWidth).clamp(0.0, 1.0);
        widget.onChanged(1 + ((rtl ? 1 - x : x) * (widget.count - 1)).round());
      }

      return Semantics(
        slider: true,
        label: 'Progression du programme',
        value: 'Semaine ${widget.week} sur ${widget.count}',
        increasedValue:
            widget.week < widget.count
                ? 'Semaine ${widget.week + 1} sur ${widget.count}'
                : null,
        decreasedValue:
            widget.week > 1
                ? 'Semaine ${widget.week - 1} sur ${widget.count}'
                : null,
        onIncrease: widget.week < widget.count ? () => _step(1) : null,
        onDecrease: widget.week > 1 ? () => _step(-1) : null,
        onTap: widget.onDetails,
        onTapHint: 'Afficher le détail de la semaine',
        onLongPress: widget.onChoose,
        onLongPressHint: 'Choisir une semaine',
        excludeSemantics: true,
        child: Focus(
          focusNode: _focus,
          onFocusChange: (value) => setState(() => _focused = value),
          onKeyEvent: (_, event) {
            if (event is! KeyDownEvent && event is! KeyRepeatEvent) {
              return KeyEventResult.ignored;
            }
            final key = event.logicalKey;
            if (key == LogicalKeyboardKey.arrowRight) {
              _step(rtl ? -1 : 1);
            } else if (key == LogicalKeyboardKey.arrowLeft) {
              _step(rtl ? 1 : -1);
            } else if (key == LogicalKeyboardKey.home) {
              widget.onChanged(1);
            } else if (key == LogicalKeyboardKey.end) {
              widget.onChanged(widget.count);
            } else if (key == LogicalKeyboardKey.f2) {
              widget.onChoose();
            } else if (key == LogicalKeyboardKey.enter ||
                key == LogicalKeyboardKey.space) {
              widget.onDetails();
            } else {
              return KeyEventResult.ignored;
            }
            return KeyEventResult.handled;
          },
          child: GestureDetector(
            key: const ValueKey('week-slider'),
            behavior: HitTestBehavior.opaque,
            onTap: () {
              _focus.requestFocus();
              widget.onDetails();
            },
            onLongPress: () {
              _focus.requestFocus();
              widget.onChoose();
            },
            onHorizontalDragStart: (details) {
              _focus.requestFocus();
              drag(details.localPosition);
            },
            onHorizontalDragUpdate: (details) => drag(details.localPosition),
            child: SizedBox(
              height: target,
              child: Stack(
                children: [
                  Positioned(
                    left: target / 2 - 2,
                    right: target / 2 - 2,
                    top: 22,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        for (var i = 1; i <= widget.count; i++)
                          Container(
                            width: 4,
                            height: 4,
                            decoration: BoxDecoration(
                              color: i <= widget.week ? widget.color : SL.dot,
                              shape: BoxShape.circle,
                            ),
                          ),
                      ],
                    ),
                  ),
                  PositionedDirectional(
                    start: target / 2,
                    top: 22.5,
                    width: trackWidth * fraction,
                    height: 3,
                    child: ColoredBox(color: widget.color),
                  ),
                  PositionedDirectional(
                    start: trackWidth * fraction,
                    top: 0,
                    width: target,
                    height: target,
                    child: Center(
                      child: Container(
                        constraints: const BoxConstraints(
                          minWidth: 32,
                          minHeight: 20,
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: widget.color,
                          borderRadius: BorderRadius.circular(20),
                          border:
                              _focused
                                  ? Border.all(color: SL.text, width: 1.5)
                                  : null,
                        ),
                        child: Text(
                          'S${widget.week}',
                          key: const ValueKey('selected-week'),
                          maxLines: 1,
                          textAlign: TextAlign.center,
                          textScaler: MediaQuery.textScalerOf(
                            context,
                          ).clamp(maxScaleFactor: 1.5),
                          style: TextStyle(
                            fontSize: 11,
                            height: 1.1,
                            fontWeight: FontWeight.w700,
                            color: ProgrammeColors.of(context).onSlider,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    },
  );
}

class _DayCard extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  final bool isToday, done;
  final VoidCallback onOpen, onSummary;
  const _DayCard({
    required this.week,
    required this.day,
    required this.isToday,
    required this.done,
    required this.onOpen,
    required this.onSummary,
  });

  @override
  Widget build(BuildContext context) {
    final compact = MediaQuery.sizeOf(context).height < 800;
    final recovery = day.exercises.isEmpty;
    final estimate = isToday && !recovery ? store.dayEstimate(day) : null;
    final foreground = isToday ? Colors.white : SL.text;
    final secondary = isToday ? KPalette.light : SL.dim;
    final status = done ? 'Séance effectuée' : 'Séance à faire';
    final statusIcon = Icon(
      done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
      size: 20,
      color: done ? (isToday ? KPalette.light : SL.success) : secondary,
    );
    return Semantics(
      button: true,
      selected: isToday,
      label:
          'Jour ${day.j} · ${day.title}. $status${isToday ? ". Aujourd’hui" : ""}',
      value:
          !isToday
              ? null
              : estimate == null
              ? 'Repos et récupération. GtG suspendu.'
              : '${estimate.durationLabel}, ${day.exercises.length} exercices, ${estimate.sets.round()} séries, ${estimate.volumeLabel}',
      onTap: onOpen,
      onLongPress: onSummary,
      onTapHint: done ? 'Afficher l’historique' : 'Ouvrir la séance',
      onLongPressHint: 'Afficher le résumé',
      child: ExcludeSemantics(
        child: KCard(
          key: ValueKey('programme-day-${day.j}'),
          color: isToday ? SL.bordeaux : SL.card,
          onTap: onOpen,
          onLongPress: onSummary,
          padding:
              isToday
                  ? EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: compact ? 12 : 16,
                  )
                  : const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child:
              isToday
                  ? Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'J${day.j} · AUJOURD’HUI',
                              style: TextStyle(
                                color: secondary,
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                letterSpacing: .9,
                              ),
                            ),
                          ),
                          statusIcon,
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        day.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: foreground,
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          height: 1.2,
                        ),
                      ),
                      if (recovery) ...[
                        const SizedBox(height: 18),
                        Text(
                          'Prends le temps de récupérer.',
                          style: TextStyle(
                            color: foreground,
                            fontSize: 16,
                            height: 1.3,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Repos et récupération · GtG suspendu',
                          style: TextStyle(color: secondary, fontSize: 12),
                        ),
                      ],
                      if (estimate != null) ...[
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    estimate.durationLabel,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 25,
                                      height: 1.15,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: -.5,
                                      fontFeatures: [
                                        FontFeature.tabularFigures(),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    'Estimé · repos inclus',
                                    style: TextStyle(
                                      color: secondary,
                                      fontSize: 10,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    '${day.exercises.length} exercices · ${estimate.sets.round()} séries',
                                    style: TextStyle(
                                      color: foreground,
                                      fontSize: 12,
                                      height: 1.25,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    estimate.volumeLabel,
                                    style: TextStyle(
                                      color: secondary,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            SizedBox(
                              width:
                                  MediaQuery.sizeOf(context).width < 350
                                      ? 88
                                      : 106,
                              child: MuscleHeatmap(
                                data: store.plannedMuscles(estimate),
                                height: compact ? 90 : 110,
                                labels: false,
                                tint: KPalette.light,
                                glow: false,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  )
                  : ConstrainedBox(
                    constraints: const BoxConstraints(minHeight: 24),
                    child: Row(
                      children: [
                        Text(
                          'J${day.j}',
                          style: TextStyle(
                            color: SL.dim,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            fontFeatures: const [FontFeature.tabularFigures()],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            day.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: foreground,
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        statusIcon,
                      ],
                    ),
                  ),
        ),
      ),
    );
  }
}
