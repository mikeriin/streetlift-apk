import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'levelup.dart';
import 'models.dart';
import 'session_screen.dart';
import 'store.dart';
import 'ui.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late int week;
  @override
  void initState() {
    super.initState();
    week = store.program.weekFor(DateTime.now());
  }

  Future<void> _pickWeek() async {
    final selected = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder:
          (context) => DraggableScrollableSheet(
            expand: false,
            initialChildSize: .75,
            maxChildSize: .95,
            builder:
                (context, controller) => ListView.builder(
                  controller: controller,
                  itemCount: store.program.weeks.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) {
                      return const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Choisir une semaine',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      );
                    }
                    final w = store.program.weeks[i - 1];
                    final done =
                        w.days.where((d) => store.isDone(w.n, d.j)).length;
                    return ListTile(
                      selected: w.n == week,
                      leading: CircleAvatar(child: Text('${w.n}')),
                      title: Text('Semaine ${w.n} · ${w.dates}'),
                      subtitle: Text(w.block),
                      trailing: Text('$done / ${w.days.length}'),
                      onTap: () => Navigator.pop(context, w.n),
                    );
                  },
                ),
          ),
    );
    if (selected != null && mounted) setState(() => week = selected);
  }

  Future<void> _clear(WeekPlan w, DayPlan d) async {
    final ok = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Effacer cette séance ?'),
            content: Text(
              'Les séries, notes et la validation de S${w.n} · J${d.j} seront supprimées.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Annuler'),
              ),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: SL.danger,
                  foregroundColor: Colors.white,
                ),
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Effacer'),
              ),
            ],
          ),
    );
    if (ok == true) store.clearSession(w.n, d.j);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      final w = store.program.week(week);
      final now = DateTime.now();
      final current = store.program.weekFor(now);
      final today =
          store.program.containsDate(now) && current == week
              ? store.program.dayFor(now)
              : -1;
      final done = w.days.where((d) => store.isDone(w.n, d.j)).length;
      final cycle = w.days.isNotEmpty ? w.days.first.cycle : '';
      return KScreen(
        appBar: AppBar(
          title: const Text('KALIS TRACK'),
          actions: [
            const LevelPill(),
            IconButton(
              tooltip: 'Choisir une semaine',
              onPressed: _pickWeek,
              icon: const Icon(Icons.calendar_month),
            ),
          ],
        ),
        body: KList(
          key: const PageStorageKey('programme-scroll'),
          children: [
            KBanner(
              color: w.color,
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        tooltip: 'Semaine précédente',
                        onPressed:
                            week > 1 ? () => setState(() => week--) : null,
                        color: Colors.white,
                        disabledColor: Colors.white30,
                        icon: const Icon(Icons.chevron_left),
                      ),
                      Expanded(
                        child: InkWell(
                          onTap: _pickWeek,
                          borderRadius: BorderRadius.circular(10),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Column(
                              children: [
                                Text(
                                  'SEMAINE $week',
                                  key: const ValueKey('selected-week'),
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: .5,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  w.dates.replaceAll('→', ' au '),
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  cycle.isEmpty
                                      ? w.block
                                      : '${w.block} · $cycle',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      IconButton(
                        tooltip: 'Semaine suivante',
                        onPressed:
                            week < store.program.weeks.length
                                ? () => setState(() => week++)
                                : null,
                        color: Colors.white,
                        disabledColor: Colors.white30,
                        icon: const Icon(Icons.chevron_right),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                    child: Row(
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(3),
                            child: LinearProgressIndicator(
                              value: w.days.isEmpty ? 0 : done / w.days.length,
                              minHeight: 4,
                              color: Colors.white,
                              backgroundColor: Colors.white.withValues(
                                alpha: .2,
                              ),
                              semanticsLabel: 'Journées validées',
                              semanticsValue: '$done sur ${w.days.length}',
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          '$done / ${w.days.length}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            if (week != current)
              TextButton.icon(
                onPressed: () => setState(() => week = current),
                icon: const Icon(Icons.today_outlined, size: 18),
                label: const Text('Revenir à la semaine actuelle'),
              ),
            for (final d in w.days)
              _DayTile(
                week: w,
                day: d,
                isToday: d.j == today,
                done: store.isDone(w.n, d.j),
                onClear: () => _clear(w, d),
                onTap: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SessionScreen(week: w, day: d),
                    ),
                  );
                  if (context.mounted) checkLevelUp(context);
                },
              ),
          ],
        ),
      );
    },
  );
}

class _DayTile extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  final bool isToday, done;
  final VoidCallback onTap, onClear;
  const _DayTile({
    required this.week,
    required this.day,
    required this.isToday,
    required this.done,
    required this.onTap,
    required this.onClear,
  });

  @override
  Widget build(BuildContext context) {
    final rest = day.exercises.isEmpty;
    return KCard(
      padding: const EdgeInsets.fromLTRB(12, 6, 2, 6),
      accent: isToday ? SL.steel : null,
      onTap: onTap,
      onLongPress: onClear,
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: (done ? SL.mainGreen : week.color).withValues(alpha: .2),
              borderRadius: BorderRadius.circular(12),
            ),
            child:
                done
                    ? Icon(
                      Icons.check,
                      color: SL.mainGreen,
                      semanticLabel: 'J${day.j} validé',
                    )
                    : Text(
                      'J${day.j}',
                      style: TextStyle(
                        color: rest ? SL.dim : SL.text,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  day.title,
                  style: TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w700,
                    color: rest ? SL.dim : SL.text,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  rest
                      ? 'Récupération · GtG suspendu'
                      : '${day.exercises.length} exercices',
                  style: TextStyle(fontSize: 12, color: SL.dim),
                ),
                if (isToday)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      'AUJOURD’HUI',
                      style: TextStyle(
                        color: SL.steel,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          PopupMenuButton<String>(
            tooltip: 'Actions de la séance',
            onSelected: (_) => onClear(),
            itemBuilder:
                (_) => const [
                  PopupMenuItem(
                    value: 'clear',
                    child: Text('Effacer l’historique'),
                  ),
                ],
          ),
        ],
      ),
    );
  }
}
