import 'package:flutter/material.dart';

import 'levelup.dart';
import 'main.dart';
import 'models.dart';
import 'session_screen.dart';
import 'store.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late int week;

  @override
  void initState() {
    super.initState();
    week = store.program.weekFor(DateTime.now());
  }

  void _pickWeek() {
    showModalBottomSheet(
      context: context,
      backgroundColor: SL.surface,
      builder:
          (_) => ListView.builder(
            itemCount: store.program.weeks.length,
            itemBuilder: (_, i) {
              final w = store.program.weeks[i];
              final doneDays = List.generate(
                7,
                (j) => store.isDone(w.n, j + 1) ? 1 : 0,
              ).fold<int>(0, (a, b) => a + b);
              return ListTile(
                leading: CircleAvatar(
                  radius: 14,
                  backgroundColor: w.color,
                  child: Text(
                    '${w.n}',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                title: Text(
                  'S${w.n} · ${w.dates}',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                subtitle: Text(w.block),
                trailing: Text(
                  '$doneDays/7',
                  style: TextStyle(color: SL.dim, fontSize: 12),
                ),
                selected: w.n == week,
                onTap: () {
                  setState(() => week = w.n);
                  Navigator.pop(context);
                },
              );
            },
          ),
    );
  }

  void _confirmClear(BuildContext context, WeekPlan w, DayPlan d) {
    if (!store.logs.containsKey(store.sessionKey(w.n, d.j))) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Aucun historique pour cette séance.')),
      );
      return;
    }
    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            backgroundColor: SL.surface,
            title: const Text('Supprimer l\u2019historique ?'),
            content: Text(
              'S${w.n} · J${d.j} — les séries saisies, les notes et le statut « fait » seront effacés. Action irréversible.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Annuler'),
              ),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: SL.danger,
                  foregroundColor: Colors.white,
                ),
                onPressed: () {
                  store.clearSession(w.n, d.j);
                  Navigator.pop(ctx);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Historique de S${w.n} · J${d.j} supprimé.',
                      ),
                    ),
                  );
                },
                child: const Text('Supprimer'),
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final w = store.program.week(week);
        final today =
            store.program.containsDate(DateTime.now()) &&
                    store.program.weekFor(DateTime.now()) == week
                ? store.program.dayFor(DateTime.now())
                : -1;
        final cycle = w.days.isNotEmpty ? w.days.first.cycle : '';
        return Scaffold(
          appBar: AppBar(
            title: const Text('KALIS TRACK'),
            actions: [
              const LevelPill(),
              IconButton(
                onPressed: _pickWeek,
                icon: const Icon(Icons.calendar_month),
              ),
            ],
          ),
          body: Column(
            children: [
              _WeekHeader(
                week: w,
                cycle: cycle,
                onPrev: week > 1 ? () => setState(() => week--) : null,
                onNext:
                    week < store.program.weeks.length
                        ? () => setState(() => week++)
                        : null,
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.only(top: 6, bottom: 16),
                  children: [
                    for (final d in w.days)
                      _DayTile(
                        week: w,
                        day: d,
                        isToday: d.j == today,
                        done: store.isDone(w.n, d.j),
                        onLongPress: () => _confirmClear(context, w, d),
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => SessionScreen(week: w, day: d),
                            ),
                          );
                          if (context.mounted) checkLevelUp(context);
                        },
                      ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _WeekHeader extends StatelessWidget {
  final WeekPlan week;
  final String cycle;
  final VoidCallback? onPrev;
  final VoidCallback? onNext;
  const _WeekHeader({
    required this.week,
    required this.cycle,
    this.onPrev,
    this.onNext,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 4),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            week.color.withValues(alpha: 0.85),
            week.color.withValues(alpha: 0.45),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: onPrev,
            icon: const Icon(Icons.chevron_left, color: Colors.white),
          ),
          Expanded(
            child: Column(
              children: [
                Text(
                  'SEMAINE ${week.n}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  week.dates,
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
                Text(
                  cycle.isEmpty ? week.block : '${week.block} · $cycle',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: onNext,
            icon: const Icon(Icons.chevron_right, color: Colors.white),
          ),
        ],
      ),
    );
  }
}

class _DayTile extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  final bool isToday;
  final bool done;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  const _DayTile({
    required this.week,
    required this.day,
    required this.isToday,
    required this.done,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final rest = day.exercises.isEmpty;
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side:
            isToday ? BorderSide(color: SL.steel, width: 1.6) : BorderSide.none,
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        leading: Container(
          width: 42,
          height: 42,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color:
                done
                    ? SL.mainGreen.withValues(alpha: 0.18)
                    : week.color.withValues(alpha: 0.20),
            borderRadius: BorderRadius.circular(12),
          ),
          child:
              done
                  ? Icon(Icons.check, color: SL.mainGreen)
                  : Text(
                    'J${day.j}',
                    style: TextStyle(
                      color: rest ? SL.dim : SL.text,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
        ),
        title: Text(
          day.title,
          maxLines: 2,
          style: TextStyle(
            fontSize: 14.5,
            fontWeight: FontWeight.w700,
            color: rest ? SL.dim : SL.text,
          ),
        ),
        subtitle:
            rest
                ? Text(
                  'Récupération · GtG suspendu',
                  style: TextStyle(fontSize: 12, color: SL.dim),
                )
                : Text(
                  '${day.exercises.length} exercices',
                  style: TextStyle(fontSize: 12, color: SL.dim),
                ),
        trailing:
            isToday
                ? Text(
                  'AUJOURD\u2019HUI',
                  style: TextStyle(
                    color: SL.steel,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                )
                : Icon(Icons.chevron_right, color: SL.dim),
        onTap: onTap,
        onLongPress: onLongPress,
      ),
    );
  }
}
