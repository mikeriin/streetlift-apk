import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'levelup.dart';
import 'models.dart';
import 'session_screen.dart';
import 'store.dart';
import 'ui.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late int week;
  @override
  void initState() {
    super.initState();
    week = store.program.weekFor(DateTime.now());
  }

  Future<void> _pickWeek() async {
    final selected = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder:
          (context) => DraggableScrollableSheet(
            expand: false,
            initialChildSize: .75,
            maxChildSize: .95,
            builder:
                (context, controller) => ListView.builder(
                  controller: controller,
                  itemCount: store.program.weeks.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) {
                      return const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Choisir une semaine',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      );
                    }
                    final w = store.program.weeks[i - 1];
                    final done =
                        w.days.where((d) => store.isDone(w.n, d.j)).length;
                    return ListTile(
                      selected: w.n == week,
                      leading: CircleAvatar(child: Text('${w.n}')),
                      title: Text('Semaine ${w.n} · ${w.dates}'),
                      subtitle: Text(w.block),
                      trailing: Text('$done / ${w.days.length}'),
                      onTap: () => Navigator.pop(context, w.n),
                    );
                  },
                ),
          ),
    );
    if (selected != null && mounted) setState(() => week = selected);
  }

  Future<void> _clear(WeekPlan w, DayPlan d) async {
    final ok = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Effacer cette séance ?'),
            content: Text(
              'Les séries, notes et la validation de S${w.n} · J${d.j} seront supprimées.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Annuler'),
              ),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: SL.danger,
                  foregroundColor: Colors.white,
                ),
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Effacer'),
              ),
            ],
          ),
    );
    if (ok == true) store.clearSession(w.n, d.j);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      final w = store.program.week(week);
      final now = DateTime.now();
      final current = store.program.weekFor(now);
      final today =
          store.program.containsDate(now) && current == week ? now.weekday : -1;
      final done = w.days.where((d) => store.isDone(w.n, d.j)).length;
      final c = Theme.of(context).colorScheme;
      return KScreen(
        appBar: AppBar(
          title: const Text('Programme'),
          actions: [
            const LevelPill(),
            IconButton(
              tooltip: 'Choisir une semaine',
              onPressed: _pickWeek,
              icon: const Icon(Icons.calendar_month_outlined),
            ),
          ],
        ),
        body: KList(
          key: const PageStorageKey('programme-scroll'),
          children: [
            KCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      IconButton(
                        tooltip: 'Semaine précédente',
                        onPressed:
                            week > 1 ? () => setState(() => week--) : null,
                        icon: const Icon(Icons.chevron_left),
                      ),
                      Expanded(
                        child: InkWell(
                          onTap: _pickWeek,
                          borderRadius: BorderRadius.circular(10),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Column(
                              children: [
                                Text(
                                  'Semaine $week',
                                  style:
                                      Theme.of(context).textTheme.headlineSmall,
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  w.dates.replaceAll('→', ' au '),
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      IconButton(
                        tooltip: 'Semaine suivante',
                        onPressed:
                            week < store.program.weeks.length
                                ? () => setState(() => week++)
                                : null,
                        icon: const Icon(Icons.chevron_right),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(w.block, style: Theme.of(context).textTheme.titleMedium),
                  if (w.days.isNotEmpty && w.days.first.cycle.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(
                      w.days.first.cycle,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                  const SizedBox(height: 16),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(value: done / w.days.length),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '$done / ${w.days.length} journées validées',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  if (week != current)
                    TextButton.icon(
                      onPressed: () => setState(() => week = current),
                      icon: const Icon(Icons.today_outlined),
                      label: const Text('Revenir à la semaine actuelle'),
                    ),
                ],
              ),
            ),
            const KSection('Tes séances'),
            for (final d in w.days)
              KCard(
                accent: d.j == today ? c.primary : null,
                onLongPress: () => _clear(w, d),
                onTap: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SessionScreen(week: w, day: d),
                    ),
                  );
                  if (context.mounted) checkLevelUp(context);
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 42,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: c.primaryContainer,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        children: [
                          Text(
                            [
                              'LUN',
                              'MAR',
                              'MER',
                              'JEU',
                              'VEN',
                              'SAM',
                              'DIM',
                            ][d.j - 1],
                            style: TextStyle(
                              color: c.primary,
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${store.program.dateFor(week, d.j).day}',
                            style: TextStyle(
                              color: c.primary,
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            d.title,
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 5),
                          Text(
                            d.exercises.isEmpty
                                ? 'Récupération'
                                : '${d.exercises.length} exercices',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          if (d.j == today || store.isDone(w.n, d.j)) ...[
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              children: [
                                if (d.j == today)
                                  KBadge('Aujourd’hui', color: c.primary),
                                if (store.isDone(w.n, d.j))
                                  KBadge(
                                    'Validée',
                                    icon: Icons.check,
                                    color: SL.mainGreen,
                                  ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                    PopupMenuButton<String>(
                      tooltip: 'Actions de la séance',
                      padding: EdgeInsets.zero,
                      onSelected: (_) => _clear(w, d),
                      itemBuilder:
                          (_) => const [
                            PopupMenuItem(
                              value: 'clear',
                              child: Text('Effacer l’historique'),
                            ),
                          ],
                    ),
                  ],
                ),
              ),
          ],
        ),
      );
    },
  );
}
