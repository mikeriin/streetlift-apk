import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'estimate_view.dart';
import 'levelup.dart';
import 'models.dart';
import 'muscle_body.dart';
import 'session_history.dart';
import 'session_screen.dart';
import 'store.dart';
import 'ui.dart';

class HomeScreen extends StatefulWidget {
  final DateTime? referenceDate;
  const HomeScreen({super.key, this.referenceDate});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late int week;
  DateTime get now => widget.referenceDate ?? DateTime.now();
  @override
  void initState() {
    super.initState();
    week = store.program.weekFor(now);
  }

  void _selectWeek(int value) => setState(() => week = value);

  Future<void> _pickWeek() async {
    final selected = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder:
          (context) => DraggableScrollableSheet(
            expand: false,
            initialChildSize: .75,
            maxChildSize: .95,
            builder:
                (context, controller) => ListView.builder(
                  controller: controller,
                  itemCount: store.program.weeks.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) {
                      return const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Choisir une semaine',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      );
                    }
                    final w = store.program.weeks[i - 1];
                    final done =
                        w.days.where((d) => store.isDone(w.n, d.j)).length;
                    return ListTile(
                      selected: w.n == week,
                      leading: CircleAvatar(child: Text('${w.n}')),
                      title: Text('Semaine ${w.n} · ${w.dates}'),
                      subtitle: Text(
                        w.n == store.program.weekFor(now)
                            ? '${w.block} · Semaine actuelle'
                            : w.block,
                      ),
                      trailing: Text('$done / ${w.days.length}'),
                      onTap: () => Navigator.pop(context, w.n),
                    );
                  },
                ),
          ),
    );
    if (selected != null && mounted) _selectWeek(selected);
  }

  Future<void> _weekDetails(WeekPlan w) => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder:
        (sheetContext) => DraggableScrollableSheet(
          expand: false,
          initialChildSize: .7,
          maxChildSize: .94,
          builder:
              (context, controller) => KList(
                controller: controller,
                children: [
                  Text(
                    'Semaine ${w.n}',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  Text(w.dates.replaceAll('→', ' au ')),
                  Text(w.block, style: TextStyle(color: SL.steel)),
                  if (w.days.first.cycle.isNotEmpty) Text(w.days.first.cycle),
                  Text(
                    '${w.days.where((d) => store.isDone(w.n, d.j)).length} / ${w.days.length} journées validées',
                  ),
                  const KSection('Séances de la semaine'),
                  for (final d in w.days)
                    KCard(
                      padding: EdgeInsets.zero,
                      child: ListTile(
                        leading: Text('J${d.j}'),
                        title: Text(d.title),
                        subtitle: Text(
                          d.exercises.isEmpty
                              ? 'Récupération'
                              : '${d.exercises.length} exercices · ${store.dayEstimate(d).durationLabel}',
                        ),
                        trailing: Icon(
                          store.isDone(w.n, d.j)
                              ? Icons.check_circle_outline
                              : Icons.chevron_right,
                          size: 18,
                        ),
                        onTap: () {
                          Navigator.pop(sheetContext);
                          _open(w, d);
                        },
                      ),
                    ),
                  if (w.n != store.program.weekFor(now))
                    TextButton(
                      onPressed: () {
                        Navigator.pop(sheetContext);
                        _selectWeek(store.program.weekFor(now));
                      },
                      child: const Text('Revenir à la semaine actuelle'),
                    ),
                  TextButton(
                    onPressed: () => Navigator.pop(sheetContext),
                    child: const Text('Fermer'),
                  ),
                ],
              ),
        ),
  );

  Future<void> _open(WeekPlan w, DayPlan d) async {
    final log = store.logs[store.sessionKey(w.n, d.j)];
    await Navigator.push<void>(
      context,
      MaterialPageRoute(
        builder:
            (_) =>
                log?.done == true
                    ? SessionHistoryScreen(log: log!)
                    : SessionScreen(week: w, day: d),
      ),
    );
    if (mounted) checkLevelUp(context);
  }

  void _summary(WeekPlan w, DayPlan d) {
    final done = store.isDone(w.n, d.j);
    final estimate = store.dayEstimate(d);
    final overview = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(d.title, style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Text(
          done ? 'Séance effectuée' : 'Séance à faire',
          style: TextStyle(color: done ? SL.mainGreen : SL.dim),
        ),
        const SizedBox(height: 8),
        if (d.exercises.isEmpty)
          const Text('Repos et récupération · GtG suspendu')
        else
          Row(
            children: [
              Expanded(child: Text('${d.exercises.length} exercices')),
              SizedBox(
                width: 110,
                child: MuscleHeatmap(
                  data: store.plannedMuscles(estimate),
                  height: 110,
                  labels: false,
                ),
              ),
            ],
          ),
      ],
    );
    if (d.exercises.isEmpty) {
      showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        builder:
            (context) => SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Résumé · S${w.n} · J${d.j}',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 14),
                  overview,
                ],
              ),
            ),
      );
    } else {
      showEstimate(
        context,
        'Résumé · S${w.n} · J${d.j}',
        estimate,
        overview: overview,
      );
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      final w = store.program.week(week), current = store.program.weekFor(now);
      final today =
          store.program.containsDate(now) && current == week
              ? store.program.dayFor(now)
              : -1;
      return KScreen(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          titleSpacing: 8,
          title: SizedBox(
            height: 52,
            width: double.infinity,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Image.asset(
                  'assets/icon/icon_fg.png',
                  width: 64,
                  height: 64,
                  color: SL.text,
                  colorBlendMode: BlendMode.srcIn,
                  semanticLabel: 'Kalis Track',
                ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.sizeOf(context).width * .4,
                    ),
                    child: const FittedBox(
                      fit: BoxFit.scaleDown,
                      child: LevelPill(),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: IconButton(
                    tooltip: 'Choisir une semaine',
                    onPressed: _pickWeek,
                    icon: const Icon(Icons.calendar_month_outlined),
                  ),
                ),
              ],
            ),
          ),
        ),
        body: KList(
          key: const PageStorageKey('programme-scroll'),
          gap: 6,
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          children: [
            _WeekSlider(
              week: week,
              count: store.program.weeks.length,
              color: w.color,
              onChanged: _selectWeek,
              onDetails: () => _weekDetails(w),
            ),
            for (final d in w.days)
              _DayCard(
                week: w,
                day: d,
                isToday: d.j == today,
                done: store.isDone(w.n, d.j),
                onOpen: () => _open(w, d),
                onSummary: () => _summary(w, d),
              ),
          ],
        ),
      );
    },
  );
}

/// The text follows the native slider, whose keyboard and accessibility
/// controls remain available. Holding the thumb opens the selected week.
class _WeekSlider extends StatelessWidget {
  final int week, count;
  final Color color;
  final ValueChanged<int> onChanged;
  final VoidCallback onDetails;
  const _WeekSlider({
    required this.week,
    required this.count,
    required this.color,
    required this.onChanged,
    required this.onDetails,
  });

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      const target = 48.0;
      final fraction = count <= 1 ? 0.0 : (week - 1) / (count - 1);
      final rtl = Directionality.of(context) == TextDirection.rtl;
      final left =
          (constraints.maxWidth - target) * (rtl ? 1 - fraction : fraction);
      return Semantics(
        onLongPress: onDetails,
        onLongPressHint: 'Afficher le détail de la semaine',
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          excludeFromSemantics: true,
          onLongPressStart: (details) {
            if ((details.localPosition.dx - left - target / 2).abs() <=
                target / 2) {
              onDetails();
            }
          },
          child: SizedBox(
            height: target,
            child: Stack(
              children: [
                Positioned.fill(
                  child: SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      trackHeight: 2,
                      trackShape: const RectangularSliderTrackShape(),
                      thumbShape: SliderComponentShape.noThumb,
                      overlayShape: const RoundSliderOverlayShape(
                        overlayRadius: target / 2,
                      ),
                      showValueIndicator: ShowValueIndicator.never,
                      activeTrackColor: color,
                      inactiveTrackColor: SL.line,
                      activeTickMarkColor: Colors.transparent,
                      inactiveTickMarkColor: Colors.transparent,
                    ),
                    child: Slider(
                      key: const ValueKey('week-slider'),
                      min: 1,
                      max: count > 1 ? count.toDouble() : 2,
                      divisions: count > 1 ? count - 1 : null,
                      value: week.toDouble(),
                      allowedInteraction: SliderInteraction.slideOnly,
                      semanticFormatterCallback:
                          (value) => 'Semaine ${value.round()} sur $count',
                      onChanged:
                          count > 1
                              ? (value) => onChanged(value.round())
                              : null,
                    ),
                  ),
                ),
                Positioned(
                  left: left,
                  top: 0,
                  width: target,
                  height: target,
                  child: IgnorePointer(
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.surface,
                          border: Border.all(color: color, width: 1.5),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'S$week',
                          key: const ValueKey('selected-week'),
                          maxLines: 1,
                          textScaler: MediaQuery.textScalerOf(
                            context,
                          ).clamp(maxScaleFactor: 1.5),
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: SL.text,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

class _DayCard extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  final bool isToday, done;
  final VoidCallback onOpen, onSummary;
  const _DayCard({
    required this.week,
    required this.day,
    required this.isToday,
    required this.done,
    required this.onOpen,
    required this.onSummary,
  });

  @override
  Widget build(BuildContext context) {
    final recovery = day.exercises.isEmpty;
    final estimate = isToday ? store.dayEstimate(day) : null;
    final title = day.title.toLowerCase();
    return Semantics(
      button: true,
      selected: isToday,
      onTapHint: done ? 'Afficher l’historique' : 'Ouvrir la séance',
      onLongPressHint: 'Afficher le résumé',
      child: KCard(
        key: ValueKey('programme-day-${day.j}'),
        accent: isToday ? week.color : null,
        color:
            isToday
                ? Color.alphaBlend(
                  week.color.withValues(alpha: .14),
                  Theme.of(context).colorScheme.surfaceContainerLow,
                )
                : null,
        onTap: onOpen,
        onLongPress: onSummary,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 46),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 7),
                child: Row(
                  children: [
                    Icon(
                      done
                          ? Icons.check_circle_outline
                          : Icons.radio_button_unchecked,
                      size: 17,
                      color: done ? SL.mainGreen : SL.dim,
                      semanticLabel:
                          done ? 'Séance effectuée' : 'Séance à faire',
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 23,
                      child: Text(
                        'J${day.j}',
                        style: TextStyle(fontSize: 11.5, color: SL.dim),
                      ),
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        title.isEmpty
                            ? title
                            : title[0].toUpperCase() + title.substring(1),
                        maxLines: isToday ? 3 : 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight:
                              isToday ? FontWeight.w600 : FontWeight.w500,
                          color: recovery ? SL.dim : SL.text,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (isToday)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child:
                    recovery
                        ? Text(
                          'Repos et récupération · GtG suspendu',
                          style: TextStyle(fontSize: 12, color: SL.dim),
                        )
                        : Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _metric(
                                    Icons.fitness_center,
                                    '${day.exercises.length} ex. · ${estimate!.sets.round()} séries',
                                  ),
                                  _metric(
                                    Icons.bolt_outlined,
                                    estimate.volumeLabel.replaceAll(
                                      ' + non chiffré',
                                      ' *',
                                    ),
                                  ),
                                  _metric(
                                    Icons.schedule,
                                    estimate.durationLabel,
                                  ),
                                  if (estimate.hasTonnage)
                                    Text(
                                      '${estimate.tonnage.label} kg·rép.',
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: SL.dim,
                                      ),
                                    ),
                                  const SizedBox(height: 3),
                                  Text(
                                    estimate.partial
                                        ? '* volume partiel · repos inclus'
                                        : 'Repos et transitions inclus',
                                    style: TextStyle(
                                      fontSize: 9.5,
                                      color: SL.dim,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 6),
                            SizedBox(
                              width: 92,
                              child: Semantics(
                                label: 'Groupes musculaires ciblés',
                                child: MuscleHeatmap(
                                  data: store.plannedMuscles(estimate),
                                  height: 102,
                                  labels: false,
                                ),
                              ),
                            ),
                          ],
                        ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _metric(IconData icon, String text) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      children: [
        Icon(icon, size: 15, color: SL.dim),
        const SizedBox(width: 6),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 12.5))),
      ],
    ),
  );
}
