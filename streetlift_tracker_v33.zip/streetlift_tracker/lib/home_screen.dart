import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'levelup.dart';
import 'models.dart';
import 'muscle_body.dart';
import 'estimate_view.dart';
import 'session_screen.dart';
import 'store.dart';
import 'ui.dart';

class HomeScreen extends StatefulWidget {
  final DateTime Function()? now;
  const HomeScreen({super.key, this.now});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late int week;
  @override
  void initState() {
    super.initState();
    week = store.program.weekFor(widget.now?.call() ?? DateTime.now());
  }

  Future<void> _pickWeek() async {
    final selected = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder:
          (context) => DraggableScrollableSheet(
            expand: false,
            initialChildSize: .75,
            maxChildSize: .95,
            builder:
                (context, controller) => ListView.builder(
                  controller: controller,
                  itemCount: store.program.weeks.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) {
                      return const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Choisir une semaine',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      );
                    }
                    final w = store.program.weeks[i - 1];
                    final done =
                        w.days.where((d) => store.isDone(w.n, d.j)).length;
                    return ListTile(
                      selected: w.n == week,
                      leading: CircleAvatar(child: Text('${w.n}')),
                      title: Text('Semaine ${w.n} · ${w.dates}'),
                      subtitle: Text(w.block),
                      trailing: Text('$done / ${w.days.length}'),
                      onTap: () => Navigator.pop(context, w.n),
                    );
                  },
                ),
          ),
    );
    if (selected != null && mounted) setState(() => week = selected);
  }

  Future<void> _clear(WeekPlan w, DayPlan d) async {
    final ok = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Effacer cette séance ?'),
            content: Text(
              'Les séries, notes et la validation de S${w.n} · J${d.j} seront supprimées.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Annuler'),
              ),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: SL.danger,
                  foregroundColor: Colors.white,
                ),
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Effacer'),
              ),
            ],
          ),
    );
    if (ok == true) store.clearSession(w.n, d.j);
  }

  void _select(int n) => setState(() => week = n);

  void _weekDetails(WeekPlan w) {
    final done = w.days.where((d) => store.isDone(w.n, d.j)).length;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder:
          (context) => SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Semaine ${w.n}',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 6),
                Text(w.dates.replaceAll('→', ' au ')),
                const SizedBox(height: 6),
                Text(
                  w.block,
                  style: TextStyle(color: w.color, fontWeight: FontWeight.w600),
                ),
                if (w.days.isNotEmpty && w.days.first.cycle.isNotEmpty)
                  Text(w.days.first.cycle),
                const SizedBox(height: 12),
                Text('$done / ${w.days.length} journées validées'),
                Text(
                  '${w.days.where((d) => d.exercises.isNotEmpty).length} séances prévues',
                ),
                const SizedBox(height: 14),
                LinearProgressIndicator(
                  value: w.days.isEmpty ? 0 : done / w.days.length,
                  minHeight: 3,
                  color: w.color,
                ),
                const SizedBox(height: 12),
                TextButton.icon(
                  onPressed: () {
                    Navigator.pop(context);
                    _pickWeek();
                  },
                  icon: const Icon(Icons.calendar_month_outlined, size: 18),
                  label: const Text('Choisir une autre semaine'),
                ),
              ],
            ),
          ),
    );
  }

  Future<void> _open(WeekPlan w, DayPlan d) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => SessionScreen(week: w, day: d)),
    );
    if (mounted) {
      checkLevelUp(context);
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      final w = store.program.week(week);
      final now = widget.now?.call() ?? DateTime.now();
      final current = store.program.weekFor(now);
      final today =
          store.program.containsDate(now) && current == week
              ? store.program.dayFor(now)
              : -1;
      return KScreen(
        appBar: AppBar(
          toolbarHeight: 56,
          automaticallyImplyLeading: false,
          titleSpacing: 0,
          title: SizedBox(
            height: 56,
            child: Stack(
              children: [
                Center(
                  child: Image.asset(
                    'assets/icon/icon_fg.png',
                    width: 62,
                    height: 52,
                    color: SL.text,
                    semanticLabel: 'Kalis Track',
                  ),
                ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 8),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        maxWidth: MediaQuery.sizeOf(context).width * .43,
                      ),
                      child: const FittedBox(
                        fit: BoxFit.scaleDown,
                        child: LevelPill(),
                      ),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 4),
                    child: IconButton(
                      tooltip: 'Choisir une semaine',
                      onPressed: _pickWeek,
                      icon: const Icon(Icons.calendar_month_outlined),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        body: KList(
          key: const PageStorageKey('programme-scroll'),
          gap: 4,
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          children: [
            _weekSlider(w),
            if (week != current)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: () => _select(current),
                  icon: const Icon(Icons.today_outlined, size: 16),
                  label: const Text('Semaine actuelle'),
                ),
              ),
            for (final d in w.days)
              _DayTile(
                week: w,
                day: d,
                isToday: d.j == today,
                done: store.isDone(w.n, d.j),
                onClear: () => _clear(w, d),
                onTap: () => _open(w, d),
              ),
          ],
        ),
      );
    },
  );

  Widget _weekSlider(WeekPlan w) {
    final max = store.program.weeks.length;
    return Column(
      children: [
        Row(
          children: [
            IconButton(
              tooltip: 'Semaine précédente',
              onPressed: week > 1 ? () => _select(week - 1) : null,
              icon: const Icon(Icons.chevron_left, size: 20),
            ),
            Expanded(
              child: InkWell(
                key: const ValueKey('week-details'),
                onTap: () => _weekDetails(w),
                borderRadius: BorderRadius.circular(8),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 7),
                  child: Column(
                    children: [
                      Text(
                        'SEMAINE $week',
                        key: const ValueKey('selected-week'),
                        style: TextStyle(
                          color: w.color,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        w.dates.replaceAll('→', ' au '),
                        style: TextStyle(color: SL.dim, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            IconButton(
              tooltip: 'Semaine suivante',
              onPressed: week < max ? () => _select(week + 1) : null,
              icon: const Icon(Icons.chevron_right, size: 20),
            ),
          ],
        ),
        SizedBox(
          height: 24,
          child: SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: 2,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
              activeTickMarkColor: Colors.transparent,
              inactiveTickMarkColor: Colors.transparent,
            ),
            child: Slider(
              key: const ValueKey('week-slider'),
              value: week.toDouble(),
              min: 1,
              max: max.toDouble(),
              divisions: max > 1 ? max - 1 : null,
              activeColor: w.color,
              label: 'Semaine $week',
              semanticFormatterCallback: (v) => 'Semaine ${v.round()} sur $max',
              onChanged: max > 1 ? (v) => _select(v.round()) : null,
            ),
          ),
        ),
      ],
    );
  }
}

class _DayTile extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  final bool isToday, done;
  final VoidCallback onTap, onClear;
  const _DayTile({
    required this.week,
    required this.day,
    required this.isToday,
    required this.done,
    required this.onTap,
    required this.onClear,
  });
  @override
  Widget build(BuildContext context) {
    final rest = day.exercises.isEmpty;
    final estimate = isToday ? store.dayEstimate(day) : null;
    final color = done ? SL.mainGreen : week.color;
    final title = day.title.toLowerCase();
    return KCard(
      key: ValueKey('programme-day-${day.j}'),
      padding: EdgeInsets.fromLTRB(10, isToday ? 6 : 0, 1, isToday ? 4 : 0),
      accent: isToday ? color : null,
      onTap: onTap,
      onLongPress: onClear,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SizedBox(
                width: 28,
                child:
                    done
                        ? Icon(
                          Icons.check_circle_outline,
                          color: SL.mainGreen,
                          size: 19,
                          semanticLabel: 'J${day.j} validé',
                        )
                        : Text(
                          'J${day.j}',
                          style: TextStyle(color: SL.dim, fontSize: 11.5),
                        ),
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title.isEmpty
                          ? title
                          : title[0].toUpperCase() + title.substring(1),
                      maxLines: isToday ? 2 : 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: isToday ? FontWeight.w600 : FontWeight.w500,
                        color: rest ? SL.dim : SL.text,
                      ),
                    ),
                    if (isToday)
                      Padding(
                        padding: const EdgeInsets.only(top: 3),
                        child: Text(
                          'AUJOURD’HUI${done ? ' · TERMINÉE' : ''}',
                          style: TextStyle(
                            color: color,
                            fontSize: 9,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                tooltip: 'Actions de la séance',
                child: const SizedBox(
                  width: 44,
                  height: 44,
                  child: Icon(Icons.more_vert, size: 17),
                ),
                onSelected: (v) {
                  if (v == 'details') {
                    showEstimate(context, day.title, store.dayEstimate(day));
                  } else {
                    onClear();
                  }
                },
                itemBuilder:
                    (_) => [
                      const PopupMenuItem(
                        value: 'details',
                        child: Text('Volume et durée'),
                      ),
                      const PopupMenuItem(
                        value: 'clear',
                        child: Text('Effacer l’historique'),
                      ),
                    ],
              ),
            ],
          ),
          if (isToday) ...[
            if (rest)
              Padding(
                padding: const EdgeInsets.fromLTRB(32, 0, 12, 9),
                child: Text(
                  'Récupération · GtG suspendu',
                  style: TextStyle(color: SL.dim, fontSize: 12),
                ),
              )
            else
              Padding(
                padding: const EdgeInsets.only(left: 4, right: 10),
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final muscles = store.plannedMuscles(estimate!);
                    final map = Semantics(
                      label: 'Muscles ciblés : ${muscles.keys.join(', ')}',
                      child: MuscleHeatmap(
                        data: muscles,
                        height: 108,
                        labels: false,
                      ),
                    );
                    final stats = Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${day.exercises.length} ex. · ${estimate.sets.round()} séries',
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          estimate.volumeLabel
                              .replaceAll(' + non chiffré', ' *')
                              .replaceAll('s d’effort', 's'),
                          style: const TextStyle(fontSize: 12),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          estimate.durationLabel,
                          style: TextStyle(
                            color: color,
                            fontSize: 17,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          estimate.partial
                              ? '* volume partiel · repos inclus'
                              : 'repos et transitions inclus',
                          style: TextStyle(color: SL.dim, fontSize: 9.5),
                        ),
                      ],
                    );
                    if (MediaQuery.textScalerOf(context).scale(12) > 19) {
                      return Column(
                        children: [stats, SizedBox(width: 110, child: map)],
                      );
                    }
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(child: stats),
                        const SizedBox(width: 8),
                        SizedBox(
                          width: constraints.maxWidth < 310 ? 85 : 102,
                          child: map,
                        ),
                      ],
                    );
                  },
                ),
              ),
            Wrap(
              alignment: WrapAlignment.end,
              children: [
                if (!rest)
                  TextButton(
                    onPressed:
                        () =>
                            showEstimate(context, 'Volume et durée', estimate!),
                    child: const Text(
                      'Détails',
                      style: TextStyle(fontSize: 11.5),
                    ),
                  ),
                TextButton.icon(
                  onPressed: onTap,
                  icon: Icon(
                    done ? Icons.visibility_outlined : Icons.play_arrow_rounded,
                    size: 17,
                  ),
                  label: Text(
                    done
                        ? 'Consulter'
                        : rest
                        ? 'Ouvrir'
                        : 'Commencer',
                    style: const TextStyle(fontSize: 11.5),
                  ),
                ),
                const SizedBox(width: 8),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
