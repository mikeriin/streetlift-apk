import 'package:flutter/material.dart';

import 'main.dart';
import 'muscle_body.dart';
import 'store.dart';
import 'progression_screen.dart';
import 'session_history.dart';

class RecordsScreen extends StatelessWidget {
  const RecordsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = store.program.pilotage;
    return Scaffold(
      appBar: AppBar(title: const Text('SUIVI & RECORDS')),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final total = store.program.weeks.fold<int>(
            0,
            (a, w) => a + w.days.length,
          );
          final done = store.completedCount;
          final sessions =
              store.logs.entries
                  .where((e) => e.value.done && e.value.finishedAt != null)
                  .toList()
                ..sort(
                  (a, b) => b.value.finishedAt!.compareTo(a.value.finishedAt!),
                );
          final lp = store.levelProgress;
          final muscles = store.weeklyMuscles();
          final ranked =
              muscles.entries.where((e) => e.value > 0).toList()
                ..sort((a, b) => b.value.compareTo(a.value));
          return ListView(
            padding: const EdgeInsets.only(bottom: 24),
            children: [
              // ----- niveau -----
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Container(
                        width: 54,
                        height: 54,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: SL.steel.withValues(alpha: 0.16),
                          shape: BoxShape.circle,
                          border: Border.all(color: SL.steel, width: 2),
                        ),
                        child: Text(
                          '${store.level}',
                          style: TextStyle(
                            color: SL.steel,
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'NIVEAU ${store.level} · ${store.progression.rank.title}',
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(height: 6),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: LinearProgressIndicator(
                                value: lp.need == 0 ? 0 : lp.inLevel / lp.need,
                                minHeight: 7,
                                backgroundColor: SL.faint,
                                color: SL.steel,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              '${lp.inLevel} / ${lp.need} XP · ${store.xp} XP au total',
                              style: TextStyle(color: SL.dim, fontSize: 12),
                            ),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                Icon(
                                  Icons.toll,
                                  size: 15,
                                  color: SL.inputYellow,
                                ),
                                const SizedBox(width: 5),
                                Expanded(
                                  child: Text(
                                    '${store.credits} crédit${store.credits > 1 ? 's' : ''} de déverrouillage',
                                    style: TextStyle(
                                      color: SL.inputYellow,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 2),
                            Text(
                              '${store.progression.earnedBadges} badges · ${store.progression.currentStreak} semaines de régularité',
                              style: TextStyle(color: SL.dim, fontSize: 11),
                            ),
                            TextButton(
                              onPressed: () => openProgression(context),
                              child: const Text('Objectifs et récompenses →'),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // ----- groupes musculaires de la semaine -----
              Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'GROUPES MUSCULAIRES · CETTE SEMAINE',
                        style: TextStyle(
                          color: SL.dim,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.6,
                        ),
                      ),
                      const SizedBox(height: 6),
                      MuscleHeatmap(data: muscles, height: 320),
                      const SizedBox(height: 8),
                      if (ranked.isEmpty)
                        Text(
                          'Valide des séries : la carte se colore au fil de la semaine.',
                          style: TextStyle(color: SL.dim, fontSize: 12.5),
                        )
                      else
                        MuscleLegend(data: muscles),
                    ],
                  ),
                ),
              ),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'AVANCEMENT DU PROGRAMME',
                        style: TextStyle(
                          color: SL.dim,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.6,
                        ),
                      ),
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(5),
                        child: LinearProgressIndicator(
                          value: total == 0 ? 0 : done / total,
                          minHeight: 9,
                          backgroundColor: SL.faint,
                          color: SL.steel,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '$done / $total séances validées',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const _SectionTitle('1RM — ACTUEL vs CIBLE 12 MOIS'),
              for (final l in p.mainLifts)
                _TargetTile(
                  name: l.name,
                  unit: l.unit,
                  current: store.values[l.ref] ?? l.oneRm,
                  start: l.oneRm,
                  target: l.target,
                ),
              const _SectionTitle('ENDURANCE — MAX DE REPS'),
              for (final m in p.repMax)
                _TargetTile(
                  name: m.name,
                  unit: 'reps',
                  current: store.values[m.ref] ?? m.max,
                  start: m.max,
                  target: m.target,
                ),
              const _SectionTitle('DERNIÈRES SÉANCES TERMINÉES'),
              if (sessions.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    'Rien pour l\u2019instant. Termine ta première séance : elle apparaîtra ici.',
                    style: TextStyle(color: SL.dim),
                  ),
                ),
              for (final e in sessions.take(20))
                _SessionTile(id: e.key, log: e.value),
            ],
          );
        },
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String t;
  const _SectionTitle(this.t);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 18, 16, 6),
    child: Text(
      t,
      style: TextStyle(
        color: SL.dim,
        fontSize: 12,
        fontWeight: FontWeight.w800,
        letterSpacing: 0.6,
      ),
    ),
  );
}

class _TargetTile extends StatelessWidget {
  final String name;
  final String unit;
  final double current;
  final double start;
  final double target;
  const _TargetTile({
    required this.name,
    required this.unit,
    required this.current,
    required this.start,
    required this.target,
  });

  String _n(double v) =>
      v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);

  @override
  Widget build(BuildContext context) {
    final span = (target - start);
    final frac = span <= 0 ? 1.0 : ((current - start) / span).clamp(0.0, 1.0);
    final reached = current >= target;
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    name,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                    ),
                  ),
                ),
                Text(
                  '${_n(current)} / ${_n(target)} $unit',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    color: reached ? SL.mainGreen : SL.text,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 7),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: frac,
                minHeight: 6,
                backgroundColor: SL.faint,
                color: reached ? SL.mainGreen : SL.inputYellow,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SessionTile extends StatelessWidget {
  final String id; // "S8-J1"
  final SessionLog log;
  const _SessionTile({required this.id, required this.log});

  @override
  Widget build(BuildContext context) {
    final dt = DateTime.tryParse(log.finishedAt ?? '');
    final when =
        dt == null
            ? ''
            : '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')} '
                '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    final notes = log.ex.values.where((e) => e.note.trim().isNotEmpty).length;
    return Card(
      child: ListTile(
        dense: true,
        leading: Icon(Icons.check_circle, color: SL.mainGreen),
        trailing: const Icon(Icons.chevron_right),
        onTap:
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => SessionHistoryScreen(log: log)),
            ),
        title: Text(
          log.title ?? id.replaceAll('-', ' · '),
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          '$when${notes > 0 ? ' · $notes note${notes > 1 ? 's' : ''}' : ''}',
        ),
      ),
    );
  }
}
