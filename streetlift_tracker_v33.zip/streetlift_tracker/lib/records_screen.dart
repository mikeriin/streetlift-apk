import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'ui.dart';
import 'muscle_body.dart';
import 'store.dart';
import 'progression_screen.dart';
import 'session_history.dart';

class RecordsScreen extends StatelessWidget {
  const RecordsScreen({super.key});
  @override
  Widget build(BuildContext context) => KScreen(
    appBar: const KTopBar(),
    body: ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final p = store.program.pilotage;
        final total = store.program.weeks.fold<int>(
          0,
          (a, w) => a + w.days.length,
        );
        final done = store.completedCount;
        final sessions =
            store.logs.entries
                .where((e) => e.value.done && e.value.finishedAt != null)
                .toList()
              ..sort(
                (a, b) => b.value.finishedAt!.compareTo(a.value.finishedAt!),
              );
        final lp = store.levelProgress;
        final muscles = store.weeklyMuscles();
        return KList(
          key: const PageStorageKey('suivi-scroll'),
          children: [
            const KPageIntro('Suivi', 'Chaque effort compte.'),
            KMenuTile(
              icon: Icons.history_rounded,
              title: 'Historique des séances',
              subtitle:
                  '${sessions.length} séance${sessions.length > 1 ? 's' : ''} terminée${sessions.length > 1 ? 's' : ''}',
              onTap:
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder:
                          (_) => KScreen(
                            appBar: AppBar(title: const Text('Historique')),
                            body: KList(
                              children: [
                                if (sessions.isEmpty)
                                  const KEmpty(
                                    icon: Icons.history,
                                    title: 'Ton historique commence ici',
                                    message:
                                        'Tes séances terminées apparaîtront ici.',
                                  ),
                                for (final e in sessions)
                                  _SessionTile(id: e.key, log: e.value),
                              ],
                            ),
                          ),
                    ),
                  ),
            ),
            KProgressCard(
              level: store.level,
              credits: store.credits,
              inLevel: lp.inLevel,
              need: lp.need,
              rank: store.progression.rank.title,
              onTap: () => openProgression(context),
            ),
            const KSection('Ton programme'),
            KCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '$done / $total séances validées',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: total == 0 ? 0 : done / total,
                      semanticsLabel: 'Avancement du programme',
                    ),
                  ),
                ],
              ),
            ),
            const KSection(
              'Muscles sollicités',
              subtitle: 'Séries validées cette semaine',
            ),
            KCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MuscleHeatmap(data: muscles, height: 220),
                  const SizedBox(height: 6),
                  if (muscles.values.every((v) => v <= 0))
                    Text(
                      'Valide des séries pour voir ta répartition musculaire.',
                      style: Theme.of(context).textTheme.bodySmall,
                    )
                  else
                    MuscleLegend(data: muscles),
                ],
              ),
            ),
            const KSection(
              'Force',
              subtitle: 'Tes références actuelles et tes cibles à 12 mois',
            ),
            for (final l in p.mainLifts)
              _TargetTile(
                name: l.name,
                unit: l.unit,
                current: store.values[l.ref] ?? l.oneRm,
                start: l.oneRm,
                target: l.target,
              ),
            const KSection(
              'Endurance',
              subtitle: 'Maximum de répétitions au poids de corps',
            ),
            for (final m in p.repMax)
              _TargetTile(
                name: m.name,
                unit: 'reps',
                current: store.values[m.ref] ?? m.max,
                start: m.max,
                target: m.target,
              ),
            const KSection(
              'Séances terminées',
              subtitle: 'Les 20 dernières séances enregistrées',
            ),
            if (sessions.isEmpty)
              const KEmpty(
                icon: Icons.history,
                title: 'Ton historique commence ici',
                message:
                    'Termine une séance pour retrouver ses séries, ses charges et tes notes.',
              ),
            for (final e in sessions.take(20))
              _SessionTile(id: e.key, log: e.value),
          ],
        );
      },
    ),
  );
}

class _TargetTile extends StatelessWidget {
  final String name, unit;
  final double current, start, target;
  const _TargetTile({
    required this.name,
    required this.unit,
    required this.current,
    required this.start,
    required this.target,
  });
  String _n(double v) =>
      v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);
  @override
  Widget build(BuildContext context) {
    final span = target - start;
    final frac = span <= 0 ? 1.0 : ((current - start) / span).clamp(0.0, 1.0);
    final reached = current >= target;
    return KCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(name, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              KBadge(
                '${_n(current)} $unit',
                color: reached ? SL.mainGreen : SL.steel,
              ),
              KBadge(
                'Cible ${_n(target)} $unit',
                icon:
                    reached ? Icons.check_circle_outline : Icons.flag_outlined,
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: frac,
              color: reached ? SL.mainGreen : SL.steel,
            ),
          ),
        ],
      ),
    );
  }
}

class _SessionTile extends StatelessWidget {
  final String id;
  final SessionLog log;
  const _SessionTile({required this.id, required this.log});
  @override
  Widget build(BuildContext context) {
    final dt = DateTime.tryParse(log.finishedAt ?? '')?.toLocal();
    final when =
        dt == null
            ? ''
            : '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year} · ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    final notes = log.ex.values.where((e) => e.note.trim().isNotEmpty).length;
    return KCard(
      padding: EdgeInsets.zero,
      child: ListTile(
        leading: Icon(Icons.check_circle_outline, color: SL.mainGreen),
        trailing: const Icon(Icons.chevron_right),
        onTap:
            () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SessionHistoryScreen(log: log, sessionKey: id),
              ),
            ),
        title: Text(log.title ?? id.replaceAll('-', ' · ')),
        subtitle: Text(
          '$when${notes > 0 ? ' · $notes note${notes > 1 ? 's' : ''}' : ''}',
        ),
      ),
    );
  }
}
