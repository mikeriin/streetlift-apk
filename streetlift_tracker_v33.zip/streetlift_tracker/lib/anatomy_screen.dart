// M2 (mannequin 3D) : écran « Anatomie » (Arsenal › Anatomie).
//
// Le mannequin anatomique s'explore : vues Face / Dos / Profil / 3/4, rotation
// au doigt, un des 11 groupes de l'application mis en évidence, nom du muscle
// au toucher (réglage « Nom du muscle au toucher »). La liste des muscles du
// groupe reste toujours affichée en texte (jamais l'information par la
// couleur seule). Placé dans l'Arsenal, à côté de la bibliothèque
// d'exercices : c'est la référence qu'on consulte avec les fiches.
import 'package:flutter/material.dart';

import 'app_theme.dart';
import 'mannequin_3d.dart';
import 'ui.dart';

/// Libellés des 11 groupes de l'application.
const kGroupLabels = {
  'pectoraux': 'Pectoraux',
  'épaules': 'Épaules',
  'biceps': 'Biceps',
  'triceps': 'Triceps',
  'avant-bras': 'Avant-bras',
  'gainage': 'Gainage',
  'dos': 'Dos',
  'quadriceps': 'Quadriceps',
  'ischios': 'Ischios',
  'fessiers': 'Fessiers',
  'mollets': 'Mollets',
};

/// Vue de départ qui montre le mieux un groupe.
MannequinView viewForGroup(String? group) => switch (group) {
  'dos' ||
  'triceps' ||
  'ischios' ||
  'fessiers' ||
  'mollets' => MannequinView.dos,
  _ => MannequinView.face,
};

class AnatomyScreen extends StatefulWidget {
  final String? initialGroup;
  const AnatomyScreen({super.key, this.initialGroup});

  @override
  State<AnatomyScreen> createState() => AnatomyScreenState();
}

class AnatomyScreenState extends State<AnatomyScreen> {
  MannequinMap? _map;
  late String? _group = widget.initialGroup;
  late MannequinView _view = viewForGroup(widget.initialGroup);

  String? get group => _group;

  @override
  void initState() {
    super.initState();
    // Carte déjà chargée : utilisée tout de suite, sans attente.
    _map = MannequinMap.loaded;
    if (_map == null) {
      MannequinMap.load().then((m) {
        if (mounted) setState(() => _map = m);
      });
    }
  }

  void _select(String? group) => setState(() {
    _group = group;
    _view = viewForGroup(group);
  });

  @override
  Widget build(BuildContext context) {
    final map = _map;
    final group = _group;
    final intensities = map == null || group == null
        ? const <String, double>{}
        : map.fromGroups({group: kIntensityPrimary});
    final height = (MediaQuery.sizeOf(context).height * .58).clamp(
      300.0,
      560.0,
    );
    final tt = Theme.of(context).textTheme;
    return KScreen(
      appBar: AppBar(title: const Text('ANATOMIE')),
      body: KList(
        key: const ValueKey('anatomy-list'),
        children: [
          const KPageIntro(
            'Anatomie',
            'Fais tourner le mannequin, choisis une vue et un groupe.',
          ),
          Mannequin3D(
            key: const ValueKey('anatomy-mannequin'),
            intensities: intensities,
            view: _view,
            height: height,
            semanticLabel: group == null
                ? 'Mannequin anatomique en 3D'
                : 'Mannequin anatomique en 3D, groupe '
                      '${kGroupLabels[group]} en rouge',
          ),
          ValueListenableBuilder<bool>(
            valueListenable: Display3DSettings.instance.touchNames,
            builder: (context, names, _) => Text(
              names
                  ? 'Touche un muscle pour afficher son nom.'
                  : 'Nom du muscle au toucher désactivé '
                        '(Réglages › Affichage 3D).',
              style: tt.bodySmall,
            ),
          ),
          const KSection('Groupe musculaire'),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              ChoiceChip(
                key: const ValueKey('anatomy-group-none'),
                label: const Text('Aucun'),
                selected: group == null,
                onSelected: (_) => _select(null),
              ),
              for (final e in kGroupLabels.entries)
                ChoiceChip(
                  key: ValueKey('anatomy-group-${e.key}'),
                  label: Text(e.value),
                  selected: group == e.key,
                  onSelected: (_) => _select(group == e.key ? null : e.key),
                ),
            ],
          ),
          if (group != null && map != null)
            KCard(
              key: const ValueKey('anatomy-group-list'),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: mannequinHeat(1, SL.dark),
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          kGroupLabels[group]!,
                          style: tt.titleMedium,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(map.names(intensities).join(', '), style: tt.bodyMedium),
                ],
              ),
            ),
          Text(
            'Modèle : Z-Anatomy, dérivé de BodyParts3D (CC BY-SA 4.0). '
            'Crédits dans Réglages › À propos › Sources et licences. '
            'Repères d’entraînement, pas un avis médical.',
            style: tt.bodySmall,
          ),
        ],
      ),
    );
  }
}
