// M1 (mannequin 3D) : socle du moteur 3D et écran de diagnostic
// « Moteur 3D » (Réglages › À propos › Moteur 3D).
//
// Le moteur est flutter_scene (Flutter GPU sur Impeller), décision du
// propriétaire du 27/09/2026. Cet écran affiche un rendu test (icosaèdre gris
// mat dont une calotte rayonne dans le rouge historique, avec halo en bloom),
// indique si le téléphone est compatible et mesure la fluidité sur 10 s.
// Les lots suivants y afficheront le mannequin. Sans Flutter GPU, l'écran le
// dit clairement et rien ne plante : l'application garde ses illustrations 2D.
import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' show FrameTiming;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_gpu/gpu.dart' as gpu;
import 'package:flutter_scene/scene.dart';
import 'package:vector_math/vector_math.dart' as vm;

import 'app_theme.dart';
import 'device.dart';
import 'ui.dart';

/// Résultat de la vérification du moteur 3D sur cet appareil.
class Engine3DSupport {
  /// Flutter GPU répond (contexte GPU créé).
  final bool gpuAvailable;

  /// Ressources du moteur chargées (shaders, tables) : le rendu peut démarrer.
  final bool engineReady;

  /// Raison lisible en cas d'échec (jamais affichée brute à l'utilisateur).
  final String? error;

  const Engine3DSupport({
    required this.gpuAvailable,
    required this.engineReady,
    this.error,
  });

  bool get compatible => gpuAvailable && engineReady;
}

Future<Engine3DSupport>? _support;

/// Vérifie une seule fois par lancement que Flutter GPU et flutter_scene
/// fonctionnent. Ne lève jamais d'exception.
Future<Engine3DSupport> engine3DSupport() => _support ??= _probe();

Future<Engine3DSupport> _probe() async {
  try {
    // Lève une exception si Flutter GPU n'est pas activé ou pas pris en
    // charge (moteur de rendu Skia, pilote trop ancien, tests sur ordinateur).
    gpu.gpuContext;
  } catch (e) {
    return Engine3DSupport(
      gpuAvailable: false,
      engineReady: false,
      error: '$e',
    );
  }
  try {
    await Scene.initializeStaticResources();
  } catch (e) {
    return Engine3DSupport(gpuAvailable: true, engineReady: false, error: '$e');
  }
  return Engine3DSupport(
    gpuAvailable: true,
    engineReady: Scene.isReadyToRender,
    error: Scene.isReadyToRender ? null : 'Ressources du moteur non chargées',
  );
}

/// Mesure de fluidité : images par seconde et temps d'image (du début de la
/// construction à la fin du rendu GPU de chaque image).
class FrameStats {
  final int frames;
  final Duration window;
  final double meanMs, p99Ms;

  const FrameStats({
    required this.frames,
    required this.window,
    required this.meanMs,
    required this.p99Ms,
  });

  double get fps =>
      window.inMicroseconds == 0 ? 0 : frames * 1e6 / window.inMicroseconds;

  /// Calcule la moyenne et le 99e centile (rang supérieur) des durées.
  static FrameStats of(List<Duration> spans, Duration window) {
    if (spans.isEmpty) {
      return FrameStats(frames: 0, window: window, meanMs: 0, p99Ms: 0);
    }
    final ms = [for (final s in spans) s.inMicroseconds / 1000]..sort();
    final mean = ms.reduce((a, b) => a + b) / ms.length;
    final rank = (ms.length * .99).ceil().clamp(1, ms.length) - 1;
    return FrameStats(
      frames: ms.length,
      window: window,
      meanMs: mean,
      p99Ms: ms[rank],
    );
  }
}

/// Seuil de fluidité retenu pour la suite du pipeline (images par seconde).
const kEngine3DFluidFps = 45.0;

/// Durée de la mesure de fluidité.
const kEngine3DMeasure = Duration(seconds: 10);

double _linear(double c) =>
    c <= .04045 ? c / 12.92 : math.pow((c + .055) / 1.055, 2.4).toDouble();

vm.Vector4 _linearColor(Color c, [double scale = 1]) => vm.Vector4(
  _linear(c.r) * scale,
  _linear(c.g) * scale,
  _linear(c.b) * scale,
  1,
);

/// Gris mat de la musculature (page de référence validée : #8F8B8A).
const kMuscleGray = Color(0xFF8F8B8A);

/// Fond de la scène 3D (page de référence validée).
Color sceneBackground(bool dark) =>
    dark ? const Color(0xFF161414) : const Color(0xFFEDEBEA);

/// Icosaèdre régulier à facettes planes, rayon 1, séparé en deux parties :
/// la calotte haute (5 faces autour du sommet +Y) et le reste. Chaque face
/// porte sa normale sortante ; les triangles sont orientés dans le sens
/// direct vu de l'extérieur (convention de flutter_scene 0.23).
({MeshGeometry cap, MeshGeometry body}) _icosahedron() {
  final t = (1 + math.sqrt(5)) / 2;
  final raw = <vm.Vector3>[
    vm.Vector3(-1, t, 0),
    vm.Vector3(1, t, 0),
    vm.Vector3(-1, -t, 0),
    vm.Vector3(1, -t, 0),
    vm.Vector3(0, -1, t),
    vm.Vector3(0, 1, t),
    vm.Vector3(0, -1, -t),
    vm.Vector3(0, 1, -t),
    vm.Vector3(t, 0, -1),
    vm.Vector3(t, 0, 1),
    vm.Vector3(-t, 0, -1),
    vm.Vector3(-t, 0, 1),
  ];
  // Inclinaison autour de Z qui amène le sommet (-1, t, 0) sur l'axe +Y.
  final tilt = vm.Quaternion.axisAngle(vm.Vector3(0, 0, 1), -math.atan(1 / t));
  final v = [for (final p in raw) tilt.rotated(p.normalized())];
  const faces = <List<int>>[
    [0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11], //
    [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
    [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9],
    [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1],
  ];
  var top = 0;
  for (var i = 1; i < v.length; i++) {
    if (v[i].y > v[top].y) top = i;
  }
  MeshGeometry build(Iterable<List<int>> list) {
    final tris = list.toList();
    final pos = Float32List(tris.length * 9);
    final nor = Float32List(tris.length * 9);
    final idx = <int>[];
    for (var f = 0; f < tris.length; f++) {
      var a = v[tris[f][0]], b = v[tris[f][1]], c = v[tris[f][2]];
      var n = (b - a).cross(c - a);
      if (n.dot(a + b + c) < 0) {
        final swap = b;
        b = c;
        c = swap;
        n = -n;
      }
      n.normalize();
      final corners = [a, b, c];
      for (var k = 0; k < 3; k++) {
        final o = (f * 3 + k) * 3;
        pos[o] = corners[k].x;
        pos[o + 1] = corners[k].y;
        pos[o + 2] = corners[k].z;
        nor[o] = n.x;
        nor[o + 1] = n.y;
        nor[o + 2] = n.z;
        idx.add(f * 3 + k);
      }
    }
    return MeshGeometry.fromArrays(positions: pos, normals: nor, indices: idx);
  }

  return (
    cap: build(faces.where((f) => f.contains(top))),
    body: build(faces.where((f) => !f.contains(top))),
  );
}

/// Scène du rendu test : icosaèdre gris mat, calotte rouge qui rayonne.
class Engine3DTestScene {
  final Scene scene = Scene();
  final Node figure = Node(name: 'figure');
  final PhysicallyBasedMaterial _cap = PhysicallyBasedMaterial();

  Engine3DTestScene() {
    final geometry = _icosahedron();
    final body = PhysicallyBasedMaterial()
      ..baseColorFactor = _linearColor(kMuscleGray)
      ..metallicFactor = 0
      ..roughnessFactor = .78;
    _cap
      ..metallicFactor = 0
      ..roughnessFactor = .6;
    figure
      ..add(Node(name: 'corps', mesh: Mesh(geometry.body, body)))
      ..add(Node(name: 'calotte', mesh: Mesh(geometry.cap, _cap)));
    scene
      ..add(figure)
      ..directionalLight = DirectionalLight(
        direction: vm.Vector3(-1, -2, 2),
        intensity: 2.2,
      )
      ..environmentIntensity = .7;
    // Halo : seules les surfaces plus lumineuses que le seuil rayonnent
    // (la calotte émissive), la musculature grise reste mate.
    scene.postProcess.bloom
      ..enabled = true
      ..threshold = 1.0
      ..intensity = .35
      ..scatter = .7;
    applyTheme(SL.dark);
  }

  /// Rampe historique : rouge du haut de la rampe (`heat(1)` de
  /// muscle_body.dart), selon le thème (#E85959 en sombre, #A61717 en clair).
  void applyTheme(bool dark) {
    final red = dark ? KPalette.lightRed : KPalette.actionRed;
    _cap
      ..baseColorFactor = _linearColor(red)
      ..emissiveFactor = _linearColor(red)
      ..emissiveStrength = 2.4;
  }

  void setOrientation(double yaw, double pitch) {
    figure.rotation =
        vm.Quaternion.axisAngle(vm.Vector3(1, 0, 0), pitch) *
        vm.Quaternion.axisAngle(vm.Vector3(0, 1, 0), yaw);
  }
}

/// Écran « Moteur 3D » : rendu test, compatibilité et fluidité.
class Engine3DScreen extends StatefulWidget {
  /// Mesure de fluidité lancée automatiquement une fois le rendu prêt.
  final bool autoMeasure;
  const Engine3DScreen({super.key, this.autoMeasure = true});

  @override
  State<Engine3DScreen> createState() => Engine3DScreenState();
}

class Engine3DScreenState extends State<Engine3DScreen> {
  Engine3DSupport? _support;
  Map<String, Object?> _info = const {};
  Engine3DTestScene? _scene;

  // Orientation (radians) et vitesse de rotation (rad/s) de la figure.
  double _yaw = .6, _pitch = -.25, _spinYaw = 0, _spinPitch = 0;
  bool _dragging = false;

  // Mesure de fluidité.
  final List<Duration> _spans = [];
  Timer? _measureTimer;
  DateTime? _measureStart;
  FrameStats? _stats;
  bool _measuring = false;

  /// Dernière mesure terminée (tests d'intégration et captures CI).
  FrameStats? get stats => _stats;
  Engine3DSupport? get support => _support;
  Map<String, Object?> get info => _info;

  @override
  void initState() {
    super.initState();
    unawaited(_init());
  }

  Future<void> _init() async {
    final results = await Future.wait<Object>([
      engine3DSupport(),
      graphicsInfo(),
    ]);
    if (!mounted) return;
    final support = results[0] as Engine3DSupport;
    Engine3DTestScene? scene;
    if (support.compatible) {
      try {
        scene = Engine3DTestScene()..setOrientation(_yaw, _pitch);
      } catch (e) {
        // Contexte présent mais création impossible : traité comme
        // incompatible plutôt que de planter.
        _support = Engine3DSupport(
          gpuAvailable: true,
          engineReady: false,
          error: '$e',
        );
        setState(() => _info = results[1] as Map<String, Object?>);
        return;
      }
    }
    setState(() {
      _support = support;
      _info = results[1] as Map<String, Object?>;
      _scene = scene;
    });
    if (scene != null && widget.autoMeasure) {
      // Laisse le premier rendu se stabiliser avant de mesurer.
      _measureTimer = Timer(const Duration(milliseconds: 800), startMeasure);
    }
  }

  @override
  void dispose() {
    _stopMeasure(record: false);
    super.dispose();
  }

  bool get _reduceMotion => MediaQuery.of(context).disableAnimations;

  /// Rendu continu seulement si quelque chose bouge (rotation automatique,
  /// élan du doigt, mesure) ; sinon l'image reste fixe, sans boucle.
  bool get _animating =>
      !_reduceMotion ||
      _dragging ||
      _spinYaw.abs() > .01 ||
      _spinPitch.abs() > .01 ||
      _measuring;

  void _onTick(Duration elapsed, double dt) {
    final scene = _scene;
    if (scene == null || dt <= 0 || dt > .25) return;
    if (!_dragging) {
      // Élan du doigt amorti, puis rotation lente automatique.
      final damping = math.exp(-2.5 * dt);
      final autoSpin = _reduceMotion ? 0.0 : .45;
      _spinYaw = autoSpin + (_spinYaw - autoSpin) * damping;
      _spinPitch *= damping;
      _yaw += _spinYaw * dt;
      _pitch = (_pitch + _spinPitch * dt).clamp(-1.2, 1.2);
    }
    scene.setOrientation(_yaw, _pitch);
  }

  void startMeasure() {
    if (!mounted || _scene == null || _measuring) return;
    _spans.clear();
    SchedulerBinding.instance.addTimingsCallback(_onTimings);
    setState(() {
      _measuring = true;
      _measureStart = DateTime.now();
    });
    _measureTimer?.cancel();
    _measureTimer = Timer(kEngine3DMeasure, () => _stopMeasure(record: true));
  }

  void _onTimings(List<FrameTiming> timings) {
    for (final t in timings) {
      _spans.add(t.totalSpan);
    }
  }

  void _stopMeasure({required bool record}) {
    _measureTimer?.cancel();
    _measureTimer = null;
    if (!_measuring) return;
    SchedulerBinding.instance.removeTimingsCallback(_onTimings);
    final window = DateTime.now().difference(_measureStart!);
    _measuring = false;
    if (record && mounted) {
      setState(() => _stats = FrameStats.of(List.of(_spans), window));
    }
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    _scene?.applyTheme(dark);
    return KScreen(
      appBar: AppBar(title: const Text('MOTEUR 3D')),
      body: KList(
        key: const ValueKey('engine3d-list'),
        children: [
          _view(dark),
          _compatibility(context),
          _performance(context),
          Text(
            'Cet écran servira à vérifier le mannequin anatomique 3D des '
            'prochaines versions. Tant qu’il n’est pas prêt, les fiches '
            'gardent leurs illustrations 2D.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }

  Widget _view(bool dark) {
    final scene = _scene;
    final support = _support;
    Widget child;
    if (support == null) {
      child = const Center(child: CircularProgressIndicator());
    } else if (scene == null) {
      child = Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.view_in_ar_outlined, size: 40, color: SL.dim),
              const SizedBox(height: 12),
              Text(
                'La 3D n’est pas disponible sur ce téléphone.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 6),
              Text(
                'Les fiches et les statistiques continuent d’utiliser les '
                'illustrations 2D.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      );
    } else {
      child = GestureDetector(
        key: const ValueKey('engine3d-view'),
        behavior: HitTestBehavior.opaque,
        onPanStart: (_) => setState(() {
          _dragging = true;
          _spinYaw = _spinPitch = 0;
        }),
        onPanUpdate: (d) {
          _yaw += d.delta.dx * .012;
          _pitch = (_pitch + d.delta.dy * .012).clamp(-1.2, 1.2);
          _scene?.setOrientation(_yaw, _pitch);
        },
        onPanEnd: (d) => setState(() {
          _dragging = false;
          _spinYaw = (d.velocity.pixelsPerSecond.dx * .012).clamp(-8, 8);
          _spinPitch = (d.velocity.pixelsPerSecond.dy * .012).clamp(-8, 8);
        }),
        child: Semantics(
          label:
              'Rendu test en 3D : figure grise dont le sommet est rouge. '
              'Fais glisser pour la tourner.',
          child: SceneView(
            scene.scene,
            autoTick: _animating,
            onTick: _onTick,
            camera: PerspectiveCamera(
              position: vm.Vector3(0, .35, -3.6),
              target: vm.Vector3(0, 0, 0),
            ),
          ),
        ),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(KSpace.radius),
      child: ColoredBox(
        color: sceneBackground(dark),
        child: AspectRatio(aspectRatio: 1, child: child),
      ),
    );
  }

  Widget _compatibility(BuildContext context) {
    final support = _support;
    final ok = support?.compatible ?? false;
    final tt = Theme.of(context).textTheme;
    final backend = _backendLabel();
    final device = [
      _info['manufacturer'],
      _info['model'],
    ].whereType<String>().where((s) => s.isNotEmpty).join(' ');
    final android =
        _info['release'] == null
            ? 'inconnue'
            : 'Android ${_info['release']} (API ${_info['sdk']})';
    return KCard(
      key: const ValueKey('engine3d-compat'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                support == null
                    ? Icons.hourglass_empty
                    : ok
                    ? Icons.check_circle
                    : Icons.cancel,
                color:
                    support == null
                        ? SL.dim
                        : ok
                        ? SL.success
                        : SL.danger,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  support == null
                      ? 'Vérification…'
                      : ok
                      ? 'Compatible'
                      : 'Non compatible',
                  style: tt.titleLarge,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _row(
            'Flutter GPU',
            support == null
                ? '…'
                : support.gpuAvailable
                ? 'disponible'
                : 'absent',
          ),
          _row('API graphique', backend),
          _row('Appareil', device.isEmpty ? 'inconnu' : device),
          _row('Version', android),
          if (support != null && !ok) ...[
            const SizedBox(height: 8),
            Text(
              support.gpuAvailable
                  ? 'Le moteur 3D n’a pas pu démarrer sur ce téléphone.'
                  : 'Ce téléphone n’active pas Flutter GPU, nécessaire au '
                      'moteur 3D.',
              style: tt.bodySmall,
            ),
          ],
        ],
      ),
    );
  }

  String _backendLabel() {
    final used = _info['impellerBackend'];
    if (used is String && used.isNotEmpty) {
      final name = used == 'OpenGLES' ? 'OpenGL ES' : used;
      return '$name (Impeller)';
    }
    final vulkan = _info['vulkanVersion'];
    final major = _info['glesMajor'], minor = _info['glesMinor'];
    final caps = <String>[
      if (vulkan is int && vulkan > 0)
        'Vulkan ${vulkan >> 22}.${(vulkan >> 12) & 0x3ff}',
      if (major is int && major > 0) 'OpenGL ES $major.$minor',
    ];
    return caps.isEmpty ? 'inconnue' : caps.join(' · ');
  }

  Widget _row(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 120,
          child: Text(label, style: TextStyle(color: SL.dim)),
        ),
        Expanded(child: Text(value)),
      ],
    ),
  );

  Widget _performance(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    final stats = _stats;
    final canMeasure = _scene != null;
    String fmt(double v) => v.toStringAsFixed(1).replaceAll('.', ',');
    return KCard(
      key: const ValueKey('engine3d-perf'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Fluidité', style: tt.titleMedium),
          const SizedBox(height: 8),
          if (!canMeasure)
            Text(
              'Mesure impossible sans moteur 3D.',
              style: tt.bodySmall,
            )
          else if (_measuring) ...[
            Text(
              'Mesure en cours sur ${kEngine3DMeasure.inSeconds} s…',
              style: tt.bodyMedium,
            ),
            const SizedBox(height: 8),
            const LinearProgressIndicator(),
          ] else if (stats == null)
            Text('Mesure en attente.', style: tt.bodySmall)
          else ...[
            _row('Images/s', fmt(stats.fps)),
            _row('Temps moyen', '${fmt(stats.meanMs)} ms'),
            _row('99e centile', '${fmt(stats.p99Ms)} ms'),
            const SizedBox(height: 6),
            Text(
              stats.fps >= kEngine3DFluidFps
                  ? 'Fluide : le mannequin animé pourra s’afficher.'
                  : 'Moins de ${kEngine3DFluidFps.round()} images/s : '
                      'l’animation 3D risque d’être saccadée.',
              style: tt.bodySmall,
            ),
          ],
          if (canMeasure && !_measuring) ...[
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: OutlinedButton.icon(
                key: const ValueKey('engine3d-measure'),
                onPressed: startMeasure,
                icon: const Icon(Icons.speed),
                label: Text(
                  stats == null ? 'Mesurer (10 s)' : 'Mesurer à nouveau',
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
