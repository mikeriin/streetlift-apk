import 'package:flutter/material.dart';

// ============================================================================
// PALETTE — deux thèmes, mêmes rôles. Sombre : « salle de nuit » (validé).
// Clair : dérivé, accents assombris pour passer WCAG AA (≥ 4,5:1 texte).
// ============================================================================
class KPalette {
  final bool dark;
  const KPalette(this.dark);

  Color get bg => dark ? const Color(0xFF0E1216) : const Color(0xFFF7F9FA);
  Color get surface => dark ? const Color(0xFF171D23) : const Color(0xFFFFFFFF);
  Color get card => dark ? const Color(0xFF1B222A) : const Color(0xFFFFFFFF);
  Color get text => dark ? const Color(0xFFE8EDF1) : const Color(0xFF14232B);
  Color get dim => dark ? const Color(0xFF8FA0AC) : const Color(0xFF52616B);
  Color get steel => dark ? const Color(0xFF4FA3C7) : const Color(0xFF1C6C8C);

  /// Accent « saisie » (texte, icônes, chips) — héritage des cellules jaunes.
  Color get inputYellow =>
      dark ? const Color(0xFFE9C46A) : const Color(0xFF8F6D1F);
  Color get mainGreen =>
      dark ? const Color(0xFF57B368) : const Color(0xFF3A7D44);
  Color get prevViolet =>
      dark ? const Color(0xFFB39DDB) : const Color(0xFF5E4B9E);
  Color get danger => dark ? const Color(0xFFE0645C) : const Color(0xFFC0392B);

  // Rôles secondaires (remplacent les SL.line/24 en dur).
  Color get line => dark ? const Color(0x1FFFFFFF) : const Color(0xFFDCE3E8);
  Color get faint => dark ? const Color(0x14FFFFFF) : const Color(0xFFEDF1F4);
  Color get dot => dark ? const Color(0x3DFFFFFF) : const Color(0xFFC5CED5);
  Color get onAccent =>
      dark ? const Color(0xFF0B0F12) : const Color(0xFFFFFFFF);

  /// Champs de saisie de séance (jaune) : fond et bordure.
  Color get fieldFill =>
      dark ? const Color(0x1AE9C46A) : const Color(0xFFFDF3D0);
  Color get fieldBorder =>
      dark ? const Color(0x59E9C46A) : const Color(0xFFD8BE7A);

  /// Champs de formulaire (neutres).
  Color get formFill =>
      dark ? const Color(0x0AFFFFFF) : const Color(0xFFF0F3F5);
  Color get formBorder =>
      dark ? const Color(0x24FFFFFF) : const Color(0xFFC9D2D8);
}

class SL {
  static bool dark = true;
  static KPalette get _palette => KPalette(dark);
  static Color get bg => _palette.bg;
  static Color get surface => _palette.surface;
  static Color get card => _palette.card;
  static Color get text => _palette.text;
  static Color get dim => _palette.dim;
  static Color get steel => _palette.steel;
  static Color get inputYellow => _palette.inputYellow;
  static Color get mainGreen => _palette.mainGreen;
  static Color get prevViolet => _palette.prevViolet;
  static Color get danger => _palette.danger;
  static Color get line => _palette.line;
  static Color get faint => _palette.faint;
  static Color get dot => _palette.dot;
  static Color get onAccent => _palette.onAccent;
  static Color get fieldFill => _palette.fieldFill;
  static Color get fieldBorder => _palette.fieldBorder;
  static Color get formFill => _palette.formFill;
  static Color get formBorder => _palette.formBorder;
}

/// Décoration des champs de SAISIE de séance (jaune) — usage explicite.
InputDecoration logDeco({String? hint, String? suffix}) => InputDecoration(
  hintText: hint,
  suffixText: suffix,
  isDense: true,
  filled: true,
  fillColor: SL.fieldFill,
  hintStyle: TextStyle(
    color: SL.dim.withValues(alpha: 0.7),
    fontWeight: FontWeight.w600,
  ),
  contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    borderSide: BorderSide(color: SL.fieldBorder),
  ),
  enabledBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    borderSide: BorderSide(color: SL.fieldBorder),
  ),
  focusedBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    borderSide: BorderSide(color: SL.inputYellow, width: 1.6),
  ),
);

/// Fabrique de thème : un seul endroit, deux luminosités.
ThemeData buildTheme(bool dark) {
  SL.dark = dark;
  final palette = KPalette(dark);
  final scheme = (dark ? const ColorScheme.dark() : const ColorScheme.light())
      .copyWith(
        primary: palette.steel,
        onPrimary: palette.onAccent,
        primaryContainer: palette.steel.withValues(alpha: dark ? 0.18 : 0.10),
        onPrimaryContainer: palette.text,
        secondary: palette.inputYellow,
        onSecondary: palette.onAccent,
        secondaryContainer: palette.inputYellow.withValues(alpha: 0.14),
        onSecondaryContainer: palette.text,
        tertiary: palette.prevViolet,
        onTertiary: palette.onAccent,
        tertiaryContainer: palette.prevViolet.withValues(alpha: 0.14),
        onTertiaryContainer: palette.text,
        surfaceContainer: palette.card,
        surfaceContainerLow: palette.card,
        surfaceContainerHigh: palette.card,
        surface: palette.surface,
        onSurface: palette.text,
        onSurfaceVariant: palette.dim,
        outline: palette.formBorder,
        outlineVariant: palette.line,
        error: palette.danger,
        surfaceContainerHighest: palette.faint,
        inverseSurface:
            dark ? const Color(0xFFE8EDF1) : const Color(0xFF14232B),
        onInverseSurface:
            dark ? const Color(0xFF0E1216) : const Color(0xFFF7F9FA),
        inversePrimary:
            dark ? const Color(0xFF1C6C8C) : const Color(0xFF7CC4E0),
      );
  OutlineInputBorder border(Color c, [double w = 1]) => OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    borderSide: BorderSide(color: c, width: w),
  );
  return ThemeData(
    useMaterial3: true,
    brightness: dark ? Brightness.dark : Brightness.light,
    colorScheme: scheme,
    scaffoldBackgroundColor: palette.bg,
    splashFactory: InkRipple.splashFactory,
    cardTheme: CardThemeData(
      color: palette.card,
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: const BorderRadius.all(Radius.circular(18)),
        side: BorderSide(color: palette.line),
      ),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: palette.bg,
      foregroundColor: palette.text,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleSpacing: 16,
      toolbarHeight: 64,
      titleTextStyle: TextStyle(
        color: palette.text,
        fontSize: 20,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.3,
      ),
    ),
    // Formulaires (éditeurs, recherche, réglages) : neutres. La saisie de
    // séance utilise logDeco() explicitement — jamais le mélange des deux.
    inputDecorationTheme: InputDecorationTheme(
      isDense: true,
      filled: true,
      fillColor: palette.formFill,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      border: border(palette.formBorder),
      enabledBorder: border(palette.formBorder),
      focusedBorder: border(palette.steel, 1.6),
      labelStyle: TextStyle(color: palette.dim, fontSize: 13),
      floatingLabelStyle: TextStyle(color: palette.steel, fontSize: 13),
      hintStyle: TextStyle(color: palette.dim.withValues(alpha: 0.7)),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(48, 48),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(48, 48),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        side: BorderSide(color: scheme.outline),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        minimumSize: const Size(48, 48),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
      ),
    ),
    iconButtonTheme: IconButtonThemeData(
      style: IconButton.styleFrom(minimumSize: const Size(48, 48)),
    ),
    listTileTheme: ListTileThemeData(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      titleTextStyle: TextStyle(
        color: palette.text,
        fontSize: 15,
        fontWeight: FontWeight.w700,
      ),
      subtitleTextStyle: TextStyle(
        color: palette.dim,
        fontSize: 13,
        height: 1.35,
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: palette.card,
      selectedColor: scheme.primaryContainer,
      secondarySelectedColor: scheme.primaryContainer,
      labelStyle: TextStyle(
        color: palette.text,
        fontSize: 13,
        fontWeight: FontWeight.w600,
      ),
      secondaryLabelStyle: TextStyle(
        color: palette.steel,
        fontSize: 13,
        fontWeight: FontWeight.w700,
      ),
      side: BorderSide(color: palette.line),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(
      color: palette.steel,
      linearTrackColor: palette.faint,
      linearMinHeight: 6,
    ),
    tabBarTheme: TabBarThemeData(
      labelColor: palette.steel,
      unselectedLabelColor: palette.dim,
      indicatorColor: palette.steel,
      dividerColor: palette.line,
      labelStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (s) =>
            s.contains(WidgetState.selected)
                ? scheme.onPrimary
                : scheme.onSurfaceVariant,
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (s) =>
            s.contains(WidgetState.selected)
                ? scheme.primary
                : scheme.surfaceContainerHighest,
      ),
      trackOutlineColor: WidgetStateProperty.resolveWith(
        (s) =>
            s.contains(WidgetState.selected)
                ? Colors.transparent
                : scheme.outline,
      ),
    ),
    segmentedButtonTheme: SegmentedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: WidgetStateProperty.resolveWith(
          (s) =>
              s.contains(WidgetState.selected)
                  ? scheme.primary.withValues(alpha: dark ? 0.22 : 0.14)
                  : palette.card,
        ),
        foregroundColor: WidgetStateProperty.resolveWith(
          (s) =>
              s.contains(WidgetState.selected)
                  ? scheme.primary
                  : scheme.onSurfaceVariant,
        ),
        side: WidgetStateProperty.all(BorderSide(color: scheme.outline)),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontWeight: FontWeight.w800, fontSize: 13),
        ),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: palette.surface,
      indicatorColor: scheme.primary.withValues(alpha: 0.22),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      iconTheme: WidgetStateProperty.resolveWith(
        (s) => IconThemeData(
          color:
              s.contains(WidgetState.selected)
                  ? scheme.primary
                  : scheme.onSurfaceVariant,
        ),
      ),
      labelTextStyle: WidgetStateProperty.resolveWith(
        (s) => TextStyle(
          fontSize: 11.5,
          fontWeight: FontWeight.w700,
          color:
              s.contains(WidgetState.selected)
                  ? scheme.primary
                  : scheme.onSurfaceVariant,
        ),
      ),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: palette.surface,
      showDragHandle: true,
      dragHandleColor: palette.dot,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: palette.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      titleTextStyle: TextStyle(
        color: scheme.onSurface,
        fontSize: 17,
        fontWeight: FontWeight.w800,
      ),
      contentTextStyle: TextStyle(
        color: scheme.onSurface,
        fontSize: 14,
        height: 1.4,
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: scheme.inverseSurface,
      contentTextStyle: TextStyle(
        color: scheme.onInverseSurface,
        fontWeight: FontWeight.w600,
      ),
      actionTextColor: scheme.inversePrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: palette.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      textStyle: TextStyle(color: scheme.onSurface, fontSize: 14),
    ),
    dividerColor: palette.line,
    iconTheme: IconThemeData(color: scheme.onSurface),
    textTheme: TextTheme(
      bodyLarge: TextStyle(color: scheme.onSurface, fontSize: 16, height: 1.35),
      bodyMedium: TextStyle(
        color: scheme.onSurface,
        fontSize: 14,
        height: 1.35,
      ),
      bodySmall: TextStyle(
        color: scheme.onSurfaceVariant,
        fontSize: 12.5,
        height: 1.3,
      ),
      titleMedium: TextStyle(
        color: scheme.onSurface,
        fontSize: 15,
        fontWeight: FontWeight.w700,
      ),
      titleLarge: TextStyle(
        color: scheme.onSurface,
        fontSize: 20,
        fontWeight: FontWeight.w800,
        height: 1.3,
      ),
      headlineSmall: TextStyle(
        color: scheme.onSurface,
        fontSize: 24,
        fontWeight: FontWeight.w800,
        height: 1.2,
      ),
      labelLarge: TextStyle(
        color: scheme.onSurface,
        fontSize: 14,
        fontWeight: FontWeight.w700,
      ),
    ),
  );
}
