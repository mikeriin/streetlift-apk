import 'package:flutter/material.dart';

/// Géométrie commune des champs et commandes, indépendante des cartes.
class KControl {
  // Une surface fine, avec une zone tactile de 44 px grâce au padding natif.
  static const double height = 44, radius = 7, iconSize = 18, gap = 8;
  static const double buttonHeight = 40;
  static const density = VisualDensity(vertical: -1);
  static const double formGap = 12;
  static const shape = RoundedRectangleBorder(
    borderRadius: BorderRadius.all(Radius.circular(radius)),
  );
  // 18 px de texte + 2 × 11 px : une surface de formulaire de 40 px.
  static const fieldPadding = EdgeInsets.symmetric(
    horizontal: 12,
    vertical: 11,
  );
  // Le sélecteur Flutter réserve 24 px à son contenu au lieu de 18.
  static const selectPadding = EdgeInsets.symmetric(
    horizontal: 12,
    vertical: 8,
  );
  static const textStyle = TextStyle(fontSize: 15, height: 1.2);
  static const numberStyle = TextStyle(
    fontSize: 15,
    height: 1.2,
    fontWeight: FontWeight.w400,
    fontFeatures: [FontFeature.tabularFigures()],
  );
}

// ============================================================================
// PALETTE — deux thèmes, mêmes rôles. Sombre : « salle de nuit » (validé).
// Clair : dérivé, accents assombris pour passer WCAG AA (≥ 4,5:1 texte).
// ============================================================================
class KPalette {
  final bool dark;
  const KPalette(this.dark);

  Color get bg => dark ? const Color(0xFF0E1216) : const Color(0xFFF7F9FA);
  Color get surface => dark ? const Color(0xFF171D23) : const Color(0xFFFFFFFF);
  Color get card => dark ? const Color(0xFF1B222A) : const Color(0xFFFFFFFF);
  Color get text => dark ? const Color(0xFFE8EDF1) : const Color(0xFF14232B);
  Color get dim => dark ? const Color(0xFF8FA0AC) : const Color(0xFF52616B);
  Color get steel => dark ? const Color(0xFF4FA3C7) : const Color(0xFF1C6C8C);

  /// Accent « saisie » (texte, icônes, chips) — héritage des cellules jaunes.
  Color get inputYellow =>
      dark ? const Color(0xFFE9C46A) : const Color(0xFF8F6D1F);
  Color get mainGreen =>
      dark ? const Color(0xFF57B368) : const Color(0xFF3A7D44);
  Color get prevViolet =>
      dark ? const Color(0xFFB39DDB) : const Color(0xFF5E4B9E);
  Color get danger => dark ? const Color(0xFFE0645C) : const Color(0xFFC0392B);

  // Rôles secondaires (remplacent les SL.line/24 en dur).
  Color get line => dark ? const Color(0x1FFFFFFF) : const Color(0xFFDCE3E8);
  Color get faint => dark ? const Color(0x14FFFFFF) : const Color(0xFFEDF1F4);
  Color get dot => dark ? const Color(0x3DFFFFFF) : const Color(0xFFC5CED5);
  Color get onAccent =>
      dark ? const Color(0xFF0B0F12) : const Color(0xFFFFFFFF);

  /// Champs de saisie de séance (jaune) : fond et bordure.
  Color get fieldFill =>
      dark ? const Color(0x0EE9C46A) : const Color(0xFFFFF9E9);
  Color get fieldBorder =>
      dark ? const Color(0x40E9C46A) : const Color(0xFFD8BE7A);

  /// Champs de formulaire (neutres).
  Color get formFill =>
      dark ? const Color(0x0AFFFFFF) : const Color(0xFFF0F3F5);
  Color get formBorder =>
      dark ? const Color(0x24FFFFFF) : const Color(0xFFC9D2D8);
}

class SL {
  static bool dark = true;
  static KPalette get _palette => KPalette(dark);
  static Color get bg => _palette.bg;
  static Color get surface => _palette.surface;
  static Color get card => _palette.card;
  static Color get text => _palette.text;
  static Color get dim => _palette.dim;
  static Color get steel => _palette.steel;
  static Color get inputYellow => _palette.inputYellow;
  static Color get mainGreen => _palette.mainGreen;
  static Color get prevViolet => _palette.prevViolet;
  static Color get danger => _palette.danger;
  static Color get line => _palette.line;
  static Color get faint => _palette.faint;
  static Color get dot => _palette.dot;
  static Color get onAccent => _palette.onAccent;
  static Color get fieldFill => _palette.fieldFill;
  static Color get fieldBorder => _palette.fieldBorder;
  static Color get formFill => _palette.formFill;
  static Color get formBorder => _palette.formBorder;
}

/// Accents de l'accueil validé, sans recolorer les autres écrans.
class ProgrammeColors {
  final bool dark;
  const ProgrammeColors(this.dark);
  factory ProgrammeColors.of(BuildContext context) =>
      ProgrammeColors(Theme.of(context).brightness == Brightness.dark);

  Color get card => dark ? const Color(0xFF171E24) : Colors.white;
  Color get accent => dark ? const Color(0xFF79BED8) : const Color(0xFF1C6C8C);
  Color get muted => dark ? const Color(0xFF91A0AA) : const Color(0xFF52616B);
  Color get levelRest =>
      dark ? const Color(0xFF61707A) : const Color(0xFF9BA7AF);
  Color get green => dark ? const Color(0xFF95C9AA) : const Color(0xFF3A7D44);
  Color get volume => dark ? const Color(0xFFD2C095) : const Color(0xFF8F6D1F);
  Color get circle => dark ? const Color(0xFF222B32) : const Color(0xFFE4EBEF);
  Color get onAccent => dark ? const Color(0xFF0E1216) : Colors.white;
}

/// Décoration des champs de SAISIE de séance (jaune) — usage explicite.
InputDecoration logDeco({String? hint, String? suffix}) => InputDecoration(
  hintText: hint,
  suffixText: suffix,
  isDense: true,
  filled: true,
  fillColor: SL.fieldFill,
  hintStyle: TextStyle(
    color: SL.dim.withValues(alpha: 0.7),
    fontWeight: FontWeight.w600,
  ),
  contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.circular(KControl.radius),
    borderSide: BorderSide(color: SL.fieldBorder),
  ),
  enabledBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(KControl.radius),
    borderSide: BorderSide(color: SL.fieldBorder),
  ),
  focusedBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(KControl.radius),
    borderSide: BorderSide(color: SL.inputYellow, width: 1.2),
  ),
);

/// Fabrique de thème : un seul endroit, deux luminosités.
ThemeData buildTheme(bool dark) {
  SL.dark = dark;
  final palette = KPalette(dark);
  final scheme = (dark ? const ColorScheme.dark() : const ColorScheme.light())
      .copyWith(
        primary: palette.steel,
        onPrimary: palette.onAccent,
        primaryContainer: palette.steel.withValues(alpha: dark ? 0.18 : 0.10),
        onPrimaryContainer: palette.text,
        secondary: palette.inputYellow,
        onSecondary: palette.onAccent,
        secondaryContainer: palette.inputYellow.withValues(alpha: 0.14),
        onSecondaryContainer: palette.text,
        tertiary: palette.prevViolet,
        onTertiary: palette.onAccent,
        tertiaryContainer: palette.prevViolet.withValues(alpha: 0.14),
        onTertiaryContainer: palette.text,
        surfaceContainer: palette.card,
        surfaceContainerLow: palette.card,
        surfaceContainerHigh: palette.card,
        surface: palette.surface,
        onSurface: palette.text,
        onSurfaceVariant: palette.dim,
        outline: palette.formBorder,
        outlineVariant: palette.line,
        error: palette.danger,
        surfaceContainerHighest: palette.faint,
        inverseSurface:
            dark ? const Color(0xFFE8EDF1) : const Color(0xFF14232B),
        onInverseSurface:
            dark ? const Color(0xFF0E1216) : const Color(0xFFF7F9FA),
        inversePrimary:
            dark ? const Color(0xFF1C6C8C) : const Color(0xFF7CC4E0),
      );
  OutlineInputBorder border(Color c, [double w = 1]) => OutlineInputBorder(
    borderRadius: BorderRadius.circular(KControl.radius),
    borderSide: BorderSide(color: c, width: w),
  );
  return ThemeData(
    useMaterial3: true,
    brightness: dark ? Brightness.dark : Brightness.light,
    colorScheme: scheme,
    scaffoldBackgroundColor: palette.bg,
    splashFactory: InkRipple.splashFactory,
    cardTheme: CardThemeData(
      color: palette.card,
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: const BorderRadius.all(Radius.circular(12)),
        side: dark ? BorderSide.none : BorderSide(color: palette.line),
      ),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: palette.bg,
      foregroundColor: palette.text,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleSpacing: 12,
      toolbarHeight: 52,
      titleTextStyle: TextStyle(
        color: palette.text,
        fontSize: 17,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.3,
      ),
    ),
    // Formulaires (éditeurs, recherche, réglages) : neutres. La saisie de
    // séance utilise logDeco() explicitement — jamais le mélange des deux.
    inputDecorationTheme: InputDecorationTheme(
      isDense: true,
      filled: true,
      fillColor: palette.formFill,
      contentPadding: KControl.fieldPadding,
      floatingLabelBehavior: FloatingLabelBehavior.always,
      alignLabelWithHint: true,
      helperMaxLines: 2,
      errorMaxLines: 3,
      prefixIconConstraints: const BoxConstraints(
        minWidth: KControl.height,
        minHeight: KControl.height,
      ),
      suffixIconConstraints: const BoxConstraints(
        minWidth: KControl.height,
        minHeight: KControl.height,
      ),
      border: border(palette.formBorder),
      enabledBorder: border(palette.formBorder),
      focusedBorder: border(palette.steel, 1.2),
      labelStyle: TextStyle(color: palette.dim, fontSize: 13),
      floatingLabelStyle: TextStyle(color: palette.steel, fontSize: 13),
      hintStyle: TextStyle(color: palette.dim.withValues(alpha: 0.7)),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(KControl.height, KControl.buttonHeight),
        iconSize: KControl.iconSize,
        visualDensity: KControl.density,
        tapTargetSize: MaterialTapTargetSize.padded,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        shape: KControl.shape,
        textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(KControl.height, KControl.buttonHeight),
        iconSize: KControl.iconSize,
        visualDensity: KControl.density,
        tapTargetSize: MaterialTapTargetSize.padded,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        side: BorderSide(color: scheme.outline),
        shape: KControl.shape,
        textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        minimumSize: const Size(KControl.height, KControl.buttonHeight),
        iconSize: KControl.iconSize,
        visualDensity: KControl.density,
        shape: KControl.shape,
        tapTargetSize: MaterialTapTargetSize.padded,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
      ),
    ),
    iconButtonTheme: IconButtonThemeData(
      style: IconButton.styleFrom(
        minimumSize: const Size(KControl.buttonHeight, KControl.buttonHeight),
        iconSize: KControl.iconSize,
        visualDensity: const VisualDensity(horizontal: -1, vertical: -1),
        shape: KControl.shape,
        padding: const EdgeInsets.all(8),
        tapTargetSize: MaterialTapTargetSize.padded,
      ),
    ),
    listTileTheme: ListTileThemeData(
      dense: true,
      visualDensity: const VisualDensity(vertical: -1),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
      titleTextStyle: TextStyle(
        color: palette.text,
        fontSize: 14,
        fontWeight: FontWeight.w500,
      ),
      subtitleTextStyle: TextStyle(
        color: palette.dim,
        fontSize: 12,
        height: 1.3,
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: palette.card,
      selectedColor: scheme.primaryContainer,
      secondarySelectedColor: scheme.primaryContainer,
      labelStyle: TextStyle(
        color: palette.text,
        fontSize: 13,
        fontWeight: FontWeight.w500,
      ),
      secondaryLabelStyle: TextStyle(
        color: palette.steel,
        fontSize: 13,
        fontWeight: FontWeight.w700,
      ),
      side: BorderSide(color: palette.line),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(
      color: palette.steel,
      linearTrackColor: palette.faint,
      linearMinHeight: 6,
    ),
    tabBarTheme: TabBarThemeData(
      labelColor: palette.steel,
      unselectedLabelColor: palette.dim,
      indicatorColor: palette.steel,
      dividerColor: palette.line,
      labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (s) =>
            s.contains(WidgetState.selected)
                ? scheme.onPrimary
                : scheme.onSurfaceVariant,
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (s) =>
            s.contains(WidgetState.selected)
                ? scheme.primary
                : scheme.surfaceContainerHighest,
      ),
      trackOutlineColor: WidgetStateProperty.resolveWith(
        (s) =>
            s.contains(WidgetState.selected)
                ? Colors.transparent
                : scheme.outline,
      ),
    ),
    segmentedButtonTheme: SegmentedButtonThemeData(
      style: ButtonStyle(
        padding: const WidgetStatePropertyAll(
          EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        ),
        shape: const WidgetStatePropertyAll(KControl.shape),
        tapTargetSize: MaterialTapTargetSize.padded,
        // 36 px visibles ; le padding natif étend la zone tactile à 44 px.
        visualDensity: KControl.density,
        backgroundColor: WidgetStateProperty.resolveWith(
          (s) =>
              s.contains(WidgetState.selected)
                  ? scheme.primary.withValues(alpha: dark ? 0.14 : 0.09)
                  : palette.card,
        ),
        foregroundColor: WidgetStateProperty.resolveWith(
          (s) =>
              s.contains(WidgetState.selected)
                  ? scheme.primary
                  : scheme.onSurfaceVariant,
        ),
        side: WidgetStateProperty.all(BorderSide(color: scheme.outline)),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontWeight: FontWeight.w500, fontSize: 13),
        ),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: palette.surface,
      indicatorColor: scheme.primary.withValues(alpha: 0.22),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      iconTheme: WidgetStateProperty.resolveWith(
        (s) => IconThemeData(
          color:
              s.contains(WidgetState.selected)
                  ? scheme.primary
                  : scheme.onSurfaceVariant,
        ),
      ),
      labelTextStyle: WidgetStateProperty.resolveWith(
        (s) => TextStyle(
          fontSize: 11.5,
          fontWeight: FontWeight.w700,
          color:
              s.contains(WidgetState.selected)
                  ? scheme.primary
                  : scheme.onSurfaceVariant,
        ),
      ),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: palette.surface,
      showDragHandle: true,
      dragHandleColor: palette.dot,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(14)),
      ),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: palette.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      titleTextStyle: TextStyle(
        color: scheme.onSurface,
        fontSize: 17,
        fontWeight: FontWeight.w700,
      ),
      contentTextStyle: TextStyle(
        color: scheme.onSurface,
        fontSize: 14,
        height: 1.4,
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: scheme.inverseSurface,
      contentTextStyle: TextStyle(
        color: scheme.onInverseSurface,
        fontWeight: FontWeight.w600,
      ),
      actionTextColor: scheme.inversePrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: palette.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      textStyle: TextStyle(color: scheme.onSurface, fontSize: 14),
    ),
    dividerColor: palette.line,
    iconTheme: IconThemeData(color: scheme.onSurface),
    textTheme: TextTheme(
      bodyLarge: KControl.textStyle.copyWith(color: scheme.onSurface),
      bodyMedium: TextStyle(
        color: scheme.onSurface,
        fontSize: 14,
        height: 1.35,
      ),
      bodySmall: TextStyle(
        color: scheme.onSurfaceVariant,
        fontSize: 12.5,
        height: 1.3,
      ),
      titleMedium: TextStyle(
        color: scheme.onSurface,
        fontSize: 15,
        fontWeight: FontWeight.w600,
      ),
      titleLarge: TextStyle(
        color: scheme.onSurface,
        fontSize: 18,
        fontWeight: FontWeight.w700,
        height: 1.3,
      ),
      headlineSmall: TextStyle(
        color: scheme.onSurface,
        fontSize: 22,
        fontWeight: FontWeight.w700,
        height: 1.2,
      ),
      labelLarge: TextStyle(
        color: scheme.onSurface,
        fontSize: 14,
        fontWeight: FontWeight.w500,
      ),
    ),
  );
}
