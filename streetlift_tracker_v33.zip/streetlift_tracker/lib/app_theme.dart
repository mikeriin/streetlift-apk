import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'motion.dart';

/// Commandes tactiles partagées par les formulaires et les séances.
class KControl {
  static const double height = 48, radius = 24, iconSize = 20, gap = 10;
  static const double buttonHeight = 48;
  static const density = VisualDensity.standard;
  static const double formGap = 16;
  static const shape = RoundedRectangleBorder(
    borderRadius: BorderRadius.all(Radius.circular(radius)),
  );
  static const fieldPadding = EdgeInsets.symmetric(
    horizontal: 14,
    vertical: 14,
  );
  static const selectPadding = EdgeInsets.symmetric(
    horizontal: 14,
    vertical: 11,
  );
  static const textStyle = TextStyle(
    fontFamily: 'Roboto',
    fontSize: 15,
    height: 1.3,
  );
  static const numberStyle = TextStyle(
    fontFamily: 'Roboto',
    fontSize: 15,
    height: 1.3,
    fontWeight: FontWeight.w600,
    fontFeatures: [FontFeature.tabularFigures()],
  );
}

/// Bordeaux, anthracite et vert. Les couleurs textuelles sont adaptées au contraste.
class KPalette {
  static const burgundy = Color(0xFF6B0C0C);
  static const actionRed = Color(0xFFA61717);
  static const black = Color(0xFF121212);
  static const charcoal = Color(0xFF1E1E1E);
  static const gray = Color(0xFF8A8A8A);
  static const light = Color(0xFFF4F4F4);
  static const success = Color(0xFF388E3C);
  final bool dark;
  const KPalette(this.dark);
  Color get bg => dark ? black : light;
  Color get surface => dark ? charcoal : Colors.white;
  Color get card => dark ? charcoal : Colors.white;
  Color get text => dark ? light : black;
  Color get dim => dark ? gray : const Color(0xFF616161);
  Color get bordeaux => burgundy;
  Color get action => actionRed;
  Color get logo => dark ? light : burgundy;
  Color get steel => dark ? light : burgundy;
  Color get inputYellow => steel;
  Color get mainGreen =>
      dark ? const Color(0xFF64AA67) : const Color(0xFF2C7230);
  Color get prevViolet =>
      dark ? const Color(0xFFCCCCCC) : const Color(0xFF575757);
  Color get danger => dark ? const Color(0xFFF09B9B) : actionRed;
  Color get line => dark ? const Color(0xFF383838) : const Color(0xFFDDDDDD);
  Color get faint => dark ? const Color(0xFF232323) : const Color(0xFFE5E5E5);
  Color get dot => gray;
  Color get onAccent => dark ? black : light;
  Color get progressTrack => dark ? gray : const Color(0xFFD7D7D7);
  Color get fieldFill => dark ? charcoal : const Color(0xFFEEEEEE);
  Color get fieldBorder => gray;
  Color get formFill => dark ? charcoal : const Color(0xFFEEEEEE);
  Color get formBorder => gray;
}

class SL {
  static bool dark = true;
  static KPalette get _palette => KPalette(dark);
  static Color get bg => _palette.bg;
  static Color get surface => _palette.surface;
  static Color get card => _palette.card;
  static Color get text => _palette.text;
  static Color get dim => _palette.dim;
  static Color get bordeaux => _palette.bordeaux;
  static Color get action => _palette.action;
  static Color get progressTrack => _palette.progressTrack;
  static Color get logo => _palette.logo;
  static Color get steel => _palette.steel;
  static Color get inputYellow => _palette.inputYellow;
  static Color get mainGreen => _palette.mainGreen;
  static Color get prevViolet => _palette.prevViolet;
  static Color get danger => _palette.danger;
  static Color get line => _palette.line;
  static Color get faint => _palette.faint;
  static Color get dot => _palette.dot;
  static Color get onAccent => _palette.onAccent;
  static Color get fieldFill => _palette.fieldFill;
  static Color get fieldBorder => _palette.fieldBorder;
  static Color get formFill => _palette.formFill;
  static Color get formBorder => _palette.formBorder;
}

class ProgrammeColors {
  final bool dark;
  const ProgrammeColors(this.dark);
  factory ProgrammeColors.of(BuildContext context) =>
      ProgrammeColors(Theme.of(context).brightness == Brightness.dark);
  KPalette get p => KPalette(dark);
  Color get card => p.card;
  Color get accent => p.steel;
  Color get muted => p.dim;
  Color get levelRest => p.dot;
  Color get green => p.mainGreen;
  Color get volume => p.steel;
  Color get circle => p.faint;
  Color get onAccent => p.onAccent;
}

InputDecoration logDeco({String? hint, String? suffix}) => InputDecoration(
  hintText: hint,
  suffixText: suffix,
  isDense: true,
  filled: true,
  fillColor: SL.fieldFill,
  hintStyle: TextStyle(
    fontFamily: 'Roboto',
    color: SL.dim.withValues(alpha: .8),
  ),
  contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.circular(16),
    borderSide: BorderSide(color: SL.fieldBorder),
  ),
  enabledBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(16),
    borderSide: BorderSide(color: SL.fieldBorder),
  ),
  focusedBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(16),
    borderSide: BorderSide(color: SL.steel, width: 1.5),
  ),
);

ThemeData buildTheme(bool dark) {
  SL.dark = dark;
  final p = KPalette(dark);
  final scheme = (dark ? const ColorScheme.dark() : const ColorScheme.light())
      .copyWith(
        primary: p.steel,
        onPrimary: p.onAccent,
        primaryContainer: p.faint,
        onPrimaryContainer: p.text,
        secondary: p.mainGreen,
        onSecondary: dark ? KPalette.black : KPalette.light,
        secondaryContainer: p.mainGreen.withValues(alpha: .14),
        onSecondaryContainer: p.text,
        tertiary: p.prevViolet,
        onTertiary: p.onAccent,
        tertiaryContainer: p.prevViolet.withValues(alpha: .14),
        onTertiaryContainer: p.text,
        surface: p.surface,
        onSurface: p.text,
        onSurfaceVariant: p.dim,
        surfaceContainer: p.card,
        surfaceContainerLow: p.card,
        surfaceContainerHigh: p.formFill,
        surfaceContainerHighest: p.faint,
        outline: p.formBorder,
        outlineVariant: p.line,
        error: p.danger,
        inverseSurface: dark ? KPalette.light : KPalette.black,
        onInverseSurface: dark ? KPalette.black : KPalette.light,
        inversePrimary: dark ? p.bordeaux : KPalette.light,
      );
  OutlineInputBorder border(Color c, [double width = 1]) => OutlineInputBorder(
    borderRadius: BorderRadius.circular(KControl.radius),
    borderSide: BorderSide(color: c, width: width),
  );
  const buttonText = TextStyle(
    fontFamily: 'Roboto',
    fontSize: 14,
    fontWeight: FontWeight.w600,
  );
  return ThemeData(
    useMaterial3: true,
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: KPageTransitionsBuilder(),
        TargetPlatform.iOS: KPageTransitionsBuilder(cupertino: true),
        TargetPlatform.macOS: KPageTransitionsBuilder(cupertino: true),
        TargetPlatform.windows: KPageTransitionsBuilder(),
        TargetPlatform.linux: KPageTransitionsBuilder(),
        TargetPlatform.fuchsia: KPageTransitionsBuilder(),
      },
    ),
    brightness: dark ? Brightness.dark : Brightness.light,
    colorScheme: scheme,
    scaffoldBackgroundColor: p.bg,
    splashFactory: InkSparkle.splashFactory,
    cardTheme: CardThemeData(
      color: p.card,
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(32)),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: p.bg,
      foregroundColor: p.text,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleSpacing: 16,
      toolbarHeight: 64,
      systemOverlayStyle:
          dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
      titleTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 19,
        fontWeight: FontWeight.w700,
        letterSpacing: -.5,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      isDense: true,
      filled: true,
      fillColor: p.formFill,
      contentPadding: KControl.fieldPadding,
      floatingLabelBehavior: FloatingLabelBehavior.always,
      alignLabelWithHint: true,
      helperMaxLines: 2,
      errorMaxLines: 3,
      prefixIconConstraints: const BoxConstraints(minWidth: 48, minHeight: 48),
      suffixIconConstraints: const BoxConstraints(minWidth: 48, minHeight: 48),
      border: border(p.formBorder),
      enabledBorder: border(Colors.transparent),
      focusedBorder: border(p.steel, 1.5),
      labelStyle: TextStyle(fontFamily: 'Roboto', color: p.dim, fontSize: 14),
      floatingLabelStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.steel,
        fontSize: 14,
      ),
      hintStyle: TextStyle(fontFamily: 'Roboto', color: p.dim),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: p.bordeaux,
        foregroundColor: KPalette.light,
        minimumSize: const Size(48, 48),
        iconSize: 20,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        shape: KControl.shape,
        textStyle: buttonText,
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(48, 48),
        iconSize: 20,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        side: BorderSide(color: p.formBorder),
        shape: KControl.shape,
        textStyle: buttonText,
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        minimumSize: const Size(44, 44),
        iconSize: 20,
        shape: KControl.shape,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        textStyle: buttonText,
      ),
    ),
    iconButtonTheme: IconButtonThemeData(
      style: IconButton.styleFrom(
        minimumSize: const Size(48, 48),
        iconSize: 22,
        shape: KControl.shape,
        padding: const EdgeInsets.all(12),
      ),
    ),
    listTileTheme: ListTileThemeData(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      iconColor: p.steel,
      selectedColor: p.steel,
      selectedTileColor: p.faint,
      titleTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 15,
        fontWeight: FontWeight.w600,
      ),
      subtitleTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.dim,
        fontSize: 13,
        height: 1.4,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: p.faint,
      selectedColor: p.fieldFill,
      secondarySelectedColor: p.fieldFill,
      labelStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 13,
        fontWeight: FontWeight.w500,
      ),
      secondaryLabelStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.steel,
        fontSize: 13,
        fontWeight: FontWeight.w600,
      ),
      side: BorderSide.none,
      shape: const StadiumBorder(),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(
      color: p.bordeaux,
      linearTrackColor: p.progressTrack,
      linearMinHeight: 6,
    ),
    tabBarTheme: TabBarThemeData(
      labelColor: p.steel,
      unselectedLabelColor: p.dim,
      indicatorColor: p.steel,
      dividerColor: Colors.transparent,
      labelStyle: const TextStyle(
        fontFamily: 'Roboto',
        fontSize: 14,
        fontWeight: FontWeight.w600,
      ),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? Colors.white : p.dim,
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? p.action : p.faint,
      ),
      trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
    ),
    checkboxTheme: CheckboxThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      fillColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? KPalette.success : null,
      ),
      checkColor: const WidgetStatePropertyAll(Colors.white),
    ),
    segmentedButtonTheme: SegmentedButtonThemeData(
      style: ButtonStyle(
        padding: const WidgetStatePropertyAll(
          EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        ),
        shape: const WidgetStatePropertyAll(KControl.shape),
        backgroundColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? p.action : p.faint,
        ),
        foregroundColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? Colors.white : p.dim,
        ),
        side: const WidgetStatePropertyAll(BorderSide.none),
        textStyle: const WidgetStatePropertyAll(
          TextStyle(
            fontFamily: 'Roboto',
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
      ),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: p.surface,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      dragHandleColor: p.dot,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(36)),
      ),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: p.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(36)),
      titleTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 21,
        fontWeight: FontWeight.w700,
      ),
      contentTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 15,
        height: 1.45,
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: scheme.inverseSurface,
      contentTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: scheme.onInverseSurface,
        fontWeight: FontWeight.w500,
      ),
      actionTextColor: scheme.inversePrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: p.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      textStyle: TextStyle(fontFamily: 'Roboto', color: p.text, fontSize: 14),
    ),
    dividerColor: p.line,
    iconTheme: IconThemeData(color: p.text),
    textTheme: TextTheme(
      bodyLarge: KControl.textStyle.copyWith(color: p.text),
      bodyMedium: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 14,
        height: 1.4,
      ),
      bodySmall: TextStyle(
        fontFamily: 'Roboto',
        color: p.dim,
        fontSize: 12.5,
        height: 1.4,
      ),
      titleMedium: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 16,
        fontWeight: FontWeight.w600,
        letterSpacing: -.2,
      ),
      titleLarge: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 22,
        fontWeight: FontWeight.w700,
        height: 1.2,
        letterSpacing: -.5,
      ),
      headlineSmall: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 28,
        fontWeight: FontWeight.w700,
        height: 1.15,
        letterSpacing: -.8,
      ),
      headlineLarge: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 34,
        fontWeight: FontWeight.w700,
        height: 1.1,
        letterSpacing: -1.1,
      ),
      labelLarge: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 14,
        fontWeight: FontWeight.w600,
      ),
    ),
  );
}
