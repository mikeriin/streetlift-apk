import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Commandes tactiles partagées par les formulaires et les séances.
class KControl {
  static const double height = 48, radius = 14, iconSize = 20, gap = 10;
  static const double buttonHeight = 48;
  static const density = VisualDensity.standard;
  static const double formGap = 16;
  static const shape = RoundedRectangleBorder(
    borderRadius: BorderRadius.all(Radius.circular(radius)),
  );
  static const fieldPadding = EdgeInsets.symmetric(
    horizontal: 14,
    vertical: 14,
  );
  static const selectPadding = EdgeInsets.symmetric(
    horizontal: 14,
    vertical: 11,
  );
  static const textStyle = TextStyle(
    fontFamily: 'Roboto',
    fontSize: 15,
    height: 1.3,
  );
  static const numberStyle = TextStyle(
    fontFamily: 'Roboto',
    fontSize: 15,
    height: 1.3,
    fontWeight: FontWeight.w600,
    fontFeatures: [FontFeature.tabularFigures()],
  );
}

/// Bordeaux pour l'identité ; accents lisibles pour les informations.
class KPalette {
  final bool dark;
  const KPalette(this.dark);
  Color get bg => dark ? const Color(0xFF121013) : const Color(0xFFF6F3F4);
  Color get surface => dark ? const Color(0xFF1D191D) : Colors.white;
  Color get card => dark ? const Color(0xFF211C20) : Colors.white;
  Color get text => dark ? const Color(0xFFF8F1F3) : const Color(0xFF241A20);
  Color get dim => dark ? const Color(0xFFB5A7AF) : const Color(0xFF75636D);
  Color get bordeaux => const Color(0xFF782A40);
  Color get steel => dark ? const Color(0xFFE7A9BA) : const Color(0xFF782A40);
  Color get inputYellow =>
      dark ? const Color(0xFFE7A9BA) : const Color(0xFF782A40);
  Color get mainGreen =>
      dark ? const Color(0xFF9DCCB1) : const Color(0xFF356C50);
  Color get prevViolet =>
      dark ? const Color(0xFFC8B7D3) : const Color(0xFF735584);
  Color get danger => dark ? const Color(0xFFFFA294) : const Color(0xFFB3322D);
  Color get line => dark ? const Color(0xFF392F36) : const Color(0xFFE7DDE2);
  Color get faint => dark ? const Color(0xFF2D252B) : const Color(0xFFF1E9ED);
  Color get dot => dark ? const Color(0xFF60515A) : const Color(0xFFC6B5BE);
  Color get onAccent => dark ? const Color(0xFF361620) : Colors.white;
  Color get fieldFill =>
      dark ? const Color(0xFF30232B) : const Color(0xFFF8EDF1);
  Color get fieldBorder =>
      dark ? const Color(0xFF59404C) : const Color(0xFFDCC1CC);
  Color get formFill =>
      dark ? const Color(0xFF2B242A) : const Color(0xFFF3EDF0);
  Color get formBorder =>
      dark ? const Color(0xFF4A3C45) : const Color(0xFFD9CBD2);
}

class SL {
  static bool dark = true;
  static KPalette get _palette => KPalette(dark);
  static Color get bg => _palette.bg;
  static Color get surface => _palette.surface;
  static Color get card => _palette.card;
  static Color get text => _palette.text;
  static Color get dim => _palette.dim;
  static Color get bordeaux => _palette.bordeaux;
  static Color get steel => _palette.steel;
  static Color get inputYellow => _palette.inputYellow;
  static Color get mainGreen => _palette.mainGreen;
  static Color get prevViolet => _palette.prevViolet;
  static Color get danger => _palette.danger;
  static Color get line => _palette.line;
  static Color get faint => _palette.faint;
  static Color get dot => _palette.dot;
  static Color get onAccent => _palette.onAccent;
  static Color get fieldFill => _palette.fieldFill;
  static Color get fieldBorder => _palette.fieldBorder;
  static Color get formFill => _palette.formFill;
  static Color get formBorder => _palette.formBorder;
}

class ProgrammeColors {
  final bool dark;
  const ProgrammeColors(this.dark);
  factory ProgrammeColors.of(BuildContext context) =>
      ProgrammeColors(Theme.of(context).brightness == Brightness.dark);
  KPalette get p => KPalette(dark);
  Color get card => p.card;
  Color get accent => p.steel;
  Color get muted => p.dim;
  Color get levelRest => p.dot;
  Color get green => p.mainGreen;
  Color get volume => p.steel;
  Color get circle => p.faint;
  Color get onAccent => p.onAccent;
}

InputDecoration logDeco({String? hint, String? suffix}) => InputDecoration(
  hintText: hint,
  suffixText: suffix,
  isDense: true,
  filled: true,
  fillColor: SL.fieldFill,
  hintStyle: TextStyle(
    fontFamily: 'Roboto',
    color: SL.dim.withValues(alpha: .8),
  ),
  contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
  border: OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    borderSide: BorderSide(color: SL.fieldBorder),
  ),
  enabledBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    borderSide: BorderSide(color: SL.fieldBorder),
  ),
  focusedBorder: OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    borderSide: BorderSide(color: SL.steel, width: 1.5),
  ),
);

ThemeData buildTheme(bool dark) {
  SL.dark = dark;
  final p = KPalette(dark);
  final scheme = (dark ? const ColorScheme.dark() : const ColorScheme.light())
      .copyWith(
        primary: p.steel,
        onPrimary: p.onAccent,
        primaryContainer: p.faint,
        onPrimaryContainer: p.text,
        secondary: p.mainGreen,
        onSecondary: dark ? const Color(0xFF15291E) : Colors.white,
        secondaryContainer: p.mainGreen.withValues(alpha: .14),
        onSecondaryContainer: p.text,
        tertiary: p.prevViolet,
        onTertiary: p.onAccent,
        tertiaryContainer: p.prevViolet.withValues(alpha: .14),
        onTertiaryContainer: p.text,
        surface: p.surface,
        onSurface: p.text,
        onSurfaceVariant: p.dim,
        surfaceContainer: p.card,
        surfaceContainerLow: p.card,
        surfaceContainerHigh: p.formFill,
        surfaceContainerHighest: p.faint,
        outline: p.formBorder,
        outlineVariant: p.line,
        error: p.danger,
        inverseSurface:
            dark ? const Color(0xFFF8F1F3) : const Color(0xFF241A20),
        onInverseSurface:
            dark ? const Color(0xFF241A20) : const Color(0xFFF8F1F3),
        inversePrimary: dark ? p.bordeaux : const Color(0xFFE7A9BA),
      );
  OutlineInputBorder border(Color c, [double width = 1]) => OutlineInputBorder(
    borderRadius: BorderRadius.circular(KControl.radius),
    borderSide: BorderSide(color: c, width: width),
  );
  const buttonText = TextStyle(
    fontFamily: 'Roboto',
    fontSize: 14,
    fontWeight: FontWeight.w600,
  );
  return ThemeData(
    useMaterial3: true,
    brightness: dark ? Brightness.dark : Brightness.light,
    colorScheme: scheme,
    scaffoldBackgroundColor: p.bg,
    splashFactory: InkSparkle.splashFactory,
    cardTheme: CardThemeData(
      color: p.card,
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: p.bg,
      foregroundColor: p.text,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleSpacing: 16,
      toolbarHeight: 64,
      systemOverlayStyle:
          dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
      titleTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 19,
        fontWeight: FontWeight.w700,
        letterSpacing: -.5,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      isDense: true,
      filled: true,
      fillColor: p.formFill,
      contentPadding: KControl.fieldPadding,
      floatingLabelBehavior: FloatingLabelBehavior.always,
      alignLabelWithHint: true,
      helperMaxLines: 2,
      errorMaxLines: 3,
      prefixIconConstraints: const BoxConstraints(minWidth: 48, minHeight: 48),
      suffixIconConstraints: const BoxConstraints(minWidth: 48, minHeight: 48),
      border: border(p.formBorder),
      enabledBorder: border(Colors.transparent),
      focusedBorder: border(p.steel, 1.5),
      labelStyle: TextStyle(fontFamily: 'Roboto', color: p.dim, fontSize: 14),
      floatingLabelStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.steel,
        fontSize: 14,
      ),
      hintStyle: TextStyle(fontFamily: 'Roboto', color: p.dim),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: p.bordeaux,
        foregroundColor: Colors.white,
        minimumSize: const Size(48, 48),
        iconSize: 20,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        shape: KControl.shape,
        textStyle: buttonText,
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(48, 48),
        iconSize: 20,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        side: BorderSide(color: p.formBorder),
        shape: KControl.shape,
        textStyle: buttonText,
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        minimumSize: const Size(44, 44),
        iconSize: 20,
        shape: KControl.shape,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        textStyle: buttonText,
      ),
    ),
    iconButtonTheme: IconButtonThemeData(
      style: IconButton.styleFrom(
        minimumSize: const Size(48, 48),
        iconSize: 22,
        shape: KControl.shape,
        padding: const EdgeInsets.all(12),
      ),
    ),
    listTileTheme: ListTileThemeData(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      iconColor: p.steel,
      selectedColor: p.steel,
      selectedTileColor: p.faint,
      titleTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 15,
        fontWeight: FontWeight.w600,
      ),
      subtitleTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.dim,
        fontSize: 13,
        height: 1.4,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: p.faint,
      selectedColor: p.fieldFill,
      secondarySelectedColor: p.fieldFill,
      labelStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 13,
        fontWeight: FontWeight.w500,
      ),
      secondaryLabelStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.steel,
        fontSize: 13,
        fontWeight: FontWeight.w600,
      ),
      side: BorderSide.none,
      shape: const StadiumBorder(),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(
      color: p.steel,
      linearTrackColor: p.faint,
      linearMinHeight: 6,
    ),
    tabBarTheme: TabBarThemeData(
      labelColor: p.steel,
      unselectedLabelColor: p.dim,
      indicatorColor: p.steel,
      dividerColor: Colors.transparent,
      labelStyle: const TextStyle(
        fontFamily: 'Roboto',
        fontSize: 14,
        fontWeight: FontWeight.w600,
      ),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? Colors.white : p.dim,
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? p.bordeaux : p.faint,
      ),
      trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
    ),
    checkboxTheme: CheckboxThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      fillColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? p.bordeaux : null,
      ),
      checkColor: const WidgetStatePropertyAll(Colors.white),
    ),
    segmentedButtonTheme: SegmentedButtonThemeData(
      style: ButtonStyle(
        padding: const WidgetStatePropertyAll(
          EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        ),
        shape: const WidgetStatePropertyAll(KControl.shape),
        backgroundColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? p.bordeaux : p.faint,
        ),
        foregroundColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? Colors.white : p.dim,
        ),
        side: const WidgetStatePropertyAll(BorderSide.none),
        textStyle: const WidgetStatePropertyAll(
          TextStyle(
            fontFamily: 'Roboto',
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
      ),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: p.surface,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      dragHandleColor: p.dot,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
      ),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: p.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      titleTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 21,
        fontWeight: FontWeight.w700,
      ),
      contentTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 15,
        height: 1.45,
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: scheme.inverseSurface,
      contentTextStyle: TextStyle(
        fontFamily: 'Roboto',
        color: scheme.onInverseSurface,
        fontWeight: FontWeight.w500,
      ),
      actionTextColor: scheme.inversePrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: p.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      textStyle: TextStyle(fontFamily: 'Roboto', color: p.text, fontSize: 14),
    ),
    dividerColor: p.line,
    iconTheme: IconThemeData(color: p.text),
    textTheme: TextTheme(
      bodyLarge: KControl.textStyle.copyWith(color: p.text),
      bodyMedium: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 14,
        height: 1.4,
      ),
      bodySmall: TextStyle(
        fontFamily: 'Roboto',
        color: p.dim,
        fontSize: 12.5,
        height: 1.4,
      ),
      titleMedium: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 16,
        fontWeight: FontWeight.w600,
        letterSpacing: -.2,
      ),
      titleLarge: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 22,
        fontWeight: FontWeight.w700,
        height: 1.2,
        letterSpacing: -.5,
      ),
      headlineSmall: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 28,
        fontWeight: FontWeight.w700,
        height: 1.15,
        letterSpacing: -.8,
      ),
      headlineLarge: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 34,
        fontWeight: FontWeight.w700,
        height: 1.1,
        letterSpacing: -1.1,
      ),
      labelLarge: TextStyle(
        fontFamily: 'Roboto',
        color: p.text,
        fontSize: 14,
        fontWeight: FontWeight.w600,
      ),
    ),
  );
}
