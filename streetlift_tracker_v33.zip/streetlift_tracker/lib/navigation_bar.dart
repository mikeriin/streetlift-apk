import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'ui.dart';

/// Le contenu défile sous la navigation ; les listes gardent une fin accessible.
class AppNavigationFrame extends StatelessWidget {
  final Widget body;
  final int index;
  final ValueChanged<int> onTap;
  const AppNavigationFrame({
    super.key,
    required this.body,
    required this.index,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final keyboardOpen = MediaQuery.viewInsetsOf(context).bottom > 0;
    return Scaffold(
      extendBody: true,
      // Chaque écran intérieur ajuste déjà sa hauteur au clavier.
      resizeToAvoidBottomInset: false,
      body: KBottomOverlay(
        inset: keyboardOpen ? 0 : HeroNavBar.heightFor(context),
        child: body,
      ),
      bottomNavigationBar:
          keyboardOpen ? null : HeroNavBar(index: index, onTap: onTap),
    );
  }
}

/// Cercles opaques fixes, halo de sélection et flou du contenu en arrière-plan.
class HeroNavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const HeroNavBar({super.key, required this.index, required this.onTap});

  static const _labels = [
    'Arsenal',
    'Suivi',
    'Programme',
    'Pilotage',
    'Réglages',
  ];
  static const _outline = [
    Icons.grid_view_outlined,
    Icons.emoji_events_outlined,
    Icons.fitness_center_outlined,
    Icons.tune_outlined,
    Icons.settings_outlined,
  ];
  static const _filled = [
    Icons.grid_view_rounded,
    Icons.emoji_events_rounded,
    Icons.fitness_center_rounded,
    Icons.tune_rounded,
    Icons.settings_rounded,
  ];
  static const _flex = [100, 100, 135, 100, 100];

  static double _bottom(BuildContext context) =>
      math.max(12, MediaQuery.paddingOf(context).bottom);
  static double _textExtra(BuildContext context) =>
      (MediaQuery.textScalerOf(context).scale(11).clamp(11, 14.3) - 11) * 1.5;
  static double heightFor(BuildContext context) =>
      128 + _textExtra(context) + _bottom(context);

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final palette = KPalette(dark);
    final bottom = _bottom(context);
    final extra = _textExtra(context);
    final duration =
        MediaQuery.disableAnimationsOf(context)
            ? Duration.zero
            : const Duration(milliseconds: 220);
    return SizedBox(
      height: heightFor(context),
      child: Material(
        type: MaterialType.transparency,
        child: Stack(
          children: [
            Positioned.fill(
              child: IgnorePointer(
                child: _NavigationBlur(background: palette.bg),
              ),
            ),
            Positioned(
              left: 2,
              right: 2,
              bottom: bottom,
              height: 96 + extra,
              child: SafeArea(
                top: false,
                bottom: false,
                child: LayoutBuilder(
                  builder: (context, bounds) {
                    final labelStyle = Theme.of(
                      context,
                    ).textTheme.bodySmall!.copyWith(
                      fontSize: MediaQuery.textScalerOf(
                        context,
                      ).scale(11).clamp(11, 14.3),
                      fontWeight: FontWeight.w600,
                      letterSpacing: -.2,
                      height: 1.45,
                    );
                    // Une même taille finale pour les cinq titres, même si le
                    // texte système est agrandi ou l'écran plus étroit.
                    var fit = 1.0;
                    for (var i = 0; i < _labels.length; i++) {
                      final painter = TextPainter(
                        text: TextSpan(
                          text: _labels[i].toUpperCase(),
                          style: labelStyle,
                        ),
                        textDirection: Directionality.of(context),
                      )..layout();
                      fit = math.min(
                        fit,
                        (bounds.maxWidth * _flex[i] / 535 - 2) / painter.width,
                      );
                      painter.dispose();
                    }
                    final fittedStyle = labelStyle.copyWith(
                      fontSize: labelStyle.fontSize! * fit,
                    );
                    return Row(
                      children: [
                        for (var i = 0; i < _labels.length; i++)
                          Expanded(
                            flex: _flex[i],
                            child: Semantics(
                              button: true,
                              selected: index == i,
                              label: _labels[i],
                              onTap: () => onTap(i),
                              excludeSemantics: true,
                              child: Tooltip(
                                message: _labels[i],
                                child: InkWell(
                                  key: ValueKey('nav-$i'),
                                  onTap: () => onTap(i),
                                  splashFactory: NoSplash.splashFactory,
                                  highlightColor: Colors.transparent,
                                  borderRadius: BorderRadius.circular(8),
                                  child: TweenAnimationBuilder<double>(
                                    duration: duration,
                                    curve: Curves.easeInOut,
                                    tween: Tween(
                                      begin: index == i ? 1 : 0,
                                      end: index == i ? 1 : 0,
                                    ),
                                    builder: (context, selected, _) {
                                      final color =
                                          Color.lerp(
                                            palette.dim,
                                            palette.steel,
                                            selected,
                                          )!;
                                      final disc =
                                          Color.lerp(
                                            dark
                                                ? const Color(0xFF26343E)
                                                : const Color(0xFFE5ECF0),
                                            dark
                                                ? const Color(0xFF193D4D)
                                                : const Color(0xFFDBEEF5),
                                            selected,
                                          )!;
                                      final halo = palette.steel.withValues(
                                        alpha: (dark ? .48 : .36) * selected,
                                      );
                                      final hero = i == 2;
                                      return Column(
                                        children: [
                                          SizedBox(
                                            height: 72,
                                            child: Center(
                                              child: Container(
                                                key: ValueKey('nav-disc-$i'),
                                                width: hero ? 58 : 46,
                                                height: hero ? 58 : 46,
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: disc,
                                                  boxShadow: [
                                                    BoxShadow(
                                                      color: halo,
                                                      blurRadius: 12,
                                                    ),
                                                    BoxShadow(
                                                      color: halo,
                                                      blurRadius: 24,
                                                    ),
                                                  ],
                                                ),
                                                child: Center(
                                                  child: SizedBox(
                                                    width: hero ? 46 : 36,
                                                    height: hero ? 46 : 36,
                                                    child: Stack(
                                                      alignment:
                                                          Alignment.center,
                                                      children: [
                                                        Icon(
                                                          _outline[i],
                                                          size: hero ? 46 : 36,
                                                          color: color
                                                              .withValues(
                                                                alpha:
                                                                    1 -
                                                                    selected,
                                                              ),
                                                        ),
                                                        Icon(
                                                          _filled[i],
                                                          size: hero ? 46 : 36,
                                                          color: color
                                                              .withValues(
                                                                alpha: selected,
                                                              ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(height: 5),
                                          Text(
                                            _labels[i].toUpperCase(),
                                            maxLines: 1,
                                            textScaler: TextScaler.noScaling,
                                            style: fittedStyle.copyWith(
                                              color: color,
                                              shadows: [
                                                Shadow(
                                                  color: palette.bg,
                                                  blurRadius: 5,
                                                  offset: const Offset(0, 1),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Le filtrage porte directement sur les pixels déjà peints par la liste.
/// Des bandes jointives font varier le rayon ; un ShaderMask autour d'un
/// BackdropFilter isolerait le fond dans une couche vide sur certains moteurs.
class _NavigationBlur extends StatelessWidget {
  final Color background;
  const _NavigationBlur({required this.background});

  @override
  Widget build(BuildContext context) => ClipRect(
    child: LayoutBuilder(
      builder: (context, bounds) {
        const bands = 16;
        final ratio = MediaQuery.devicePixelRatioOf(context);
        double edge(int i) =>
            (bounds.maxHeight * i / bands * ratio).round() / ratio;
        return Stack(
          fit: StackFit.expand,
          children: [
            for (var i = 1; i < bands; i++)
              Positioned(
                left: 0,
                right: 0,
                top: edge(i),
                height: edge(i + 1) - edge(i),
                child: ClipRect(
                  child: BackdropFilter(
                    filter: ui.ImageFilter.blur(
                      sigmaX: 18 * i / (bands - 1),
                      sigmaY: 18 * i / (bands - 1),
                    ),
                    child: const SizedBox.expand(),
                  ),
                ),
              ),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    background.withValues(alpha: 0),
                    background.withValues(alpha: .12),
                    background.withValues(alpha: .38),
                  ],
                  stops: const [0, .5, 1],
                ),
              ),
            ),
          ],
        );
      },
    ),
  );
}
