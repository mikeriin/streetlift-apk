import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'device.dart';
import 'notifications.dart';

class NotificationSettingsPanel extends StatefulWidget {
  final NotificationService? service;
  const NotificationSettingsPanel({super.key, this.service});
  @override
  State<NotificationSettingsPanel> createState() =>
      _NotificationSettingsPanelState();
}

class _NotificationSettingsPanelState extends State<NotificationSettingsPanel> {
  NotificationService get service => widget.service ?? Notif.service;
  bool working = false;
  @override
  void initState() {
    super.initState();
    unawaited(service.reschedule());
  }

  void message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> run(Future<void> Function() action) async {
    if (working) return;
    setState(() => working = true);
    try {
      await action();
    } finally {
      if (mounted) setState(() => working = false);
    }
  }

  Future<void> open(String page) async {
    if (!await openDeviceSettings(page)) {
      message('Ouvre les réglages Android → Applications → Kalis Track.');
    }
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ReminderStatus>(
    valueListenable: service.status,
    builder: (context, state, _) {
      final s = service.app.settings;
      final access = state.access;
      final busy = working || state.busy;
      final blocked = access != null && !access.usable;
      final scheme = Theme.of(context).colorScheme;
      String title;
      String detail;
      if (state.error != null) {
        title = 'Rappels à vérifier';
        detail = state.error!;
      } else if (access != null && !access.allowed) {
        title = 'Notifications bloquées par Android';
        detail =
            'Autorise les notifications de Kalis Track dans les réglages du téléphone.';
      } else if (access != null && !access.channelAllowed) {
        title = 'Canal « Rappel quotidien » désactivé';
        detail =
            'Réactive ce canal dans Android pour recevoir la séance du jour.';
      } else if (!s.notifOn) {
        title = 'Rappel quotidien désactivé';
        detail =
            'Active-le pour recevoir les séances à l’heure choisie. Les boutons de test restent disponibles.';
      } else if (state.count == 0) {
        title = 'Aucune séance à rappeler';
        detail =
            'Le programme est terminé, les séances restantes sont déjà validées ou les jours de repos sont ignorés.';
      } else {
        title = '${state.count} rappels programmés';
        final next = state.next!;
        final date = MaterialLocalizations.of(context).formatMediumDate(next);
        final time = TimeOfDay.fromDateTime(next).format(context);
        detail =
            'Prochain rappel : $date à $time. Tous les jours restants du programme sont couverts.';
      }
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SwitchListTile.adaptive(
            title: const Text('Notification de la séance du jour'),
            subtitle: const Text(
              'Les séances déjà terminées ne sont pas rappelées.',
            ),
            value: s.notifOn,
            onChanged:
                busy
                    ? null
                    : (value) => run(() async {
                      if (value && !await service.requestPermission()) {
                        message(
                          'Autorise les notifications et le canal « Rappel quotidien » dans Android.',
                        );
                        return;
                      }
                      s.notifOn = value;
                      service.app.saveSettings();
                      await service.reschedule();
                    }),
          ),
          ListTile(
            leading: const Icon(Icons.schedule),
            title: const Text('Heure du rappel'),
            subtitle: Text(
              TimeOfDay(
                hour: s.notifHour,
                minute: s.notifMinute,
              ).format(context),
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap:
                busy
                    ? null
                    : () => run(() async {
                      final time = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay(
                          hour: s.notifHour,
                          minute: s.notifMinute,
                        ),
                        helpText: 'Heure du rappel',
                      );
                      if (time == null) return;
                      s.notifHour = time.hour;
                      s.notifMinute = time.minute;
                      service.app.saveSettings();
                      await service.reschedule();
                    }),
          ),
          SwitchListTile.adaptive(
            title: const Text('Ignorer les jours de repos'),
            value: s.notifSkipRest,
            onChanged:
                busy
                    ? null
                    : (value) => run(() async {
                      s.notifSkipRest = value;
                      service.app.saveSettings();
                      await service.reschedule();
                    }),
          ),
          Container(
            margin: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      blocked || state.error != null
                          ? Icons.notifications_off_outlined
                          : Icons.notifications_active_outlined,
                      color: blocked ? scheme.error : scheme.primary,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        busy ? 'Vérification des rappels…' : title,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                if (busy) const LinearProgressIndicator() else Text(detail),
                if (access != null && access.usable) ...[
                  const SizedBox(height: 10),
                  Text(
                    access.exact
                        ? 'Heure précise autorisée, y compris en veille.'
                        : 'Heure approximative : Android peut retarder le rappel en veille.',
                  ),
                  if (!access.exact)
                    TextButton.icon(
                      onPressed:
                          busy
                              ? null
                              : () => run(() async {
                                final granted =
                                    await service.requestExactPermission();
                                if (!granted) {
                                  message(
                                    'Les rappels restent actifs à une heure approximative.',
                                  );
                                }
                              }),
                      icon: const Icon(Icons.alarm_add),
                      label: const Text('Autoriser l’heure précise'),
                    ),
                ],
                if (blocked)
                  FilledButton.tonalIcon(
                    onPressed:
                        busy
                            ? null
                            : () => open(
                              access.allowed ? 'channel' : 'notifications',
                            ),
                    icon: const Icon(Icons.settings),
                    label: const Text('Ouvrir les réglages Android'),
                  ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    OutlinedButton.icon(
                      onPressed:
                          busy
                              ? null
                              : () => run(() async {
                                if (await service.test()) {
                                  message(
                                    'Test envoyé à Android. Vérifie le volet des notifications.',
                                  );
                                } else if (service.status.value.error == null) {
                                  message(
                                    'Les notifications sont bloquées dans Android.',
                                  );
                                }
                              }),
                      icon: const Icon(Icons.notifications_outlined),
                      label: const Text('Tester maintenant'),
                    ),
                    OutlinedButton.icon(
                      onPressed:
                          busy
                              ? null
                              : () => run(() async {
                                if (await service.test(delayed: true)) {
                                  message(
                                    service.status.value.access?.exact == true
                                        ? 'Test prévu dans 15 s. Verrouille l’écran pour vérifier.'
                                        : 'Test prévu à partir de 15 s ; Android peut le retarder sans l’heure précise.',
                                  );
                                } else if (service.status.value.error == null) {
                                  message(
                                    'Les notifications sont bloquées dans Android.',
                                  );
                                }
                              }),
                      icon: const Icon(Icons.phonelink_lock),
                      label: const Text('Tester en veille'),
                    ),
                    TextButton.icon(
                      onPressed:
                          busy
                              ? null
                              : () =>
                                  run(() => service.reschedule(force: true)),
                      icon: const Icon(Icons.refresh),
                      label: const Text('Vérifier / reprogrammer'),
                    ),
                  ],
                ),
                if (state.technicalError != null)
                  TextButton.icon(
                    onPressed: () async {
                      await Clipboard.setData(
                        ClipboardData(text: state.technicalError!),
                      );
                      message('Diagnostic copié.');
                    },
                    icon: const Icon(Icons.copy),
                    label: const Text('Copier le diagnostic'),
                  ),
                ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  title: const Text('Le test ne s’affiche toujours pas ?'),
                  children: [
                    const Text(
                      'Vérifie le canal « Rappel quotidien », le mode Ne pas déranger et les restrictions de batterie. Sur Samsung, retire Kalis Track des applications en veille profonde. Après un arrêt forcé, rouvre l’application.',
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: [
                        TextButton(
                          onPressed: () => open('channel'),
                          child: const Text('Canal de notification'),
                        ),
                        TextButton(
                          onPressed: () => open('battery'),
                          child: const Text('Réglages batterie'),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      );
    },
  );
}
