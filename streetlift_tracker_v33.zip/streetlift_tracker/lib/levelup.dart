// Pastille de niveau (accueil) ; l'écran de récompenses et la cérémonie de
// niveau vivent dans rewards.dart, ré-exportés ici pour les écrans existants.
import 'package:flutter/material.dart';

import 'app_theme.dart';
import 'store.dart';
import 'ui.dart';
import 'progression_screen.dart';

export 'rewards.dart' show checkLevelUp;

/// Niveau et avancement vers le prochain, accessibles depuis tous les onglets.
class LevelPill extends StatelessWidget {
  const LevelPill({super.key});
  @override
  Widget build(BuildContext context) {
    final p = store.levelProgress;
    return Semantics(
      button: true,
      label: 'Niveau ${store.level}',
      value: '${p.inLevel} sur ${p.need} XP',
      onTap: () => openProgression(context),
      excludeSemantics: true,
      child: Tooltip(
        message: 'Ouvrir ma progression',
        child: InkWell(
          onTap: () => openProgression(context),
          borderRadius: BorderRadius.circular(20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(minWidth: 48, minHeight: 56),
            child: Align(
              widthFactor: 1,
              heightFactor: 1,
              alignment: Alignment.centerLeft,
              child: LevelProgressNumber(
                level: store.level,
                progress: p.need == 0 ? 0 : p.inLevel / p.need,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class LevelProgressNumber extends StatelessWidget {
  final int level;
  final double progress;
  const LevelProgressNumber({
    super.key,
    required this.level,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    final colors = ProgrammeColors.of(context);
    return SizedBox(
      width: 88,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  'NIV.',
                  textScaler: TextScaler.noScaling,
                  style: TextStyle(
                    color: colors.muted,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    letterSpacing: .8,
                  ),
                ),
                const SizedBox(width: 7),
                Text(
                  '$level',
                  textScaler: TextScaler.noScaling,
                  style: TextStyle(
                    color: SL.text,
                    fontSize: 30,
                    height: 1,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -1,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 7),
          KProgressBar(
            value: progress,
            height: 4,
            semanticsLabel: 'Progression vers le niveau suivant',
          ),
        ],
      ),
    );
  }
}
