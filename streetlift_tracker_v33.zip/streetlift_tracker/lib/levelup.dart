// Dialogue de passage de niveau (WODs déverrouillés).
import 'package:flutter/material.dart';

import 'main.dart';
import 'store.dart';

/// À appeler après une séance terminée ou un score de WOD enregistré.
void checkLevelUp(BuildContext context) {
  final up = store.consumeLevelUp();
  if (up == null || !context.mounted) return;
  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Row(
        children: [
          Icon(Icons.military_tech, color: SL.inputYellow, size: 28),
          const SizedBox(width: 8),
          Text('NIVEAU ${up.to}', style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Niveau ${up.from} → ${up.to}.'),
          const SizedBox(height: 10),
          Row(
            children: [
              Icon(Icons.toll, size: 20, color: SL.inputYellow),
              const SizedBox(width: 8),
              Expanded(
                child: Text('+${up.credits} crédit${up.credits > 1 ? 's' : ''} de déverrouillage — ${store.credits} disponible${store.credits > 1 ? 's' : ''}. Dépense-les dans Perso → WOD.',
                    style: const TextStyle(fontWeight: FontWeight.w700, height: 1.35)),
              ),
            ],
          ),
        ],
      ),
      actions: [
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: SL.steel, foregroundColor: SL.onAccent),
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Continuer'),
        ),
      ],
    ),
  );
}

/// Pastille de niveau (barre d'app de l'accueil).
class LevelPill extends StatelessWidget {
  const LevelPill({super.key});
  @override
  Widget build(BuildContext context) {
    final p = store.levelProgress;
    return Container(
      margin: const EdgeInsets.only(right: 4),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: SL.steel.withOpacity(0.16), borderRadius: BorderRadius.circular(12)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.military_tech, size: 16, color: SL.inputYellow),
          const SizedBox(width: 4),
          Text('NIV. ${store.level}', style: TextStyle(color: SL.steel, fontSize: 12, fontWeight: FontWeight.w900)),
          const SizedBox(width: 6),
          SizedBox(
            width: 34,
            height: 5,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(value: p.need == 0 ? 0 : p.inLevel / p.need, backgroundColor: SL.faint, color: SL.steel),
            ),
          ),
        ],
      ),
    );
  }
}
