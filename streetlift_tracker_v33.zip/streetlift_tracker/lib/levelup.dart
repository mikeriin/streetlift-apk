// Dialogue de passage de niveau (WODs déverrouillés).
import 'package:flutter/material.dart';

import 'app_theme.dart';
import 'store.dart';
import 'progression_screen.dart';

/// À appeler après une séance terminée ou un score de WOD enregistré.
void checkLevelUp(BuildContext context) {
  final up = store.consumeLevelUp();
  if (up == null || !context.mounted) return;
  showDialog(
    context: context,
    builder:
        (ctx) => AlertDialog(
          title: Row(
            children: [
              Icon(Icons.military_tech, color: SL.inputYellow, size: 28),
              const SizedBox(width: 8),
              Text(
                'Niveau ${up.to}',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Niveau ${up.from} → ${up.to} · ${store.progression.rank.title}',
                ),
                const SizedBox(height: 6),
                Text(
                  '${store.xp} XP au total · ${store.progression.earnedBadges} badges obtenus',
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Icon(Icons.toll, size: 20, color: SL.inputYellow),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '+${up.credits} crédit${up.credits > 1 ? 's' : ''} de déverrouillage — ${store.credits} disponible${store.credits > 1 ? 's' : ''}. Dépense-les dans Arsenal → WOD.',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                openProgression(context);
              },
              child: const Text('Ma progression'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: SL.steel,
                foregroundColor: SL.onAccent,
              ),
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Continuer'),
            ),
          ],
        ),
  );
}

/// Pastille de niveau (barre d'app de l'accueil).
class LevelPill extends StatelessWidget {
  const LevelPill({super.key});
  @override
  Widget build(BuildContext context) {
    final p = store.levelProgress;
    return Tooltip(
      message: 'Ouvrir ma progression',
      child: InkWell(
        onTap: () => openProgression(context),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
          child: Container(
            constraints: const BoxConstraints(minHeight: 36),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: SL.steel.withValues(alpha: .16),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.military_tech, size: 16, color: SL.inputYellow),
                const SizedBox(width: 4),
                Text(
                  'NIV. ${store.level}',
                  style: TextStyle(
                    color: SL.steel,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(width: 6),
                SizedBox(
                  width: 28,
                  height: 5,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      value: p.need == 0 ? 0 : p.inLevel / p.need,
                      color: SL.steel,
                      backgroundColor: SL.faint,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
