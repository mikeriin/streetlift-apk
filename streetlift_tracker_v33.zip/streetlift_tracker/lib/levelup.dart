// Dialogue de passage de niveau (WODs déverrouillés).
import 'package:flutter/material.dart';

import 'app_theme.dart';
import 'store.dart';
import 'progression_screen.dart';

/// À appeler après une séance terminée ou un score de WOD enregistré.
void checkLevelUp(BuildContext context) {
  final up = store.consumeLevelUp();
  if (up == null || !context.mounted) return;
  showDialog(
    context: context,
    builder:
        (ctx) => AlertDialog(
          title: Row(
            children: [
              Icon(Icons.military_tech, color: SL.inputYellow, size: 28),
              const SizedBox(width: 8),
              Text(
                'Niveau ${up.to}',
                style: const TextStyle(fontWeight: FontWeight.w900),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Niveau ${up.from} → ${up.to} · ${store.progression.rank.title}',
                ),
                const SizedBox(height: 6),
                Text(
                  '${store.xp} XP au total · ${store.progression.earnedBadges} badges obtenus',
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Icon(Icons.toll, size: 20, color: SL.inputYellow),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '+${up.credits} crédit${up.credits > 1 ? 's' : ''} de déverrouillage — ${store.credits} disponible${store.credits > 1 ? 's' : ''}. Dépense-les dans Arsenal → WOD.',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                openProgression(context);
              },
              child: const Text('Ma progression'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: SL.steel,
                foregroundColor: SL.onAccent,
              ),
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Continuer'),
            ),
          ],
        ),
  );
}

/// Pastille de niveau (barre d'app de l'accueil).
class LevelPill extends StatelessWidget {
  const LevelPill({super.key});
  @override
  Widget build(BuildContext context) => Tooltip(
    message: 'Ouvrir ma progression',
    child: TextButton.icon(
      onPressed: () => openProgression(context),
      icon: const Icon(Icons.military_tech_outlined, size: 20),
      label: Text('Niv. ${store.level}'),
    ),
  );
}
