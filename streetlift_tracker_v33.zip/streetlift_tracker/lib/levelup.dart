// Dialogue de passage de niveau (WODs déverrouillés).
import 'package:flutter/material.dart';

import 'app_theme.dart';
import 'store.dart';
import 'progression_screen.dart';

/// À appeler après une séance terminée ou un score de WOD enregistré.
void checkLevelUp(BuildContext context) {
  final up = store.consumeLevelUp();
  if (up == null || !context.mounted) return;
  showDialog(
    context: context,
    builder:
        (ctx) => AlertDialog(
          title: Row(
            children: [
              Icon(Icons.military_tech, color: SL.inputYellow, size: 28),
              const SizedBox(width: 8),
              Text(
                'Niveau ${up.to}',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Niveau ${up.from} → ${up.to} · ${store.progression.rank.title}',
                ),
                const SizedBox(height: 6),
                Text(
                  '${store.xp} XP au total · ${store.progression.earnedBadges} badges obtenus',
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Icon(Icons.toll, size: 20, color: SL.inputYellow),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '+${up.credits} crédit${up.credits > 1 ? 's' : ''} de déverrouillage — ${store.credits} disponible${store.credits > 1 ? 's' : ''}. Dépense-les dans Arsenal → WOD.',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                openProgression(context);
              },
              child: const Text('Ma progression'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: SL.steel,
                foregroundColor: SL.onAccent,
              ),
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Continuer'),
            ),
          ],
        ),
  );
}

/// Niveau et avancement vers le prochain, accessibles depuis tous les onglets.
class LevelPill extends StatelessWidget {
  const LevelPill({super.key});
  @override
  Widget build(BuildContext context) {
    final p = store.levelProgress;
    return Semantics(
      button: true,
      label: 'Niveau ${store.level}',
      value: '${p.inLevel} sur ${p.need} XP',
      onTap: () => openProgression(context),
      excludeSemantics: true,
      child: Tooltip(
        message: 'Ouvrir ma progression',
        child: InkWell(
          onTap: () => openProgression(context),
          borderRadius: BorderRadius.circular(20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(minWidth: 48, minHeight: 56),
            child: Align(
              widthFactor: 1,
              heightFactor: 1,
              alignment: Alignment.centerLeft,
              child: LevelProgressNumber(
                level: store.level,
                progress: p.need == 0 ? 0 : p.inLevel / p.need,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class LevelProgressNumber extends StatelessWidget {
  final int level;
  final double progress;
  const LevelProgressNumber({
    super.key,
    required this.level,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    final colors = ProgrammeColors.of(context);
    return SizedBox(
      width: 88,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  'NIV.',
                  textScaler: TextScaler.noScaling,
                  style: TextStyle(
                    color: colors.muted,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    letterSpacing: .8,
                  ),
                ),
                const SizedBox(width: 7),
                Text(
                  '$level',
                  textScaler: TextScaler.noScaling,
                  style: TextStyle(
                    color: SL.text,
                    fontSize: 30,
                    height: 1,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -1,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 7),
          LinearProgressIndicator(
            value: progress.clamp(0.0, 1.0),
            minHeight: 4,
            color: SL.bordeaux,
            backgroundColor: SL.progressTrack,
            borderRadius: BorderRadius.circular(20),
            semanticsLabel: 'Progression vers le niveau suivant',
          ),
        ],
      ),
    );
  }
}
