import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';

/// Un seul dock, quatre destinations stables, libellés et zones tactiles visibles.
class HeroNavBar extends StatelessWidget {
  static const double extent = 100;
  final int index;
  final ValueChanged<int> onTap;
  const HeroNavBar({super.key, required this.index, required this.onTap});
  @override
  Widget build(BuildContext context) => SafeArea(
    top: false,
    child: SizedBox(
      height: extent,
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 560),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(40),
              child: BackdropFilter(
                filter: ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: SL.surface.withValues(alpha: .94),
                    borderRadius: BorderRadius.circular(40),
                    border: Border.all(color: SL.line.withValues(alpha: .65)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(5),
                    child: Row(
                      children: [
                        _item(context, 0, Icons.grid_view_rounded, 'Arsenal'),
                        _item(context, 1, Icons.insights_rounded, 'Stats'),
                        _item(
                          context,
                          2,
                          Icons.fitness_center_rounded,
                          'Programme',
                        ),
                        _item(context, 3, Icons.settings_outlined, 'Réglages'),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );
  Widget _item(BuildContext context, int i, IconData icon, String label) {
    final selected = index == i;
    return Expanded(
      child: Semantics(
        button: true,
        selected: selected,
        label: label,
        onTap: () => onTap(i),
        excludeSemantics: true,
        child: Tooltip(
          message: label,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              key: ValueKey('nav-$i'),
              borderRadius: BorderRadius.circular(32),
              onTap: () {
                if (!selected) HapticFeedback.selectionClick();
                onTap(i);
              },
              child: AnimatedContainer(
                duration:
                    MediaQuery.disableAnimationsOf(context)
                        ? Duration.zero
                        : const Duration(milliseconds: 180),
                decoration: BoxDecoration(
                  color: selected ? SL.bordeaux : Colors.transparent,
                  borderRadius: BorderRadius.circular(32),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      icon,
                      size: i == 2 ? 26 : 23,
                      color: selected ? Colors.white : SL.dim,
                    ),
                    const SizedBox(height: 5),
                    Text(
                      label.toUpperCase(),
                      maxLines: 1,
                      textScaler: MediaQuery.textScalerOf(
                        context,
                      ).clamp(maxScaleFactor: 1.15),
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight:
                            selected ? FontWeight.w700 : FontWeight.w500,
                        color: selected ? Colors.white : SL.dim,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
