import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'ui.dart';

/// Cinq boutons flottants ; le contenu continue à défiler sous leur flou.
class HeroNavBar extends StatelessWidget {
  static const double extent = 94;
  final int index;
  final ValueChanged<int> onTap;
  const HeroNavBar({super.key, required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewPaddingOf(context).bottom;
    final background = Theme.of(context).scaffoldBackgroundColor;
    return SizedBox(
      height: extent + bottom,
      child: Stack(
        fit: StackFit.expand,
        children: [
          IgnorePointer(
            child: ExcludeSemantics(
              child: LayoutBuilder(
                builder: (context, bounds) {
                  // Bandes bornées : chaque filtre lit le vrai contenu défilant.
                  // Aucun saveLayer ne coupe l'accès au fond des BackdropFilter.
                  const bands = 8;
                  final bandHeight = bounds.maxHeight / bands;
                  return Stack(
                    children: [
                      for (var i = 0; i < bands; i++)
                        Positioned(
                          left: 0,
                          right: 0,
                          top: i * bandHeight,
                          height: bandHeight,
                          child: ClipRect(
                            child: BackdropFilter(
                              filter: ui.ImageFilter.blur(
                                sigmaX: i * 2,
                                sigmaY: i * 2,
                              ),
                              child: const SizedBox.expand(),
                            ),
                          ),
                        ),
                      Positioned.fill(
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                background.withValues(alpha: 0),
                                background.withValues(alpha: .48),
                                background.withValues(alpha: .92),
                              ],
                              stops: const [0, .55, 1],
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
          SafeArea(
            top: false,
            bottom: false,
            child: Align(
              alignment: Alignment.topCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: KSpace.maxWidth),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(15, 20, 15, 0),
                  child: SizedBox(
                    height: 60,
                    child: Row(
                      children: [
                        _item(context, 0, Icons.grid_view_rounded, 'Arsenal'),
                        _item(context, 1, Icons.emoji_events_outlined, 'Suivi'),
                        _item(
                          context,
                          2,
                          Icons.fitness_center_rounded,
                          'Programme',
                        ),
                        _item(context, 3, Icons.tune_rounded, 'Pilotage'),
                        _item(context, 4, Icons.settings_outlined, 'Réglages'),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _item(BuildContext context, int i, IconData icon, String label) {
    final colors = ProgrammeColors.of(context);
    final selected = index == i;
    final hero = i == 2;
    return Expanded(
      child: Semantics(
        button: true,
        selected: selected,
        label: label,
        onTap: () => onTap(i),
        excludeSemantics: true,
        child: Tooltip(
          message: label,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              key: ValueKey('nav-$i'),
              onTap: () => onTap(i),
              customBorder: const CircleBorder(),
              child: Center(
                child: AnimatedContainer(
                  duration:
                      MediaQuery.disableAnimationsOf(context)
                          ? Duration.zero
                          : const Duration(milliseconds: 180),
                  width: hero ? 54 : 42,
                  height: hero ? 54 : 42,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: selected ? colors.accent : colors.circle,
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x18000000),
                        blurRadius: 12,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Icon(
                    icon,
                    size: hero ? 30 : 25,
                    color: selected ? colors.onAccent : colors.muted,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
