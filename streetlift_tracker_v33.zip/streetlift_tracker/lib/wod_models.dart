// Modèles WOD (For Time, rounds, AMRAP, EMOM, routine libre) + WODs préchargés.

class WodResult {
  String at; // ISO
  String score; // texte affiché (ex. « 12:34 » ou « 7 rounds + 5 »)
  int? seconds; // pour les formats chronométrés
  int? rounds; // AMRAP / EMOM
  int? reps;
  String notes;
  WodResult(
      {required this.at,
      required this.score,
      this.seconds,
      this.rounds,
      this.reps,
      this.notes = ''});

  Map<String, dynamic> toJson() => {
        'at': at,
        'score': score,
        'seconds': seconds,
        'rounds': rounds,
        'reps': reps,
        'notes': notes
      };
  WodResult.fromJson(Map<String, dynamic> j)
      : at = j['at'] as String,
        score = j['score'] as String? ?? '',
        seconds = j['seconds'] as int?,
        rounds = j['rounds'] as int?,
        reps = j['reps'] as int?,
        notes = j['notes'] as String? ?? '';
}

/// Types : fortime · rounds · amrap · emom · routine
const wodTypes = <String, String>{
  'fortime': 'For Time',
  'rounds': 'Rounds for time',
  'amrap': 'AMRAP',
  'emom': 'EMOM',
  'routine': 'Routine / libre',
};

class Wod {
  String id;
  String name;
  String type;
  int rounds; // rounds / emom : nombre de tours
  int restSec; // repos entre rounds (0 = aucun)
  int minutes; // amrap : durée ; fortime : time cap (0 = aucun)
  int interval; // emom : intervalle en s
  String scheme; // ex. « 27-21-15-12-9 »
  List<String> lines; // mouvements, une ligne = un mouvement / un bloc
  String notes; // pénalités, objectifs, team…
  String source;
  int level; // niveau requis pour le déverrouiller (1 = libre)
  List<WodResult> results;

  Wod({
    required this.id,
    required this.name,
    this.type = 'fortime',
    this.rounds = 0,
    this.restSec = 0,
    this.minutes = 0,
    this.interval = 60,
    this.scheme = '',
    List<String>? lines,
    this.notes = '',
    this.source = '',
    this.level = 1,
    List<WodResult>? results,
  })  : lines = lines ?? [],
        results = results ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'type': type,
        'rounds': rounds,
        'restSec': restSec,
        'minutes': minutes,
        'interval': interval,
        'scheme': scheme,
        'lines': lines,
        'notes': notes,
        'source': source,
        'level': level,
        'results': results.map((r) => r.toJson()).toList(),
      };
  Wod.fromJson(Map<String, dynamic> j)
      : id = j['id'] as String,
        name = j['name'] as String,
        type = j['type'] as String? ?? 'fortime',
        rounds = j['rounds'] as int? ?? 0,
        restSec = j['restSec'] as int? ?? 0,
        minutes = j['minutes'] as int? ?? 0,
        interval = j['interval'] as int? ?? 60,
        scheme = j['scheme'] as String? ?? '',
        lines = ((j['lines'] as List?) ?? []).map((e) => e.toString()).toList(),
        notes = j['notes'] as String? ?? '',
        source = j['source'] as String? ?? '',
        level = j['level'] as int? ?? 1,
        results = ((j['results'] as List?) ?? [])
            .map((r) => WodResult.fromJson(r as Map<String, dynamic>))
            .toList();

  String get typeLabel => wodTypes[type] ?? type;

  /// Résumé de l'entête (ex. « 5 rounds · repos 1 min · cap 20 min »).
  String header() {
    final p = <String>[];
    if (type == 'amrap') p.add('$minutes min');
    if (type == 'emom') p.add('$rounds × $interval s');
    if (type == 'rounds') p.add('$rounds rounds');
    if (restSec > 0) {
      p.add('repos ${restSec >= 60 ? '${restSec ~/ 60} min' : '$restSec s'}');
    }
    if (type != 'amrap' && minutes > 0) p.add('cap $minutes min');
    if (scheme.isNotEmpty) p.add(scheme);
    return p.join(' · ');
  }

  bool get timed => type == 'fortime' || type == 'rounds' || type == 'routine';

  /// Meilleur résultat : temps mini pour les formats chronométrés,
  /// rounds+reps maxi pour l'AMRAP, sinon le dernier.
  WodResult? best() {
    if (results.isEmpty) return null;
    if (timed) {
      final t = results.where((r) => r.seconds != null).toList();
      if (t.isEmpty) return results.last;
      t.sort((a, b) => a.seconds!.compareTo(b.seconds!));
      return t.first;
    }
    if (type == 'amrap' || type == 'emom') {
      final t = results.where((r) => r.rounds != null).toList();
      if (t.isEmpty) return results.last;
      t.sort((a, b) => ((b.rounds! * 1000) + (b.reps ?? 0))
          .compareTo((a.rounds! * 1000) + (a.reps ?? 0)));
      return t.first;
    }
    return results.last;
  }
}

/// WODs préchargés (les 19 « en stock » de Gaël).
List<Wod> seedWods() {
  var n = 0;
  String nid() => 'seed${++n}';
  return [
    Wod(id: nid(), name: '5 rounds bodyweight', type: 'rounds', rounds: 5, restSec: 60,
        lines: ['10 push-ups', '20 air squats', '30 sit-ups', '20 reverse lunges', '10 burpees'],
        source: 'onlinewod'),
    Wod(id: nid(), name: 'Routine intermédiaire barre', type: 'routine',
        lines: [
          '18 tractions · 30" rest · 28 dips · 15" rest · 5 dips + 10 pompes',
          '15 tractions · 30" rest · 24 dips · 15" rest · 10 dips + 10 pompes',
          '12 tractions · 30" rest · 20 dips · 15" rest · 12 dips + 10 pompes',
          '8 tractions · 30" rest · 15 dips · 15" rest · 17 dips + 10 pompes',
        ],
        source: 'caliwodfr'),
    Wod(id: nid(), name: 'Dips + knees to chest circuit', type: 'rounds', rounds: 5, restSec: 120,
        lines: ['10 dips', '20 knees to chest', '10 dips'], source: 'calisthenicsworkouts'),
    Wod(id: nid(), name: 'IPC 100-80-60-40-20', type: 'fortime',
        lines: ['100 pompes surélevées (pieds sur banc)', '80 tractions', '60 burpees', '40 toes-to-bar', '20 burpees-tractions'],
        notes: 'Objectif — intermédiaire < 40 min · confirmé < 35 min · athlète < 30 min',
        source: 'david_invictusphysicalcoaching'),
    Wod(id: nid(), name: '400 m run 21-15-9', type: 'fortime', scheme: '21-15-9',
        lines: ['400 m run', 'burpees', 'sit-ups', 'air squats'],
        notes: 'Chaque round commence par 400 m de course.', source: 'onlinewod'),
    Wod(id: nid(), name: '10 rounds 10-10-10-10', type: 'rounds', rounds: 10,
        lines: ['10 pull-ups', '10 push-ups', '10 air squats', '10 burpees'], source: 'fitnessinbox'),
    Wod(id: nid(), name: 'Set sur barre (muscle-ups)', type: 'routine',
        lines: [
          '1 MU + 8 pull-ups + 1 MU + 10 bar dips',
          '2 MU + 7 pull-ups + 1 MU + 9 bar dips',
          '3 MU + 6 pull-ups + 1 MU + 8 bar dips',
          '4 MU + 5 pull-ups + 1 MU + 7 bar dips',
          '4 MU + 4 pull-ups + 1 MU + 7 bar dips',
          '3 MU + 3 pull-ups + 1 MU + 8 bar dips',
          '2 MU + 2 pull-ups + 1 MU + 9 bar dips',
          '1 MU + 1 pull-up + 1 MU + 10 bar dips',
        ],
        source: 'caliwodfr'),
    Wod(id: nid(), name: 'WOD Team of 2', type: 'routine',
        lines: [
          '1000 m run — ensemble',
          '2 rounds à partager : 100 m sandbag lunges 20 kg · 100 m farmer carry 2×24 kg · 80 m burpees broad jump',
          '1000 m run — ensemble',
          '2 rounds à partager : 500 m skierg · 500 m run · 500 m row',
          '1000 m run — ensemble',
          '100 wall balls',
        ],
        notes: 'En binôme.', source: 'caliwodfr'),
    Wod(id: nid(), name: 'Pyramide accumulée burpees', type: 'fortime',
        lines: [
          '10 burpees',
          '10 burpees · 25 push-ups',
          '10 burpees · 25 push-ups · 50 lunges',
          '10 burpees · 25 push-ups · 50 lunges · 100 sit-ups',
          '10 burpees · 25 push-ups · 50 lunges · 100 sit-ups · 150 air squats',
        ],
        source: 'onlinewod'),
    Wod(id: nid(), name: 'IPC 1 → 15 reps', type: 'fortime', scheme: '1-2-3-…-15',
        lines: ['pompes', 'burpees', 'tractions', 'toes-to-bar'],
        notes: 'Objectif — intermédiaire < 50 min · confirmé < 45 min · athlète < 40 min',
        source: 'david_invictusphysicalcoaching'),
    Wod(id: nid(), name: 'IPC 5000 m avec pénalités', type: 'fortime',
        lines: ['5000 m de course'],
        notes: 'Toutes les 5\'00", pénalité : 5-10 burpees · 10-20 pompes · 20-30 air squats. Choisis ton niveau. Commence par la course, ne coupe pas le chrono.',
        source: 'david_invictusphysicalcoaching'),
    Wod(id: nid(), name: 'AMRAP 3-4-5', type: 'routine', restSec: 120,
        lines: [
          'AMRAP 3 min : 3 burpees · 3 air squats · 3 push-ups',
          'Repos 2 min',
          'AMRAP 4 min : 6 burpees · 6 air squats · 6 push-ups',
          'Repos 2 min',
          'AMRAP 5 min : 9 burpees · 9 air squats · 9 push-ups',
        ],
        source: 'onlinewod'),
    Wod(id: nid(), name: 'Routine avancée muscle-ups', type: 'routine',
        lines: [
          '5 MU · 35 dips · 20 pull-ups · 40 pompes',
          '5 MU · 30 dips · 18 pull-ups · 35 pompes',
          '5 MU · 25 dips · 16 pull-ups · 30 pompes',
          '5 MU · 20 dips · 12 pull-ups · 25 pompes',
          '5 MU · 15 dips · 10 pull-ups · 20 pompes',
        ],
        source: 'caliwodfr'),
    Wod(id: nid(), name: '27-21-15-12-9 burpees / sit-ups', type: 'fortime', scheme: '27-21-15-12-9',
        lines: ['burpees', 'sit-ups'], notes: '400 m run entre chaque round.', source: 'onlinewod'),
    Wod(id: nid(), name: 'Run & burpees descendant', type: 'fortime',
        lines: ['1000 m run · 50 burpees', '800 m run · 40 burpees', '600 m run · 30 burpees', '400 m run · 20 burpees', '200 m run · 10 burpees'],
        source: 'onlinewod'),
    Wod(id: nid(), name: 'IPC 10 → 1 multi-ladder', type: 'fortime',
        lines: [
          '10-9-8-7-6-5-4-3-2-1 burpees',
          '20-18-16-14-12-10-8-6-4-2 tractions',
          '30-27-24-21-18-15-12-9-6-3 air squats',
          '40-36-32-28-24-20-16-12-8-4 pompes',
        ],
        notes: '1re série : 10 burpees · 20 tractions · 30 air squats · 40 pompes, etc. Objectif — inter. < 50 min · confirmé < 45 min · athlète < 40 min',
        source: 'david_invictusphysicalcoaching'),
    Wod(id: nid(), name: 'IPC 100 bench press', type: 'fortime',
        lines: ['100 bench press'],
        notes: 'À chaque break, pénalité : 15 pompes · 10 dips · 5 burpees. Barre — débutant 50 kg · inter. 70 kg · confirmé 90 kg · athlète 110 kg',
        source: 'david_invictusphysicalcoaching'),
    Wod(id: nid(), name: '44-22 squats / burpees / lunges', type: 'fortime',
        lines: ['44 air squats', '22 burpees', '44 reverse lunges', '22 burpees', '44 forward lunges'],
        source: 'onlinewod'),
    Wod(id: nid(), name: '20/1 → 1/20 push-ups / sit-ups', type: 'fortime', scheme: '20/1 → 1/20',
        lines: ['20 push-ups · 1 sit-up', '19 push-ups · 2 sit-ups', '… jusqu\'à 1 push-up · 20 sit-ups'],
        source: 'onlinewod'),
  ];
}

/// Niveaux requis des WODs préchargés d'origine (migration des installations existantes).
const seedLevels = <String, int>{
  'seed1': 1, 'seed2': 5, 'seed3': 2, 'seed4': 8, 'seed5': 2, 'seed6': 4, 'seed7': 7,
  'seed8': 3, 'seed9': 5, 'seed10': 8, 'seed11': 4, 'seed12': 1, 'seed13': 9, 'seed14': 3,
  'seed15': 4, 'seed16': 9, 'seed17': 6, 'seed18': 2, 'seed19': 3,
};

/// Deuxième fournée : 12 WODs (captures de septembre 2026).
List<Wod> seedWodsV2() => [
      Wod(id: 'seed20', name: '4 rounds burpees & 100 m', type: 'rounds', rounds: 4, level: 2,
          lines: ['10 burpees', '100 m run', '10 air squats', '100 m run', '10 push-ups', '100 m run', '10 sit-ups', '100 m run'],
          source: 'onlinewod'),
      Wod(id: 'seed21', name: 'Routine avancée dips lestés', type: 'routine', level: 8,
          lines: [
            '10 dips 25 kg + (1 pull-up + 1 muscle-up) ×4 + 14 tractions + 30 pompes',
            '10 dips 25 kg + (1 pull-up + 1 muscle-up) ×3 + 13 tractions + 28 pompes',
            '10 dips 25 kg + (1 pull-up + 1 muscle-up) ×2 + 12 tractions + 25 pompes',
            '10 dips 25 kg + (1 pull-up + 1 muscle-up) ×1 + 11 tractions + 22 pompes',
          ],
          source: 'caliwodfr'),
      Wod(id: 'seed22', name: 'Set sur barre +5 kg dégressif', type: 'routine', scheme: '10-8-6-4-2', level: 9,
          lines: ['muscle-ups', 'dips barre', 'pull-ups'],
          notes: 'Lesté +5 kg. 10-8-6-4-2 de chaque, enchaîné.', source: 'caliwodfr'),
      Wod(id: 'seed23', name: 'WOD 21-15-9 barre + burpees / lunges', type: 'fortime', level: 5,
          lines: ['21 pull-ups', '21 dips', '21 push-ups', '50 burpees', '15 pull-ups', '15 dips', '15 push-ups', '50 walking lunges', '9 pull-ups', '9 dips', '9 push-ups'],
          notes: 'Débutant : poids du corps · Intermédiaire : lesté 10 kg · Confirmé : lesté 20 kg', source: 'caliwodfr'),
      Wod(id: 'seed24', name: 'Cindy — niveau athlète (IPC)', type: 'amrap', minutes: 20, level: 9,
          lines: ['3 muscle-ups stricts', '6 HSPU stricts', '9 box jumps'],
          notes: 'AMRAP 20 min. Choisis ton niveau et dépasse tes limites.', source: 'david_invictusphysicalcoaching'),
      Wod(id: 'seed25', name: 'HYROX — jour 407', type: 'rounds', rounds: 2, minutes: 60, level: 6,
          lines: ['400 m run', '100 walking lunges', '400 m run', '80 air squats', '400 m run', '60 sit-ups', '400 m run', '40 push-ups', '400 m run', '20 burpees', '400 m run'],
          notes: 'Time cap 55/60 min.', source: 'entrainement_high_rox'),
      Wod(id: 'seed26', name: '10 rounds 30-20-10-5', type: 'rounds', rounds: 10, level: 3,
          lines: ['30 air squats', '20 sit-ups', '10 push-ups', '5 burpees'], source: 'onlinewod'),
      Wod(id: 'seed27', name: 'Iron Body', type: 'rounds', rounds: 10, level: 6,
          lines: ['10 pull-ups', '20 push-ups', '30 air squats', '40 sit-ups'], notes: 'Score = temps.', source: 'ironboundtribe'),
      Wod(id: 'seed28', name: '6 rounds 24-24-24 + 400 m', type: 'rounds', rounds: 6, level: 3,
          lines: ['24 air squats', '24 push-ups', '24 walking lunge steps', '400 m run'], source: 'onlinewod'),
      Wod(id: 'seed29', name: 'E5MOM 25 min — max tractions (IPC)', type: 'emom', rounds: 5, interval: 300, level: 7,
          lines: ['20 burpees', '30 pompes', '40 air squats', '+ le reste du temps : MAX de tractions'],
          notes: 'Départ toutes les 5 min pendant 25 min. Objectif total tractions — intermédiaire 50 · confirmé 75 · athlète 100.',
          source: 'david_invictusphysicalcoaching'),
      Wod(id: 'seed30', name: 'AMRAP 40 — partner (I go, you go)', type: 'amrap', minutes: 40, level: 4,
          lines: ['3 burpees', '4 air squats', '5 push-ups', '6 sit-ups'], notes: 'En binôme, en alternance.', source: 'onlinewod'),
    ];
