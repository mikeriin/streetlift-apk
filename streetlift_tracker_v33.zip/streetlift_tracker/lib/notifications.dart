// Les dates locales sont converties en instants UTC avant planification.
// Cela respecte le changement d'heure sans supposer le fuseau du téléphone.
import 'dart:async';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'store.dart';

class Notif {
  static final _p = FlutterLocalNotificationsPlugin();
  static bool _ready = false;
  static Future<void> _queue = Future<void>.value();
  static void Function(int week, int day)? onOpen;

  static void _open(String? payload) {
    final match = RegExp(r'^S(\d+)-J([1-7])$').firstMatch(payload ?? '');
    if (match == null) return;
    final week = int.parse(match[1]!);
    if (week > 0 && week <= store.program.weeks.length) {
      onOpen?.call(week, int.parse(match[2]!));
    }
  }

  static Future<void> init() async {
    try {
      tzdata.initializeTimeZones();
      await _p.initialize(
        const InitializationSettings(
          android: AndroidInitializationSettings('ic_stat_kalis'),
        ),
        onDidReceiveNotificationResponse: (response) => _open(response.payload),
      );
      _ready = true;
      final launch = await _p.getNotificationAppLaunchDetails();
      if (launch?.didNotificationLaunchApp ?? false) {
        _open(launch?.notificationResponse?.payload);
      }
    } catch (_) {
      _ready = false;
    }
  }

  static Future<bool> requestPermission() async {
    if (!_ready) await init();
    if (!_ready) return false;
    try {
      final android =
          _p
              .resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin
              >();
      return await android?.requestNotificationsPermission() ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Sérialiser évite qu'un ancien réglage recrée des rappels après désactivation.
  static Future<void> reschedule() {
    _queue = _queue.then((_) => _reschedule()).catchError((Object _) {});
    return _queue;
  }

  static Future<void> _reschedule() async {
    if (!_ready) return;
    for (var i = 0; i < 7; i++) {
      await _p.cancel(100 + i);
    }
    final settings = AppSettings.fromJson(store.settings.toJson());
    if (!settings.notifOn) return;
    final now = DateTime.now();
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'kalis_daily',
        'Rappel quotidien',
        channelDescription: 'La séance du jour',
        importance: Importance.high,
        priority: Priority.high,
        icon: 'ic_stat_kalis',
      ),
    );
    for (var i = 0; i < 7; i++) {
      final at = DateTime(
        now.year,
        now.month,
        now.day + i,
        settings.notifHour,
        settings.notifMinute,
      );
      if (!at.isAfter(now) || !store.program.containsDate(at)) continue;
      final week = store.program.week(store.program.weekFor(at));
      final day = week.day(at.weekday);
      if (day == null ||
          (settings.notifSkipRest && day.exercises.isEmpty) ||
          store.isDone(week.n, day.j)) {
        continue;
      }
      await _p.zonedSchedule(
        100 + i,
        'S${week.n} · J${day.j} — ${day.title}',
        day.exercises.isEmpty
            ? 'Journée de récupération.'
            : '${day.exercises.length} exercices · ${week.block}',
        tz.TZDateTime.from(at.toUtc(), tz.UTC),
        details,
        payload: 'S${week.n}-J${day.j}',
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
      );
    }
  }
}
