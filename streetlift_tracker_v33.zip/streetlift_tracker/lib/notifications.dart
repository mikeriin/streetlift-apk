// Rappels quotidiens : la séance du jour, planifiée pour les 7 prochains jours
// (contenu dynamique), replanifiée à chaque ouverture et à chaque réglage.
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import 'store.dart';

class Notif {
  static final FlutterLocalNotificationsPlugin _p = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static Future<void> init() async {
    try {
      tzdata.initializeTimeZones();
      await _p.initialize(
        const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
      );
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  /// Android 13+ : permission explicite. Retourne true si accordée.
  static Future<bool> requestPermission() async {
    if (!_ready) return false;
    try {
      final android = _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      final ok = await android?.requestNotificationsPermission();
      return ok ?? true;
    } catch (_) {
      return false;
    }
  }

  static Future<void> cancelAll() async {
    if (!_ready) return;
    try {
      await _p.cancelAll();
    } catch (_) {}
  }

  static Future<void> reschedule() async {
    if (!_ready) return;
    try {
      await _p.cancelAll();
      final s = store.settings;
      if (!s.notifOn) return;
      final now = DateTime.now();
      const details = NotificationDetails(
        android: AndroidNotificationDetails(
          'kalis_daily',
          'Rappel quotidien',
          channelDescription: 'La séance du jour, chaque matin',
          importance: Importance.high,
          priority: Priority.high,
          styleInformation: BigTextStyleInformation(''),
        ),
      );
      for (var i = 0; i < 7; i++) {
        final at = DateTime(now.year, now.month, now.day + i, s.notifHour, s.notifMinute);
        if (!at.isAfter(now)) continue;
        final w = store.program.weekFor(at);
        final j = store.program.dayFor(at);
        final week = store.program.week(w);
        final day = week.day(j);
        if (day == null) continue;
        final rest = day.exercises.isEmpty;
        if (rest && s.notifSkipRest) continue;
        final title = rest ? 'S$w · J$j — Repos complet' : 'S$w · J$j — ${day.title}';
        final body = rest
            ? 'Récupération : marche, mobilité légère, sommeil. GtG suspendu.'
            : '${day.exercises.length} exercices · ${week.block}${day.cycle.isNotEmpty ? ' · ${day.cycle}' : ''}';
        await _p.zonedSchedule(
          100 + i,
          title,
          body,
          tz.TZDateTime.from(at.toUtc(), tz.UTC),
          details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        );
      }
    } catch (_) {}
  }
}
