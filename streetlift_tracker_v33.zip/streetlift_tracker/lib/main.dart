import 'package:flutter/material.dart';

import 'home_screen.dart';
import 'pilotage_screen.dart';
import 'records_screen.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.init();
  runApp(const SLApp());
}

// --- Palette « salle de nuit » : encre bleutée + acier, jaune = saisie ---
class SL {
  static const bg = Color(0xFF0E1216);
  static const surface = Color(0xFF171D23);
  static const card = Color(0xFF1B222A);
  static const steel = Color(0xFF4FA3C7);
  static const text = Color(0xFFE8EDF1);
  static const dim = Color(0xFF8FA0AC);
  static const inputYellow = Color(0xFFE9C46A); // cellules jaunes du classeur
  static const mainGreen = Color(0xFF57B368); // lignes vertes (lifts)
  static const prevViolet = Color(0xFFB39DDB); // prévention
  static const danger = Color(0xFFE0645C);
}

class SLApp extends StatelessWidget {
  const SLApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.dark(
      surface: SL.surface,
      primary: SL.steel,
      secondary: SL.inputYellow,
      onSurface: SL.text,
      error: SL.danger,
    );
    return MaterialApp(
      title: 'Kalis Track',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: SL.bg,
        cardTheme: const CardThemeData(
          color: SL.card,
          elevation: 0,
          margin: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(14)),
          ),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: SL.bg,
          elevation: 0,
          titleTextStyle: TextStyle(
            color: SL.text,
            fontSize: 17,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.3,
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          isDense: true,
          filled: true,
          fillColor: SL.inputYellow.withOpacity(0.10),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: SL.inputYellow.withOpacity(0.35)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: SL.inputYellow.withOpacity(0.35)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: SL.inputYellow, width: 1.5),
          ),
          labelStyle: const TextStyle(color: SL.dim, fontSize: 12),
        ),
        dividerColor: Colors.white12,
        textTheme: const TextTheme(
          bodyMedium: TextStyle(color: SL.text, fontSize: 14, height: 1.35),
          bodySmall: TextStyle(color: SL.dim, fontSize: 12.5, height: 1.3),
        ),
      ),
      home: const RootNav(),
    );
  }
}

class RootNav extends StatefulWidget {
  const RootNav({super.key});
  @override
  State<RootNav> createState() => _RootNavState();
}

class _RootNavState extends State<RootNav> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final pages = const [HomeScreen(), PilotageScreen(), RecordsScreen()];
    return Scaffold(
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        backgroundColor: SL.surface,
        indicatorColor: SL.steel.withOpacity(0.22),
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.fitness_center), label: 'Séances'),
          NavigationDestination(icon: Icon(Icons.tune), label: 'Pilotage'),
          NavigationDestination(
              icon: Icon(Icons.emoji_events_outlined), label: 'Suivi'),
        ],
      ),
    );
  }
}
