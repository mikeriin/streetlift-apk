import 'dart:async';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'device.dart';
import 'startup.dart';
import 'app_theme.dart';
import 'ui.dart';
export 'app_theme.dart' show SL, buildTheme, logDeco;
import 'session_screen.dart';

import 'home_screen.dart';
import 'notifications.dart';
import 'arsenal_screen.dart';
import 'pilotage_screen.dart';
import 'records_screen.dart';
import 'settings_screen.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Une première image Flutter immédiate permet d'animer l'ouverture pendant
  // l'initialisation, au lieu de figer l'écran natif deux secondes.
  runApp(
    AppStartup(
      initialization: store.init(),
      appBuilder: (_) => const SLApp(),
      errorBuilder:
          (error, stack) => _InitErrorApp(error: '$error', stack: '$stack'),
      isDark:
          () =>
              store.settings.theme == 'dark' ||
              (store.settings.theme == 'system' &&
                  WidgetsBinding
                          .instance
                          .platformDispatcher
                          .platformBrightness ==
                      Brightness.dark),
      onReady: _bindNotifications,
    ),
  );
  try {
    await enableHighRefreshRate();
  } catch (_) {}
}

void _bindNotifications() {
  Notif.onOpen = (week, day) {
    final nav = appNavigator.currentState;
    final plan = store.program.week(week);
    final session = plan.day(day);
    if (nav != null && session != null) {
      nav.push(
        MaterialPageRoute(
          builder: (_) => SessionScreen(week: plan, day: session),
        ),
      );
    }
  };
  // AppStartup appelle ce point après le rendu de l'accueil : le navigateur
  // est prêt, sans attendre une interaction pour planifier une autre frame.
  Notif.bind();
}

/// Écran de secours si l'initialisation échoue : l'erreur est lisible et copiable
/// au lieu d'un lancement bloqué sur l'écran de démarrage.
class _InitErrorApp extends StatelessWidget {
  final String error;
  final String stack;
  const _InitErrorApp({required this.error, required this.stack});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: buildTheme(true),
    home: KScreen(
      appBar: AppBar(title: const Text('Problème au démarrage')),
      body: KList(
        children: [
          const KCard(
            child: Text(
              'Kalis Track n’a pas pu s’ouvrir. Tu peux conserver une copie de tes données et copier le rapport pour identifier le problème.',
            ),
          ),
          KCard(child: Text(error, style: TextStyle(color: SL.danger))),
          KCard(
            padding: EdgeInsets.zero,
            child: ExpansionTile(
              title: const Text('Détails du problème'),
              childrenPadding: const EdgeInsets.all(16),
              children: [
                SelectableText(
                  stack,
                  style: TextStyle(
                    color: SL.dim,
                    fontSize: 12,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
          OutlinedButton.icon(
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              final raw = jsonEncode({
                for (final key in prefs.getKeys()) key: prefs.get(key),
              });
              await Clipboard.setData(ClipboardData(text: raw));
            },
            icon: const Icon(Icons.save_alt),
            label: const Text('Copier les données pour récupération'),
          ),
          FilledButton.icon(
            onPressed:
                () => Clipboard.setData(ClipboardData(text: '$error\n$stack')),
            icon: const Icon(Icons.copy),
            label: const Text('Copier le rapport'),
          ),
        ],
      ),
    ),
  );
}

// Thèmes construits une seule fois (ThemeData est coûteux à recréer).
final ThemeData _lightTheme = buildTheme(false);
final ThemeData _darkTheme = buildTheme(true);

final appNavigator = GlobalKey<NavigatorState>();

class SLApp extends StatelessWidget {
  const SLApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: store.themeMode,
      builder: (context, t, _) {
        final mode =
            t == 'dark'
                ? ThemeMode.dark
                : t == 'light'
                ? ThemeMode.light
                : ThemeMode.system;
        return MaterialApp(
          navigatorKey: appNavigator,
          title: 'Kalis Track',
          locale: const Locale('fr'),
          supportedLocales: const [Locale('fr')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          debugShowCheckedModeBanner: false,
          themeMode: mode,
          theme: _lightTheme,
          darkTheme: _darkTheme,
          builder: (context, child) {
            SL.dark = Theme.of(context).brightness == Brightness.dark;
            return child ?? const SizedBox.shrink();
          },
          home: const RootNav(),
        );
      },
    );
  }
}

class RootNav extends StatefulWidget {
  const RootNav({super.key});
  @override
  State<RootNav> createState() => _RootNavState();
}

class _RootNavState extends State<RootNav> with WidgetsBindingObserver {
  int _tabIndex = 2;
  final Set<int> _visited = {2};
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    store.themeMode.addListener(_onTheme);
    store.persistenceError.addListener(_onPersistenceError);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    store.themeMode.removeListener(_onTheme);
    store.persistenceError.removeListener(_onPersistenceError);
    super.dispose();
  }

  void _onTheme() => setState(() {});
  void _onPersistenceError() {
    final message = store.persistenceError.value;
    if (message != null && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      store.flush();
    }
    if (state == AppLifecycleState.resumed) {
      store.notifyListeners();
      Notif.reschedule();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Synchronise la palette runtime avec le thème effectif (système compris).
    final t = store.settings.theme;
    final platformDark =
        MediaQuery.platformBrightnessOf(context) == Brightness.dark;
    SL.dark = t == 'dark' || (t == 'system' && platformDark);
    // Reconstruit aussi les composants historiques qui lisent la palette SL.
    final pages = [
      // ignore: prefer_const_constructors
      ArsenalScreen(),
      // ignore: prefer_const_constructors
      RecordsScreen(),
      // ignore: prefer_const_constructors
      HomeScreen(),
      // ignore: prefer_const_constructors
      PilotageScreen(),
      // ignore: prefer_const_constructors
      SettingsScreen(),
    ];
    return Scaffold(
      body: IndexedStack(
        index: _tabIndex,
        children: [
          for (var i = 0; i < pages.length; i++)
            _visited.contains(i)
                ? TickerMode(
                  enabled: i == _tabIndex,
                  child: KeyedSubtree(key: ValueKey('tab-$i'), child: pages[i]),
                )
                : const SizedBox.shrink(),
        ],
      ),
      bottomNavigationBar: HeroNavBar(
        index: _tabIndex,
        onTap: (i) {
          FocusManager.instance.primaryFocus?.unfocus();
          setState(() {
            _tabIndex = i;
            _visited.add(i);
          });
        },
      ),
    );
  }
}

/// Fond translucide et aplat continu : descente, passage à plat, remontée.
class HeroNavBar extends StatefulWidget {
  final int index;
  final ValueChanged<int> onTap;
  const HeroNavBar({super.key, required this.index, required this.onTap});

  @override
  State<HeroNavBar> createState() => _HeroNavBarState();
}

class _HeroNavBarState extends State<HeroNavBar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _transition;
  late int _from, _to;
  double _startLift = 1;

  // Le changement de position se fait uniquement pendant le passage à plat.
  int get _paintIndex => _transition.value < .48 ? _from : _to;
  double get _lift {
    final t = _transition.value;
    if (t < .42) {
      return _startLift * (1 - Curves.easeInOutCubic.transform(t / .42));
    }
    if (t <= .54) return 0;
    return Curves.easeInOutCubic.transform((t - .54) / .46);
  }

  @override
  void initState() {
    super.initState();
    _from = _to = widget.index;
    _transition = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 360),
      value: 1,
    );
  }

  @override
  void didUpdateWidget(covariant HeroNavBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.index == widget.index) return;
    // Un appui pendant l'animation repart de la hauteur affichée, sans saut.
    final currentIndex = _paintIndex;
    final currentLift = _lift;
    _from = currentIndex;
    _to = widget.index;
    _startLift = currentLift;
    if (MediaQuery.disableAnimationsOf(context)) {
      _transition.value = 1;
    } else {
      _transition.forward(from: currentLift == 0 ? .42 : 0);
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.disableAnimationsOf(context)) {
      _from = _to = widget.index;
      _transition.value = 1;
    }
  }

  @override
  void dispose() {
    _transition.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.paddingOf(context).bottom;
    return Material(
      color: Colors.transparent,
      child: DecoratedBox(
        decoration: BoxDecoration(
          // Une couleur de fond unique dont seule l'opacité varie.
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              SL.steel.withValues(alpha: 0),
              SL.steel.withValues(alpha: .035),
              SL.steel.withValues(alpha: .085),
            ],
            stops: const [0, .42, 1],
          ),
        ),
        child: SafeArea(
          top: false,
          bottom: false,
          child: SizedBox(
            height: 70 + bottom,
            child: AnimatedBuilder(
              animation: _transition,
              builder: (context, _) {
                final paintIndex = _paintIndex;
                final lift = _lift;
                final rtl = Directionality.of(context) == TextDirection.rtl;
                return Stack(
                  fit: StackFit.expand,
                  children: [
                    IgnorePointer(
                      child: RepaintBoundary(
                        child: CustomPaint(
                          painter: _NavWavePainter(
                            index: rtl ? 4 - paintIndex : paintIndex,
                            lift: lift,
                            color: SL.steel,
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(bottom: bottom),
                      child: Row(
                        children: [
                          _item(
                            context,
                            0,
                            Icons.grid_view_rounded,
                            'Arsenal',
                            paintIndex,
                            lift,
                          ),
                          _item(
                            context,
                            1,
                            Icons.emoji_events_outlined,
                            'Suivi',
                            paintIndex,
                            lift,
                          ),
                          _item(
                            context,
                            2,
                            Icons.fitness_center_rounded,
                            'Programme',
                            paintIndex,
                            lift,
                            hero: true,
                          ),
                          _item(
                            context,
                            3,
                            Icons.tune_rounded,
                            'Pilotage',
                            paintIndex,
                            lift,
                          ),
                          _item(
                            context,
                            4,
                            Icons.settings_outlined,
                            'Réglages',
                            paintIndex,
                            lift,
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _item(
    BuildContext context,
    int i,
    IconData icon,
    String label,
    int paintIndex,
    double lift, {
    bool hero = false,
  }) {
    final selected = widget.index == i;
    final ink =
        i == paintIndex
            ? Color.lerp(
              SL.dim,
              SL.onAccent,
              Curves.easeInCubic.transform(lift),
            )!
            : SL.dim;
    return Expanded(
      child: Semantics(
        button: true,
        selected: selected,
        label: label,
        onTap: () => widget.onTap(i),
        excludeSemantics: true,
        child: Tooltip(
          message: label,
          child: InkWell(
            key: ValueKey('nav-$i'),
            onTap: () => widget.onTap(i),
            splashFactory: NoSplash.splashFactory,
            highlightColor: Colors.transparent,
            borderRadius: BorderRadius.circular(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 44,
                  child: Center(
                    child: Icon(icon, size: hero ? 27 : 24, color: ink),
                  ),
                ),
                const SizedBox(height: 2),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      hero ? label.toUpperCase() : label,
                      maxLines: 1,
                      style: TextStyle(
                        fontSize: hero ? 10.5 : 11,
                        fontWeight:
                            selected ? FontWeight.w800 : FontWeight.w600,
                        letterSpacing: hero ? .4 : 0,
                        color: SL.onAccent,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Une seule surface opaque et un seul aplat pour la barre et la bosse.
class _NavWavePainter extends CustomPainter {
  final int index;
  final double lift;
  final Color color;
  const _NavWavePainter({
    required this.index,
    required this.lift,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final slot = size.width / 5;
    final center = slot * (index + .5);
    final half = (slot * .9).clamp(48.0, 88.0);
    const base = 50.0;
    final peak = base - 47 * lift;
    final path =
        Path()
          ..moveTo(0, base)
          ..lineTo(center - half, base)
          ..cubicTo(
            center - half * .48,
            base,
            center - half * .5,
            peak,
            center,
            peak,
          )
          ..cubicTo(
            center + half * .5,
            peak,
            center + half * .48,
            base,
            center + half,
            base,
          )
          ..lineTo(size.width, base)
          ..lineTo(size.width, size.height)
          ..lineTo(0, size.height)
          ..close();
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.drawPath(path, Paint()..color = color);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _NavWavePainter oldDelegate) =>
      oldDelegate.index != index ||
      oldDelegate.lift != lift ||
      oldDelegate.color != color;
}
