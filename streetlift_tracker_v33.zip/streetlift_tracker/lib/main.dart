import 'dart:async';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'device.dart';
import 'startup.dart';
import 'app_theme.dart';
import 'ui.dart';
export 'app_theme.dart' show SL, buildTheme, logDeco;
import 'session_screen.dart';

import 'home_screen.dart';
import 'notifications.dart';
import 'arsenal_screen.dart';
import 'pilotage_screen.dart';
import 'records_screen.dart';
import 'settings_screen.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Une première image Flutter immédiate permet d'animer l'ouverture pendant
  // l'initialisation, au lieu de figer l'écran natif deux secondes.
  runApp(
    AppStartup(
      initialization: store.init(),
      appBuilder: (_) => const SLApp(),
      errorBuilder:
          (error, stack) => _InitErrorApp(error: '$error', stack: '$stack'),
      isDark:
          () =>
              store.settings.theme == 'dark' ||
              (store.settings.theme == 'system' &&
                  WidgetsBinding
                          .instance
                          .platformDispatcher
                          .platformBrightness ==
                      Brightness.dark),
      onReady: _bindNotifications,
    ),
  );
  try {
    await enableHighRefreshRate();
  } catch (_) {}
}

void _bindNotifications() {
  Notif.onOpen = (week, day) {
    final nav = appNavigator.currentState;
    final plan = store.program.week(week);
    final session = plan.day(day);
    if (nav != null && session != null) {
      nav.push(
        MaterialPageRoute(
          builder: (_) => SessionScreen(week: plan, day: session),
        ),
      );
    }
  };
  // AppStartup appelle ce point après le rendu de l'accueil : le navigateur
  // est prêt, sans attendre une interaction pour planifier une autre frame.
  Notif.bind();
}

/// Écran de secours si l'initialisation échoue : l'erreur est lisible et copiable
/// au lieu d'un lancement bloqué sur l'écran de démarrage.
class _InitErrorApp extends StatelessWidget {
  final String error;
  final String stack;
  const _InitErrorApp({required this.error, required this.stack});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: buildTheme(true),
    home: KScreen(
      appBar: AppBar(title: const Text('Problème au démarrage')),
      body: KList(
        children: [
          const KCard(
            child: Text(
              'Kalis Track n’a pas pu s’ouvrir. Tu peux conserver une copie de tes données et copier le rapport pour identifier le problème.',
            ),
          ),
          KCard(child: Text(error, style: TextStyle(color: SL.danger))),
          KCard(
            padding: EdgeInsets.zero,
            child: ExpansionTile(
              title: const Text('Détails du problème'),
              childrenPadding: const EdgeInsets.all(16),
              children: [
                SelectableText(
                  stack,
                  style: TextStyle(
                    color: SL.dim,
                    fontSize: 12,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
          OutlinedButton.icon(
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              final raw = jsonEncode({
                for (final key in prefs.getKeys()) key: prefs.get(key),
              });
              await Clipboard.setData(ClipboardData(text: raw));
            },
            icon: const Icon(Icons.save_alt),
            label: const Text('Copier les données pour récupération'),
          ),
          FilledButton.icon(
            onPressed:
                () => Clipboard.setData(ClipboardData(text: '$error\n$stack')),
            icon: const Icon(Icons.copy),
            label: const Text('Copier le rapport'),
          ),
        ],
      ),
    ),
  );
}

// Thèmes construits une seule fois (ThemeData est coûteux à recréer).
final ThemeData _lightTheme = buildTheme(false);
final ThemeData _darkTheme = buildTheme(true);

final appNavigator = GlobalKey<NavigatorState>();

class SLApp extends StatelessWidget {
  const SLApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: store.themeMode,
      builder: (context, t, _) {
        final mode =
            t == 'dark'
                ? ThemeMode.dark
                : t == 'light'
                ? ThemeMode.light
                : ThemeMode.system;
        return MaterialApp(
          navigatorKey: appNavigator,
          title: 'Kalis Track',
          locale: const Locale('fr'),
          supportedLocales: const [Locale('fr')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          debugShowCheckedModeBanner: false,
          themeMode: mode,
          theme: _lightTheme,
          darkTheme: _darkTheme,
          builder: (context, child) {
            SL.dark = Theme.of(context).brightness == Brightness.dark;
            return child ?? const SizedBox.shrink();
          },
          home: const RootNav(),
        );
      },
    );
  }
}

class RootNav extends StatefulWidget {
  const RootNav({super.key});
  @override
  State<RootNav> createState() => _RootNavState();
}

class _RootNavState extends State<RootNav> with WidgetsBindingObserver {
  int _tabIndex = 2;
  final Set<int> _visited = {2};
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    store.themeMode.addListener(_onTheme);
    store.persistenceError.addListener(_onPersistenceError);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    store.themeMode.removeListener(_onTheme);
    store.persistenceError.removeListener(_onPersistenceError);
    super.dispose();
  }

  void _onTheme() => setState(() {});
  void _onPersistenceError() {
    final message = store.persistenceError.value;
    if (message != null && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      store.flush();
    }
    if (state == AppLifecycleState.resumed) {
      store.notifyListeners();
      Notif.reschedule();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Synchronise la palette runtime avec le thème effectif (système compris).
    final t = store.settings.theme;
    final platformDark =
        MediaQuery.platformBrightnessOf(context) == Brightness.dark;
    SL.dark = t == 'dark' || (t == 'system' && platformDark);
    // Reconstruit aussi les composants historiques qui lisent la palette SL.
    final pages = [
      // ignore: prefer_const_constructors
      ArsenalScreen(),
      // ignore: prefer_const_constructors
      RecordsScreen(),
      // ignore: prefer_const_constructors
      HomeScreen(),
      // ignore: prefer_const_constructors
      PilotageScreen(),
      // ignore: prefer_const_constructors
      SettingsScreen(),
    ];
    return Scaffold(
      body: IndexedStack(
        index: _tabIndex,
        children: [
          for (var i = 0; i < pages.length; i++)
            _visited.contains(i)
                ? TickerMode(
                  enabled: i == _tabIndex,
                  child: KeyedSubtree(key: ValueKey('tab-$i'), child: pages[i]),
                )
                : const SizedBox.shrink(),
        ],
      ),
      bottomNavigationBar: HeroNavBar(
        index: _tabIndex,
        onTap: (i) {
          FocusManager.instance.primaryFocus?.unfocus();
          setState(() {
            _tabIndex = i;
            _visited.add(i);
          });
        },
      ),
    );
  }
}

/// Même fond que l'écran, avec un fondu discret et une vague sous l'onglet actif.
class HeroNavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const HeroNavBar({super.key, required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final motion = !MediaQuery.disableAnimationsOf(context);
    return Material(
      color: SL.bg,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              SL.bg,
              Color.alphaBlend(
                SL.steel.withValues(alpha: SL.dark ? .035 : .025),
                SL.bg,
              ),
              Color.alphaBlend(
                SL.steel.withValues(alpha: SL.dark ? .085 : .06),
                SL.bg,
              ),
            ],
            stops: const [0, .42, 1],
          ),
        ),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 70,
            child: LayoutBuilder(
              builder: (context, bounds) {
                final rtl = Directionality.of(context) == TextDirection.rtl;
                final target = (rtl ? 4 - index : index).toDouble();
                return Stack(
                  fit: StackFit.expand,
                  children: [
                    IgnorePointer(
                      child: RepaintBoundary(
                        child: TweenAnimationBuilder<double>(
                          tween: Tween(begin: target, end: target),
                          duration:
                              motion
                                  ? const Duration(milliseconds: 280)
                                  : Duration.zero,
                          curve: Curves.easeInOutCubic,
                          builder:
                              (context, position, _) => CustomPaint(
                                painter: _NavWavePainter(
                                  position: position,
                                  color: SL.steel,
                                  dark: SL.dark,
                                ),
                              ),
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        _item(context, 0, Icons.grid_view_rounded, 'Arsenal'),
                        _item(context, 1, Icons.emoji_events_outlined, 'Suivi'),
                        _item(
                          context,
                          2,
                          Icons.fitness_center_rounded,
                          'Programme',
                          hero: true,
                        ),
                        _item(context, 3, Icons.tune_rounded, 'Pilotage'),
                        _item(context, 4, Icons.settings_outlined, 'Réglages'),
                      ],
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _item(
    BuildContext context,
    int i,
    IconData icon,
    String label, {
    bool hero = false,
  }) {
    final selected = index == i;
    final color = selected ? SL.steel : SL.dim;
    return Expanded(
      child: Semantics(
        button: true,
        selected: selected,
        label: label,
        onTap: () => onTap(i),
        excludeSemantics: true,
        child: Tooltip(
          message: label,
          child: InkWell(
            key: ValueKey('nav-$i'),
            onTap: () => onTap(i),
            borderRadius: BorderRadius.circular(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 44,
                  child: Center(
                    child: AnimatedContainer(
                      duration:
                          MediaQuery.disableAnimationsOf(context)
                              ? Duration.zero
                              : const Duration(milliseconds: 180),
                      width: hero ? 44 : 38,
                      height: hero ? 44 : 38,
                      decoration: BoxDecoration(
                        color: selected ? SL.steel : Colors.transparent,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        icon,
                        size: hero ? 27 : 24,
                        color: selected ? SL.onAccent : color,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      hero ? label.toUpperCase() : label,
                      maxLines: 1,
                      style: TextStyle(
                        fontSize: hero ? 10.5 : 11,
                        fontWeight:
                            selected ? FontWeight.w800 : FontWeight.w600,
                        letterSpacing: hero ? .4 : 0,
                        color: color,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// La forme s'élève autour de l'icône et rejoint doucement le bas de la barre.
/// Elle est décorative : toutes les zones tactiles et sémantiques restent fixes.
class _NavWavePainter extends CustomPainter {
  final double position;
  final Color color;
  final bool dark;
  const _NavWavePainter({
    required this.position,
    required this.color,
    required this.dark,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final slot = size.width / 5;
    final center = slot * (position + .5);
    final half = (slot * .9).clamp(48.0, 88.0);
    final base = size.height;
    final path =
        Path()
          ..moveTo(center - half, base)
          ..cubicTo(center - half * .48, base, center - half * .5, 3, center, 3)
          ..cubicTo(
            center + half * .5,
            3,
            center + half * .48,
            base,
            center + half,
            base,
          )
          ..close();
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            color.withValues(alpha: dark ? .24 : .18),
            color.withValues(alpha: dark ? .13 : .085),
            color.withValues(alpha: .025),
          ],
          stops: const [0, .58, 1],
        ).createShader(Rect.fromLTWH(center - half, 3, half * 2, base - 3)),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _NavWavePainter oldDelegate) =>
      oldDelegate.position != position ||
      oldDelegate.color != color ||
      oldDelegate.dark != dark;
}
