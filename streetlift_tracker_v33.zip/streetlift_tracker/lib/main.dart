import 'package:flutter/material.dart';
import 'package:flutter_displaymode/flutter_displaymode.dart';

import 'home_screen.dart';
import 'notifications.dart';
import 'perso_screen.dart';
import 'pilotage_screen.dart';
import 'records_screen.dart';
import 'settings_screen.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.init();
  await Notif.init();
  Notif.reschedule(); // rappels des 7 prochains jours (asynchrone)
  try {
    await FlutterDisplayMode.setHighRefreshRate(); // 90/120 Hz si l'écran le permet
  } catch (_) {}
  runApp(const SLApp());
}

// ============================================================================
// PALETTE — deux thèmes, mêmes rôles. Sombre : « salle de nuit » (validé).
// Clair : dérivé, accents assombris pour passer WCAG AA (≥ 4,5:1 texte).
// ============================================================================
class SL {
  static bool dark = true;

  static Color get bg => dark ? const Color(0xFF0E1216) : const Color(0xFFF7F9FA);
  static Color get surface => dark ? const Color(0xFF171D23) : const Color(0xFFFFFFFF);
  static Color get card => dark ? const Color(0xFF1B222A) : const Color(0xFFFFFFFF);
  static Color get text => dark ? const Color(0xFFE8EDF1) : const Color(0xFF14232B);
  static Color get dim => dark ? const Color(0xFF8FA0AC) : const Color(0xFF52616B);
  static Color get steel => dark ? const Color(0xFF4FA3C7) : const Color(0xFF1C6C8C);
  /// Accent « saisie » (texte, icônes, chips) — héritage des cellules jaunes.
  static Color get inputYellow => dark ? const Color(0xFFE9C46A) : const Color(0xFF8F6D1F);
  static Color get mainGreen => dark ? const Color(0xFF57B368) : const Color(0xFF3A7D44);
  static Color get prevViolet => dark ? const Color(0xFFB39DDB) : const Color(0xFF5E4B9E);
  static Color get danger => dark ? const Color(0xFFE0645C) : const Color(0xFFC0392B);

  // Rôles secondaires (remplacent les SL.line/24 en dur).
  static Color get line => dark ? const Color(0x1FFFFFFF) : const Color(0xFFDCE3E8);
  static Color get faint => dark ? const Color(0x14FFFFFF) : const Color(0xFFEDF1F4);
  static Color get dot => dark ? const Color(0x3DFFFFFF) : const Color(0xFFC5CED5);
  static Color get onAccent => dark ? const Color(0xFF0B0F12) : const Color(0xFFFFFFFF);
  /// Champs de saisie de séance (jaune) : fond et bordure.
  static Color get fieldFill => dark ? const Color(0x1AE9C46A) : const Color(0xFFFDF3D0);
  static Color get fieldBorder => dark ? const Color(0x59E9C46A) : const Color(0xFFD8BE7A);
  /// Champs de formulaire (neutres).
  static Color get formFill => dark ? const Color(0x0AFFFFFF) : const Color(0xFFF0F3F5);
  static Color get formBorder => dark ? const Color(0x24FFFFFF) : const Color(0xFFC9D2D8);
}

/// Décoration des champs de SAISIE de séance (jaune) — usage explicite.
InputDecoration logDeco({String? hint, String? suffix}) => InputDecoration(
      hintText: hint,
      suffixText: suffix,
      isDense: true,
      filled: true,
      fillColor: SL.fieldFill,
      hintStyle: TextStyle(color: SL.dim.withOpacity(0.7), fontWeight: FontWeight.w600),
      contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: SL.fieldBorder)),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: SL.fieldBorder)),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: SL.inputYellow, width: 1.6)),
    );

/// Fabrique de thème : un seul endroit, deux luminosités.
ThemeData buildTheme(bool dark) {
  SL.dark = dark;
  final scheme = (dark ? const ColorScheme.dark() : const ColorScheme.light()).copyWith(
    primary: SL.steel,
    onPrimary: SL.onAccent,
    secondary: SL.inputYellow,
    surface: SL.surface,
    onSurface: SL.text,
    onSurfaceVariant: SL.dim,
    outline: SL.formBorder,
    outlineVariant: SL.line,
    error: SL.danger,
    surfaceContainerHighest: SL.faint,
    inverseSurface: dark ? const Color(0xFFE8EDF1) : const Color(0xFF14232B),
    onInverseSurface: dark ? const Color(0xFF0E1216) : const Color(0xFFF7F9FA),
    inversePrimary: dark ? const Color(0xFF1C6C8C) : const Color(0xFF7CC4E0),
  );
  OutlineInputBorder border(Color c, [double w = 1]) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: c, width: w),
      );
  return ThemeData(
    useMaterial3: true,
    brightness: dark ? Brightness.dark : Brightness.light,
    colorScheme: scheme,
    scaffoldBackgroundColor: SL.bg,
    splashFactory: InkRipple.splashFactory,
    cardTheme: CardThemeData(
      color: SL.card,
      elevation: 0,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      shape: RoundedRectangleBorder(
        borderRadius: const BorderRadius.all(Radius.circular(14)),
        side: dark ? BorderSide.none : BorderSide(color: SL.line),
      ),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: SL.bg,
      foregroundColor: SL.text,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleTextStyle: TextStyle(
        color: SL.text,
        fontSize: 17,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.3,
      ),
    ),
    // Formulaires (éditeurs, recherche, réglages) : neutres. La saisie de
    // séance utilise logDeco() explicitement — jamais le mélange des deux.
    inputDecorationTheme: InputDecorationTheme(
      isDense: true,
      filled: true,
      fillColor: SL.formFill,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      border: border(SL.formBorder),
      enabledBorder: border(SL.formBorder),
      focusedBorder: border(SL.steel, 1.6),
      labelStyle: TextStyle(color: SL.dim, fontSize: 13),
      floatingLabelStyle: TextStyle(color: SL.steel, fontSize: 13),
      hintStyle: TextStyle(color: SL.dim.withOpacity(0.7)),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((s) =>
          s.contains(WidgetState.selected) ? SL.onAccent : SL.dim),
      trackColor: WidgetStateProperty.resolveWith((s) =>
          s.contains(WidgetState.selected) ? SL.steel : SL.faint),
      trackOutlineColor: WidgetStateProperty.resolveWith((s) =>
          s.contains(WidgetState.selected) ? Colors.transparent : SL.formBorder),
    ),
    segmentedButtonTheme: SegmentedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: WidgetStateProperty.resolveWith((s) =>
            s.contains(WidgetState.selected) ? SL.steel.withOpacity(dark ? 0.22 : 0.14) : SL.card),
        foregroundColor: WidgetStateProperty.resolveWith((s) =>
            s.contains(WidgetState.selected) ? SL.steel : SL.dim),
        side: WidgetStateProperty.all(BorderSide(color: SL.formBorder)),
        textStyle: WidgetStateProperty.all(
            const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: SL.surface,
      indicatorColor: SL.steel.withOpacity(0.22),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(
          color: s.contains(WidgetState.selected) ? SL.steel : SL.dim)),
      labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
          fontSize: 11.5,
          fontWeight: FontWeight.w700,
          color: s.contains(WidgetState.selected) ? SL.steel : SL.dim)),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: SL.surface,
      showDragHandle: true,
      dragHandleColor: SL.dot,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: SL.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      titleTextStyle: TextStyle(color: SL.text, fontSize: 17, fontWeight: FontWeight.w800),
      contentTextStyle: TextStyle(color: SL.text, fontSize: 14, height: 1.4),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: scheme.inverseSurface,
      contentTextStyle: TextStyle(color: scheme.onInverseSurface, fontWeight: FontWeight.w600),
      actionTextColor: scheme.inversePrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: SL.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      textStyle: TextStyle(color: SL.text, fontSize: 14),
    ),
    dividerColor: SL.line,
    iconTheme: IconThemeData(color: SL.text),
    textTheme: TextTheme(
      bodyLarge: TextStyle(color: SL.text, fontSize: 16, height: 1.35),
      bodyMedium: TextStyle(color: SL.text, fontSize: 14, height: 1.35),
      bodySmall: TextStyle(color: SL.dim, fontSize: 12.5, height: 1.3),
      titleMedium: TextStyle(color: SL.text, fontSize: 15, fontWeight: FontWeight.w700),
      labelLarge: TextStyle(color: SL.text, fontSize: 14, fontWeight: FontWeight.w700),
    ),
  );
}

// Thèmes construits une seule fois (ThemeData est coûteux à recréer).
final ThemeData _lightTheme = buildTheme(false);
final ThemeData _darkTheme = buildTheme(true);

class SLApp extends StatelessWidget {
  const SLApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: store.themeMode,
      builder: (context, t, _) {
        final mode = t == 'dark'
            ? ThemeMode.dark
            : t == 'light'
                ? ThemeMode.light
                : ThemeMode.system;
        return MaterialApp(
          title: 'Kalis Track',
          debugShowCheckedModeBanner: false,
          themeMode: mode,
          theme: _lightTheme,
          darkTheme: _darkTheme,
          home: const RootNav(),
        );
      },
    );
  }
}

int _tabIndex = 2; // Programme, au centre : l'essence de l'app

class RootNav extends StatefulWidget {
  const RootNav({super.key});
  @override
  State<RootNav> createState() => _RootNavState();
}

class _RootNavState extends State<RootNav> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    store.themeMode.addListener(_onTheme);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    store.themeMode.removeListener(_onTheme);
    super.dispose();
  }

  void _onTheme() => setState(() {});

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) store.flush();
  }

  @override
  Widget build(BuildContext context) {
    // Synchronise la palette runtime avec le thème effectif (système compris).
    final t = store.settings.theme;
    final platformDark = MediaQuery.platformBrightnessOf(context) == Brightness.dark;
    SL.dark = t == 'dark' || (t == 'system' && platformDark);
    final pages = const [
      PersoScreen(),
      RecordsScreen(),
      HomeScreen(),
      PilotageScreen(),
      SettingsScreen(),
    ];
    return KeyedSubtree(
      key: ValueKey('root-${SL.dark}'),
      child: Scaffold(
        body: pages[_tabIndex],
        bottomNavigationBar: HeroNavBar(
          index: _tabIndex,
          onTap: (i) => setState(() => _tabIndex = i),
        ),
      ),
    );
  }
}

/// Barre de navigation : 4 destinations sobres + le Programme en héros central.
class HeroNavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const HeroNavBar({super.key, required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: SL.surface, border: Border(top: BorderSide(color: SL.line))),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 76,
          child: Row(
            children: [
              _item(0, Icons.playlist_add_check_rounded, 'Perso'),
              _item(1, Icons.emoji_events_outlined, 'Suivi'),
              _hero(),
              _item(3, Icons.tune_rounded, 'Pilotage'),
              _item(4, Icons.settings_outlined, 'Réglages'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _item(int i, IconData ic, String label) {
    final sel = index == i;
    final c = sel ? SL.steel : SL.dim;
    return Expanded(
      child: InkWell(
        onTap: () => onTap(i),
        borderRadius: BorderRadius.circular(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 56,
              height: 30,
              decoration: BoxDecoration(
                color: sel ? SL.steel.withOpacity(0.20) : Colors.transparent,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(ic, size: 23, color: c),
            ),
            const SizedBox(height: 4),
            Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: c)),
          ],
        ),
      ),
    );
  }

  Widget _hero() {
    final sel = index == 2;
    return Expanded(
      child: InkWell(
        onTap: () => onTap(2),
        borderRadius: BorderRadius.circular(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: SL.steel,
                shape: BoxShape.circle,
                border: Border.all(color: sel ? SL.text : Colors.transparent, width: 2),
                boxShadow: [BoxShadow(color: SL.steel.withOpacity(sel ? 0.55 : 0.30), blurRadius: sel ? 18 : 10, spreadRadius: sel ? 1 : 0)],
              ),
              child: Icon(Icons.fitness_center_rounded, size: 27, color: SL.onAccent),
            ),
            const SizedBox(height: 4),
            Text('PROGRAMME', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w900, letterSpacing: 0.6, color: sel ? SL.steel : SL.text)),
          ],
        ),
      ),
    );
  }
}
