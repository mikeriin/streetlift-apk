import 'dart:async';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'device.dart';
import 'app_theme.dart';
import 'ui.dart';
export 'app_theme.dart' show SL, buildTheme, logDeco;
import 'session_screen.dart';

import 'home_screen.dart';
import 'notifications.dart';
import 'arsenal_screen.dart';
import 'pilotage_screen.dart';
import 'records_screen.dart';
import 'settings_screen.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Object? initError;
  StackTrace? initStack;
  try {
    await store.init();
  } catch (e, st) {
    initError = e;
    initStack = st;
  }
  try {
    await enableHighRefreshRate(); // 90/120 Hz si l'écran le permet
  } catch (_) {}
  if (initError != null) {
    runApp(_InitErrorApp(error: '$initError', stack: '$initStack'));
    return;
  }
  runApp(const SLApp());
  Notif.onOpen = (week, day) {
    final nav = appNavigator.currentState;
    final plan = store.program.week(week);
    final session = plan.day(day);
    if (nav != null && session != null) {
      nav.push(
        MaterialPageRoute(
          builder: (_) => SessionScreen(week: plan, day: session),
        ),
      );
    }
  };
  WidgetsBinding.instance.addPostFrameCallback((_) {
    Notif.bind();
  });
}

/// Écran de secours si l'initialisation échoue : l'erreur est lisible et copiable
/// au lieu d'un lancement bloqué sur l'écran de démarrage.
class _InitErrorApp extends StatelessWidget {
  final String error;
  final String stack;
  const _InitErrorApp({required this.error, required this.stack});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: buildTheme(true),
    home: KScreen(
      appBar: AppBar(title: const Text('Problème au démarrage')),
      body: KList(
        children: [
          const KCard(
            child: Text(
              'Kalis Track n’a pas pu s’ouvrir. Tu peux conserver une copie de tes données et copier le rapport pour identifier le problème.',
            ),
          ),
          KCard(child: Text(error, style: TextStyle(color: SL.danger))),
          KCard(
            padding: EdgeInsets.zero,
            child: ExpansionTile(
              title: const Text('Détails du problème'),
              childrenPadding: const EdgeInsets.all(16),
              children: [
                SelectableText(
                  stack,
                  style: TextStyle(
                    color: SL.dim,
                    fontSize: 12,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
          OutlinedButton.icon(
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              final raw = jsonEncode({
                for (final key in prefs.getKeys()) key: prefs.get(key),
              });
              await Clipboard.setData(ClipboardData(text: raw));
            },
            icon: const Icon(Icons.save_alt),
            label: const Text('Copier les données pour récupération'),
          ),
          FilledButton.icon(
            onPressed:
                () => Clipboard.setData(ClipboardData(text: '$error\n$stack')),
            icon: const Icon(Icons.copy),
            label: const Text('Copier le rapport'),
          ),
        ],
      ),
    ),
  );
}

// Thèmes construits une seule fois (ThemeData est coûteux à recréer).
final ThemeData _lightTheme = buildTheme(false);
final ThemeData _darkTheme = buildTheme(true);

final appNavigator = GlobalKey<NavigatorState>();

class SLApp extends StatelessWidget {
  const SLApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: store.themeMode,
      builder: (context, t, _) {
        final mode =
            t == 'dark'
                ? ThemeMode.dark
                : t == 'light'
                ? ThemeMode.light
                : ThemeMode.system;
        return MaterialApp(
          navigatorKey: appNavigator,
          title: 'Kalis Track',
          locale: const Locale('fr'),
          supportedLocales: const [Locale('fr')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          debugShowCheckedModeBanner: false,
          themeMode: mode,
          theme: _lightTheme,
          darkTheme: _darkTheme,
          builder: (context, child) {
            SL.dark = Theme.of(context).brightness == Brightness.dark;
            return child ?? const SizedBox.shrink();
          },
          home: const RootNav(),
        );
      },
    );
  }
}

class RootNav extends StatefulWidget {
  const RootNav({super.key});
  @override
  State<RootNav> createState() => _RootNavState();
}

class _RootNavState extends State<RootNav> with WidgetsBindingObserver {
  int _tabIndex = 2;
  final Set<int> _visited = {2};
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    store.themeMode.addListener(_onTheme);
    store.persistenceError.addListener(_onPersistenceError);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    store.themeMode.removeListener(_onTheme);
    store.persistenceError.removeListener(_onPersistenceError);
    super.dispose();
  }

  void _onTheme() => setState(() {});
  void _onPersistenceError() {
    final message = store.persistenceError.value;
    if (message != null && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      store.flush();
    }
    if (state == AppLifecycleState.resumed) {
      store.notifyListeners();
      Notif.reschedule();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Synchronise la palette runtime avec le thème effectif (système compris).
    final t = store.settings.theme;
    final platformDark =
        MediaQuery.platformBrightnessOf(context) == Brightness.dark;
    SL.dark = t == 'dark' || (t == 'system' && platformDark);
    // Reconstruit aussi les composants historiques qui lisent la palette SL.
    final pages = [
      // ignore: prefer_const_constructors
      ArsenalScreen(),
      // ignore: prefer_const_constructors
      RecordsScreen(),
      // ignore: prefer_const_constructors
      HomeScreen(),
      // ignore: prefer_const_constructors
      PilotageScreen(),
      // ignore: prefer_const_constructors
      SettingsScreen(),
    ];
    return Scaffold(
      body: IndexedStack(
        index: _tabIndex,
        children: [
          for (var i = 0; i < pages.length; i++)
            _visited.contains(i)
                ? TickerMode(
                  enabled: i == _tabIndex,
                  child: KeyedSubtree(key: ValueKey('tab-$i'), child: pages[i]),
                )
                : const SizedBox.shrink(),
        ],
      ),
      bottomNavigationBar: HeroNavBar(
        index: _tabIndex,
        onTap: (i) {
          FocusManager.instance.primaryFocus?.unfocus();
          setState(() {
            _tabIndex = i;
            _visited.add(i);
          });
        },
      ),
    );
  }
}

/// Les destinations partagent les mêmes tailles et états de sélection.
class HeroNavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const HeroNavBar({super.key, required this.index, required this.onTap});
  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: BoxDecoration(
      border: Border(
        top: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
      ),
    ),
    child: NavigationBar(
      selectedIndex: index,
      onDestinationSelected: onTap,
      height: 76,
      elevation: 0,
      destinations: const [
        NavigationDestination(
          icon: Icon(Icons.grid_view_outlined),
          selectedIcon: Icon(Icons.grid_view_rounded),
          label: 'Arsenal',
        ),
        NavigationDestination(
          icon: Icon(Icons.insights_outlined),
          selectedIcon: Icon(Icons.insights),
          label: 'Suivi',
        ),
        NavigationDestination(
          icon: Icon(Icons.calendar_today_outlined),
          selectedIcon: Icon(Icons.calendar_month),
          label: 'Programme',
        ),
        NavigationDestination(
          icon: Icon(Icons.tune_outlined),
          selectedIcon: Icon(Icons.tune),
          label: 'Pilotage',
        ),
        NavigationDestination(
          icon: Icon(Icons.settings_outlined),
          selectedIcon: Icon(Icons.settings),
          label: 'Réglages',
        ),
      ],
    ),
  );
}
