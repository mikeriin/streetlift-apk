import 'package:flutter/material.dart';

import 'builder_screen.dart';
import 'home_screen.dart';
import 'pilotage_screen.dart';
import 'records_screen.dart';
import 'settings_screen.dart';
import 'store.dart';
import 'wod_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.init();
  runApp(const SLApp());
}

// ============================================================================
// PALETTE — deux thèmes, mêmes rôles. Sombre : « salle de nuit » (validé).
// Clair : dérivé, accents assombris pour passer WCAG AA (≥ 4,5:1 texte).
// ============================================================================
class SL {
  static bool dark = true;

  static Color get bg => dark ? const Color(0xFF0E1216) : const Color(0xFFF7F9FA);
  static Color get surface => dark ? const Color(0xFF171D23) : const Color(0xFFFFFFFF);
  static Color get card => dark ? const Color(0xFF1B222A) : const Color(0xFFFFFFFF);
  static Color get text => dark ? const Color(0xFFE8EDF1) : const Color(0xFF14232B);
  static Color get dim => dark ? const Color(0xFF8FA0AC) : const Color(0xFF52616B);
  static Color get steel => dark ? const Color(0xFF4FA3C7) : const Color(0xFF1C6C8C);
  /// Accent « saisie » (texte, icônes, chips) — héritage des cellules jaunes.
  static Color get inputYellow => dark ? const Color(0xFFE9C46A) : const Color(0xFF8F6D1F);
  static Color get mainGreen => dark ? const Color(0xFF57B368) : const Color(0xFF3A7D44);
  static Color get prevViolet => dark ? const Color(0xFFB39DDB) : const Color(0xFF5E4B9E);
  static Color get danger => dark ? const Color(0xFFE0645C) : const Color(0xFFC0392B);

  // Rôles secondaires (remplacent les SL.line/24 en dur).
  static Color get line => dark ? const Color(0x1FFFFFFF) : const Color(0xFFDCE3E8);
  static Color get faint => dark ? const Color(0x14FFFFFF) : const Color(0xFFEDF1F4);
  static Color get dot => dark ? const Color(0x3DFFFFFF) : const Color(0xFFC5CED5);
  static Color get onAccent => dark ? const Color(0xFF0B0F12) : const Color(0xFFFFFFFF);
  /// Champs de saisie de séance (jaune) : fond et bordure.
  static Color get fieldFill => dark ? const Color(0x1AE9C46A) : const Color(0xFFFDF3D0);
  static Color get fieldBorder => dark ? const Color(0x59E9C46A) : const Color(0xFFD8BE7A);
  /// Champs de formulaire (neutres).
  static Color get formFill => dark ? const Color(0x0AFFFFFF) : const Color(0xFFF0F3F5);
  static Color get formBorder => dark ? const Color(0x24FFFFFF) : const Color(0xFFC9D2D8);
}

/// Décoration des champs de SAISIE de séance (jaune) — usage explicite.
InputDecoration logDeco({String? hint, String? suffix}) => InputDecoration(
      hintText: hint,
      suffixText: suffix,
      isDense: true,
      filled: true,
      fillColor: SL.fieldFill,
      hintStyle: TextStyle(color: SL.dim.withOpacity(0.7), fontWeight: FontWeight.w600),
      contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: SL.fieldBorder)),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: SL.fieldBorder)),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: SL.inputYellow, width: 1.6)),
    );

/// Fabrique de thème : un seul endroit, deux luminosités.
ThemeData buildTheme(bool dark) {
  SL.dark = dark;
  final scheme = (dark ? const ColorScheme.dark() : const ColorScheme.light()).copyWith(
    primary: SL.steel,
    onPrimary: SL.onAccent,
    secondary: SL.inputYellow,
    surface: SL.surface,
    onSurface: SL.text,
    onSurfaceVariant: SL.dim,
    outline: SL.formBorder,
    outlineVariant: SL.line,
    error: SL.danger,
    surfaceContainerHighest: SL.faint,
    inverseSurface: dark ? const Color(0xFFE8EDF1) : const Color(0xFF14232B),
    onInverseSurface: dark ? const Color(0xFF0E1216) : const Color(0xFFF7F9FA),
    inversePrimary: dark ? const Color(0xFF1C6C8C) : const Color(0xFF7CC4E0),
  );
  OutlineInputBorder border(Color c, [double w = 1]) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: c, width: w),
      );
  return ThemeData(
    useMaterial3: true,
    brightness: dark ? Brightness.dark : Brightness.light,
    colorScheme: scheme,
    scaffoldBackgroundColor: SL.bg,
    splashFactory: InkSparkle.splashFactory,
    cardTheme: CardThemeData(
      color: SL.card,
      elevation: 0,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      shape: RoundedRectangleBorder(
        borderRadius: const BorderRadius.all(Radius.circular(14)),
        side: dark ? BorderSide.none : BorderSide(color: SL.line),
      ),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: SL.bg,
      foregroundColor: SL.text,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleTextStyle: TextStyle(
        color: SL.text,
        fontSize: 17,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.3,
      ),
    ),
    // Formulaires (éditeurs, recherche, réglages) : neutres. La saisie de
    // séance utilise logDeco() explicitement — jamais le mélange des deux.
    inputDecorationTheme: InputDecorationTheme(
      isDense: true,
      filled: true,
      fillColor: SL.formFill,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      border: border(SL.formBorder),
      enabledBorder: border(SL.formBorder),
      focusedBorder: border(SL.steel, 1.6),
      labelStyle: TextStyle(color: SL.dim, fontSize: 13),
      floatingLabelStyle: TextStyle(color: SL.steel, fontSize: 13),
      hintStyle: TextStyle(color: SL.dim.withOpacity(0.7)),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((s) =>
          s.contains(WidgetState.selected) ? SL.onAccent : SL.dim),
      trackColor: WidgetStateProperty.resolveWith((s) =>
          s.contains(WidgetState.selected) ? SL.steel : SL.faint),
      trackOutlineColor: WidgetStateProperty.resolveWith((s) =>
          s.contains(WidgetState.selected) ? Colors.transparent : SL.formBorder),
    ),
    segmentedButtonTheme: SegmentedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: WidgetStateProperty.resolveWith((s) =>
            s.contains(WidgetState.selected) ? SL.steel.withOpacity(dark ? 0.22 : 0.14) : SL.card),
        foregroundColor: WidgetStateProperty.resolveWith((s) =>
            s.contains(WidgetState.selected) ? SL.steel : SL.dim),
        side: WidgetStateProperty.all(BorderSide(color: SL.formBorder)),
        textStyle: WidgetStateProperty.all(
            const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: SL.surface,
      indicatorColor: SL.steel.withOpacity(0.22),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(
          color: s.contains(WidgetState.selected) ? SL.steel : SL.dim)),
      labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
          fontSize: 11.5,
          fontWeight: FontWeight.w700,
          color: s.contains(WidgetState.selected) ? SL.steel : SL.dim)),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: SL.surface,
      showDragHandle: true,
      dragHandleColor: SL.dot,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: SL.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      titleTextStyle: TextStyle(color: SL.text, fontSize: 17, fontWeight: FontWeight.w800),
      contentTextStyle: TextStyle(color: SL.text, fontSize: 14, height: 1.4),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: scheme.inverseSurface,
      contentTextStyle: TextStyle(color: scheme.onInverseSurface, fontWeight: FontWeight.w600),
      actionTextColor: scheme.inversePrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: SL.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      textStyle: TextStyle(color: SL.text, fontSize: 14),
    ),
    dividerColor: SL.line,
    iconTheme: IconThemeData(color: SL.text),
    textTheme: TextTheme(
      bodyLarge: TextStyle(color: SL.text, fontSize: 16, height: 1.35),
      bodyMedium: TextStyle(color: SL.text, fontSize: 14, height: 1.35),
      bodySmall: TextStyle(color: SL.dim, fontSize: 12.5, height: 1.3),
      titleMedium: TextStyle(color: SL.text, fontSize: 15, fontWeight: FontWeight.w700),
      labelLarge: TextStyle(color: SL.text, fontSize: 14, fontWeight: FontWeight.w700),
    ),
  );
}

class SLApp extends StatelessWidget {
  const SLApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final t = store.settings.theme;
        final mode = t == 'dark'
            ? ThemeMode.dark
            : t == 'light'
                ? ThemeMode.light
                : ThemeMode.system;
        return MaterialApp(
          title: 'Kalis Track',
          debugShowCheckedModeBanner: false,
          themeMode: mode,
          theme: buildTheme(false),
          darkTheme: buildTheme(true),
          home: const RootNav(),
        );
      },
    );
  }
}

int _tabIndex = 0;

class RootNav extends StatefulWidget {
  const RootNav({super.key});
  @override
  State<RootNav> createState() => _RootNavState();
}

class _RootNavState extends State<RootNav> {
  @override
  Widget build(BuildContext context) {
    // Synchronise la palette runtime avec le thème effectif (système compris).
    final t = store.settings.theme;
    final platformDark = MediaQuery.platformBrightnessOf(context) == Brightness.dark;
    SL.dark = t == 'dark' || (t == 'system' && platformDark);
    final pages = const [
      HomeScreen(),
      PersoTabs(),
      PilotageScreen(),
      RecordsScreen(),
      SettingsScreen(),
    ];
    return KeyedSubtree(
      key: ValueKey('root-${SL.dark}'),
      child: Scaffold(
        body: pages[_tabIndex],
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tabIndex,
          onDestinationSelected: (i) => setState(() => _tabIndex = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.fitness_center), label: 'Programme'),
            NavigationDestination(icon: Icon(Icons.playlist_add_check), label: 'Perso'),
            NavigationDestination(icon: Icon(Icons.tune), label: 'Pilotage'),
            NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'Suivi'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Réglages'),
          ],
        ),
      ),
    );
  }
}

/// Onglet « Perso » : UN seul Scaffold, sélecteur segmenté (plus de TabBar
/// imbriquée ni d'icônes fantômes), FAB contextuel.
class PersoTabs extends StatefulWidget {
  const PersoTabs({super.key});
  @override
  State<PersoTabs> createState() => _PersoTabsState();
}

class _PersoTabsState extends State<PersoTabs> {
  int seg = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PERSO'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(52),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
            child: SizedBox(
              width: double.infinity,
              child: SegmentedButton<int>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: 0, label: Text('SÉANCES'), icon: Icon(Icons.list_alt, size: 18)),
                  ButtonSegment(value: 1, label: Text('WOD'), icon: Icon(Icons.timer_outlined, size: 18)),
                ],
                selected: {seg},
                onSelectionChanged: (s) => setState(() => seg = s.first),
              ),
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: SL.steel,
        foregroundColor: SL.onAccent,
        icon: const Icon(Icons.add),
        label: Text(seg == 0 ? 'Nouvelle séance' : 'Nouveau WOD',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        onPressed: () => seg == 0 ? newCustomSession(context) : newWod(context),
      ),
      body: IndexedStack(
        index: seg,
        children: const [CustomSessionsBody(), WodListBody()],
      ),
    );
  }
}
