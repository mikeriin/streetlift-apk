import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'alerts.dart';
import 'main.dart';
import 'models.dart';
import 'store.dart';

// ============================= TIMER =====================================
// Basé sur l'horloge murale : reste juste même si l'app passe en arrière-plan.

class TimerCtl extends ChangeNotifier {
  Timer? _t;
  bool running = false;
  bool up = false; // chronomètre (max temps)
  String label = 'REPOS';
  int total = 0;
  int remaining = 0;
  int elapsed = 0;
  List<(String, int)> _phases = [];
  int _pi = 0;
  DateTime? _deadline;
  DateTime? _startAt;

  bool get visible => running || label == 'TERMINÉ';

  void startRest(int seconds) {
    _phases = [];
    _beginPhase('REPOS', seconds);
  }

  /// Compte à rebours simple avec libellé (tenue, durée, AMRAP, intra…).
  void single(String lbl, int seconds) => _startPhases([(lbl, seconds)]);

  void emom(int rounds, int interval) => _startPhases([
        for (var i = 1; i <= rounds; i++) ('MINUTE $i/$rounds', interval)
      ]);

  void startInterval(int rounds, int work, int rest) => _startPhases([
        for (var i = 1; i <= rounds; i++) ...[
          ('EFFORT $i/$rounds', work),
          if (i < rounds) ('REPOS $i/$rounds', rest),
        ]
      ]);

  /// Chronomètre montant (dead-hang max, tenue max…).
  void stopwatch(String lbl) {
    _t?.cancel();
    _phases = [];
    up = true;
    label = lbl;
    total = 0;
    remaining = 0;
    elapsed = 0;
    _startAt = DateTime.now();
    running = true;
    notifyListeners();
    _t = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  void _startPhases(List<(String, int)> phases) {
    final prep = store.settings.prepSec;
    _phases = [if (prep > 0) ('PRÊT', prep), ...phases];
    _pi = 0;
    _beginPhase(_phases[0].$1, _phases[0].$2);
  }

  void _beginPhase(String lbl, int seconds) {
    _t?.cancel();
    up = false;
    label = lbl;
    total = seconds;
    remaining = seconds;
    _deadline = DateTime.now().add(Duration(seconds: seconds));
    running = true;
    notifyListeners();
    _t = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  void _tick() {
    if (!running) return;
    if (up) {
      elapsed = DateTime.now().difference(_startAt!).inSeconds;
      notifyListeners();
      return;
    }
    remaining = (_deadline!.difference(DateTime.now()).inMilliseconds / 1000).ceil();
    var alerted = false;
    while (remaining <= 0) {
      if (!alerted) {
        alertBeep();
        alerted = true;
      }
      if (_phases.isNotEmpty && _pi < _phases.length - 1) {
        _pi++;
        final p = _phases[_pi];
        label = p.$1;
        total = p.$2;
        _deadline = _deadline!.add(Duration(seconds: p.$2));
        remaining = (_deadline!.difference(DateTime.now()).inMilliseconds / 1000).ceil();
      } else {
        _t?.cancel();
        running = false;
        remaining = 0;
        label = 'TERMINÉ';
        break;
      }
    }
    notifyListeners();
  }

  void add(int s) {
    if (!running || up) return;
    final now = DateTime.now();
    var d = _deadline!.add(Duration(seconds: s));
    if (d.isBefore(now.add(const Duration(seconds: 1)))) {
      d = now.add(const Duration(seconds: 1));
    }
    _deadline = d;
    remaining = (d.difference(now).inMilliseconds / 1000).ceil();
    total = math.max(total, remaining);
    notifyListeners();
  }

  /// Chrono montant : 1er appui = figer (lecture du temps), 2e = fermer.
  void stop() {
    if (up && running) {
      _t?.cancel();
      running = false;
      label = 'TERMINÉ';
      notifyListeners();
      return;
    }
    _t?.cancel();
    running = false;
    up = false;
    remaining = 0;
    elapsed = 0;
    label = 'REPOS';
    notifyListeners();
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }
}

String fmt(int s) {
  final m = s ~/ 60;
  final r = s % 60;
  return '$m:${r.toString().padLeft(2, '0')}';
}

// ============================ SÉANCE =====================================

class SessionScreen extends StatefulWidget {
  final WeekPlan week;
  final DayPlan day;
  const SessionScreen({super.key, required this.week, required this.day});

  @override
  State<SessionScreen> createState() => _SessionScreenState();
}

class _SessionScreenState extends State<SessionScreen> {
  final ctl = TimerCtl();
  final pageCtl = PageController();
  late final List<List<Exercise>> groups;
  int page = 0;

  int get nPages => groups.length;

  @override
  void initState() {
    super.initState();
    groups = store.groups(widget.day);
    if (store.settings.wakelock) WakelockPlus.enable();
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    store.saveLogs();
    ctl.dispose();
    pageCtl.dispose();
    super.dispose();
  }

  void _confirmClear() {
    final w = widget.week;
    final d = widget.day;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: SL.surface,
        title: const Text('Supprimer l\u2019historique ?'),
        content: Text(
            'S${w.n} · J${d.j} — les séries saisies, les notes et le statut « fait » seront effacés. Action irréversible.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: SL.danger, foregroundColor: Colors.white),
            onPressed: () {
              store.clearSession(w.n, d.j);
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text('Historique de S${w.n} · J${d.j} supprimé.')));
              Navigator.pop(context);
            },
            child: const Text('Supprimer'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final w = widget.week;
    final d = widget.day;
    final restDay = d.exercises.isEmpty;
    return Scaffold(
      appBar: AppBar(
        title: Text(() {
          final head = w.n == 0 ? w.block : 'S${w.n} · J${d.j}';
          if (restDay) return '$head — REPOS';
          return '$head — ${page >= nPages ? 'FIN' : '${page + 1}/$nPages'}';
        }()),
        actions: [
          IconButton(
            tooltip: 'Supprimer l\u2019historique de la séance',
            icon: const Icon(Icons.delete_outline),
            onPressed: _confirmClear,
          ),
          IconButton(
            tooltip: 'Consignes de séance',
            icon: const Icon(Icons.info_outline),
            onPressed: () => showModalBottomSheet(
              context: context,
              backgroundColor: SL.surface,
              builder: (_) => Padding(
                padding: const EdgeInsets.all(18),
                child: Text(d.conduite.isEmpty ? d.title : d.conduite, style: const TextStyle(height: 1.45)),
              ),
            ),
          ),
        ],
      ),
      body: restDay
          ? _RestDay(week: w, day: d)
          : Column(
              children: [
                _ProgressDots(count: nPages + 1, index: page, color: w.color),
                Expanded(
                  child: PageView.builder(
                    controller: pageCtl,
                    onPageChanged: (i) {
                      store.saveLogs();
                      setState(() => page = i);
                    },
                    itemCount: nPages + 1,
                    itemBuilder: (_, i) => i < nPages
                        ? _ExercisePage(
                            key: ValueKey(groups[i].first.id),
                            week: w,
                            day: d,
                            exs: groups[i],
                            timer: ctl,
                          )
                        : _FinishPage(week: w, day: d),
                  ),
                ),
                _TimerBar(ctl: ctl),
              ],
            ),
    );
  }
}

class _ProgressDots extends StatelessWidget {
  final int count;
  final int index;
  final Color color;
  const _ProgressDots({required this.count, required this.index, required this.color});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          for (var i = 0; i < count; i++)
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 2.5),
              width: i == index ? 18 : 7,
              height: 7,
              decoration: BoxDecoration(
                color: i == index ? color : Colors.white24,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
        ],
      ),
    );
  }
}

// ------------------------- PAGE EXERCICE(S) ------------------------------
// Une page = un exercice, ou une paire enchaînée (ex. dips → pompes).

class _ExercisePage extends StatefulWidget {
  final WeekPlan week;
  final DayPlan day;
  final List<Exercise> exs;
  final TimerCtl timer;
  const _ExercisePage({super.key, required this.week, required this.day, required this.exs, required this.timer});

  @override
  State<_ExercisePage> createState() => _ExercisePageState();
}

class _ExercisePageState extends State<_ExercisePage> {
  late final List<ExerciseLog> logs;
  late final List<LogSpec> specs;

  @override
  void initState() {
    super.initState();
    logs = [for (final e in widget.exs) store.exLog(widget.week.n, widget.day.j, e)];
    specs = [for (final e in widget.exs) store.logSpec(e)];
    for (var k = 0; k < widget.exs.length; k++) {
      _prefill(widget.exs[k], specs[k], logs[k]);
    }
  }

  void _prefill(Exercise ex, LogSpec sp, ExerciseLog log) {
    if (!store.settings.prefill) return;
    if (sp.kind == 'hold' && sp.seconds != null) {
      for (final s in log.sets) {
        if (s.reps.isEmpty && !s.done) s.reps = '${sp.seconds}';
      }
    } else if (sp.kind == 'duration' && sp.seconds != null) {
      for (final s in log.sets) {
        if (s.reps.isEmpty && !s.done) s.reps = '${sp.seconds! ~/ 60}';
      }
    } else if (sp.kind == 'repsMax') {
      for (final s in log.sets) {
        if (s.rir.isEmpty && !s.done) s.rir = '0';
      }
    }
    if (sp.kind == 'reps' || sp.kind == 'emom') {
      final planned = store.plannedReps(ex, sp, log.sets.length);
      for (var i = 0; i < log.sets.length; i++) {
        final s = log.sets[i];
        if (s.reps.isEmpty && !s.done && planned[i] != null) {
          s.reps = '${planned[i]}';
        }
      }
    }
    if (sp.kind == 'duration' || sp.kind == 'interval') return;
    final kg = store.loadFor(ex);
    if (kg != null && kg > 0) {
      final t = kg == kg.roundToDouble() ? kg.toInt().toString() : kg.toStringAsFixed(1);
      for (final s in log.sets) {
        if (s.kg.isEmpty && !s.done) s.kg = t;
      }
    }
  }

  /// Validation d'une série : repos contextuel (myo, enchaînement, « après »…).
  void _checkSet(int k, int i) {
    final ex = widget.exs[k];
    final sp = specs[k];
    final log = logs[k];
    final s = log.sets[i];
    setState(() => s.done = !s.done);
    store.saveLogs();
    if (!s.done || !store.settings.autoTimer) return;
    final chainedFirst = widget.exs.length == 2 && k == 0;
    if (chainedFirst) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(
            duration: const Duration(seconds: 2),
            content: Text('→ Enchaîne : ${widget.exs[1].name}')));
      return;
    }
    final rest = store.restAfterSet(ex, sp, i, log.sets.length);
    if (rest != null && rest > 0) widget.timer.startRest(rest);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
      children: [
        for (var k = 0; k < widget.exs.length; k++) ...[
          if (k > 0) const SizedBox(height: 14),
          _block(k),
        ],
        const SizedBox(height: 8),
        TextFormField(
          key: ValueKey('${widget.exs.first.id}-note'),
          initialValue: logs.first.note,
          maxLines: 2,
          decoration: const InputDecoration(labelText: 'Notes / douleur'),
          onChanged: (v) => logs.first.note = v,
        ),
      ],
    );
  }

  Widget _block(int k) {
    final ex = widget.exs[k];
    final sp = specs[k];
    final log = logs[k];
    final chained = widget.exs.length == 2;
    final accent = ex.main
        ? SL.mainGreen
        : ex.prevention
            ? SL.prevViolet
            : widget.week.color;
    final interval = ex.interval;
    final showKg = sp.kind != 'duration' && sp.kind != 'interval' && sp.kind != 'emom' && sp.kind != 'amrap';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // ----- Carte prescription -----
        Container(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
          decoration: BoxDecoration(
            color: SL.card,
            borderRadius: BorderRadius.circular(16),
            border: Border(left: BorderSide(color: accent, width: 4)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (chained)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(k == 0 ? 'ENCHAÎNÉ AVEC ↓ (pas de repos entre les deux)' : 'SUITE DE L\u2019ENCHAÎNEMENT ↑',
                      style: const TextStyle(color: SL.inputYellow, fontSize: 10.5, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
                ),
              Text(ex.name.toUpperCase(),
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: -0.2, color: ex.main ? SL.mainGreen : SL.text)),
              const SizedBox(height: 10),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  if (showKg)
                    Text(store.loadLabel(ex),
                        style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: accent, fontFeatures: const [FontFeature.tabularFigures()])),
                  if (showKg) const SizedBox(width: 12),
                  Expanded(
                    child: Text(store.setsLabel(ex),
                        style: TextStyle(fontSize: showKg ? 18 : 24, fontWeight: FontWeight.w800, color: showKg ? SL.text : accent)),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  _kindChip(sp, accent),
                  if (ex.intensity.isNotEmpty) _chip(ex.intensity, accent),
                  if (ex.tempo.isNotEmpty) _chip(ex.tempo, SL.dim),
                  if (ex.rest.isNotEmpty && ex.rest != '—') _chip('Repos ${ex.rest}', SL.dim),
                  if (sp.myo) _chip('Repos final ${fmt(store.settings.defaultRest)}', SL.dim),
                ],
              ),
              if (ex.cue.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(ex.cue, style: Theme.of(context).textTheme.bodySmall),
              ],
            ],
          ),
        ),
        const SizedBox(height: 10),
        // ----- Chronos de mode -----
        if (interval != null && ex.timer == null)
          _big(accent, Icons.timer, 'Lancer ${interval.rounds}× ${interval.work} s / ${interval.rest} s',
              () => widget.timer.startInterval(interval.rounds, interval.work, interval.rest)),
        if (ex.timer != null) _modeButton(ex, accent),
        if (ex.timer == null && sp.kind == 'emom')
          _big(accent, Icons.timer, 'Lancer EMOM ${sp.seconds! ~/ 60} min', () => widget.timer.emom(sp.seconds! ~/ 60, 60)),
        if (ex.timer == null && sp.kind == 'duration')
          _big(accent, Icons.timer, 'Lancer ${sp.seconds! ~/ 60} min', () => widget.timer.single('DURÉE', sp.seconds!)),
        if (sp.cluster && sp.intra != null)
          _big(SL.inputYellow, Icons.av_timer, 'Intra-cluster ${sp.intra} s', () => widget.timer.single('INTRA', sp.intra!)),
        // ----- Logger -----
        for (var i = 0; i < log.sets.length; i++)
          _SetRow(
            label: store.setLabel(sp, i),
            entry: log.sets[i],
            spec: sp,
            showKg: showKg,
            showV: ex.main && sp.kind == 'reps',
            onCheck: () => _checkSet(k, i),
            onTimer: sp.kind == 'hold'
                ? () => widget.timer.single('TENUE', int.tryParse(log.sets[i].reps) ?? sp.seconds ?? 30)
                : sp.kind == 'holdMax'
                    ? () => widget.timer.stopwatch('MAX')
                    : sp.kind == 'duration'
                        ? () => widget.timer.single('DURÉE', (int.tryParse(log.sets[i].reps) ?? (sp.seconds! ~/ 60)) * 60)
                        : null,
          ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            TextButton.icon(
              onPressed: () {
                if (log.removeLastSet()) {
                  store.saveLogs();
                  setState(() {});
                }
              },
              icon: const Icon(Icons.remove, size: 16),
              label: const Text('série', style: TextStyle(fontSize: 12)),
            ),
            TextButton.icon(
              onPressed: () {
                log.addSet();
                _prefill(ex, sp, log);
                store.saveLogs();
                setState(() {});
              },
              icon: const Icon(Icons.add, size: 16),
              label: const Text('série', style: TextStyle(fontSize: 12)),
            ),
          ],
        ),
      ],
    );
  }

  Widget _big(Color c, IconData ic, String label, VoidCallback action) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: c, foregroundColor: Colors.black),
          icon: Icon(ic),
          label: Text(label),
          onPressed: action,
        ),
      );

  Widget _modeButton(Exercise ex, Color accent) {
    final tm = ex.timer!;
    switch (tm['type'] as String) {
      case 'emom':
        final r = tm['rounds'] as int, itv = tm['interval'] as int;
        return _big(accent, Icons.timer, 'Lancer EMOM $r×$itv s', () => widget.timer.emom(r, itv));
      case 'amrap':
        final s = tm['sec'] as int;
        return _big(accent, Icons.timer, 'Lancer AMRAP ${s ~/ 60} min', () => widget.timer.single('AMRAP', s));
      case 'hiit':
        final r = tm['rounds'] as int, wk = tm['work'] as int, rs = tm['rest'] as int;
        return _big(accent, Icons.timer, 'Lancer $r× $wk s / $rs s', () => widget.timer.startInterval(r, wk, rs));
      case 'hold':
        final s = tm['sec'] as int;
        return _big(accent, Icons.timer, 'Chrono $s s', () => widget.timer.single('TENUE', s));
    }
    return const SizedBox.shrink();
  }

  Widget _kindChip(LogSpec sp, Color c) {
    const labels = {
      'reps': 'Reps',
      'repsMax': 'MAX reps',
      'hold': 'Tenue chronométrée',
      'holdMax': 'MAX temps',
      'duration': 'Durée',
      'interval': 'Intervalles',
      'emom': 'EMOM',
      'amrap': 'AMRAP',
    };
    var t = labels[sp.kind] ?? sp.kind;
    if (sp.myo) t = 'Myo-reps · intra ${sp.intra} s';
    if (sp.cluster) t = 'Clusters · intra ${sp.intra} s';
    return _chip(t, SL.inputYellow);
  }

  Widget _chip(String t, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
        decoration: BoxDecoration(color: c.withOpacity(0.14), borderRadius: BorderRadius.circular(8)),
        child: Text(t, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: c)),
      );
}

// Ligne de série adaptée à la nature de la saisie. Champs flexibles : pas de débordement.
class _SetRow extends StatelessWidget {
  final String label;
  final SetEntry entry;
  final LogSpec spec;
  final bool showKg;
  final bool showV;
  final VoidCallback onCheck;
  final VoidCallback? onTimer;
  const _SetRow(
      {required this.label,
      required this.entry,
      required this.spec,
      required this.showKg,
      required this.showV,
      required this.onCheck,
      this.onTimer});

  Widget _f(String lbl, String init, void Function(String) on, {int flex = 3}) {
    return Flexible(
      flex: flex,
      child: TextFormField(
        initialValue: init,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        decoration: InputDecoration(labelText: lbl),
        onChanged: on,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final k = spec.kind;
    final second = k == 'hold' || k == 'holdMax';
    final secondLabel = k == 'duration'
        ? 'min'
        : second
            ? 's'
            : k == 'emom' || k == 'amrap' || k == 'interval'
                ? 'reps'
                : k == 'repsMax'
                    ? 'reps MAX'
                    : 'reps';
    final showRir = k == 'reps';
    const gap = SizedBox(width: 5);
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(
        children: [
          SizedBox(
            width: 30,
            child: Text(label, textAlign: TextAlign.center, style: const TextStyle(color: SL.dim, fontWeight: FontWeight.w800, fontSize: 12)),
          ),
          gap,
          if (showKg) ...[_f('kg', entry.kg, (v) => entry.kg = v), gap],
          _f(secondLabel, entry.reps, (v) => entry.reps = v, flex: k == 'repsMax' ? 4 : 3),
          if (showRir) ...[gap, _f(store.effortLabel, entry.rir, (v) => entry.rir = v, flex: 2)],
          if (showV) ...[gap, _f('m/s', entry.v, (v) => entry.v = v)],
          gap,
          if (onTimer != null)
            IconButton(
              onPressed: onTimer,
              icon: Icon(k == 'holdMax' ? Icons.timer_outlined : Icons.hourglass_bottom, size: 22),
              color: SL.inputYellow,
              visualDensity: VisualDensity.compact,
              tooltip: k == 'holdMax' ? 'Chrono montant' : 'Compte à rebours',
            ),
          IconButton.filled(
            style: IconButton.styleFrom(
              backgroundColor: entry.done ? SL.mainGreen : Colors.white.withOpacity(0.08),
              foregroundColor: entry.done ? Colors.black : SL.dim,
            ),
            icon: const Icon(Icons.check, size: 20),
            onPressed: onCheck,
          ),
        ],
      ),
    );
  }
}

// --------------------------- BARRE TIMER ---------------------------------

class _TimerBar extends StatelessWidget {
  final TimerCtl ctl;
  const _TimerBar({required this.ctl});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: ctl,
      builder: (context, _) {
        if (!ctl.visible) return const SizedBox.shrink();
        final done = !ctl.running;
        final frac = ctl.up ? 1.0 : (ctl.total == 0 ? 0.0 : ctl.remaining / ctl.total);
        final effort = ctl.label.startsWith('EFFORT') || ctl.label == 'TENUE' || ctl.label == 'MAX';
        final color = done
            ? SL.mainGreen
            : effort
                ? SL.danger
                : SL.steel;
        return Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 8, 12),
          decoration: const BoxDecoration(color: SL.surface, border: Border(top: BorderSide(color: Colors.white12))),
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(value: done ? 1 : frac, minHeight: 5, backgroundColor: Colors.white10, color: color),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Text(ctl.label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1)),
                    const Spacer(),
                    Text(ctl.up ? fmt(ctl.elapsed) : (done ? '0:00' : fmt(ctl.remaining)),
                        style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: color, fontFeatures: const [FontFeature.tabularFigures()])),
                    const Spacer(),
                    if (!ctl.up) ...[
                      TextButton(onPressed: done ? null : () => ctl.add(-15), child: const Text('\u221215')),
                      TextButton(onPressed: done ? null : () => ctl.add(15), child: const Text('+15')),
                    ],
                    IconButton(onPressed: ctl.stop, icon: Icon(done ? Icons.close : Icons.stop_circle, size: 24)),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ------------------------- FIN & JOUR DE REPOS ---------------------------

class _FinishPage extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  const _FinishPage({required this.week, required this.day});

  @override
  Widget build(BuildContext context) {
    final log = store.sessionLog(week.n, day.j);
    var doneSets = 0;
    var totalSets = 0;
    for (final ex in day.exercises) {
      final l = store.exLog(week.n, day.j, ex);
      totalSets += l.sets.length;
      doneSets += l.sets.where((s) => s.done).length;
    }
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(log.done ? Icons.emoji_events : Icons.flag, size: 64, color: week.color),
            const SizedBox(height: 12),
            Text(week.n == 0 ? week.block : 'S${week.n} · J${day.j}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text('$doneSets / $totalSets séries validées', style: const TextStyle(color: SL.dim)),
            const SizedBox(height: 24),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: log.done ? SL.card : SL.mainGreen,
                foregroundColor: log.done ? SL.dim : Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 14),
              ),
              icon: Icon(log.done ? Icons.undo : Icons.check_circle),
              label: Text(log.done ? 'Repasser en « à faire »' : 'Terminer la séance', style: const TextStyle(fontWeight: FontWeight.w800)),
              onPressed: () {
                final title = week.n == 0 ? week.block : 'S${week.n} · J${day.j}';
                store.markSessionDone(week.n, day.j, !log.done, title: title);
                if (!log.done) return;
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _RestDay extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  const _RestDay({required this.week, required this.day});

  @override
  Widget build(BuildContext context) {
    final done = store.isDone(week.n, day.j);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.bedtime, size: 60, color: SL.steel),
            const SizedBox(height: 14),
            const Text('REPOS COMPLET', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            Text(
              day.conduite.isEmpty
                  ? 'Marche, mobilité légère, sommeil maximal. GtG suspendu. Note ta HRV et ta FC de repos.'
                  : day.conduite,
              textAlign: TextAlign.center,
              style: const TextStyle(color: SL.dim, height: 1.5),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: done ? SL.card : SL.mainGreen, foregroundColor: done ? SL.dim : Colors.black),
              icon: Icon(done ? Icons.undo : Icons.check),
              label: Text(done ? 'Marqué fait' : 'Marquer comme fait'),
              onPressed: () => store.markSessionDone(week.n, day.j, !done, title: 'S${week.n} · J${day.j}'),
            ),
          ],
        ),
      ),
    );
  }
}
