import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'device.dart';

import 'timers.dart';
export 'timers.dart' show TimerCtl;
import 'app_theme.dart';
import 'ui.dart';
import 'models.dart';
import 'store.dart';

const _tab = [FontFeature.tabularFigures()];

// ============================= TIMER =====================================
// Basé sur l'horloge murale : reste juste même si l'app passe en arrière-plan.

String fmt(int s) => '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}';

/// Espace insécable avant les unités (« 3\u00A0min », « 90\u00A0s »).
String nbsp(String t) => t.replaceAllMapped(
  RegExp(r'(\d) (kg|s|min|reps|lb)\b'),
  (m) => '${m[1]}\u00A0${m[2]}',
);

// ============================ SÉANCE =====================================

class SessionScreen extends StatefulWidget {
  final WeekPlan week;
  final DayPlan day;
  const SessionScreen({super.key, required this.week, required this.day});

  @override
  State<SessionScreen> createState() => _SessionScreenState();
}

class _SessionScreenState extends State<SessionScreen> {
  final ctl = TimerCtl();
  final pageCtl = PageController();
  late final List<List<Exercise>> groups;
  int page = 0;

  int get nPages => groups.length;

  @override
  void initState() {
    super.initState();
    groups = store.groups(widget.day);
    if (store.settings.wakelock) keepAwake(true);
  }

  @override
  void dispose() {
    keepAwake(false);
    store.flush();
    ctl.dispose();
    pageCtl.dispose();
    super.dispose();
  }

  void _confirmClear() {
    final w = widget.week;
    final d = widget.day;
    final head = w.n == 0 ? w.block : 'S${w.n} · J${d.j}';
    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            title: const Text('Supprimer l\u2019historique ?'),
            content: Text(
              '$head — séries, notes et statut « fait » seront effacés. Action irréversible.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Annuler'),
              ),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: SL.danger,
                  foregroundColor: Colors.white,
                ),
                onPressed: () {
                  store.clearSession(w.n, d.j);
                  Navigator.pop(ctx);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Historique de $head supprimé.')),
                  );
                  Navigator.pop(context);
                },
                child: const Text('Supprimer'),
              ),
            ],
          ),
    );
  }

  void _go(int target) {
    FocusManager.instance.primaryFocus?.unfocus();
    store.saveLogs(affectsProgression: false);
    if (MediaQuery.of(context).disableAnimations) {
      pageCtl.jumpToPage(target);
    } else {
      pageCtl.animateToPage(
        target,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _chooseExercise() async {
    final selected = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder:
          (context) => DraggableScrollableSheet(
            expand: false,
            initialChildSize: .65,
            builder:
                (context, controller) => ListView(
                  controller: controller,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  children: [
                    const Padding(
                      padding: EdgeInsets.all(16),
                      child: Text(
                        'Dans cette séance',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    for (var i = 0; i < nPages; i++)
                      ListTile(
                        selected: i == page,
                        leading: CircleAvatar(child: Text('${i + 1}')),
                        title: Text(
                          groups[i]
                              .map((e) => store.splitName(e.name).$1)
                              .join(' + '),
                        ),
                        subtitle:
                            groups[i].length > 1
                                ? const Text('Exercices enchaînés')
                                : null,
                        onTap: () => Navigator.pop(context, i),
                      ),
                    ListTile(
                      leading: const Icon(Icons.flag_outlined),
                      title: const Text('Bilan de séance'),
                      selected: page == nPages,
                      onTap: () => Navigator.pop(context, nPages),
                    ),
                  ],
                ),
          ),
    );
    if (selected != null && mounted) _go(selected);
  }

  void _instructions() => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder:
        (context) => SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Consignes de séance',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 12),
              Text(widget.day.conduite),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Fermer'),
              ),
            ],
          ),
        ),
  );

  @override
  Widget build(BuildContext context) {
    final w = widget.week;
    final d = widget.day;
    final restDay = d.exercises.isEmpty;
    final head = w.n == 0 ? w.block : 'S${w.n} · J${d.j}';
    return KScreen(
      appBar: AppBar(
        title: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              restDay ? 'Récupération' : d.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              head,
              style: Theme.of(context).textTheme.bodySmall,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Options de séance',
            onSelected: (value) {
              if (value == 'clear') _confirmClear();
              if (value == 'instructions') _instructions();
            },
            itemBuilder:
                (_) => [
                  if (d.conduite.isNotEmpty)
                    const PopupMenuItem(
                      value: 'instructions',
                      child: Text('Consignes de séance'),
                    ),
                  const PopupMenuItem(
                    value: 'clear',
                    child: Text('Effacer l’historique'),
                  ),
                ],
          ),
        ],
      ),
      body:
          restDay
              ? _RestDay(week: w, day: d)
              : Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                page == nPages
                                    ? 'Bilan de séance'
                                    : '${groups[page].length > 1 ? 'Enchaînement' : 'Exercice'} ${page + 1} / $nPages',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                            ),
                            TextButton.icon(
                              onPressed: _chooseExercise,
                              icon: const Icon(Icons.list_alt, size: 18),
                              label: const Text('Exercices'),
                            ),
                          ],
                        ),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(
                            value: (page + 1) / (nPages + 1),
                            semanticsLabel:
                                'Étape ${page + 1} sur ${nPages + 1}',
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: PageView.builder(
                      controller: pageCtl,
                      onPageChanged: (i) {
                        store.saveLogs(affectsProgression: false);
                        setState(() => page = i);
                      },
                      itemCount: nPages + 1,
                      itemBuilder:
                          (_, i) =>
                              i < nPages
                                  ? _ExercisePage(
                                    key: ValueKey(groups[i].first.id),
                                    week: w,
                                    day: d,
                                    exs: groups[i],
                                    timer: ctl,
                                  )
                                  : _FinishPage(week: w, day: d),
                    ),
                  ),
                  _TimerBar(ctl: ctl),
                ],
              ),
      bottomNavigationBar:
          restDay || MediaQuery.of(context).viewInsets.bottom > 0
              ? null
              : KBottomActions(
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: page > 0 ? () => _go(page - 1) : null,
                        icon: const Icon(Icons.chevron_left),
                        label: const Text('Précédent'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: page < nPages ? () => _go(page + 1) : null,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Text(
                                page == nPages - 1 ? 'Bilan' : 'Suivant',
                              ),
                            ),
                            const SizedBox(width: 6),
                            const Icon(Icons.chevron_right),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
    );
  }
}

// ------------------------- PAGE EXERCICE(S) ------------------------------
// Une page = un exercice, ou une paire enchaînée (ex. dips → pompes).

class _ExercisePage extends StatefulWidget {
  final WeekPlan week;
  final DayPlan day;
  final List<Exercise> exs;
  final TimerCtl timer;
  const _ExercisePage({
    super.key,
    required this.week,
    required this.day,
    required this.exs,
    required this.timer,
  });

  @override
  State<_ExercisePage> createState() => _ExercisePageState();
}

class _ExercisePageState extends State<_ExercisePage> {
  late final List<ExerciseLog> logs;
  late final List<LogSpec> specs;
  int epoch = 0; // force la recréation des champs (reprise du précédent…)

  @override
  void initState() {
    super.initState();
    logs = [
      for (final e in widget.exs) store.exLog(widget.week.n, widget.day.j, e),
    ];
    specs = [for (final e in widget.exs) store.logSpec(e)];
    for (var k = 0; k < widget.exs.length; k++) {
      _prefill(widget.exs[k], specs[k], logs[k]);
    }
  }

  void _prefill(Exercise ex, LogSpec sp, ExerciseLog log) {
    if (!store.settings.prefill) return;
    if (sp.kind == 'hold' && sp.seconds != null) {
      for (final s in log.sets) {
        if (s.reps.isEmpty && !s.done) s.reps = '${sp.seconds}';
      }
    } else if (sp.kind == 'duration' && sp.seconds != null) {
      for (final s in log.sets) {
        if (s.reps.isEmpty && !s.done) s.reps = '${sp.seconds! ~/ 60}';
      }
    }
    if (sp.kind == 'reps' || sp.kind == 'emom') {
      final planned = store.plannedReps(ex, sp, log.sets.length);
      for (var i = 0; i < log.sets.length; i++) {
        final s = log.sets[i];
        if (s.reps.isEmpty && !s.done && planned[i] != null) {
          s.reps = '${planned[i]}';
        }
      }
    }
    if (sp.kind == 'duration' || sp.kind == 'interval') return;
    final kg = store.loadFor(ex);
    if (kg != null && kg > 0) {
      final t =
          kg == kg.roundToDouble()
              ? kg.toInt().toString()
              : kg.toStringAsFixed(1);
      for (final s in log.sets) {
        if (s.kg.isEmpty && !s.done) s.kg = t;
      }
    }
  }

  void _checkSet(int k, int i) {
    final ex = widget.exs[k];
    final sp = specs[k];
    final log = logs[k];
    final s = log.sets[i];
    setState(() {
      s.done = !s.done;
      s.completedAt = s.done ? DateTime.now().toIso8601String() : null;
    });
    if (store.settings.vibration) HapticFeedback.lightImpact();
    store.saveLogs();
    if (!s.done || !store.settings.autoTimer) return;
    if (widget.exs.length == 2 && k == 0) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            duration: const Duration(seconds: 2),
            content: Text(
              'Enchaîne : ${store.splitName(widget.exs[1].name).$1}',
            ),
          ),
        );
      return;
    }
    final rest = store.restAfterSet(ex, sp, i, log.sets.length);
    if (rest != null && rest > 0) widget.timer.startRest(rest);
  }

  void _reusePrevious(int k, ExerciseLog prev) {
    final log = logs[k];
    for (var i = 0; i < log.sets.length && i < prev.sets.length; i++) {
      final s = log.sets[i];
      if (s.done) continue;
      final p = prev.sets[i];
      if (p.kg.isNotEmpty) s.kg = p.kg;
      if (p.reps.isNotEmpty) s.reps = p.reps;
    }
    store.saveLogs(affectsProgression: false);
    setState(() => epoch++);
  }

  @override
  Widget build(BuildContext context) => ListView(
    key: PageStorageKey('exercise-scroll-${widget.exs.first.id}'),
    keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
    padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
    children: [
      for (var k = 0; k < widget.exs.length; k++) ...[
        if (k > 0) const SizedBox(height: 12),
        _block(k),
      ],
    ],
  );

  Widget _block(int k) {
    final ex = widget.exs[k];
    final sp = specs[k];
    final log = logs[k];
    final chained = widget.exs.length == 2;
    final accent =
        ex.main
            ? SL.mainGreen
            : ex.prevention
            ? SL.prevViolet
            : widget.week.color;
    final (title, subtitle) = store.splitName(ex.name);
    final interval = ex.interval;
    final noLoad =
        sp.kind == 'duration' ||
        sp.kind == 'interval' ||
        sp.kind == 'emom' ||
        sp.kind == 'amrap';
    final showKg = !noLoad && store.showKgFor(ex, log);
    final showRir = sp.kind == 'reps' && store.showRirFor(log);
    final showV = sp.kind == 'reps' && store.showVFor(ex, log);
    final loadLabel = store.loadLabel(ex);
    final showBigLoad =
        !noLoad && loadLabel != '—' && (loadLabel != 'PdC' || showKg);
    final kindLabel = _kindLabel(sp);
    final showIntensity =
        ex.intensity.isNotEmpty &&
        !kindLabel.toLowerCase().startsWith(ex.intensity.toLowerCase());
    final prev =
        widget.week.n > 0
            ? store.previousLog(widget.week.n, widget.day.j, ex)
            : null;

    return KCard(
      key: ValueKey('exercise-card-${ex.id}'),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ----- Carte prescription -----
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (chained)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: _chip(
                      k == 0 ? 'ENCHAÎNÉ · A' : 'ENCHAÎNÉ · B',
                      SL.inputYellow,
                      small: true,
                    ),
                  ),
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.2,
                    height: 1.2,
                    color: SL.text,
                  ),
                ),
                if (subtitle.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 3),
                    child: Text(
                      subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: SL.dim,
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                const SizedBox(height: 10),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    if (showBigLoad) ...[
                      Flexible(
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            loadLabel,
                            style: TextStyle(
                              fontSize: 40,
                              fontWeight: FontWeight.w900,
                              color: accent,
                              height: 1,
                              fontFeatures: _tab,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                    ],
                    Expanded(
                      child: Text(
                        nbsp(store.setsLabel(ex)),
                        style: TextStyle(
                          fontSize: showBigLoad ? 18 : 24,
                          fontWeight: FontWeight.w800,
                          color: showBigLoad ? SL.text : accent,
                          fontFeatures: _tab,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    _chip(kindLabel, SL.inputYellow),
                    if (showIntensity) _chip(nbsp(ex.intensity), accent),
                    if (ex.tempo.isNotEmpty) _chip(nbsp(ex.tempo), SL.dim),
                    if (ex.rest.isNotEmpty && ex.rest != '—')
                      _chip('Repos ${nbsp(ex.rest)}', SL.dim),
                    if (sp.myo)
                      _chip(
                        'Repos final ${fmt(store.settings.defaultRest)}',
                        SL.dim,
                      ),
                  ],
                ),
                if (ex.cue.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Text(ex.cue, style: Theme.of(context).textTheme.bodySmall),
                ],
                if (prev != null) ...[
                  const SizedBox(height: 10),
                  InkWell(
                    borderRadius: BorderRadius.circular(8),
                    onTap: () => _reusePrevious(k, prev.log),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: [
                          Icon(Icons.history, size: 15, color: SL.dim),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              'S${prev.week} · ${store.summarize(prev.log, kg: showKg)}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: SL.dim,
                                fontSize: 12.5,
                                fontFeatures: _tab,
                              ),
                            ),
                          ),
                          Text(
                            'Reprendre',
                            style: TextStyle(
                              color: SL.steel,
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 10),
          // ----- Chronos de mode -----
          if (interval != null && ex.timer == null)
            _big(
              accent,
              Icons.timer,
              'Lancer ${interval.rounds}× ${interval.work}\u00A0s / ${interval.rest}\u00A0s',
              () => widget.timer.startInterval(
                interval.rounds,
                interval.work,
                interval.rest,
              ),
            ),
          if (ex.timer != null && !sp.cluster) _modeButton(ex, accent),
          if (ex.timer == null && sp.kind == 'emom')
            _big(
              accent,
              Icons.timer,
              'Lancer EMOM ${sp.seconds! ~/ 60}\u00A0min',
              () => widget.timer.emom(sp.seconds! ~/ 60, 60),
            ),
          if (ex.timer == null && sp.kind == 'duration')
            _big(
              accent,
              Icons.timer,
              'Lancer ${sp.seconds! ~/ 60}\u00A0min',
              () => widget.timer.single('DURÉE', sp.seconds!),
            ),
          if (sp.cluster && sp.intra != null)
            _big(
              SL.inputYellow,
              Icons.av_timer,
              'Intra-cluster ${sp.intra}\u00A0s',
              () => widget.timer.single('INTRA', sp.intra!, prepare: false),
            ),
          // ----- Logger : en-tête de colonnes + lignes -----
          _HeaderRow(
            spec: sp,
            showKg: showKg,
            showRir: showRir,
            showV: showV,
            hasTimer: sp.timed,
          ),
          for (var i = 0; i < log.sets.length; i++)
            _SetRow(
              key: ValueKey('${ex.id}-$i-$epoch'),
              label: store.setLabel(sp, i),
              entry: log.sets[i],
              spec: sp,
              showKg: showKg,
              showRir: showRir,
              showV: showV,
              onCheck: () => _checkSet(k, i),
              onTimer:
                  sp.kind == 'hold'
                      ? () => widget.timer.single(
                        'TENUE',
                        int.tryParse(log.sets[i].reps) ?? sp.seconds ?? 30,
                      )
                      : sp.kind == 'holdMax'
                      ? () => widget.timer.stopwatch('MAX')
                      : sp.kind == 'duration'
                      ? () => widget.timer.single(
                        'DURÉE',
                        (int.tryParse(log.sets[i].reps) ??
                                (sp.seconds! ~/ 60)) *
                            60,
                      )
                      : null,
            ),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Row(
              children: [
                IconButton(
                  tooltip: 'Retirer une série',
                  icon: const Icon(Icons.remove),
                  onPressed: () {
                    if (log.removeLastSet()) {
                      store.saveLogs(affectsProgression: false);
                      setState(() {});
                    }
                  },
                ),
                IconButton(
                  tooltip: 'Ajouter une série',
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    log.addSet();
                    _prefill(ex, sp, log);
                    store.saveLogs(affectsProgression: false);
                    setState(() {});
                  },
                ),
                Expanded(
                  child: Text(
                    '${log.sets.length} séries',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
                if (!noLoad)
                  PopupMenuButton<String>(
                    tooltip: 'Colonnes',
                    icon: Icon(Icons.tune, size: 20, color: SL.dim),
                    onSelected: (v) {
                      setState(() {
                        if (v == 'kg') log.showKg = !showKg;
                        if (v == 'rir') log.showRir = !showRir;
                        if (v == 'v') log.showV = !showV;
                      });
                      store.saveLogs(affectsProgression: false);
                    },
                    itemBuilder:
                        (_) => [
                          CheckedPopupMenuItem(
                            value: 'kg',
                            checked: showKg,
                            child: const Text('Charge (kg)'),
                          ),
                          if (sp.kind == 'reps')
                            CheckedPopupMenuItem(
                              value: 'rir',
                              checked: showRir,
                              child: Text(store.settings.rpe ? 'RPE' : 'RIR'),
                            ),
                          if (sp.kind == 'reps')
                            CheckedPopupMenuItem(
                              value: 'v',
                              checked: showV,
                              child: const Text('Vitesse (m/s)'),
                            ),
                        ],
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          TextFormField(
            key: ValueKey('${ex.id}-note'),
            initialValue: log.note,
            minLines: 1,
            maxLines: 3,
            textAlign: TextAlign.left,
            decoration: const InputDecoration(
              labelText: 'Notes',
              hintText: 'Sensations, ajustements…',
            ),
            onChanged: (value) {
              log.note = value;
              store.saveLogs(affectsProgression: false);
            },
          ),
        ],
      ),
    );
  }

  Widget _big(Color c, IconData ic, String label, VoidCallback action) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: FilledButton.icon(
          style: FilledButton.styleFrom(
            backgroundColor: c,
            foregroundColor: SL.onAccent,
            minimumSize: const Size.fromHeight(48),
          ),
          icon: Icon(ic),
          label: Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          onPressed: action,
        ),
      );

  Widget _modeButton(Exercise ex, Color accent) {
    final tm = ex.timer!;
    switch (tm['type'] as String) {
      case 'emom':
        final r = tm['rounds'] as int, itv = tm['interval'] as int;
        return _big(
          accent,
          Icons.timer,
          'Lancer EMOM $r × $itv\u00A0s',
          () => widget.timer.emom(r, itv),
        );
      case 'amrap':
        final s = tm['sec'] as int;
        return _big(
          accent,
          Icons.timer,
          'Lancer AMRAP ${s ~/ 60}\u00A0min',
          () => widget.timer.single('AMRAP', s),
        );
      case 'hiit':
        final r = tm['rounds'] as int,
            wk = tm['work'] as int,
            rs = tm['rest'] as int;
        return _big(
          accent,
          Icons.timer,
          'Lancer $r× $wk\u00A0s / $rs\u00A0s',
          () => widget.timer.startInterval(r, wk, rs),
        );
      case 'hold':
        final s = tm['sec'] as int;
        return _big(
          accent,
          Icons.timer,
          'Chrono $s\u00A0s',
          () => widget.timer.single('TENUE', s),
        );
    }
    return const SizedBox.shrink();
  }

  String _kindLabel(LogSpec sp) {
    const labels = {
      'reps': 'Reps',
      'repsMax': 'Max de reps',
      'hold': 'Tenue chronométrée',
      'holdMax': 'Max de temps',
      'duration': 'Durée',
      'interval': 'Intervalles',
      'emom': 'EMOM',
      'amrap': 'AMRAP',
    };
    if (sp.myo) return 'Myo-reps · intra ${sp.intra}\u00A0s';
    if (sp.cluster) return 'Clusters · intra ${sp.intra}\u00A0s';
    return labels[sp.kind] ?? sp.kind;
  }

  Widget _chip(String t, Color c, {bool small = false}) => Container(
    padding: EdgeInsets.symmetric(
      horizontal: small ? 7 : 9,
      vertical: small ? 3 : 5,
    ),
    decoration: BoxDecoration(
      color: c.withValues(alpha: SL.dark ? 0.14 : 0.12),
      borderRadius: BorderRadius.circular(8),
    ),
    child: Text(
      t,
      style: TextStyle(
        fontSize: small ? 10 : 11.5,
        fontWeight: FontWeight.w800,
        color: c,
        letterSpacing: small ? 0.5 : 0,
      ),
    ),
  );
}

// --- Disposition commune en-tête / lignes : mêmes flex, mêmes largeurs fixes.
const double _wLabel = 34;
const double _wBtn = 48;
const _gap = SizedBox(width: 6);

bool _splitColumns(BuildContext context, bool kg, bool rir, bool velocity) {
  final count = 1 + (kg ? 1 : 0) + (rir ? 1 : 0) + (velocity ? 1 : 0);
  final width = MediaQuery.sizeOf(context).width.clamp(0.0, KSpace.maxWidth);
  final available = width - 56 - _wLabel - _wBtn - 12;
  return count > 2 &&
      available / count < MediaQuery.textScalerOf(context).scale(64);
}

class _HeaderRow extends StatelessWidget {
  final LogSpec spec;
  final bool showKg, showRir, showV, hasTimer;
  const _HeaderRow({
    required this.spec,
    required this.showKg,
    required this.showRir,
    required this.showV,
    required this.hasTimer,
  });

  @override
  Widget build(BuildContext context) {
    final k = spec.kind;
    final second =
        k == 'hold' || k == 'holdMax'
            ? 'S'
            : k == 'duration'
            ? 'MIN'
            : k == 'repsMax'
            ? 'REPS MAX'
            : 'REPS';
    final compact = _splitColumns(context, showKg, showRir, showV);
    final st = TextStyle(
      color: SL.dim,
      fontSize: 10.5,
      fontWeight: FontWeight.w800,
      letterSpacing: 0.6,
    );
    Widget h(String t, int flex) => Expanded(
      flex: flex,
      child: Text(t, textAlign: TextAlign.center, style: st),
    );
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 6, 0, 2),
      child: Row(
        children: [
          SizedBox(
            width: _wLabel,
            child: Text('Série', textAlign: TextAlign.center, style: st),
          ),
          _gap,
          if (showKg) ...[h('kg', 3), _gap],
          h(second, k == 'repsMax' ? 4 : 3),
          if (showRir && !compact) ...[
            _gap,
            h(store.effortLabel.toUpperCase(), 2),
          ],
          if (showV && !compact) ...[_gap, h('M/S', 3)],
          _gap,
          if (hasTimer) const SizedBox(width: _wBtn),
          const SizedBox(width: _wBtn),
        ],
      ),
    );
  }
}

class _SetRow extends StatefulWidget {
  final String label;
  final SetEntry entry;
  final LogSpec spec;
  final bool showKg, showRir, showV;
  final VoidCallback onCheck;
  final VoidCallback? onTimer;
  const _SetRow({
    super.key,
    required this.label,
    required this.entry,
    required this.spec,
    required this.showKg,
    required this.showRir,
    required this.showV,
    required this.onCheck,
    this.onTimer,
  });

  @override
  State<_SetRow> createState() => _SetRowState();
}

class _SetRowState extends State<_SetRow> {
  late final TextEditingController kg, reps, rir, v;

  @override
  void initState() {
    super.initState();
    kg = TextEditingController(text: widget.entry.kg);
    reps = TextEditingController(text: widget.entry.reps);
    rir = TextEditingController(text: widget.entry.rir);
    v = TextEditingController(text: widget.entry.v);
  }

  @override
  void dispose() {
    for (final c in [kg, reps, rir, v]) {
      c.dispose();
    }
    super.dispose();
  }

  Widget _f(
    TextEditingController c,
    void Function(String) on, {
    int flex = 3,
    bool decimal = true,
    String? label,
  }) {
    return Flexible(
      flex: flex,
      child: TextField(
        controller: c,
        keyboardType: TextInputType.numberWithOptions(decimal: decimal),
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w700,
          color: SL.text,
          fontFeatures: _tab,
        ),
        decoration: logDeco(hint: '–').copyWith(labelText: label),
        onTap:
            () =>
                c.selection = TextSelection(
                  baseOffset: 0,
                  extentOffset: c.text.length,
                ),
        onChanged: (text) {
          on(text);
          store.saveLogs(affectsProgression: false);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final e = widget.entry;
    final k = widget.spec.kind;
    final done = e.done;
    final compact = _splitColumns(
      context,
      widget.showKg,
      widget.showRir,
      widget.showV,
    );
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Column(
        children: [
          Row(
            children: [
              SizedBox(
                width: _wLabel,
                child: Text(
                  widget.label,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: done ? SL.mainGreen : SL.dim,
                    fontWeight: FontWeight.w800,
                    fontSize: 12.5,
                    fontFeatures: _tab,
                  ),
                ),
              ),
              _gap,
              if (widget.showKg) ...[_f(kg, (t) => e.kg = t), _gap],
              _f(
                reps,
                (t) => e.reps = t,
                flex: k == 'repsMax' ? 4 : 3,
                decimal: false,
              ),
              if (widget.showRir && !compact) ...[
                _gap,
                _f(rir, (t) => e.rir = t, flex: 2),
              ],
              if (widget.showV && !compact) ...[_gap, _f(v, (t) => e.v = t)],
              _gap,
              if (widget.onTimer != null)
                SizedBox(
                  width: _wBtn,
                  height: _wBtn,
                  child: IconButton(
                    onPressed: widget.onTimer,
                    icon: Icon(
                      k == 'holdMax'
                          ? Icons.timer_outlined
                          : Icons.hourglass_bottom,
                      size: 22,
                    ),
                    color: SL.inputYellow,
                    tooltip:
                        k == 'holdMax' ? 'Chrono montant' : 'Compte à rebours',
                  ),
                ),
              SizedBox(
                width: _wBtn,
                height: _wBtn,
                child: IconButton.filled(
                  style: IconButton.styleFrom(
                    backgroundColor: done ? SL.mainGreen : SL.faint,
                    foregroundColor: done ? SL.onAccent : SL.dim,
                  ),
                  icon: const Icon(Icons.check, size: 22),
                  tooltip:
                      done
                          ? 'Annuler la série ${widget.label}'
                          : 'Valider la série ${widget.label}',
                  onPressed: widget.onCheck,
                ),
              ),
            ],
          ),
          if (compact && (widget.showRir || widget.showV)) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                const SizedBox(width: _wLabel + 6),
                if (widget.showRir)
                  _f(rir, (t) => e.rir = t, label: store.effortLabel),
                if (widget.showRir && widget.showV) _gap,
                if (widget.showV) _f(v, (t) => e.v = t, label: 'Vitesse (m/s)'),
                const SizedBox(width: _wBtn + 6),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

// --------------------------- BARRE TIMER ---------------------------------

class _TimerBar extends StatelessWidget {
  final TimerCtl ctl;
  const _TimerBar({required this.ctl});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: ctl,
      builder: (context, _) {
        if (!ctl.visible) return const SizedBox.shrink();
        final done = !ctl.running;
        final frac =
            ctl.up ? 1.0 : (ctl.total == 0 ? 0.0 : ctl.remaining / ctl.total);
        final effort =
            ctl.label.startsWith('EFFORT') ||
            ctl.label == 'TENUE' ||
            ctl.label == 'MAX';
        final color =
            done
                ? SL.mainGreen
                : effort
                ? SL.danger
                : SL.steel;
        return Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 8, 12),
          decoration: BoxDecoration(
            color: SL.surface,
            border: Border(top: BorderSide(color: SL.line)),
          ),
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: done ? 1 : frac,
                    minHeight: 5,
                    backgroundColor: SL.faint,
                    color: color,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Flexible(
                      flex: 2,
                      child: Text(
                        ctl.label,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: color,
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Flexible(
                      flex: 3,
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          ctl.up
                              ? fmt(ctl.elapsed)
                              : (done ? '0:00' : fmt(ctl.remaining)),
                          style: TextStyle(
                            fontSize: 34,
                            fontWeight: FontWeight.w900,
                            color: color,
                            fontFeatures: _tab,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (!ctl.up) ...[
                      TextButton(
                        onPressed: done ? null : () => ctl.add(-15),
                        style: TextButton.styleFrom(
                          minimumSize: const Size(40, 44),
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                        ),
                        child: const Text('\u221215'),
                      ),
                      TextButton(
                        onPressed: done ? null : () => ctl.add(15),
                        style: TextButton.styleFrom(
                          minimumSize: const Size(40, 44),
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                        ),
                        child: const Text('+15'),
                      ),
                    ],
                    IconButton(
                      onPressed: ctl.stop,
                      icon: Icon(
                        done ? Icons.close : Icons.stop_circle,
                        size: 26,
                      ),
                      tooltip: done ? 'Fermer' : 'Arrêter',
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ------------------------- FIN & JOUR DE REPOS ---------------------------

class _FinishPage extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  const _FinishPage({required this.week, required this.day});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) => _build(context),
  );

  Widget _build(BuildContext context) {
    final log = store.sessionLog(week.n, day.j);
    var doneSets = 0;
    var totalSets = 0;
    for (final ex in day.exercises) {
      final l = store.exLog(week.n, day.j, ex);
      totalSets += l.sets.length;
      doneSets += l.sets.where((s) => s.done).length;
    }
    final title = week.n == 0 ? week.block : 'S${week.n} · J${day.j}';
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              log.done ? Icons.emoji_events : Icons.flag,
              size: 64,
              color: week.color,
            ),
            const SizedBox(height: 12),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            Text(
              '$doneSets / $totalSets séries validées',
              style: TextStyle(color: SL.dim, fontFeatures: _tab),
            ),
            const SizedBox(height: 6),
            Text(
              log.done
                  ? 'XP et bonus ajoutés à ta progression'
                  : '+${week.n == 0 ? 60 : 100} XP de base + bonus éventuels',
              style: TextStyle(
                color: SL.inputYellow,
                fontSize: 12.5,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: log.done ? SL.card : SL.mainGreen,
                foregroundColor: log.done ? SL.dim : SL.onAccent,
                minimumSize: const Size(220, 50),
              ),
              icon: Icon(log.done ? Icons.undo : Icons.check_circle),
              label: Text(
                log.done ? 'Repasser en « à faire »' : 'Terminer la séance',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              onPressed: () {
                final wasDone = log.done;
                store.markSessionDone(week.n, day.j, !wasDone, title: title);
                if (wasDone) return;
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _RestDay extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  const _RestDay({required this.week, required this.day});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) => _build(context),
  );

  Widget _build(BuildContext context) {
    final done = store.isDone(week.n, day.j);
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.bedtime, size: 60, color: SL.steel),
            const SizedBox(height: 14),
            const Text(
              'REPOS COMPLET',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 10),
            Text(
              day.conduite.isEmpty
                  ? 'Marche, mobilité légère, sommeil maximal. GtG suspendu. Note ta HRV et ta FC de repos.'
                  : day.conduite,
              textAlign: TextAlign.center,
              style: TextStyle(color: SL.dim, height: 1.5),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: done ? SL.card : SL.mainGreen,
                foregroundColor: done ? SL.dim : SL.onAccent,
                minimumSize: const Size(220, 50),
              ),
              icon: Icon(done ? Icons.undo : Icons.check),
              label: Text(
                done ? 'Marqué fait' : 'Marquer comme fait',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              onPressed:
                  () => store.markSessionDone(
                    week.n,
                    day.j,
                    !done,
                    title: 'S${week.n} · J${day.j}',
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
