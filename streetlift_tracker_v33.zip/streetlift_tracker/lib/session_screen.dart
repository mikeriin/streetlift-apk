import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'main.dart';
import 'models.dart';
import 'store.dart';

// ============================= TIMER =====================================

class TimerCtl extends ChangeNotifier {
  Timer? _t;
  int total = 0;
  int remaining = 0;
  bool running = false;
  String label = 'REPOS';
  // Mode intervalle
  List<(String, int)> _phases = [];
  int _phaseIdx = 0;

  void startRest(int seconds) {
    _phases = [];
    _begin('REPOS', seconds);
  }

  void startInterval(int rounds, int work, int rest) {
    _phases = [];
    for (var i = 1; i <= rounds; i++) {
      _phases.add(('EFFORT $i/$rounds', work));
      if (i < rounds) _phases.add(('REPOS $i/$rounds', rest));
    }
    _phaseIdx = 0;
    final p = _phases[0];
    _begin(p.$1, p.$2);
  }

  void _begin(String lbl, int seconds) {
    _t?.cancel();
    label = lbl;
    total = seconds;
    remaining = seconds;
    running = true;
    notifyListeners();
    _t = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  void _tick() {
    remaining--;
    if (remaining <= 0) {
      _alert();
      if (_phases.isNotEmpty && _phaseIdx < _phases.length - 1) {
        _phaseIdx++;
        final p = _phases[_phaseIdx];
        label = p.$1;
        total = p.$2;
        remaining = p.$2;
      } else {
        stop(silent: true);
        label = 'TERMINÉ';
      }
    }
    notifyListeners();
  }

  void _alert() {
    SystemSound.play(SystemSoundType.alert);
    HapticFeedback.heavyImpact();
    Future.delayed(const Duration(milliseconds: 250), HapticFeedback.heavyImpact);
    Future.delayed(const Duration(milliseconds: 500), HapticFeedback.heavyImpact);
  }

  void add(int s) {
    if (!running) return;
    remaining = (remaining + s).clamp(1, 3600);
    total = remaining > total ? remaining : total;
    notifyListeners();
  }

  void stop({bool silent = false}) {
    _t?.cancel();
    _t = null;
    running = false;
    if (!silent) {
      remaining = 0;
      label = 'REPOS';
    }
    notifyListeners();
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }
}

String fmt(int s) {
  final m = s ~/ 60;
  final r = s % 60;
  return '$m:${r.toString().padLeft(2, '0')}';
}

// ============================ SÉANCE =====================================

class SessionScreen extends StatefulWidget {
  final WeekPlan week;
  final DayPlan day;
  const SessionScreen({super.key, required this.week, required this.day});

  @override
  State<SessionScreen> createState() => _SessionScreenState();
}

class _SessionScreenState extends State<SessionScreen> {
  final ctl = TimerCtl();
  final pageCtl = PageController();
  int page = 0;

  int get nEx => widget.day.exercises.length;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    store.saveLogs();
    ctl.dispose();
    pageCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = widget.week;
    final d = widget.day;
    final restDay = d.exercises.isEmpty;
    return Scaffold(
      appBar: AppBar(
        title: Text(restDay
            ? 'S${w.n} · J${d.j} — REPOS'
            : 'S${w.n} · J${d.j} — ${page >= nEx ? 'FIN' : '${page + 1}/$nEx'}'),
        actions: [
          IconButton(
            tooltip: 'Consignes de séance',
            icon: const Icon(Icons.info_outline),
            onPressed: () => showModalBottomSheet(
              context: context,
              backgroundColor: SL.surface,
              builder: (_) => Padding(
                padding: const EdgeInsets.all(18),
                child: Text(d.conduite.isEmpty ? d.title : d.conduite,
                    style: const TextStyle(height: 1.45)),
              ),
            ),
          ),
        ],
      ),
      body: restDay
          ? _RestDay(week: w, day: d)
          : Column(
              children: [
                _ProgressDots(count: nEx + 1, index: page, color: w.color),
                Expanded(
                  child: PageView.builder(
                    controller: pageCtl,
                    onPageChanged: (i) {
                      store.saveLogs();
                      setState(() => page = i);
                    },
                    itemCount: nEx + 1,
                    itemBuilder: (_, i) => i < nEx
                        ? _ExercisePage(
                            key: ValueKey(d.exercises[i].id),
                            week: w,
                            day: d,
                            ex: d.exercises[i],
                            timer: ctl,
                          )
                        : _FinishPage(week: w, day: d),
                  ),
                ),
                _TimerBar(ctl: ctl),
              ],
            ),
    );
  }
}

class _ProgressDots extends StatelessWidget {
  final int count;
  final int index;
  final Color color;
  const _ProgressDots(
      {required this.count, required this.index, required this.color});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          for (var i = 0; i < count; i++)
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 2.5),
              width: i == index ? 18 : 7,
              height: 7,
              decoration: BoxDecoration(
                color: i == index ? color : Colors.white24,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
        ],
      ),
    );
  }
}

// ------------------------- PAGE EXERCICE ---------------------------------

class _ExercisePage extends StatefulWidget {
  final WeekPlan week;
  final DayPlan day;
  final Exercise ex;
  final TimerCtl timer;
  const _ExercisePage(
      {super.key,
      required this.week,
      required this.day,
      required this.ex,
      required this.timer});

  @override
  State<_ExercisePage> createState() => _ExercisePageState();
}

class _ExercisePageState extends State<_ExercisePage> {
  late final ExerciseLog log;

  @override
  void initState() {
    super.initState();
    log = store.exLog(widget.week.n, widget.day.j, widget.ex);
    // Pré-remplit la charge suggérée sur les lignes vides.
    final kg = store.loadFor(widget.ex);
    if (kg != null && kg > 0) {
      final t = kg == kg.roundToDouble()
          ? kg.toInt().toString()
          : kg.toStringAsFixed(1);
      for (final s in log.sets) {
        if (s.kg.isEmpty && !s.done) s.kg = t;
      }
    }
  }

  void _checkSet(SetEntry s) {
    setState(() => s.done = !s.done);
    store.saveLogs();
    if (s.done) {
      final rest = widget.ex.restSec;
      if (rest != null && rest > 0) widget.timer.startRest(rest);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ex = widget.ex;
    final accent = ex.main
        ? SL.mainGreen
        : ex.prevention
            ? SL.prevViolet
            : widget.week.color;
    final interval = ex.interval;
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
      children: [
        // ----- Carte prescription -----
        Container(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
          decoration: BoxDecoration(
            color: SL.card,
            borderRadius: BorderRadius.circular(16),
            border: Border(left: BorderSide(color: accent, width: 4)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(ex.name.toUpperCase(),
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.2,
                      color: ex.main ? SL.mainGreen : SL.text)),
              const SizedBox(height: 10),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(store.loadLabel(ex),
                      style: TextStyle(
                          fontSize: 40,
                          fontWeight: FontWeight.w900,
                          color: accent,
                          fontFeatures: const [FontFeature.tabularFigures()])),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(store.setsLabel(ex),
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  if (ex.intensity.isNotEmpty) _chip(ex.intensity, accent),
                  if (ex.tempo.isNotEmpty) _chip(ex.tempo, SL.dim),
                  if (ex.rest.isNotEmpty && ex.rest != '—')
                    _chip('Repos ${ex.rest}', SL.dim),
                ],
              ),
              if (ex.cue.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(ex.cue, style: Theme.of(context).textTheme.bodySmall),
              ],
            ],
          ),
        ),
        const SizedBox(height: 10),
        // ----- Intervalle (HIIT / EMOM court) -----
        if (interval != null)
          FilledButton.icon(
            style: FilledButton.styleFrom(
                backgroundColor: accent, foregroundColor: Colors.black),
            icon: const Icon(Icons.timer),
            label: Text(
                'Lancer ${interval.rounds}× ${interval.work} s / ${interval.rest} s'),
            onPressed: () => widget.timer
                .startInterval(interval.rounds, interval.work, interval.rest),
          ),
        // ----- Logger de séries -----
        for (var i = 0; i < log.sets.length; i++)
          _SetRow(
            index: i,
            entry: log.sets[i],
            showV: ex.main,
            onCheck: () => _checkSet(log.sets[i]),
          ),
        const SizedBox(height: 8),
        TextFormField(
          key: ValueKey('${ex.id}-note'),
          initialValue: log.note,
          maxLines: 2,
          decoration: const InputDecoration(labelText: 'Notes / douleur'),
          onChanged: (v) => log.note = v,
        ),
      ],
    );
  }

  Widget _chip(String t, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
        decoration: BoxDecoration(
          color: c.withOpacity(0.14),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(t,
            style: TextStyle(
                fontSize: 11.5, fontWeight: FontWeight.w700, color: c)),
      );
}

class _SetRow extends StatelessWidget {
  final int index;
  final SetEntry entry;
  final bool showV;
  final VoidCallback onCheck;
  const _SetRow(
      {required this.index,
      required this.entry,
      required this.showV,
      required this.onCheck});

  Widget _f(String label, String init, void Function(String) on,
      {double w = 62}) {
    return SizedBox(
      width: w,
      child: TextFormField(
        initialValue: init,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        decoration: InputDecoration(labelText: label),
        onChanged: on,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(
        children: [
          SizedBox(
            width: 26,
            child: Text('${index + 1}',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: SL.dim, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 4),
          _f('kg', entry.kg, (v) => entry.kg = v),
          const SizedBox(width: 6),
          _f('reps', entry.reps, (v) => entry.reps = v),
          const SizedBox(width: 6),
          _f('RIR', entry.rir, (v) => entry.rir = v, w: 52),
          if (showV) ...[
            const SizedBox(width: 6),
            _f('m/s', entry.v, (v) => entry.v = v, w: 56),
          ],
          const Spacer(),
          IconButton.filled(
            style: IconButton.styleFrom(
              backgroundColor:
                  entry.done ? SL.mainGreen : Colors.white.withOpacity(0.08),
              foregroundColor: entry.done ? Colors.black : SL.dim,
            ),
            icon: const Icon(Icons.check, size: 20),
            onPressed: onCheck,
          ),
        ],
      ),
    );
  }
}

// --------------------------- BARRE TIMER ---------------------------------

class _TimerBar extends StatelessWidget {
  final TimerCtl ctl;
  const _TimerBar({required this.ctl});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: ctl,
      builder: (context, _) {
        if (!ctl.running && ctl.label != 'TERMINÉ') {
          return const SizedBox.shrink();
        }
        final done = !ctl.running;
        final frac = ctl.total == 0 ? 0.0 : ctl.remaining / ctl.total;
        final effort = ctl.label.startsWith('EFFORT');
        final color = done
            ? SL.mainGreen
            : effort
                ? SL.danger
                : SL.steel;
        return Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 8, 12),
          decoration: const BoxDecoration(
            color: SL.surface,
            border: Border(top: BorderSide(color: Colors.white12)),
          ),
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: done ? 1 : frac,
                    minHeight: 5,
                    backgroundColor: Colors.white10,
                    color: color,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Text(ctl.label,
                        style: TextStyle(
                            color: color,
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1)),
                    const Spacer(),
                    Text(done ? '0:00' : fmt(ctl.remaining),
                        style: TextStyle(
                            fontSize: 34,
                            fontWeight: FontWeight.w900,
                            color: color,
                            fontFeatures: const [
                              FontFeature.tabularFigures()
                            ])),
                    const Spacer(),
                    TextButton(
                        onPressed: done ? null : () => ctl.add(-15),
                        child: const Text('\u221215')),
                    TextButton(
                        onPressed: done ? null : () => ctl.add(15),
                        child: const Text('+15')),
                    IconButton(
                        onPressed: () => ctl.stop(),
                        icon: Icon(done ? Icons.close : Icons.stop_circle,
                            size: 24)),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ------------------------- FIN & JOUR DE REPOS ---------------------------

class _FinishPage extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  const _FinishPage({required this.week, required this.day});

  @override
  Widget build(BuildContext context) {
    final log = store.sessionLog(week.n, day.j);
    var doneSets = 0;
    var totalSets = 0;
    for (final ex in day.exercises) {
      final l = store.exLog(week.n, day.j, ex);
      totalSets += l.sets.length;
      doneSets += l.sets.where((s) => s.done).length;
    }
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(log.done ? Icons.emoji_events : Icons.flag,
                size: 64, color: week.color),
            const SizedBox(height: 12),
            Text('S${week.n} · J${day.j}',
                style: const TextStyle(
                    fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text('$doneSets / $totalSets séries validées',
                style: const TextStyle(color: SL.dim)),
            const SizedBox(height: 24),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: log.done ? SL.card : SL.mainGreen,
                foregroundColor: log.done ? SL.dim : Colors.black,
                padding:
                    const EdgeInsets.symmetric(horizontal: 26, vertical: 14),
              ),
              icon: Icon(log.done ? Icons.undo : Icons.check_circle),
              label: Text(
                  log.done ? 'Repasser en « à faire »' : 'Terminer la séance',
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              onPressed: () {
                store.markSessionDone(week.n, day.j, !log.done);
                if (!log.done) return;
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _RestDay extends StatelessWidget {
  final WeekPlan week;
  final DayPlan day;
  const _RestDay({required this.week, required this.day});

  @override
  Widget build(BuildContext context) {
    final done = store.isDone(week.n, day.j);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.bedtime, size: 60, color: SL.steel),
            const SizedBox(height: 14),
            const Text('REPOS COMPLET',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            Text(
              day.conduite.isEmpty
                  ? 'Marche, mobilité légère, sommeil maximal. GtG suspendu. Note ta HRV et ta FC de repos.'
                  : day.conduite,
              textAlign: TextAlign.center,
              style: const TextStyle(color: SL.dim, height: 1.5),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                  backgroundColor: done ? SL.card : SL.mainGreen,
                  foregroundColor: done ? SL.dim : Colors.black),
              icon: Icon(done ? Icons.undo : Icons.check),
              label: Text(done ? 'Marqué fait' : 'Marquer comme fait'),
              onPressed: () =>
                  store.markSessionDone(week.n, day.j, !done),
            ),
          ],
        ),
      ),
    );
  }
}
