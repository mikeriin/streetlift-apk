import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'ui.dart';
import 'store.dart';

/// Lecture d'une séance terminée, y compris après modification du modèle.
class SessionHistoryScreen extends StatelessWidget {
  final SessionLog log;
  const SessionHistoryScreen({super.key, required this.log});
  @override
  Widget build(BuildContext context) => KScreen(
    appBar: AppBar(title: Text(log.title ?? 'Historique')),
    body:
        log.ex.isEmpty
            ? const Padding(
              padding: KSpace.content,
              child: KEmpty(
                icon: Icons.check_circle_outline,
                title: 'Séance effectuée',
                message: 'Aucune série enregistrée pour cette séance.',
              ),
            )
            : ListView.separated(
              padding: KSpace.content,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemCount: log.ex.length,
              itemBuilder: (context, i) {
                final entry = log.ex.entries.elementAt(i);
                final ex = entry.value;
                return KCard(
                  child: Padding(
                    padding: EdgeInsets.zero,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(
                          log.exerciseNames[entry.key] ?? entry.key,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 8),
                        for (var j = 0; j < ex.sets.length; j++)
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Text(
                              '${ex.sets[j].done ? '✓' : '–'}  ${j + 1} · '
                              '${ex.sets[j].kg.isEmpty ? '' : '${ex.sets[j].kg} kg · '}'
                              '${ex.sets[j].reps.isEmpty ? 'Non renseigné' : ex.sets[j].reps}'
                              '${ex.sets[j].rir.isEmpty ? '' : ' · effort ${ex.sets[j].rir}'}',
                              style: TextStyle(
                                color: ex.sets[j].done ? SL.text : SL.dim,
                              ),
                            ),
                          ),
                        if (ex.note.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(
                            'Notes',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          const SizedBox(height: 4),
                          Text(ex.note),
                        ],
                      ],
                    ),
                  ),
                );
              },
            ),
  );
}
