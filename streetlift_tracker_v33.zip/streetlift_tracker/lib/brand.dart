import 'package:flutter/material.dart';

/// Une seule silhouette pour l'ouverture et l'en-tête du Programme.
class KalisLogo extends StatelessWidget {
  static const double headerSize = 48;
  final double size;
  final Color color;
  const KalisLogo({super.key, this.size = headerSize, required this.color});

  @override
  Widget build(BuildContext context) => Image.asset(
    'assets/icon/icon_fg.png',
    width: size,
    height: size,
    color: color,
    colorBlendMode: BlendMode.srcIn,
    semanticLabel: 'Kalis Track',
  );
}
