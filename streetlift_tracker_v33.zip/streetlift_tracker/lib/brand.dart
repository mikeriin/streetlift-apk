import 'package:flutter/material.dart';

/// Monogramme K, dessiné en vectoriel comme les icônes Android livrées.
class KalisLogo extends StatelessWidget {
  static const double headerSize = 48;
  final double size;
  final Color color;
  final double scale;
  const KalisLogo({
    super.key,
    this.size = headerSize,
    required this.color,
    this.scale = 1,
  });
  @override
  Widget build(BuildContext context) => Semantics(
    image: true,
    label: 'Kalis Track',
    child: SizedBox(
      width: size,
      height: size,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xFF782A40),
          borderRadius: BorderRadius.circular(size * .28),
        ),
        child: Padding(
          padding: EdgeInsets.all(size * .19),
          child: CustomPaint(painter: _KalisMark(color)),
        ),
      ),
    ),
  );
}

class _KalisMark extends CustomPainter {
  final Color color;
  const _KalisMark(this.color);
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 100, size.height / 100);
    final pen =
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 14
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round;
    canvas.drawLine(const Offset(22, 15), const Offset(22, 85), pen);
    canvas.drawPath(
      Path()
        ..moveTo(78, 15)
        ..lineTo(43, 48)
        ..lineTo(82, 85),
      pen,
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(_KalisMark oldDelegate) => oldDelegate.color != color;
}
