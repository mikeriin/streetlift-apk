import 'package:flutter/material.dart';

/// Silhouette historique, conservée à l'identique et recolorée en bordeaux.
class KalisLogo extends StatelessWidget {
  static const double headerSize = 48;
  final double size;
  final Color color;
  final double scale;
  const KalisLogo({
    super.key,
    this.size = headerSize,
    required this.color,
    this.scale = 1,
  });

  @override
  Widget build(BuildContext context) => Semantics(
    image: true,
    label: 'Kalis Track',
    child: SizedBox(
      width: size,
      height: size,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xFFF7F4F2),
          borderRadius: BorderRadius.circular(size * .36),
        ),
        child: Padding(
          padding: EdgeInsets.all(size * .13),
          child: Transform.scale(
            scale: scale,
            child: Image.asset(
              'assets/icon/logo_mark.png',
              color: color,
              colorBlendMode: BlendMode.srcIn,
              fit: BoxFit.contain,
              excludeFromSemantics: true,
            ),
          ),
        ),
      ),
    ),
  );
}
