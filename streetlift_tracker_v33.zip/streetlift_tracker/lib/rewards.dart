// Écran de récompenses : après une séance validée ou un score de WOD, les XP
// gagnés défilent, la jauge se remplit (et passe le niveau s'il y a lieu), les
// bonus s'affichent un à un (badge, défi, semaine validée, record, crédits),
// puis la cérémonie de niveau montre l'insigne. Une seule passe d'animations
// (aucune boucle infinie), « Réduire les animations » rend tout immédiat, et
// le réglage « Célébrations » remplace l'écran par une simple confirmation.
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_theme.dart';
import 'game.dart';
import 'game_widgets.dart';
import 'progression.dart';
import 'progression_screen.dart';
import 'store.dart';
import 'ui.dart';

/// À appeler après une séance terminée ou un score de WOD enregistré : affiche
/// le bilan en attente, sinon la cérémonie de niveau seule si le niveau a
/// monté (import, suppression…).
void checkLevelUp(BuildContext context) {
  final reward = store.consumeReward();
  final up = store.consumeLevelUp();
  if (!context.mounted) return;
  if (reward != null) {
    if (store.settings.celebrations) {
      Navigator.of(context).push(
        PageRouteBuilder<void>(
          fullscreenDialog: true,
          opaque: false,
          transitionDuration:
              MediaQuery.disableAnimationsOf(context)
                  ? Duration.zero
                  : const Duration(milliseconds: 260),
          pageBuilder: (_, __, ___) => RewardScreen(reward: reward),
          transitionsBuilder:
              (_, animation, __, child) =>
                  FadeTransition(opacity: animation, child: child),
        ),
      );
    } else {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            duration: const Duration(seconds: 3),
            content: Text(
              '+${reward.xpGained} XP · niveau ${reward.levelAfter}${reward.levelUp ? ' · niveau supérieur, +${reward.creditsGained} crédit${reward.creditsGained > 1 ? 's' : ''}' : ''}',
            ),
          ),
        );
    }
    return;
  }
  if (up == null) return;
  showDialog<void>(
    context: context,
    builder:
        (ctx) => AlertDialog(
          title: Row(
            children: [
              RankInsignia(
                rankIndex: rankIndexOf(store.progression.rank),
                prestige: GameState.prestigeOf(up.to),
                size: 36,
              ),
              const SizedBox(width: 10),
              Text(
                'Niveau ${up.to}',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ],
          ),
          content: Text(
            'Niveau ${up.from} → ${up.to} · ${store.progression.rank.title}\n+${up.credits} crédit${up.credits > 1 ? 's' : ''} de déverrouillage — ${store.credits} disponible${store.credits > 1 ? 's' : ''}.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                openProgression(context);
              },
              child: const Text('Ma progression'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Continuer'),
            ),
          ],
        ),
  );
}

class RewardScreen extends StatefulWidget {
  final RewardSummary reward;
  const RewardScreen({super.key, required this.reward});
  @override
  State<RewardScreen> createState() => _RewardScreenState();
}

class _RewardScreenState extends State<RewardScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _confetti;
  bool _haptics = false;

  RewardSummary get r => widget.reward;

  @override
  void initState() {
    super.initState();
    // Une seule descente ; le départ différé est intégré à la courbe du
    // peintre (aucun minuteur à attendre dans les tests).
    _confetti = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2600),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_haptics) return;
    _haptics = true;
    final reduce = MediaQuery.disableAnimationsOf(context);
    if (store.settings.vibration) {
      if (r.levelUp) {
        HapticFeedback.heavyImpact();
      } else {
        HapticFeedback.mediumImpact();
      }
    }
    if (r.levelUp && !reduce) _confetti.forward();
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduce = MediaQuery.disableAnimationsOf(context);
    final d = reduce ? Duration.zero : const Duration(milliseconds: 1100);
    return Scaffold(
      backgroundColor: SL.bg.withValues(alpha: .97),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: _confetti,
                  builder:
                      (_, __) => CustomPaint(
                        painter: _ConfettiPainter(_confetti.value),
                      ),
                ),
              ),
            ),
            KList(
              children: [
                const SizedBox(height: 12),
                Text(
                  r.heading.toUpperCase(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: SL.accent,
                    fontSize: 12,
                    letterSpacing: 1.6,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  r.title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 18),
                TweenAnimationBuilder<double>(
                  tween: Tween<double>(
                    begin: reduce ? r.xpAfter.toDouble() : r.xpBefore.toDouble(),
                    end: r.xpAfter.toDouble(),
                  ),
                  duration: d,
                  curve: Curves.easeOutCubic,
                  builder: (context, xp, _) => _XpMeter(total: xp, reward: r),
                ),
                const SizedBox(height: 18),
                for (var i = 0; i < r.lines.length; i++)
                  _Appear(
                    delay:
                        reduce
                            ? Duration.zero
                            : Duration(milliseconds: 500 + 110 * i),
                    child: _LootLine(r.lines[i]),
                  ),
                if (r.levelUp) ...[
                  const SizedBox(height: 14),
                  _Appear(
                    delay:
                        reduce
                            ? Duration.zero
                            : const Duration(milliseconds: 1000),
                    scale: true,
                    child: _Ceremony(r),
                  ),
                ],
                const SizedBox(height: 22),
                FilledButton(
                  key: const ValueKey('reward-continue'),
                  style: FilledButton.styleFrom(
                    backgroundColor: SL.bordeaux,
                    foregroundColor: Colors.white,
                    minimumSize: const Size(220, KControl.buttonHeight),
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Continuer'),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    openProgression(context);
                  },
                  child: const Text('Ma progression'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// XP en cours de comptage, jauge du niveau atteint à cet instant : quand le
/// total franchit un niveau, la jauge repart et le numéro change.
class _XpMeter extends StatelessWidget {
  final double total;
  final RewardSummary reward;
  const _XpMeter({required this.total, required this.reward});
  @override
  Widget build(BuildContext context) {
    var level = 1;
    while (total >= Progression.xpAtLevel(level + 1)) {
      level++;
    }
    final inLevel = total - Progression.xpAtLevel(level);
    final need = Progression.needFor(level);
    final gained = (total - reward.xpBefore).round();
    final rank = progressRanks.lastWhere((k) => k.level <= level);
    return Column(
      children: [
        Text(
          '+$gained XP',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: SL.text,
            fontSize: 44,
            height: 1,
            fontWeight: FontWeight.w800,
            fontFeatures: const [FontFeature.tabularFigures()],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Text(
              'NIV. $level',
              style: TextStyle(
                color: SL.dim,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: .8,
                fontFeatures: const [FontFeature.tabularFigures()],
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                '${inLevel.round()} / $need XP · ${rank.title}',
                textAlign: TextAlign.end,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: SL.dim,
                  fontSize: 12,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        KProgressBar(
          value: need == 0 ? 0 : inLevel / need,
          height: 8,
          semanticsLabel: 'Progression du niveau',
          semanticsValue: '${inLevel.round()} sur $need XP',
        ),
      ],
    );
  }
}

class _LootLine extends StatelessWidget {
  final RewardLine line;
  const _LootLine(this.line);
  @override
  Widget build(BuildContext context) {
    final icon = switch (line.kind) {
      'badge' => Icons.workspace_premium_rounded,
      'mission' => Icons.flag_rounded,
      'streak' => Icons.local_fire_department_rounded,
      'record' => Icons.emoji_events_rounded,
      'goal' => Icons.track_changes_rounded,
      'credit' => Icons.toll_rounded,
      _ => Icons.fitness_center_rounded,
    };
    final color = switch (line.kind) {
      'record' || 'goal' || 'streak' => SL.success,
      _ => SL.accent,
    };
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: KCard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                line.label,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            if (line.xp > 0) ...[
              const SizedBox(width: 8),
              Text(
                '+${line.xp} XP',
                style: TextStyle(
                  color: SL.accent,
                  fontWeight: FontWeight.w700,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _Ceremony extends StatelessWidget {
  final RewardSummary r;
  const _Ceremony(this.r);
  @override
  Widget build(BuildContext context) {
    final rank = progressRanks.lastWhere((k) => k.level <= r.levelAfter);
    return KCard(
      key: const ValueKey('reward-ceremony'),
      color: SL.bordeaux,
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          RankInsignia(
            rankIndex: rankIndexOf(rank),
            prestige: GameState.prestigeOf(r.levelAfter),
            size: 84,
            light: true,
          ),
          const SizedBox(height: 12),
          Text(
            r.promotion ? 'PROMOTION' : 'NIVEAU SUPÉRIEUR',
            style: const TextStyle(
              color: KPalette.light,
              fontSize: 11,
              letterSpacing: 1.6,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            r.promotion ? rank.title : 'Niveau ${r.levelAfter}',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.w800,
            ),
          ),
          if (r.promotion)
            Text(
              'Niveau ${r.levelAfter}',
              style: const TextStyle(color: KPalette.light, fontSize: 13),
            ),
          const SizedBox(height: 10),
          Text(
            '+${r.creditsGained} crédit${r.creditsGained > 1 ? 's' : ''} WOD · ${store.credits} disponible${store.credits > 1 ? 's' : ''}',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

/// Apparition différée en fondu et glissement (échelle optionnelle), une seule
/// fois, sans minuteur : le délai est intégré à la courbe.
class _Appear extends StatelessWidget {
  final Duration delay;
  final bool scale;
  final Widget child;
  const _Appear({required this.delay, required this.child, this.scale = false});
  @override
  Widget build(BuildContext context) {
    const reveal = Duration(milliseconds: 420);
    final total = delay + reveal;
    if (total == Duration.zero) return child;
    final start = delay.inMilliseconds / total.inMilliseconds;
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: total,
      curve: Interval(start, 1, curve: Curves.easeOutCubic),
      builder:
          (context, t, child) => Opacity(
            opacity: t,
            child: Transform.translate(
              offset: Offset(0, 14 * (1 - t)),
              child:
                  scale
                      ? Transform.scale(scale: .9 + .1 * t, child: child)
                      : child,
            ),
          ),
      child: child,
    );
  }
}

/// Confettis dans la charte, une seule descente.
class _ConfettiPainter extends CustomPainter {
  final double t;
  const _ConfettiPainter(this.t);
  static const _colors = [
    KPalette.burgundy,
    KPalette.actionRed,
    KPalette.lightRed,
    KPalette.light,
  ];
  @override
  void paint(Canvas canvas, Size size) {
    // Les 36 premiers pour cent laissent la jauge se remplir d'abord.
    final t = ((this.t - .36) / .64);
    if (t <= 0 || t >= 1) return;
    final rnd = math.Random(42);
    final paint = Paint();
    for (var i = 0; i < 70; i++) {
      final x0 = rnd.nextDouble() * size.width;
      final drift = (rnd.nextDouble() - .5) * 80;
      final speed = .6 + rnd.nextDouble() * .8;
      final y = -20 + (size.height + 40) * math.min(1, t * speed);
      final x = x0 + drift * t + math.sin((t * 6 + i) * 1.3) * 8;
      final w = 4 + rnd.nextDouble() * 4, h = 6 + rnd.nextDouble() * 6;
      paint.color = _colors[i % _colors.length].withValues(alpha: 1 - t * .6);
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate((t * 4 + i) * .8);
      canvas.drawRect(Rect.fromCenter(center: Offset.zero, width: w, height: h), paint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_ConfettiPainter old) => old.t != t;
}
