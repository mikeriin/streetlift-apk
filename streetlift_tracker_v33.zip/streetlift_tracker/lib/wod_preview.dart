// Aperçu d'un WOD : volume, charge de travail, muscles sollicités, déverrouillage.

import 'package:flutter/material.dart';

import 'app_theme.dart';
import 'ui.dart';
import 'estimate_view.dart';
import 'muscle_body.dart';
import 'store.dart';
import 'wod_screen.dart';

class WodPreviewScreen extends StatelessWidget {
  final String wodId;
  final bool fromRunner;
  const WodPreviewScreen({
    super.key,
    required this.wodId,
    this.fromRunner = false,
  });

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final matches = store.wods.where((x) => x.id == wodId);
        if (matches.isEmpty) {
          return KScreen(
            appBar: AppBar(),
            body: const Center(child: Text('Ce WOD a été supprimé.')),
          );
        }
        final w = matches.first;
        final c = wodColor(w.type);
        final estimate = store.wodEstimate(w);
        final muscles = store.wodMuscles(w);
        final unlocked = store.unlocked(w);
        final cost = store.wodCost(w);
        final lp = store.levelProgress;
        return KScreen(
          appBar: AppBar(
            title: Text(w.name, maxLines: 1, overflow: TextOverflow.ellipsis),
          ),
          body: KList(
            children: [
              // ----- entête -----
              KCard(
                accent: c,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        _chip(w.typeLabel, c),
                        const SizedBox(width: 6),
                        _chip('Difficulté ${w.level}/10', SL.dim),
                        if (!unlocked)
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.lock_outline,
                                size: 16,
                                color: SL.accent,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                '$cost crédit${cost > 1 ? 's' : ''}',
                                style: TextStyle(
                                  color: SL.accent,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12.5,
                                ),
                              ),
                            ],
                          )
                        else
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.lock_open,
                                size: 16,
                                color: SL.success,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                'Acquis',
                                style: TextStyle(
                                  color: SL.success,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12.5,
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                    if (w.header().isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(
                        w.header(),
                        style: TextStyle(
                          color: SL.text,
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                        ),
                      ),
                    ],
                    if (w.source.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          '@${w.source}',
                          style: TextStyle(color: SL.dim, fontSize: 11.5),
                        ),
                      ),
                  ],
                ),
              ),
              // ----- mouvements -----
              _card(
                'Mouvements',
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (final l in w.lines)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: Text(
                          l,
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            height: 1.3,
                          ),
                        ),
                      ),
                    if (w.notes.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text(
                        w.notes,
                        style: TextStyle(
                          color: SL.dim,
                          fontSize: 12.5,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              _card(
                'Volume et durée',
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    EstimateView(estimate: estimate),
                    TextButton.icon(
                      onPressed:
                          () => showEstimate(
                            context,
                            'Détail des mouvements · par passage',
                            estimate,
                          ),
                      icon: const Icon(Icons.list_alt_outlined, size: 17),
                      label: const Text('Détail des mouvements'),
                    ),
                  ],
                ),
              ),
              // ----- muscles -----
              _card(
                'Muscles sollicités',
                Column(
                  children: [
                    MuscleHeatmap(data: muscles, height: 200),
                    const SizedBox(height: 6),
                    MuscleLegend(data: muscles),
                  ],
                ),
              ),
            ],
          ),
          bottomNavigationBar: KBottomActions(
            child:
                unlocked
                    ? FilledButton.icon(
                      icon: const Icon(Icons.play_arrow_rounded),
                      label: Text(
                        fromRunner ? 'Revenir au chrono' : 'Lancer le WOD',
                      ),
                      onPressed: () {
                        if (fromRunner) {
                          Navigator.pop(context);
                        } else {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (_) => WodRunScreen(wodId: w.id),
                            ),
                          );
                        }
                      },
                    )
                    : store.credits >= cost
                    ? FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: SL.action,
                        foregroundColor: KPalette.light,
                      ),
                      icon: const Icon(Icons.lock_open),
                      label: Text(
                        'Acheter · $cost crédit${cost > 1 ? 's' : ''}',
                      ),
                      onPressed: () {
                        if (store.unlockWod(w)) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                '« ${w.name} » ajouté à ton arsenal.',
                              ),
                            ),
                          );
                        }
                      },
                    )
                    : Container(
                      constraints: const BoxConstraints(minHeight: 44),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: SL.faint,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: Text(
                        'Il te manque ${cost - store.credits} crédit${cost - store.credits > 1 ? 's' : ''} · niveau ${store.level + 1} dans ${lp.need - lp.inLevel} XP',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: SL.dim,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                    ),
          ),
        );
      },
    );
  }

  Widget _card(String title, Widget child) => KCard(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        KSection(title, topPadding: 0),
        const SizedBox(height: 6),
        child,
      ],
    ),
  );

  Widget _chip(String t, Color c) => KBadge(t, color: c);
}
