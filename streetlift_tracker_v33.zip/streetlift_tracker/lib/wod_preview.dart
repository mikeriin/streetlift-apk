// Aperçu d'un WOD : volume, charge de travail, muscles sollicités, déverrouillage.
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

import 'main.dart';
import 'muscle_body.dart';
import 'store.dart';
import 'wod_models.dart';
import 'wod_screen.dart';

const _tab = [FontFeature.tabularFigures()];

class WodPreviewScreen extends StatelessWidget {
  final String wodId;
  const WodPreviewScreen({super.key, required this.wodId});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final w = store.wods.firstWhere((x) => x.id == wodId);
        final c = wodColor(w.type);
        final st = store.wodStats(w);
        final muscles = store.wodMuscles(w);
        final unlocked = store.unlocked(w);
        final cost = store.wodCost(w);
        final lp = store.levelProgress;
        final loadBars = st.level == 'Légère'
            ? 1
            : st.level == 'Modérée'
                ? 2
                : st.level == 'Élevée'
                    ? 4
                    : 5;
        return Scaffold(
          appBar: AppBar(title: Text(w.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 110),
            children: [
              // ----- entête -----
              Container(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                decoration: BoxDecoration(
                  color: SL.card,
                  borderRadius: BorderRadius.circular(16),
                  border: Border(left: BorderSide(color: c, width: 4)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        _chip(w.typeLabel.toUpperCase(), c),
                        const SizedBox(width: 6),
                        _chip('NIVEAU ${w.level}/10', SL.dim),
                        const Spacer(),
                        if (!unlocked)
                          Row(children: [
                            Icon(Icons.lock_outline, size: 16, color: SL.inputYellow),
                            const SizedBox(width: 4),
                            Text('$cost crédit${cost > 1 ? 's' : ''}', style: TextStyle(color: SL.inputYellow, fontWeight: FontWeight.w800, fontSize: 12.5)),
                          ])
                        else
                          Row(children: [
                            Icon(Icons.lock_open, size: 16, color: SL.mainGreen),
                            const SizedBox(width: 4),
                            Text('Débloqué', style: TextStyle(color: SL.mainGreen, fontWeight: FontWeight.w800, fontSize: 12.5)),
                          ]),
                      ],
                    ),
                    if (w.header().isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(w.header(), style: TextStyle(color: SL.text, fontWeight: FontWeight.w700, fontSize: 14)),
                    ],
                    if (w.source.isNotEmpty)
                      Padding(padding: const EdgeInsets.only(top: 4), child: Text('@${w.source}', style: TextStyle(color: SL.dim, fontSize: 11.5))),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              // ----- volume & charge -----
              _card(
                'CHARGE DE TRAVAIL',
                Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('${st.points}', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: heat(loadBars / 5), height: 1, fontFeatures: _tab)),
                        const SizedBox(width: 6),
                        Padding(padding: const EdgeInsets.only(bottom: 4), child: Text('pts', style: TextStyle(color: SL.dim, fontSize: 14, fontWeight: FontWeight.w800))),
                        const Spacer(),
                        _stat('~${st.minutes}\u00A0min', w.type == 'amrap' || w.type == 'emom' ? 'durée' : 'estimée', c),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        for (var i = 0; i < 5; i++)
                          Expanded(
                            child: Container(
                              height: 8,
                              margin: const EdgeInsets.only(right: 4),
                              decoration: BoxDecoration(color: i < loadBars ? heat(loadBars / 5) : SL.faint, borderRadius: BorderRadius.circular(4)),
                            ),
                          ),
                        const SizedBox(width: 6),
                        Text(st.level, style: TextStyle(color: heat(loadBars / 5), fontSize: 12.5, fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              // ----- muscles -----
              _card(
                'MUSCLES SOLLICITÉS',
                Column(
                  children: [
                    MuscleHeatmap(data: muscles, height: 250),
                    const SizedBox(height: 6),
                    MuscleLegend(data: muscles),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              // ----- mouvements -----
              _card(
                'MOUVEMENTS',
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (final l in w.lines)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Text(l, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, height: 1.3)),
                      ),
                    if (w.notes.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text(w.notes, style: TextStyle(color: SL.dim, fontSize: 12.5, height: 1.4)),
                    ],
                  ],
                ),
              ),
            ],
          ),
          bottomNavigationBar: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: unlocked
                  ? FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: SL.steel, foregroundColor: SL.onAccent, minimumSize: const Size.fromHeight(52)),
                      icon: const Icon(Icons.play_arrow_rounded),
                      label: const Text('Lancer le WOD', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                      onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => WodRunScreen(wodId: w.id))),
                    )
                  : store.credits >= cost
                      ? FilledButton.icon(
                          style: FilledButton.styleFrom(backgroundColor: SL.inputYellow, foregroundColor: SL.onAccent, minimumSize: const Size.fromHeight(52)),
                          icon: const Icon(Icons.lock_open),
                          label: Text('Débloquer · $cost crédit${cost > 1 ? 's' : ''} (${store.credits} dispo)', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          onPressed: () {
                            if (store.unlockWod(w)) {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('« ${w.name} » débloqué.')));
                            }
                          },
                        )
                      : Container(
                          height: 52,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(color: SL.faint, borderRadius: BorderRadius.circular(14)),
                          child: Text(
                            'Il te manque ${cost - store.credits} crédit${cost - store.credits > 1 ? 's' : ''} · niveau ${store.level + 1} dans ${lp.need - lp.inLevel} XP',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: SL.dim, fontWeight: FontWeight.w700, fontSize: 13),
                          ),
                        ),
            ),
          ),
        );
      },
    );
  }

  Widget _card(String title, Widget child) => Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
        decoration: BoxDecoration(color: SL.card, borderRadius: BorderRadius.circular(16)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(color: SL.dim, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.6)),
            const SizedBox(height: 10),
            child,
          ],
        ),
      );

  Widget _stat(String value, String label, Color c) => Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: c, fontFeatures: _tab)),
          Text(label, style: TextStyle(color: SL.dim, fontSize: 11.5, fontWeight: FontWeight.w700)),
        ],
      );

  Widget _chip(String t, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(color: c.withOpacity(0.16), borderRadius: BorderRadius.circular(7)),
        child: Text(t, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: c, letterSpacing: 0.4)),
      );
}
