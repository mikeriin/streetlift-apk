import 'dart:async';

import 'package:flutter/material.dart';
import 'device.dart';

import 'timers.dart';
export 'timers.dart' show WodClock;
import 'levelup.dart';
import 'app_theme.dart';
import 'ui.dart';
import 'store.dart';
import 'wod_models.dart';
import 'wod_preview.dart';

Color wodColor(String type) {
  switch (type) {
    case 'rounds':
      return SL.inputYellow;
    case 'amrap':
      return SL.mainGreen;
    case 'emom':
      return SL.prevViolet;
    case 'routine':
      return SL.dim;
    default:
      return SL.steel;
  }
}

String fmtT(int s) {
  final h = s ~/ 3600, m = (s % 3600) ~/ 60, r = s % 60;
  final mm = m.toString().padLeft(h > 0 ? 2 : 1, '0');
  final ss = r.toString().padLeft(2, '0');
  return h > 0 ? '$h:$mm:$ss' : '$mm:$ss';
}

int? parseT(String text) {
  final normalized = text
      .trim()
      .replaceAll('’', ':')
      .replaceAll("'", ':')
      .replaceAll('"', '');
  if (!RegExp(r'^\d+(?::\d{1,2}){0,2}$').hasMatch(normalized)) return null;
  final parts = normalized.split(':').map(int.parse).toList();
  if (parts.skip(1).any((v) => v >= 60)) return null;
  final seconds = parts.fold(0, (sum, part) => sum * 60 + part);
  return seconds > 86400 ? null : seconds;
}

// ============================ HORLOGE WOD ==============================

// ============================ LISTE ====================================
// Corps seul (Scaffold + FAB dans l'onglet Perso).

void newWod(BuildContext context) => Navigator.push(
  context,
  MaterialPageRoute(
    builder: (_) => WodEditor(wod: Wod(id: store.newWodId(), name: '')),
  ),
);

// ============================ ÉDITEUR ==================================

class WodEditor extends StatefulWidget {
  final Wod wod;
  const WodEditor({super.key, required this.wod});
  @override
  State<WodEditor> createState() => _WodEditorState();
}

class _WodEditorState extends State<WodEditor> {
  late Wod w;
  late TextEditingController name,
      rounds,
      rest,
      minutes,
      interval,
      scheme,
      lines,
      notes,
      source;

  @override
  void initState() {
    super.initState();
    w = Wod.fromJson(widget.wod.toJson());
    name = TextEditingController(text: w.name);
    rounds = TextEditingController(text: w.rounds == 0 ? '' : '${w.rounds}');
    rest = TextEditingController(text: w.restSec == 0 ? '' : '${w.restSec}');
    minutes = TextEditingController(text: w.minutes == 0 ? '' : '${w.minutes}');
    interval = TextEditingController(text: '${w.interval}');
    scheme = TextEditingController(text: w.scheme);
    lines = TextEditingController(text: w.lines.join('\n'));
    notes = TextEditingController(text: w.notes);
    source = TextEditingController(text: w.source);
  }

  @override
  void dispose() {
    for (final c in [
      name,
      rounds,
      rest,
      minutes,
      interval,
      scheme,
      lines,
      notes,
      source,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    w.name = name.text.trim();
    if (w.name.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Donne un nom au WOD.')));
      return;
    }
    w.rounds = int.tryParse(rounds.text) ?? 0;
    w.restSec = int.tryParse(rest.text) ?? 0;
    w.minutes = int.tryParse(minutes.text) ?? 0;
    w.interval = int.tryParse(interval.text) ?? 60;
    w.scheme = scheme.text.trim();
    w.lines =
        lines.text
            .split('\n')
            .map((l) => l.trim())
            .where((l) => l.isNotEmpty)
            .toList();
    w.notes = notes.text.trim();
    w.source = source.text.trim();
    if (w.lines.isEmpty ||
        w.rounds < 0 ||
        w.rounds > 3600 ||
        w.restSec < 0 ||
        w.restSec > 86400 ||
        w.interval <= 0 ||
        w.interval > 86400 ||
        w.minutes < 0 ||
        w.minutes > 1440 ||
        (['rounds', 'emom'].contains(w.type) && w.rounds == 0) ||
        (w.type == 'amrap' && w.minutes == 0)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Vérifie les mouvements, les rounds et les durées (strictement positives).',
          ),
        ),
      );
      return;
    }
    store.upsertWod(w);
    Navigator.pop(context);
  }

  Widget _num(TextEditingController c, String label) => TextField(
    controller: c,
    keyboardType: TextInputType.number,
    decoration: InputDecoration(labelText: label),
  );

  @override
  Widget build(BuildContext context) {
    final t = w.type;
    return KScreen(
      appBar: AppBar(
        title: Text(
          widget.wod.name.isEmpty ? 'Créer un WOD' : 'Modifier le WOD',
        ),
      ),
      bottomNavigationBar: KBottomActions(
        child: FilledButton(
          onPressed: _save,
          child: const Text('Enregistrer le WOD'),
        ),
      ),
      body: KList(
        children: [
          TextField(
            controller: name,
            textAlign: TextAlign.left,
            decoration: const InputDecoration(labelText: 'Nom'),
          ),
          DropdownButtonFormField<String>(
            value: t,
            isExpanded: true,
            dropdownColor: SL.card,
            decoration: const InputDecoration(labelText: 'Format'),
            items: [
              for (final e in wodTypes.entries)
                DropdownMenuItem(value: e.key, child: Text(e.value)),
            ],
            onChanged: (v) => setState(() => w.type = v ?? 'fortime'),
          ),
          LayoutBuilder(
            builder: (context, constraints) {
              final fields = <Widget>[
                if (t == 'rounds' || t == 'emom')
                  _num(rounds, t == 'emom' ? 'Rounds (minutes)' : 'Rounds'),
                if (t == 'emom') _num(interval, 'Intervalle (s)'),
                if (t == 'amrap') _num(minutes, 'Durée (min)'),
                if (t != 'amrap' && t != 'emom')
                  _num(minutes, 'Temps limite (min)'),
                if (t != 'emom') _num(rest, 'Repos entre rounds (s)'),
              ];
              return Wrap(
                spacing: 12,
                runSpacing: 16,
                children: [
                  for (final field in fields)
                    SizedBox(
                      width:
                          constraints.maxWidth < 360
                              ? constraints.maxWidth
                              : (constraints.maxWidth - 12) / 2,
                      child: field,
                    ),
                ],
              );
            },
          ),
          const SizedBox(height: 6),
          Text(
            'La difficulté dépend des mouvements, du volume et du lest. Tes WODs personnels restent accessibles sans crédits.',
            style: TextStyle(color: SL.dim, fontSize: 11.5),
          ),
          TextField(
            controller: scheme,
            textAlign: TextAlign.left,
            decoration: const InputDecoration(
              labelText: 'Schéma (optionnel)',
              hintText: 'Ex. 21-15-9 ou 1→15',
            ),
          ),
          TextField(
            controller: lines,
            textAlign: TextAlign.left,
            maxLines: 8,
            minLines: 4,
            decoration: const InputDecoration(
              labelText: 'Mouvements',
              helperText: 'Une ligne par mouvement ou par bloc',
              alignLabelWithHint: true,
              hintText: '10 push-ups\n20 air squats\n30 sit-ups',
            ),
          ),
          TextField(
            controller: notes,
            textAlign: TextAlign.left,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Consignes (optionnel)',
            ),
          ),
          TextField(
            controller: source,
            textAlign: TextAlign.left,
            decoration: const InputDecoration(labelText: 'Source (optionnel)'),
          ),
        ],
      ),
    );
  }
}

// ============================ EXÉCUTION ================================

class WodRunScreen extends StatefulWidget {
  final String wodId;
  const WodRunScreen({super.key, required this.wodId});
  @override
  State<WodRunScreen> createState() => _WodRunScreenState();
}

class _WodRunScreenState extends State<WodRunScreen> {
  final clock = WodClock();

  Wod get w => store.wods.firstWhere((x) => x.id == widget.wodId);

  @override
  void initState() {
    super.initState();
    if (store.settings.wakelock) keepAwake(true);
    clock.addListener(_onClock);
  }

  @override
  void dispose() {
    keepAwake(false);
    clock.removeListener(_onClock);
    clock.dispose();
    super.dispose();
  }

  bool _prompted = false;
  bool _scoreOpen = false;
  bool _allowExit = false;
  void _onClock() {
    if (mounted && clock.finished && !_prompted && !_scoreOpen) {
      _prompted = true;
      Future.microtask(() {
        if (mounted) _score();
      });
    }
  }

  void _start() {
    _prompted = false;
    final wod = w;
    if (wod.type == 'amrap') {
      clock.startCountdown(wod.minutes * 60);
    } else if (wod.type == 'emom') {
      clock.startEmom(wod.rounds, wod.interval);
    } else {
      clock.startStopwatch(cap: wod.minutes * 60);
    }
  }

  void _round() {
    final wod = w;
    if (!clock.running || clock.restLeft > 0) return;
    final finalRound = wod.type == 'rounds' && clock.round + 1 >= wod.rounds;
    clock.lap(rest: finalRound ? 0 : wod.restSec);
    if (wod.type == 'rounds' && wod.rounds > 0 && clock.round >= wod.rounds) {
      clock.stop();
      _score();
    }
  }

  Future<void> _score() async {
    if (!mounted || _scoreOpen) return;
    _scoreOpen = true;
    clock.stop();
    final wod = w;
    final result = await showModalBottomSheet<WodResult>(
      context: context,
      isScrollControlled: true,
      builder:
          (_) => _ScoreSheet(
            wod: wod,
            elapsed: clock.elapsed,
            rounds:
                wod.type == 'emom'
                    ? clock.elapsed ~/ wod.interval
                    : clock.round,
            completed:
                !clock.capHit &&
                (wod.type != 'rounds' || clock.round >= wod.rounds),
          ),
    );
    if (!mounted) return;
    setState(() => _scoreOpen = false);
    if (result == null) return;
    store.addWodResult(wod, result);
    clock.reset();
    checkLevelUp(context);
  }

  Future<void> _leave() async {
    final ok = await showDialog<bool>(
      context: context,
      builder:
          (ctx) => AlertDialog(
            title: const Text('Quitter le WOD ?'),
            content: const Text(
              'Le chrono sera arrêté. Enregistre ton score avant de quitter si tu veux le conserver.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Continuer'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Quitter'),
              ),
            ],
          ),
    );
    if (ok == true && mounted) {
      setState(() => _allowExit = true);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        if (!store.wods.any((x) => x.id == widget.wodId)) {
          return const KScreen(body: SizedBox.shrink());
        }
        final wod = w;
        final c = wodColor(wod.type);
        final best = wod.best();
        final results = wod.results.reversed.toList();
        return ListenableBuilder(
          listenable: clock.active,
          builder:
              (context, _) => PopScope(
                canPop: _allowExit || !clock.started,
                onPopInvokedWithResult: (didPop, result) {
                  if (!didPop) _leave();
                },
                child: KScreen(
                  appBar: AppBar(
                    title: Text(
                      wod.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    actions: [
                      IconButton(
                        tooltip: 'Aperçu : volume, charge, muscles',
                        icon: const Icon(Icons.insights),
                        onPressed:
                            () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder:
                                    (_) => WodPreviewScreen(
                                      wodId: wod.id,
                                      fromRunner: true,
                                    ),
                              ),
                            ),
                      ),
                      IconButton(
                        tooltip: 'Modifier le WOD',
                        icon: const Icon(Icons.edit_outlined),
                        onPressed:
                            clock.started
                                ? null
                                : () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder:
                                        (_) => WodEditor(
                                          wod: Wod.fromJson(wod.toJson()),
                                        ),
                                  ),
                                ),
                      ),
                    ],
                  ),
                  body: KList(
                    children: [
                      // ----- chrono -----
                      ListenableBuilder(
                        listenable: clock,
                        builder: (context, _) {
                          final main =
                              clock.countdown ? clock.remaining : clock.elapsed;
                          final col =
                              clock.capHit
                                  ? SL.danger
                                  : (clock.restLeft > 0
                                      ? SL.inputYellow
                                      : (clock.running ? c : SL.text));
                          String sub = '';
                          if (wod.type == 'emom' && clock.started) {
                            sub =
                                'Minute ${clock.emomRound}/${clock.emomRounds}';
                          } else if (wod.type == 'rounds' && wod.rounds > 0) {
                            sub = 'Round ${clock.round}/${wod.rounds}';
                          } else if (clock.round > 0) {
                            sub =
                                '${clock.round} round${clock.round > 1 ? 's' : ''}';
                          }
                          if (clock.restLeft > 0) {
                            sub = 'REPOS ${fmtT(clock.restLeft)}  ·  $sub';
                          }
                          if (clock.capHit) sub = 'TIME CAP  ·  $sub';
                          return KCard(
                            child: Column(
                              children: [
                                FittedBox(
                                  fit: BoxFit.scaleDown,
                                  child: Text(
                                    fmtT(main),
                                    style: TextStyle(
                                      fontSize: 56,
                                      fontWeight: FontWeight.w900,
                                      color: col,
                                      height: 1,
                                      fontFeatures: const [
                                        FontFeature.tabularFigures(),
                                      ],
                                    ),
                                  ),
                                ),
                                if (sub.isNotEmpty)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 6),
                                    child: Text(
                                      sub,
                                      style: TextStyle(
                                        color: SL.dim,
                                        fontWeight: FontWeight.w800,
                                        fontSize: 12.5,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                  ),
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    Expanded(
                                      child: FilledButton.icon(
                                        style: FilledButton.styleFrom(
                                          backgroundColor:
                                              clock.running
                                                  ? SL.card
                                                  : SL.steel,
                                          foregroundColor:
                                              clock.running
                                                  ? SL.text
                                                  : SL.onAccent,
                                          side:
                                              clock.running
                                                  ? BorderSide(color: SL.dot)
                                                  : null,
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 12,
                                          ),
                                        ),
                                        icon: Icon(
                                          clock.running
                                              ? Icons.pause
                                              : Icons.play_arrow,
                                        ),
                                        label: Text(
                                          clock.finished
                                              ? 'Terminé'
                                              : clock.started
                                              ? (clock.running
                                                  ? 'Pause'
                                                  : 'Reprendre')
                                              : 'Démarrer',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                        onPressed:
                                            clock.finished
                                                ? null
                                                : () =>
                                                    clock.started
                                                        ? clock.toggle()
                                                        : _start(),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    if (wod.type != 'emom')
                                      Expanded(
                                        child: FilledButton.icon(
                                          style: FilledButton.styleFrom(
                                            backgroundColor: SL.inputYellow,
                                            foregroundColor: SL.onAccent,
                                            padding: const EdgeInsets.symmetric(
                                              vertical: 12,
                                            ),
                                          ),
                                          icon: const Icon(Icons.flag),
                                          label: const Text(
                                            'Round ✓',
                                            style: TextStyle(
                                              fontWeight: FontWeight.w800,
                                            ),
                                          ),
                                          onPressed:
                                              clock.running &&
                                                      clock.restLeft == 0
                                                  ? _round
                                                  : null,
                                        ),
                                      ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    Expanded(
                                      child: FilledButton.icon(
                                        style: FilledButton.styleFrom(
                                          backgroundColor: SL.mainGreen,
                                          foregroundColor: SL.onAccent,
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 12,
                                          ),
                                        ),
                                        icon: const Icon(Icons.check_circle),
                                        label: const Text(
                                          'Terminer',
                                          style: TextStyle(
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                        onPressed:
                                            clock.started ? _score : null,
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    IconButton(
                                      onPressed:
                                          clock.started ? clock.reset : null,
                                      icon: const Icon(Icons.restart_alt),
                                      tooltip: 'Remettre à zéro',
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      // ----- entête + mouvements -----
                      KCard(
                        accent: c,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${wod.typeLabel}${wod.header().isNotEmpty ? '  ·  ${wod.header()}' : ''}',
                              style: TextStyle(
                                color: c,
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                                letterSpacing: 0.4,
                              ),
                            ),
                            const SizedBox(height: 8),
                            for (final l in wod.lines)
                              Padding(
                                padding: const EdgeInsets.only(bottom: 2),
                                child: Text(
                                  l,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    height: 1.3,
                                  ),
                                ),
                              ),
                            if (wod.notes.isNotEmpty) ...[
                              const SizedBox(height: 6),
                              Text(
                                wod.notes,
                                style: TextStyle(
                                  color: SL.dim,
                                  fontSize: 12.5,
                                  height: 1.4,
                                ),
                              ),
                            ],
                            if (wod.source.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 6),
                                child: Text(
                                  '@${wod.source}',
                                  style: TextStyle(color: SL.dim, fontSize: 11),
                                ),
                              ),
                          ],
                        ),
                      ),
                      // ----- résultats -----
                      const KSection('Résultats'),
                      if (results.isEmpty)
                        const KEmpty(
                          icon: Icons.emoji_events_outlined,
                          title: 'Ton premier score',
                          message:
                              'Termine ce WOD pour enregistrer un résultat et suivre tes records.',
                        ),
                      for (final r in results)
                        KCard(
                          padding: EdgeInsets.zero,
                          child: ListTile(
                            leading: Icon(
                              identical(r, best)
                                  ? Icons.emoji_events
                                  : Icons.timer_outlined,
                              color: identical(r, best) ? SL.mainGreen : SL.dim,
                            ),
                            title: Text(
                              r.score,
                              style: TextStyle(
                                fontWeight: FontWeight.w800,
                                color:
                                    identical(r, best) ? SL.mainGreen : SL.text,
                              ),
                            ),
                            subtitle: Text(
                              '${_date(r.at)}${r.notes.isNotEmpty ? ' · ${r.notes}' : ''}',
                              style: const TextStyle(fontSize: 12),
                            ),
                            trailing: IconButton(
                              tooltip: 'Supprimer ce résultat',
                              icon: Icon(
                                Icons.delete_outline,
                                size: 20,
                                color: SL.dim,
                              ),
                              onPressed: () async {
                                final confirmed = await showDialog<bool>(
                                  context: context,
                                  builder:
                                      (ctx) => AlertDialog(
                                        title: const Text(
                                          'Supprimer ce résultat ?',
                                        ),
                                        content: Text(r.score),
                                        actions: [
                                          TextButton(
                                            onPressed:
                                                () => Navigator.pop(ctx, false),
                                            child: const Text('Annuler'),
                                          ),
                                          FilledButton(
                                            onPressed:
                                                () => Navigator.pop(ctx, true),
                                            child: const Text('Supprimer'),
                                          ),
                                        ],
                                      ),
                                );
                                if (confirmed == true) {
                                  store.deleteWodResult(wod, r);
                                }
                              },
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
        );
      },
    );
  }

  String _date(String iso) {
    final d = DateTime.tryParse(iso);
    if (d == null) return '';
    return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
  }
}

class _ScoreSheet extends StatefulWidget {
  final Wod wod;
  final int elapsed, rounds;
  final bool completed;
  const _ScoreSheet({
    required this.wod,
    required this.elapsed,
    required this.rounds,
    required this.completed,
  });
  @override
  State<_ScoreSheet> createState() => _ScoreSheetState();
}

class _ScoreSheetState extends State<_ScoreSheet> {
  final form = GlobalKey<FormState>();
  late final time = TextEditingController(text: fmtT(widget.elapsed));
  late final rounds = TextEditingController(text: '${widget.rounds}');
  final reps = TextEditingController(text: '0');
  final notes = TextEditingController();
  late bool completed = widget.completed;

  @override
  void dispose() {
    for (final c in [time, rounds, reps, notes]) {
      c.dispose();
    }
    super.dispose();
  }

  String? _count(String? text) {
    final n = int.tryParse(text ?? '');
    return n == null || n < 0 || n > 1000000
        ? 'Nombre entier positif ou nul'
        : null;
  }

  void _save() {
    if (!form.currentState!.validate()) return;
    final at = DateTime.now().toIso8601String();
    if (widget.wod.timed) {
      final seconds = parseT(time.text)!;
      Navigator.pop(
        context,
        WodResult(
          at: at,
          seconds: seconds,
          rounds: widget.rounds,
          score: '${completed ? '' : 'Incomplet · '}${fmtT(seconds)}',
          completed: completed,
          notes: notes.text.trim(),
        ),
      );
    } else {
      final rd = int.parse(rounds.text), rp = int.parse(reps.text);
      Navigator.pop(
        context,
        WodResult(
          at: at,
          seconds: widget.elapsed,
          rounds: rd,
          reps: rp,
          notes: notes.text.trim(),
          score: '$rd round${rd > 1 ? 's' : ''}${rp > 0 ? ' + $rp' : ''}',
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(
        16,
        12,
        16,
        MediaQuery.viewInsetsOf(context).bottom + 16,
      ),
      child: Form(
        key: form,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'SCORE',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
            ),
            const SizedBox(height: 8),
            if (widget.wod.timed) ...[
              TextFormField(
                controller: time,
                keyboardType: TextInputType.datetime,
                decoration: const InputDecoration(
                  labelText: 'Temps (mm:ss ou hh:mm:ss)',
                ),
                validator:
                    (text) =>
                        (parseT(text ?? '') ?? 0) <= 0
                            ? 'Saisis un temps valide supérieur à zéro.'
                            : null,
              ),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: completed,
                title: const Text('WOD entièrement terminé'),
                subtitle: const Text(
                  'Un résultat incomplet ne compte pas comme record.',
                ),
                onChanged:
                    (value) => setState(() => completed = value ?? false),
              ),
            ] else
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: rounds,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Rounds terminés',
                      ),
                      validator: _count,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextFormField(
                      controller: reps,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: '+ reps'),
                      validator: _count,
                    ),
                  ),
                ],
              ),
            TextField(
              controller: notes,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Notes (RX, adaptation, pénalités…)',
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Annuler'),
                ),
                const Spacer(),
                FilledButton(
                  onPressed: _save,
                  child: const Text('Enregistrer'),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}
