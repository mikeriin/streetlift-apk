import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'alerts.dart';
import 'levelup.dart';
import 'main.dart';
import 'store.dart';
import 'wod_models.dart';
import 'wod_preview.dart';

Color wodColor(String type) {
  switch (type) {
    case 'rounds':
      return SL.inputYellow;
    case 'amrap':
      return SL.mainGreen;
    case 'emom':
      return SL.prevViolet;
    case 'routine':
      return SL.dim;
    default:
      return SL.steel;
  }
}

String fmtT(int s) {
  final h = s ~/ 3600, m = (s % 3600) ~/ 60, r = s % 60;
  final mm = m.toString().padLeft(h > 0 ? 2 : 1, '0');
  final ss = r.toString().padLeft(2, '0');
  return h > 0 ? '$h:$mm:$ss' : '$mm:$ss';
}

int? parseT(String t) {
  final s = t.trim().replaceAll('\u2019', ':').replaceAll("'", ':').replaceAll('"', '');
  if (s.isEmpty) return null;
  final parts = s.split(':').map((p) => int.tryParse(p.trim())).toList();
  if (parts.any((p) => p == null)) return null;
  if (parts.length == 1) return parts[0];
  if (parts.length == 2) return parts[0]! * 60 + parts[1]!;
  return parts[0]! * 3600 + parts[1]! * 60 + parts[2]!;
}

// ============================ HORLOGE WOD ==============================

class WodClock extends ChangeNotifier {
  Timer? _t;
  bool running = false;
  bool started = false;
  bool finished = false;
  bool countdown = false; // AMRAP / EMOM
  int elapsed = 0;
  int remaining = 0;
  int restLeft = 0; // repos inter-rounds, en parallèle du chrono
  int round = 0;
  int emomRound = 0, emomRounds = 0, emomInterval = 0;
  int capSec = 0;
  bool capHit = false;
  final List<int> laps = [];

  // Horloge murale : exact même après un passage en arrière-plan.
  DateTime? _startAt;
  int _acc = 0;
  DateTime? _deadline;
  DateTime? _restDeadline;

  void _run() {
    _t?.cancel();
    final now = DateTime.now();
    _startAt = now;
    if (countdown) _deadline = now.add(Duration(seconds: remaining));
    _restDeadline = restLeft > 0 ? now.add(Duration(seconds: restLeft)) : null;
    running = true;
    started = true;
    _t = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
    notifyListeners();
  }

  void startStopwatch({int cap = 0}) {
    countdown = false;
    capSec = cap;
    _run();
  }

  void startCountdown(int sec) {
    countdown = true;
    remaining = sec;
    _run();
  }

  void startEmom(int rounds, int interval) {
    emomRounds = rounds;
    emomInterval = interval;
    emomRound = 1;
    startCountdown(interval);
  }

  void toggle() {
    if (!started || finished) return;
    if (running) {
      _t?.cancel();
      _tick(); // fige les valeurs exactes
      _acc = elapsed;
      running = false;
      notifyListeners();
    } else {
      _run();
    }
  }

  void lap({int rest = 0}) {
    if (!running) return;
    round++;
    laps.add(elapsed);
    if (rest > 0) {
      restLeft = rest;
      _restDeadline = DateTime.now().add(Duration(seconds: rest));
    }
    notifyListeners();
  }

  void stop() {
    _t?.cancel();
    if (running) _tick();
    _acc = elapsed;
    running = false;
    notifyListeners();
  }

  void reset() {
    _t?.cancel();
    running = false;
    started = false;
    finished = false;
    countdown = false;
    elapsed = 0;
    remaining = 0;
    restLeft = 0;
    round = 0;
    emomRound = 0;
    emomRounds = 0;
    capHit = false;
    _acc = 0;
    _deadline = null;
    _restDeadline = null;
    laps.clear();
    notifyListeners();
  }

  void _tick() {
    if (!running) return;
    final now = DateTime.now();
    elapsed = _acc + now.difference(_startAt!).inSeconds;
    if (_restDeadline != null) {
      final left = (_restDeadline!.difference(now).inMilliseconds / 1000).ceil();
      if (left <= 0) {
        restLeft = 0;
        _restDeadline = null;
        alertBeep();
      } else {
        restLeft = left;
      }
    }
    if (countdown) {
      remaining = (_deadline!.difference(now).inMilliseconds / 1000).ceil();
      while (remaining <= 0) {
        if (emomRounds > 0 && emomRound < emomRounds) {
          alertBeep();
          emomRound++;
          _deadline = _deadline!.add(Duration(seconds: emomInterval));
          remaining = (_deadline!.difference(now).inMilliseconds / 1000).ceil();
        } else {
          alertAlarm();
          remaining = 0;
          running = false;
          finished = true;
          _t?.cancel();
          break;
        }
      }
    } else if (capSec > 0 && !capHit && elapsed >= capSec) {
      capHit = true;
      alertAlarm();
    }
    notifyListeners();
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }
}

// ============================ LISTE ====================================
// Corps seul (Scaffold + FAB dans l'onglet Perso).

void newWod(BuildContext context) => Navigator.push(
    context, MaterialPageRoute(builder: (_) => WodEditor(wod: Wod(id: store.newWodId(), name: ''))));

// ============================ ÉDITEUR ==================================

class WodEditor extends StatefulWidget {
  final Wod wod;
  const WodEditor({super.key, required this.wod});
  @override
  State<WodEditor> createState() => _WodEditorState();
}

class _WodEditorState extends State<WodEditor> {
  late Wod w;
  late TextEditingController name, rounds, rest, minutes, interval, scheme, lines, notes, source, levelCtl;

  @override
  void initState() {
    super.initState();
    w = widget.wod;
    name = TextEditingController(text: w.name);
    rounds = TextEditingController(text: w.rounds == 0 ? '' : '${w.rounds}');
    rest = TextEditingController(text: w.restSec == 0 ? '' : '${w.restSec}');
    minutes = TextEditingController(text: w.minutes == 0 ? '' : '${w.minutes}');
    interval = TextEditingController(text: '${w.interval}');
    scheme = TextEditingController(text: w.scheme);
    lines = TextEditingController(text: w.lines.join('\n'));
    notes = TextEditingController(text: w.notes);
    source = TextEditingController(text: w.source);
    levelCtl = TextEditingController(text: '${w.level}');
  }

  @override
  void dispose() {
    for (final c in [name, rounds, rest, minutes, interval, scheme, lines, notes, source, levelCtl]) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    w.name = name.text.trim();
    if (w.name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Donne un nom au WOD.')));
      return;
    }
    w.rounds = int.tryParse(rounds.text) ?? 0;
    w.restSec = int.tryParse(rest.text) ?? 0;
    w.minutes = int.tryParse(minutes.text) ?? 0;
    w.interval = int.tryParse(interval.text) ?? 60;
    w.scheme = scheme.text.trim();
    w.lines = lines.text.split('\n').map((l) => l.trim()).where((l) => l.isNotEmpty).toList();
    w.notes = notes.text.trim();
    w.source = source.text.trim();
    w.level = (int.tryParse(levelCtl.text) ?? 1).clamp(1, 10);
    if (w.type == 'emom' && w.rounds == 0) w.rounds = 10;
    if (w.type == 'amrap' && w.minutes == 0) w.minutes = 10;
    store.upsertWod(w);
    Navigator.pop(context);
  }

  Widget _num(TextEditingController c, String label) => SizedBox(
        width: (MediaQuery.of(context).size.width - 44) / 2,
        child: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: label),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final t = w.type;
    return Scaffold(
      appBar: AppBar(
        title: const Text('ÉDITEUR WOD'),
        actions: [IconButton(onPressed: _save, icon: Icon(Icons.check, color: SL.mainGreen))],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 6, 14, 30),
        children: [
          TextField(controller: name, textAlign: TextAlign.left, decoration: const InputDecoration(labelText: 'Nom')),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: t,
            dropdownColor: SL.card,
            decoration: const InputDecoration(labelText: 'Format'),
            items: [for (final e in wodTypes.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
            onChanged: (v) => setState(() => w.type = v ?? 'fortime'),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              if (t == 'rounds' || t == 'emom') _num(rounds, t == 'emom' ? 'Rounds (minutes)' : 'Rounds'),
              if (t == 'emom') _num(interval, 'Intervalle (s)'),
              if (t == 'amrap') _num(minutes, 'Durée (min)'),
              if (t != 'amrap' && t != 'emom') _num(minutes, 'Time cap (min, optionnel)'),
              if (t != 'emom') _num(rest, 'Repos entre rounds (s)'),
              _num(levelCtl, 'Niveau requis (1-10)'),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
              controller: scheme,
              textAlign: TextAlign.left,
              decoration: const InputDecoration(labelText: 'Schéma (ex. 21-15-9, 1→15, 20/1→1/20)')),
          const SizedBox(height: 10),
          TextField(
            controller: lines,
            textAlign: TextAlign.left,
            maxLines: 8,
            minLines: 4,
            decoration: const InputDecoration(
                labelText: 'Mouvements — une ligne par mouvement ou par bloc',
                alignLabelWithHint: true,
                hintText: '10 push-ups\n20 air squats\n30 sit-ups'),
          ),
          const SizedBox(height: 10),
          TextField(
              controller: notes,
              textAlign: TextAlign.left,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Notes (pénalités, objectifs, team…)')),
          const SizedBox(height: 10),
          TextField(controller: source, textAlign: TextAlign.left, decoration: const InputDecoration(labelText: 'Source (optionnel)')),
        ],
      ),
    );
  }
}

// ============================ EXÉCUTION ================================

class WodRunScreen extends StatefulWidget {
  final String wodId;
  const WodRunScreen({super.key, required this.wodId});
  @override
  State<WodRunScreen> createState() => _WodRunScreenState();
}

class _WodRunScreenState extends State<WodRunScreen> {
  final clock = WodClock();

  Wod get w => store.wods.firstWhere((x) => x.id == widget.wodId);

  @override
  void initState() {
    super.initState();
    if (store.settings.wakelock) WakelockPlus.enable();
    clock.addListener(_onClock);
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    clock.removeListener(_onClock);
    clock.dispose();
    super.dispose();
  }

  bool _prompted = false;
  void _onClock() {
    if (clock.finished && !_prompted) {
      _prompted = true;
      Future.microtask(() => _score());
    }
  }

  void _start() {
    _prompted = false;
    final wod = w;
    if (wod.type == 'amrap') {
      clock.startCountdown(wod.minutes * 60);
    } else if (wod.type == 'emom') {
      clock.startEmom(wod.rounds, wod.interval);
    } else {
      clock.startStopwatch(cap: wod.minutes * 60);
    }
  }

  void _round() {
    final wod = w;
    clock.lap(rest: wod.restSec);
    if (wod.type == 'rounds' && wod.rounds > 0 && clock.round >= wod.rounds) {
      clock.stop();
      _score();
    }
  }

  Future<void> _score() async {
    final wod = w;
    clock.stop();
    final timeCtl = TextEditingController(text: fmtT(clock.elapsed));
    final roundsCtl = TextEditingController(
        text: '${wod.type == 'emom' ? clock.emomRound : clock.round}');
    final repsCtl = TextEditingController();
    final notesCtl = TextEditingController();
    final timed = wod.timed;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(ctx).viewInsets.bottom + 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('SCORE', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
            const SizedBox(height: 10),
            if (timed)
              TextField(
                  controller: timeCtl,
                  decoration: const InputDecoration(labelText: 'Temps (mm:ss)'),
                  keyboardType: TextInputType.datetime)
            else
              Row(children: [
                Expanded(
                    child: TextField(
                        controller: roundsCtl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Rounds'))),
                const SizedBox(width: 8),
                Expanded(
                    child: TextField(
                        controller: repsCtl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: '+ reps'))),
              ]),
            const SizedBox(height: 8),
            TextField(
                controller: notesCtl,
                textAlign: TextAlign.left,
                decoration: const InputDecoration(labelText: 'Notes (RX, scaled, pénalités…)')),
            const SizedBox(height: 14),
            Row(children: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
              const Spacer(),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: SL.mainGreen, foregroundColor: SL.onAccent),
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Enregistrer', style: TextStyle(fontWeight: FontWeight.w800)),
              ),
            ]),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    WodResult r;
    if (timed) {
      final sec = parseT(timeCtl.text) ?? clock.elapsed;
      r = WodResult(at: DateTime.now().toIso8601String(), score: fmtT(sec), seconds: sec, notes: notesCtl.text.trim());
    } else {
      final rd = int.tryParse(roundsCtl.text) ?? 0;
      final rp = int.tryParse(repsCtl.text) ?? 0;
      r = WodResult(
          at: DateTime.now().toIso8601String(),
          score: '$rd round${rd > 1 ? 's' : ''}${rp > 0 ? ' + $rp' : ''}',
          rounds: rd,
          reps: rp,
          notes: notesCtl.text.trim());
    }
    store.addWodResult(w, r);
    clock.reset();
    setState(() {});
    if (mounted) checkLevelUp(context);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        if (!store.wods.any((x) => x.id == widget.wodId)) {
          return const Scaffold(body: SizedBox.shrink());
        }
        final wod = w;
        final c = wodColor(wod.type);
        final best = wod.best();
        final results = wod.results.reversed.toList();
        return Scaffold(
          appBar: AppBar(
            title: Text(wod.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            actions: [
              IconButton(
                tooltip: 'Aperçu : volume, charge, muscles',
                icon: const Icon(Icons.insights),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WodPreviewScreen(wodId: wod.id))),
              ),
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                onPressed: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => WodEditor(wod: Wod.fromJson(wod.toJson())))),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 30),
            children: [
              // ----- entête + mouvements -----
              Container(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                decoration: BoxDecoration(
                  color: SL.card,
                  borderRadius: BorderRadius.circular(16),
                  border: Border(left: BorderSide(color: c, width: 4)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${wod.typeLabel.toUpperCase()}${wod.header().isNotEmpty ? '  ·  ${wod.header()}' : ''}',
                        style: TextStyle(color: c, fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 0.4)),
                    const SizedBox(height: 8),
                    for (final l in wod.lines)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Text(l, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, height: 1.3)),
                      ),
                    if (wod.notes.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text(wod.notes, style: TextStyle(color: SL.dim, fontSize: 12.5, height: 1.4)),
                    ],
                    if (wod.source.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text('@${wod.source}', style: TextStyle(color: SL.dim, fontSize: 11)),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              // ----- chrono -----
              ListenableBuilder(
                listenable: clock,
                builder: (context, _) {
                  final main = clock.countdown ? clock.remaining : clock.elapsed;
                  final col = clock.capHit
                      ? SL.danger
                      : (clock.restLeft > 0 ? SL.inputYellow : (clock.running ? c : SL.text));
                  String sub = '';
                  if (wod.type == 'emom' && clock.started) {
                    sub = 'Minute ${clock.emomRound}/${clock.emomRounds}';
                  } else if (wod.type == 'rounds' && wod.rounds > 0) {
                    sub = 'Round ${clock.round}/${wod.rounds}';
                  } else if (clock.round > 0) {
                    sub = '${clock.round} round${clock.round > 1 ? 's' : ''}';
                  }
                  if (clock.restLeft > 0) sub = 'REPOS ${fmtT(clock.restLeft)}  ·  $sub';
                  if (clock.capHit) sub = 'TIME CAP  ·  $sub';
                  return Container(
                    padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
                    decoration: BoxDecoration(color: SL.card, borderRadius: BorderRadius.circular(16)),
                    child: Column(
                      children: [
                        Text(fmtT(main),
                            style: TextStyle(
                                fontSize: 56,
                                fontWeight: FontWeight.w900,
                                color: col,
                                height: 1,
                                fontFeatures: const [FontFeature.tabularFigures()])),
                        if (sub.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text(sub,
                                style: TextStyle(color: SL.dim, fontWeight: FontWeight.w800, fontSize: 12.5, letterSpacing: 0.5)),
                          ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton.icon(
                                style: FilledButton.styleFrom(
                                    backgroundColor: clock.running ? SL.card : c,
                                    foregroundColor: clock.running ? SL.text : SL.onAccent,
                                    side: clock.running ? BorderSide(color: SL.dot) : null,
                                    padding: const EdgeInsets.symmetric(vertical: 12)),
                                icon: Icon(clock.running ? Icons.pause : Icons.play_arrow),
                                label: Text(clock.started ? (clock.running ? 'Pause' : 'Reprendre') : 'Démarrer',
                                    style: const TextStyle(fontWeight: FontWeight.w800)),
                                onPressed: () => clock.started ? clock.toggle() : _start(),
                              ),
                            ),
                            const SizedBox(width: 8),
                            if (wod.type != 'emom')
                              Expanded(
                                child: FilledButton.icon(
                                  style: FilledButton.styleFrom(
                                      backgroundColor: SL.inputYellow,
                                      foregroundColor: SL.onAccent,
                                      padding: const EdgeInsets.symmetric(vertical: 12)),
                                  icon: const Icon(Icons.flag),
                                  label: const Text('Round ✓', style: TextStyle(fontWeight: FontWeight.w800)),
                                  onPressed: clock.running ? _round : null,
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton.icon(
                                style: FilledButton.styleFrom(
                                    backgroundColor: SL.mainGreen,
                                    foregroundColor: SL.onAccent,
                                    padding: const EdgeInsets.symmetric(vertical: 12)),
                                icon: const Icon(Icons.check_circle),
                                label: const Text('Terminer & scorer', style: TextStyle(fontWeight: FontWeight.w800)),
                                onPressed: clock.started ? _score : null,
                              ),
                            ),
                            const SizedBox(width: 8),
                            IconButton(
                                onPressed: clock.started ? clock.reset : null,
                                icon: const Icon(Icons.restart_alt),
                                tooltip: 'Remettre à zéro'),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
              // ----- résultats -----
              Padding(
                padding: EdgeInsets.fromLTRB(4, 16, 4, 6),
                child: Text('RÉSULTATS',
                    style: TextStyle(color: SL.dim, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 0.6)),
              ),
              if (results.isEmpty)
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 4),
                  child: Text('Aucun score pour l\u2019instant.', style: TextStyle(color: SL.dim)),
                ),
              for (final r in results)
                Card(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  child: ListTile(
                    dense: true,
                    leading: Icon(identical(r, best) ? Icons.emoji_events : Icons.timer_outlined,
                        color: identical(r, best) ? SL.mainGreen : SL.dim),
                    title: Text(r.score,
                        style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: identical(r, best) ? SL.mainGreen : SL.text)),
                    subtitle: Text(
                        '${_date(r.at)}${r.notes.isNotEmpty ? ' · ${r.notes}' : ''}',
                        style: const TextStyle(fontSize: 12)),
                    trailing: IconButton(
                      icon: Icon(Icons.close, size: 18, color: SL.dim),
                      onPressed: () => store.deleteWodResult(wod, r),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  String _date(String iso) {
    final d = DateTime.tryParse(iso);
    if (d == null) return '';
    return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
  }
}
