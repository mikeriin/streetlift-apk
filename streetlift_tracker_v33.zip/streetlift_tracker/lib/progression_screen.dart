import 'package:flutter/material.dart';
import 'ui.dart';
import 'progression.dart';
import 'store.dart';
import 'wod_catalog.dart';

void openProgression(BuildContext context) => Navigator.of(
  context,
).push(MaterialPageRoute(builder: (_) => const ProgressionScreen()));

class ProgressionScreen extends StatelessWidget {
  const ProgressionScreen({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      final p = store.progression;
      return DefaultTabController(
        length: 2,
        child: KScreen(
          appBar: AppBar(
            title: const Text('MA PROGRESSION'),
            bottom: TabBar(
              tabs: [
                const Tab(text: 'Parcours'),
                Tab(text: 'Badges · ${p.earnedBadges}/${p.badges.length}'),
              ],
            ),
            actions: [
              IconButton(
                tooltip: 'Comprendre les XP',
                icon: const Icon(Icons.info_outline),
                onPressed: () => _rules(context),
              ),
            ],
          ),
          body: TabBarView(children: [_Journey(p), _Badges(p)]),
        ),
      );
    },
  );
}

class _Journey extends StatelessWidget {
  final Progression p;
  const _Journey(this.p);
  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    final next = p.nextRank;
    return ListView(
      padding: KSpace.content,
      children: [
        KProgressCard(
          level: p.level,
          credits: store.credits,
          inLevel: p.inLevel,
          need: p.need,
          rank: p.rank.title,
          detailed: true,
        ),
        const SizedBox(height: 8),
        KCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Prochaines récompenses',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              Text(
                'Niveau ${p.level + 1} : +${p.nextCredits} crédit${p.nextCredits > 1 ? 's' : ''}',
              ),
              if (next != null) ...[
                const SizedBox(height: 4),
                Text('Rang ${next.title} au niveau ${next.level}'),
              ],
              const SizedBox(height: 8),
              Text(
                '${p.totalXp} XP cumulés · ${p.earnedBadges} badges obtenus',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed:
              () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const WodCatalogScreen()),
              ),
          icon: const Icon(Icons.grid_view_rounded),
          label: const Text('Explorer les WODs'),
        ),
        _heading(context, 'Cette semaine'),
        Text(
          'Du ${_date(p.week.monday)} au ${_date(p.week.monday.add(const Duration(days: 6)))} · bonus attribués automatiquement',
          style: TextStyle(color: c.onSurfaceVariant),
        ),
        const SizedBox(height: 8),
        for (final mission in p.week.missions) _Mission(mission),
        const SizedBox(height: 8),
        const Text(
          'Les jours de repos ne cassent pas ta régularité. Deux jours d’entraînement distincts suffisent pour valider une semaine ; les autres objectifs restent facultatifs.',
        ),
        _heading(context, 'Régularité'),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _Metric('${p.currentStreak}', 'semaines de suite'),
            _Metric('${p.bestStreak}', 'meilleure série'),
            _Metric('${p.activeWeeks}', 'semaines validées'),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          '8 dernières semaines · jours actifs',
          style: TextStyle(color: c.onSurfaceVariant),
        ),
        const SizedBox(height: 8),
        LayoutBuilder(
          builder:
              (context, constraints) => Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final week in p.recentWeeks)
                    Tooltip(
                      message:
                          'Semaine du ${_date(week.monday)} : ${week.activeDays.length} jours actifs',
                      child: Container(
                        width: (constraints.maxWidth - 18) / 4,
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color:
                              week.activeDays.length >= 2
                                  ? c.primary.withValues(alpha: 0.16)
                                  : c.surfaceContainerHighest,
                        ),
                        child: Column(
                          children: [
                            Text(
                              _date(week.monday),
                              style: const TextStyle(fontSize: 11),
                            ),
                            Text(
                              '${week.activeDays.length} j',
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
        ),
        _heading(context, 'Tes XP en détail'),
        _XpRow('Séances du programme', p.programXp),
        _XpRow('Séances personnelles', p.customXp),
        _XpRow('Tentatives WOD enregistrées', p.wodXp),
        _XpRow('Références et records WOD', p.recordXp),
        _XpRow('Objectifs hebdomadaires', p.weeklyXp),
        _XpRow('Badges', p.badgeXp),
        const Divider(),
        _XpRow('Total', p.totalXp, strong: true),
        _heading(context, 'Les rangs à atteindre'),
        for (final rank in progressRanks)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(
              p.level >= rank.level ? Icons.verified : Icons.lock_outline,
              color: p.level >= rank.level ? c.primary : c.onSurfaceVariant,
            ),
            title: Text(rank.title),
            subtitle: Text('À partir du niveau ${rank.level}'),
            trailing: rank == p.rank ? const Chip(label: Text('Actuel')) : null,
          ),
        const SizedBox(height: 8),
      ],
    );
  }
}

Widget _heading(BuildContext context, String title) => Padding(
  padding: const EdgeInsets.only(top: 10, bottom: 6),
  child: KSection(title, topPadding: 0),
);
String _date(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}';

class _Bar extends StatelessWidget {
  final double value;
  final String label;
  const _Bar(this.value, this.label);
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(8),
    child: LinearProgressIndicator(
      value: value,
      color: Theme.of(context).colorScheme.primary,
      backgroundColor: Theme.of(
        context,
      ).colorScheme.onSurface.withValues(alpha: 0.12),
      minHeight: 5,
      semanticsLabel: label,
      semanticsValue: '${(value * 100).round()} %',
    ),
  );
}

class _Metric extends StatelessWidget {
  final String value, label;
  const _Metric(this.value, this.label);
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(12),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          value,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
        ),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    ),
  );
}

class _Mission extends StatelessWidget {
  final WeeklyMission mission;
  const _Mission(this.mission);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: KCard(
      padding: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  mission.complete
                      ? Icons.check_circle
                      : Icons.radio_button_unchecked,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    mission.title,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '+${mission.xp} XP',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(mission.detail),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(child: _Bar(mission.fraction, mission.title)),
                const SizedBox(width: 10),
                Tooltip(
                  message:
                      mission.complete
                          ? 'Objectif atteint · bonus inclus'
                          : mission.detail,
                  child: Text(
                    mission.complete
                        ? 'Validé'
                        : '${mission.current} / ${mission.target}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}

class _XpRow extends StatelessWidget {
  final String title;
  final int xp;
  final bool strong;
  const _XpRow(this.title, this.xp, {this.strong = false});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              fontWeight: strong ? FontWeight.w600 : FontWeight.w400,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Text('$xp XP', style: const TextStyle(fontWeight: FontWeight.w700)),
      ],
    ),
  );
}

class _Badges extends StatelessWidget {
  final Progression p;
  const _Badges(this.p);
  @override
  Widget build(BuildContext context) {
    final badges = [...p.badges]..sort((a, b) {
      if (a.earned != b.earned) return a.earned ? -1 : 1;
      return b.fraction.compareTo(a.fraction);
    });
    return ListView(
      padding: KSpace.content,
      children: [
        const Text(
          'Chaque badge rapporte son bonus une seule fois. Ton historique compte dès la mise à jour.',
        ),
        const SizedBox(height: 8),
        for (final item in badges)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: KCard(
              padding: EdgeInsets.zero,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          item.earned
                              ? Icons.workspace_premium
                              : Icons.workspace_premium_outlined,
                          color: Theme.of(context).colorScheme.primary,
                          size: 28,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            item.badge.title,
                            style: const TextStyle(fontWeight: FontWeight.w600),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text('+${item.badge.xp} XP'),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(item.badge.description),
                    const SizedBox(height: 10),
                    _Bar(item.fraction, item.badge.description),
                    const SizedBox(height: 6),
                    Text(
                      item.earned
                          ? 'Obtenu · bonus inclus'
                          : '${item.current} / ${item.badge.target}',
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}

void _rules(BuildContext context) => showModalBottomSheet<void>(
  context: context,
  isScrollControlled: true,
  useSafeArea: true,
  builder:
      (context) => FractionallySizedBox(
        heightFactor: 0.85,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text(
              'Comment progresser',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            const Text(
              'Le barème de base est conservé : 100 XP pour une journée du programme validée, 60 XP pour une séance personnelle et 80 XP par tentative WOD enregistrée. Une première performance WOD valide rapporte 40 XP, puis chaque amélioration stricte de ce record rapporte 40 XP supplémentaires. Une égalité ou un WOD inachevé ne rapporte pas de bonus de record.',
            ),
            const SizedBox(height: 14),
            const Text(
              'Les badges et les objectifs hebdomadaires ajoutent des bonus automatiques. Les objectifs se renouvellent le lundi et leurs bonus passés restent calculés depuis le journal. Deux séances le même jour comptent pour un seul jour actif. Les jours de récupération du programme ne comptent pas comme des entraînements pour ces bonus.',
            ),
            const SizedBox(height: 14),
            const Text(
              'Une semaine avec 2 jours actifs prolonge la série de régularité. La semaine en cours peut encore être complétée : elle ne casse pas la série avant le lundi suivant. Aucun entraînement quotidien n’est exigé.',
            ),
            const SizedBox(height: 14),
            const Text(
              'Chaque niveau donne 1 crédit WOD. Tous les 5 niveaux : 1 crédit bonus ; tous les 10 niveaux : encore 1 crédit bonus. Les WODs déjà débloqués restent accessibles.',
            ),
            const SizedBox(height: 14),
            const Text(
              'Les XP sont recalculés depuis tes données : supprimer un résultat ou une séance retire les XP et bonus associés. Réimporter la même sauvegarde ne double aucune récompense. Les anciennes séances sans date utilisent, si possible, la date prévue du programme ; une séance personnelle sans date ne compte pas pour les bonus de régularité.',
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Compris'),
            ),
          ],
        ),
      ),
);
