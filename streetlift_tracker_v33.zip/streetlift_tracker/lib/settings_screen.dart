import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'main.dart';
import 'notifications.dart';
import 'store.dart';

const kAppVersion = '1.0.1';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final s = store.settings;
        void save() => store.saveSettings();
        return Scaffold(
          appBar: AppBar(title: const Text('RÉGLAGES')),
          body: ListView(
            padding: const EdgeInsets.only(bottom: 28),
            children: [
              const _Sec('THÈME'),
              _Tile(
                title: 'Apparence',
                subtitle: 'Système suit le mode sombre du téléphone',
                below: SegmentedButton<String>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: 'system', label: Text('Système'), icon: Icon(Icons.brightness_auto, size: 18)),
                    ButtonSegment(value: 'dark', label: Text('Sombre'), icon: Icon(Icons.dark_mode, size: 18)),
                    ButtonSegment(value: 'light', label: Text('Clair'), icon: Icon(Icons.light_mode, size: 18)),
                  ],
                  selected: {s.theme},
                  onSelectionChanged: (v) {
                    s.theme = v.first;
                    save();
                  },
                ),
              ),
              const _Sec('SAISIE DES SÉRIES'),
              _Sw('Colonne RIR / RPE par défaut', 'Sinon activable par exercice (icône ⚙ sous les séries)', s.trackRir, (v) {
                s.trackRir = v;
                save();
              }),
              _Sw('Colonne vitesse (m/s) sur les lifts', 'Pour le VBT ; activable par exercice', s.trackVelocity, (v) {
                s.trackVelocity = v;
                save();
              }),
              _Sw('Échelle RPE au lieu de RIR', null, s.rpe, (v) {
                s.rpe = v;
                save();
              }),
              _Sw('Pré-remplir charge suggérée et reps prévues', null, s.prefill, (v) {
                s.prefill = v;
                save();
              }),
              const _Sec('CHRONO'),
              _Stepper(
                title: 'Repos par défaut',
                subtitle: 'Quand l\u2019exercice n\u2019en précise pas',
                value: s.defaultRest,
                unit: 's',
                min: 0,
                max: 300,
                step: 15,
                onChanged: (v) {
                  s.defaultRest = v;
                  save();
                },
              ),
              _Sw('Lancer le repos à la validation d\u2019une série', null, s.autoTimer, (v) {
                s.autoTimer = v;
                save();
              }),
              _Stepper(
                title: 'Décompte « Prêt »',
                subtitle: 'Avant intervalles, EMOM, AMRAP et tenues',
                value: s.prepSec,
                unit: 's',
                min: 0,
                max: 10,
                step: 1,
                onChanged: (v) {
                  s.prepSec = v;
                  save();
                },
              ),
              _Sw('Son en fin de chrono', null, s.sound, (v) {
                s.sound = v;
                save();
              }),
              _Sw('Vibration en fin de chrono', 'Pré-signal léger 3 s avant la fin', s.vibration, (v) {
                s.vibration = v;
                save();
              }),
              const _Sec('SÉANCE'),
              _Sw('Garder l\u2019écran allumé', 'Pendant l\u2019exécution d\u2019une séance ou d\u2019un WOD', s.wakelock, (v) {
                s.wakelock = v;
                save();
              }),
              _Sw('Charges suggérées en livres (lb)', 'Affichage uniquement, saisie libre', s.lb, (v) {
                s.lb = v;
                save();
              }),
              const _Sec('RAPPEL QUOTIDIEN'),
              _Sw('Notification de la séance du jour', 'Titre, nombre d\u2019exercices, bloc — 7 jours planifiés', s.notifOn, (v) async {
                if (v) {
                  final ok = await Notif.requestPermission();
                  if (!ok) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Autorise les notifications pour Kalis Track dans Android.')));
                    }
                    return;
                  }
                }
                s.notifOn = v;
                save();
                Notif.reschedule();
              }),
              _Tile(
                title: 'Heure du rappel',
                subtitle: 'Chaque jour à cette heure',
                trailing: Text(
                  '${s.notifHour.toString().padLeft(2, '0')}:${s.notifMinute.toString().padLeft(2, '0')}',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: SL.steel),
                ),
                onTap: () async {
                  final t = await showTimePicker(
                    context: context,
                    initialTime: TimeOfDay(hour: s.notifHour, minute: s.notifMinute),
                    helpText: 'Heure du rappel',
                  );
                  if (t == null) return;
                  s.notifHour = t.hour;
                  s.notifMinute = t.minute;
                  save();
                  Notif.reschedule();
                },
              ),
              _Sw('Ignorer les jours de repos', null, s.notifSkipRest, (v) {
                s.notifSkipRest = v;
                save();
                Notif.reschedule();
              }),
              const _Sec('DONNÉES'),
              _Action(
                icon: Icons.upload_rounded,
                color: SL.steel,
                title: 'Exporter une sauvegarde',
                subtitle: 'Copie tout (pilotage, journal, séances, WODs, réglages) dans le presse-papiers',
                onTap: () {
                  Clipboard.setData(ClipboardData(text: store.exportAll()));
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sauvegarde copiée dans le presse-papiers.')));
                },
              ),
              _Action(
                icon: Icons.download_rounded,
                color: SL.inputYellow,
                title: 'Importer une sauvegarde',
                subtitle: 'Remplace les données actuelles par un export collé',
                onTap: () => _import(context),
              ),
              const _Sec('À PROPOS'),
              _Tile(
                title: 'Kalis Track $kAppVersion',
                subtitle: 'Programme streetlifting v3.3 embarqué · 172 exercices · 8 modes · WOD',
              ),
            ],
          ),
        );
      },
    );
  }

  void _import(BuildContext context) {
    final ctl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Importer une sauvegarde'),
        content: TextField(
          controller: ctl,
          maxLines: 6,
          textAlign: TextAlign.left,
          decoration: const InputDecoration(hintText: 'Colle ici le texte exporté', alignLabelWithHint: true),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: SL.steel, foregroundColor: SL.onAccent),
            onPressed: () {
              final ok = store.importAll(ctl.text.trim());
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'Import réussi.' : 'Import impossible : texte invalide.')));
            },
            child: const Text('Importer'),
          ),
        ],
      ),
    );
  }
}

// ---------- composants uniformes (mêmes marges, mêmes hauteurs) ----------

class _Sec extends StatelessWidget {
  final String t;
  const _Sec(this.t);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 20, 18, 6),
        child: Text(t, style: TextStyle(color: SL.dim, fontSize: 11.5, fontWeight: FontWeight.w800, letterSpacing: 0.7)),
      );
}

class _Tile extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final Widget? below;
  final VoidCallback? onTap;
  const _Tile({required this.title, this.subtitle, this.trailing, this.below, this.onTap});

  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5)),
                          if (subtitle != null)
                            Padding(
                              padding: const EdgeInsets.only(top: 2),
                              child: Text(subtitle!, style: TextStyle(color: SL.dim, fontSize: 12, height: 1.3)),
                            ),
                        ],
                      ),
                    ),
                    if (trailing != null) ...[const SizedBox(width: 10), trailing!],
                  ],
                ),
                if (below != null) Padding(padding: const EdgeInsets.only(top: 10), child: below),
              ],
            ),
          ),
        ),
      );
}

class _Sw extends StatelessWidget {
  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _Sw(this.title, this.subtitle, this.value, this.onChanged);
  @override
  Widget build(BuildContext context) => _Tile(
        title: title,
        subtitle: subtitle,
        onTap: () => onChanged(!value),
        trailing: Switch(value: value, onChanged: onChanged),
      );
}

class _Stepper extends StatelessWidget {
  final String title;
  final String? subtitle;
  final int value;
  final String unit;
  final int min, max, step;
  final ValueChanged<int> onChanged;
  const _Stepper({required this.title, this.subtitle, required this.value, required this.unit, required this.min, required this.max, required this.step, required this.onChanged});

  @override
  Widget build(BuildContext context) => _Tile(
        title: title,
        subtitle: subtitle,
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              onPressed: value > min ? () => onChanged((value - step).clamp(min, max)) : null,
              icon: const Icon(Icons.remove_circle_outline),
              color: SL.steel,
            ),
            SizedBox(
              width: 52,
              child: Text('$value\u00A0$unit', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5)),
            ),
            IconButton(
              onPressed: value < max ? () => onChanged((value + step).clamp(min, max)) : null,
              icon: const Icon(Icons.add_circle_outline),
              color: SL.steel,
            ),
          ],
        ),
      );
}

class _Action extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _Action({required this.icon, required this.color, required this.title, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) => _Tile(
        title: title,
        subtitle: subtitle,
        onTap: onTap,
        trailing: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(color: color.withOpacity(0.16), borderRadius: BorderRadius.circular(11)),
          child: Icon(icon, color: color, size: 22),
        ),
      );
}
