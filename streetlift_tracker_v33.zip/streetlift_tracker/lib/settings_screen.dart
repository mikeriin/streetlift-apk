import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'main.dart';
import 'store.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final s = store.settings;
        return Scaffold(
          appBar: AppBar(title: const Text('RÉGLAGES')),
          body: ListView(
            padding: const EdgeInsets.only(bottom: 24),
            children: [
              const _Sec('TIMER'),
              _Stepper(
                label: 'Repos par défaut',
                value: s.defaultRest,
                unit: 's',
                min: 0,
                max: 300,
                step: 15,
                onChanged: (v) {
                  s.defaultRest = v;
                  store.saveSettings();
                },
              ),
              _Sw('Lancer le timer à la validation d\u2019une série',
                  s.autoTimer, (v) {
                s.autoTimer = v;
                store.saveSettings();
              }),
              _Stepper(
                label: 'Décompte « PRÊT » avant intervalles',
                value: s.prepSec,
                unit: 's',
                min: 0,
                max: 10,
                step: 1,
                onChanged: (v) {
                  s.prepSec = v;
                  store.saveSettings();
                },
              ),
              _Sw('Son en fin de timer', s.sound, (v) {
                s.sound = v;
                store.saveSettings();
              }),
              _Sw('Vibration en fin de timer', s.vibration, (v) {
                s.vibration = v;
                store.saveSettings();
              }),
              const _Sec('SÉANCE'),
              _Sw('Pré-remplir la charge suggérée', s.prefill, (v) {
                s.prefill = v;
                store.saveSettings();
              }),
              _Sw('Garder l\u2019écran allumé pendant la séance', s.wakelock,
                  (v) {
                s.wakelock = v;
                store.saveSettings();
              }),
              const _Sec('AFFICHAGE'),
              _Sw('Échelle RPE au lieu de RIR', s.rpe, (v) {
                s.rpe = v;
                store.saveSettings();
              }),
              _Sw('Charges suggérées en livres (lb)', s.lb, (v) {
                s.lb = v;
                store.saveSettings();
              }),
              const _Sec('DONNÉES'),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.upload, color: SL.steel),
                  title: const Text('Exporter (copier dans le presse-papiers)',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                  subtitle: const Text(
                      'Pilotage, journal, séances perso, réglages — colle-le dans une note pour sauvegarder.',
                      style: TextStyle(fontSize: 12)),
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: store.exportAll()));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Sauvegarde copiée dans le presse-papiers.')));
                  },
                ),
              ),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.download, color: SL.inputYellow),
                  title: const Text('Importer une sauvegarde',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                  subtitle: const Text(
                      'Colle un export : remplace les données actuelles.',
                      style: TextStyle(fontSize: 12)),
                  onTap: () => _import(context),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _import(BuildContext context) {
    final ctl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: SL.surface,
        title: const Text('Importer'),
        content: TextField(
          controller: ctl,
          maxLines: 5,
          textAlign: TextAlign.left,
          decoration: const InputDecoration(
              labelText: 'Colle ici le JSON exporté'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () {
              final ok = store.importAll(ctl.text.trim());
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(ok
                      ? 'Import réussi.'
                      : 'Import impossible : JSON invalide.')));
            },
            child: const Text('Importer'),
          ),
        ],
      ),
    );
  }
}

class _Sec extends StatelessWidget {
  final String t;
  const _Sec(this.t);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 6),
        child: Text(t,
            style: const TextStyle(
                color: SL.dim,
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.6)),
      );
}

class _Sw extends StatelessWidget {
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _Sw(this.label, this.value, this.onChanged);
  @override
  Widget build(BuildContext context) => Card(
        child: SwitchListTile(
          title: Text(label,
              style:
                  const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
          value: value,
          activeColor: SL.steel,
          onChanged: onChanged,
        ),
      );
}

class _Stepper extends StatelessWidget {
  final String label;
  final int value;
  final String unit;
  final int min, max, step;
  final ValueChanged<int> onChanged;
  const _Stepper(
      {required this.label,
      required this.value,
      required this.unit,
      required this.min,
      required this.max,
      required this.step,
      required this.onChanged});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          child: Row(
            children: [
              Expanded(
                child: Text(label,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 14)),
              ),
              IconButton(
                  onPressed: value > min
                      ? () => onChanged((value - step).clamp(min, max))
                      : null,
                  icon: const Icon(Icons.remove_circle_outline)),
              SizedBox(
                width: 58,
                child: Text('$value $unit',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
              IconButton(
                  onPressed: value < max
                      ? () => onChanged((value + step).clamp(min, max))
                      : null,
                  icon: const Icon(Icons.add_circle_outline)),
            ],
          ),
        ),
      );
}
