# CI 3D — méthode de contrôle du mannequin 3D (établie par M1)

Pipeline « Mannequin 3D » : chaque lot contrôle son travail avec cette CI,
sans SDK Flutter local. Moteur : flutter_scene (Flutter GPU sur Impeller).

## Déclenchement

- Workflow `.github/workflows/ci-3d.yml` (copie dans ce ZIP ; l'original est
  à la racine de la branche `claude/ci-3d`).
- Déclenché **uniquement** par un push sur `claude/ci-3d` (jamais
  `claude/ci-tools`). Cette branche porte le ZIP à tester et `ci-3d.yml`,
  **sans** `build-apk.yml` (pas de build signé sur la branche de test).
- Les résultats sont recommités par la CI dans `ci-out/` sur `claude/ci-3d`
  (commit « CI 3D : résultats du run … ») : `git fetch origin claude/ci-3d`
  puis lire les fichiers. Rien à télécharger.

## Tâches

| Tâche | Contenu | Résultats dans `ci-out/` |
| --- | --- | --- |
| `checks` | Flutter 3.47.5 : `pub get` (verrou régénéré s'il est périmé), formatage, analyse, tests Python + `verify_project.py` + `package_release.py --check`, suite Dart complète, rendus de test (`KALIS_CAPTURE`), build debug | `checks.txt` (bilan), `pubspec.lock`, `pub-lock.txt`, `format.patch` (si formatage à corriger), `analyze.log`, `python-tests.log`, `flutter-tests.log`, `build-debug.log`, `flutter-version.txt` |
| `before` | Mêmes rendus de test sur le ZIP de `main` avec la version Flutter précédente | comparés dans `captures-comparaison.txt` ; paires différentes dans `captures/` (`avant_*` / `apres_*`) |
| `emulator` | Émulateur Android API 35 x86_64 (pixel_7), `-gpu swangle_indirect` (OpenGL ES via ANGLE sur SwiftShader Vulkan, build d'émulateur 13823996 comme la CI de flutter_scene), `flutter drive` de `integration_test/moteur_3d_test.dart` par `tools/ci3d_drive.sh` | `emulateur/*.png`, `emulateur/m1_releve.json`, `emulateur/impeller.txt`, `emulateur/logcat.txt`, `emulateur/drive.log` |
| `publish` | Assemble et recommite `ci-out/` | `resultat.txt` |

## Captures du vrai rendu Flutter GPU

- `flutter test` n'a **pas** Flutter GPU (moteur de test sans Impeller) : il
  sert au repli « Non compatible » (`test/m1_engine3d_test.dart`), pas au
  rendu 3D.
- Le rendu réel se capture **sur l'émulateur** : le test d'intégration
  entoure l'application d'un `RepaintBoundary`, attend la stabilisation, puis
  `toImage(pixelRatio: 1.5)` ; le PNG passe en Base64 par
  `binding.reportData` et `test_driver/integration_test.dart` l'écrit dans
  `build/ci3d/` côté hôte (même méthode que la CI de flutter_scene).
- `binding.framePolicy = fullyLive` : vraies images produites par le moteur
  (rotation, mesure). Ne pas utiliser `pumpAndSettle` une fois la scène
  affichée (le rendu animé ne se stabilise jamais) : `pump(durée)`.
- Contrôle sans référence dans le test : part de la vue couverte par la
  figure, présence du gris et du rouge historique, nombre de couleurs.
  Les captures doivent **aussi être regardées** (outil Read) avant livraison.
- Le moteur de rendu choisi par Impeller est lu dans le journal
  (`Using the Impeller rendering backend (…)`) : `emulateur/impeller.txt`.

## Temps d'image

- L'écran Moteur 3D mesure 10 s de `FrameTiming.totalSpan` (début de
  construction → fin du rendu GPU) : images/s, moyenne, 99e centile.
- Sur émulateur (rendu logiciel, build debug), ces valeurs ne représentent
  pas un téléphone : elles servent à détecter une régression d'un lot à
  l'autre. La mesure qui compte est celle du téléphone du propriétaire
  (Réglages › À propos › Moteur 3D).

## Pour un lot suivant

1. Construire le ZIP (`python3 tools/package_release.py …`), le copier à la
   racine de `claude/ci-3d` avec `ci-3d.yml`, pousser.
2. Attendre le commit de résultats, lire `ci-out/checks.txt` et
   `ci-out/resultat.txt`, appliquer `format.patch` et `pubspec.lock` si
   fournis, regarder chaque PNG de `ci-out/emulateur/`.
3. Ajouter ses propres écrans au test d'intégration (nouvelle fonction de
   capture, mêmes contrôles sans référence).
