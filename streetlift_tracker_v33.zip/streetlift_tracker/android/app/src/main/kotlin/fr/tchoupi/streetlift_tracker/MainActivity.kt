package fr.tchoupi.streetlift_tracker

import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "kalis_track/device")
            .setMethodCallHandler { call, result ->
                if (call.method != "highRefreshRate") {
                    result.notImplemented()
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        @Suppress("DEPRECATION")
                        val screen = windowManager.defaultDisplay
                        val current = screen.mode
                        val best = screen.supportedModes.filter {
                            it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight
                        }.maxByOrNull { it.refreshRate }
                        if (best != null) {
                            val params = window.attributes
                            params.preferredDisplayModeId = best.modeId
                            window.attributes = params
                        }
                    }
                    result.success(null)
                }
            }
    }
}
