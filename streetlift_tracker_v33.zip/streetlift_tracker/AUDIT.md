# Kalis Track 1.7.1 — retour à la direction artistique précédente

Livraison du 13 septembre 2026. Cette mise à jour reprend les codes visuels de la version 1.6 et les harmonise dans l’application. Les améliorations pratiques de la version 1.7 et le système de progression enrichi restent disponibles.

## Changements

| Écran / élément | Résultat |
| --- | --- |
| Style commun | Palette historique conservée, cartes compactes, marges de 12 px, titres de section en capitales et boutons homogènes. Même structure dans les thèmes clair et sombre. |
| Navigation | Retour du bouton Programme circulaire au centre, avec les quatre destinations secondaires. Les onglets visités conservent leur état ; les boutons portent des libellés accessibles. |
| Programme | Titre KALIS TRACK, bandeau en dégradé selon le bloc et repères J1 à J7 rétablis. Avancement, accès au choix de semaine et menus de séance conservés. |
| Séance | Une carte par exercice avec bande de couleur, titre vert pour les lifts principaux, charge mise en avant et champs jaunes. Prescription, séries et notes restent réunies. |
| Arsenal, Suivi et progression | Bandeau de niveau commun en dégradé avec médaillon circulaire, crédits, rang et progression XP. |
| Catalogue et WOD | Cartes, sections, badges et actions reprennent les mêmes couleurs et proportions. Les mouvements restent prioritaires dans l’aperçu ; le chrono reste prioritaire pendant le WOD. |
| Pilotage | Références et valeurs côte à côte lorsque la largeur et la taille du texte le permettent. Unités abrégées dans les champs pour laisser les nombres lisibles. |
| Réglages | Cartes compactes, réglages numériques à côté de leur libellé sur écran suffisamment large ; disposition verticale pour les petits écrans et grands textes. |
| Éditeurs et historique | Application des thèmes, surfaces et espacements communs, avec les commandes et la navigation introduites en 1.7. |

## Correction fonctionnelle

Les lignes **Exporter une sauvegarde** et **Importer une sauvegarde** avaient perdu leur gestionnaire d’appui dans le refactor 1.7. Elles déclenchent de nouveau leurs actions. Un test reproduit l’appui sur chaque ligne, vérifie le contenu copié et l’ouverture du formulaire d’import.

## Fonctionnalités conservées

- Cartes par exercice, glissement horizontal, boutons Précédent/Suivant et accès direct au bilan.
- Notes distinctes pour les exercices enchaînés, colonnes de saisie adaptatives et commandes de séries accessibles.
- Semaine sélectionnée et état des écrans conservés entre les onglets et après changement de thème.
- Recherche effaçable, filtres, menus d’actions et enregistrement explicite dans les éditeurs.
- Système de progression 1.6 : 7 rangs, 16 badges, 4 objectifs hebdomadaires, régularité et crédits.
- Réglage des rappels et résolution des blocages Android. Les boutons de test de notification restent retirés de l’interface.

## Vérifications

**83 tests Flutter et 4 tests Python réussis. Analyse Flutter sans anomalie.** Les journaux sont inclus dans `validation/`.

La suite vérifie notamment les parcours à 320 px avec texte agrandi à 130 % dans les deux thèmes, les séances et éditeurs en paysage et sur écran large, la conservation des saisies, les sauvegardes, les notifications simulées et la progression. Le test ajouté dans cette version couvre les commandes d’export et d’import.

Neuf écrans ont été rendus localement en clair et en sombre : Programme, Arsenal, Suivi, séance, progression, Pilotage, réglages, catalogue et aperçu WOD. Les champs du Pilotage ont été corrigés après inspection puis rendus à nouveau.

Le contrôle du projet confirme 40 semaines, 280 jours, 1 954 prescriptions et 172 exercices de référence. La vérification de signature passe avec le certificat d’origine.

Comparaison binaire avec la livraison 1.7 : les 72 fichiers contrôlés — assets, Android, signature, dépendances verrouillées et moteurs de données, notifications, progression et chronomètres — sont identiques. Cette livraison ne modifie ni les barèmes ni le format des sauvegardes.

## Compilation et installation

Version : **1.7.1+25**. Identifiant Android : `fr.tchoupi.streetlift_tracker`. Environnement de validation : Flutter 3.29.3 / Dart 3.7.2.

Remplace **streetlift_tracker_v33.zip** à la racine du dépôt GitHub. Le workflow fourni avec la version 1.6 reste compatible sans modification. Lance **Actions → Build APK** ou consulte le run déclenché par le commit. Télécharge l’artefact **kalis-track-apk**, extrais **kalis-track.apk**, puis installe-le par-dessus l’application existante.

L’APK n’a pas été compilé ni installé sur téléphone dans cet environnement. Les tests de notification locaux simulent Android ; le fonctionnement des tests sur le téléphone a été confirmé par l’utilisateur lors de la livraison précédente. La validation du nouvel APK reste celle du run GitHub et de son installation.
