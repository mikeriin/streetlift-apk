# Kalis Track 1.7.3 — retour des repères de séance

Livraison du 19 septembre 2026, à partir de la version 1.7.2.

## Correction

La barre continue du déroulement de séance est remplacée par les petits repères séparés de la version 1.6. L’étape active est plus longue et reprend la couleur de la semaine ; les autres repères restent discrets. Chaque page possède son repère, bilan compris. Les exercices enchaînés gardent leur page commune.

L’indicateur suit les glissements, les boutons Précédent/Suivant et la sélection dans la liste Exercices. Ses marges verticales restent réduites pour conserver la présentation compacte. Les repères peuvent revenir à la ligne si une séance personnalisée comprend beaucoup d’étapes. L’étape courante reste annoncée aux lecteurs d’écran et l’animation respecte le réglage de réduction des animations.

La direction artistique, les cartes et les saisies de la version 1.7.2 sont conservées. Le chronomètre et sa propre barre ne sont pas modifiés.

## Vérifications

- Analyse Flutter : aucune anomalie.
- 84 tests Flutter et 4 tests Python réussis ; journaux dans `validation/`.
- Séance rendue en clair et en sombre : première étape, étape suivante, bilan et petit écran avec RIR.
- À 360 × 760, avec 24 px d’espace système en haut et en bas, les cinq séries de la séance de référence S8/J1 restent visibles et validables sans défilement.
- La carte de référence garde une hauteur de 458 px logiques ; les boutons de validation restent à 44 × 44.
- Données du programme et certificat de signature d’origine vérifiés.

Les autres écrans, les notifications, les niveaux, les données, la signature et le projet Android ne sont pas modifiés par ce correctif. Aucun test de notification n’est réintroduit dans l’interface.

## Mise à jour

Version **1.7.3+27**, vérifiée avec Flutter 3.29.3 et Dart 3.7.2.

Remplace **streetlift_tracker_v33.zip** à la racine du dépôt GitHub puis lance **Actions → Build APK** avec le workflow fourni précédemment. Télécharge l’artefact **kalis-track-apk**, extrais **kalis-track.apk** et installe-le par-dessus la version existante.

L’APK n’a pas été compilé ni installé dans cet environnement. La compilation Android reste effectuée par GitHub Actions.
