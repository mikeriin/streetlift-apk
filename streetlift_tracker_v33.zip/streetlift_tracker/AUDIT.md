# Kalis Track 1.7.6 — interface affinée

Livraison du 19 septembre 2026, à partir de la version 1.7.5.

## Modifications

Cette version allège les commandes de la version 1.7.4 en conservant la direction artistique précédente : couleurs, bandeaux en dégradé, navigation centrale Programme et cartes par exercice.

- **Boutons plus fins** : surface visible de référence de 36 px, arrondis de 7 px, icônes de commande de 18 px et graisse de texte réduite. Le padding natif conserve une zone tactile de 44 px de haut. Les actions voisines gardent la même largeur et le même axe central, sans forcer la surface colorée à occuper toute la hauteur.
- **Saisie des performances** : cellules visibles de 36 px au lieu de 44, chiffres toujours en taille 15, fond jaune atténué, contours discrets. La zone de saisie couvre 44 px de haut : toucher les marges active le champ et sélectionne sa valeur. La validation conserve une cible de 44 × 44 ; une série validée reçoit un fond vert léger.
- **Formulaires** : champs et sélecteurs de 40 px à taille de texte normale, libellés persistants, aides et erreurs pouvant revenir à la ligne. Les formulaires et actions passent en colonne lorsque l’espace ou le texte l’exige.
- **Hiérarchie plus légère** : moins de gras dans les titres, listes, badges, compteurs et indications de séance ; charge principale ramenée de 32 à 28 px. Les cartes conservent leur organisation, avec des angles et une bordure d’accent plus fins.
- **Actions secondaires** : réglages +/− sans encadrement massif ; dans le WOD, Valider round et Terminer utilisent un contour, Réinitialiser un bouton texte. Démarrer conserve sa mise en avant.
- **Disposition** : suppression de la mesure intrinsèque des rangées d’actions ; adaptation au texte agrandi sans plafonner le facteur pris en compte par les grilles.

Le petit drapeau français au lancement, les repères séparés de progression de séance, les notes repliables et la sauvegarde des performances sont conservés. Les tests de notification restent absents de l’interface.

## Vérifications

Version **1.7.6+30**, avec Flutter **3.29.3** et Dart **3.7.2**.

- Analyse Flutter : aucune anomalie.
- **84 tests Flutter et 4 tests Python réussis.** Les tests existants couvrent notamment saisie, sauvegardes, navigation, chronos, notifications et progression.
- Le test de séance compacte vérifie cinq séries entièrement visibles et validables à 360 × 760, espaces système inclus, ainsi que l’activation et l’enregistrement depuis la marge d’une cellule de saisie.
- 18 vues rendues dans chacun des deux thèmes, complétées par 8 rendus à 320 × 760 avec texte à 130 %. Contrôle des alignements et des surfaces de saisie via les dimensions Flutter, avec inspection des écrans représentatifs.
- Carte de référence S8/J1 : **450 px logiques de haut**, contre 458 en 1.7.4 ; les cinq séries restent visibles sans défilement, colonne RIR comprise.
- **80 fichiers protégés identiques** à la version 1.7.5 : ressources Android, drapeau, assets, signature, dépendances verrouillées et principaux moteurs de données, progression, notifications et chronos.
- Intégrité du programme et certificat de signature vérifiés : 40 semaines, 280 jours, 1 954 prescriptions et 172 exercices dans la base.

Les journaux sont dans `validation/`. Les scripts et images temporaires de rendu ne sont pas inclus dans le projet livré.

**Limite :** l’APK n’a pas été compilé ni installé dans cet environnement. Les vérifications de rendu portent sur Flutter ; la compilation et la vérification sur téléphone passent par GitHub Actions.

## Installation

Remplace **streetlift_tracker_v33.zip** à la racine de ton dépôt, puis lance **Actions → Build APK** avec le workflow déjà fourni. Télécharge l’artefact **kalis-track-apk**, extrais **kalis-track.apk** et installe-le par-dessus la version existante. La clé de signature et l’identifiant Android restent les mêmes.
