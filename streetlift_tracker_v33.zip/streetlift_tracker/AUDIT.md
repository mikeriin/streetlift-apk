# Kalis Track 1.8.0 — Programme et estimations

## Interface issue des croquis

- Pastille de niveau à gauche, symbole Kalis Track seul au centre, calendrier à droite.
- Curseur discret des 40 semaines, avec numéro sélectionné mis en avant. Un appui sur le numéro ouvre les dates, le bloc, le cycle et l’avancement de la semaine ; le calendrier conserve le choix direct d’une semaine.
- Journées compactes. La journée actuelle est développée : état terminé ou à faire, exercices, séries, volume, durée et silhouettes des muscles ciblés.
- Actions Détails et Commencer/Consulter. Le menu de chaque journée donne aussi accès au volume et à la durée, même hors de la semaine actuelle.
- Navigation inférieure et position des onglets conservées. Cartes par exercice, saisies compactes, repères séparés du déroulement, notifications et ouverture au drapeau pendant au moins deux secondes conservés.
- Thèmes clair et sombre contrôlés. La vue de référence à 360 × 760 tient les sept jours à taille de texte normale, avec la navigation et les marges système simulées. À 320 px et texte agrandi, le défilement reste disponible.

## Charge de travail : ce que les chiffres représentent

Le volume prévu remplace les points arbitraires dans les informations d’entraînement. Les unités restent distinctes ; elles ne sont pas additionnées dans un score unique.

| Indicateur | Calcul |
| --- | --- |
| Répétitions | Somme des séries, tours, échelles, blocs et côtés prescrits. Les fourchettes restent des fourchettes. |
| Effort chronométré | Secondes de tenue ou de travail prescrites ; aucune conversion artificielle en répétitions. |
| Distance / calories d’ergomètre | Quantités prescrites, séparées des répétitions. Les calories affichées ne sont pas une estimation des calories dépensées par le corps. |
| Tonnage externe connu | Somme de la charge externe en kg × répétitions. Le poids du corps est exclu. Deux haltères sont comptés quand la prescription les indique ; un mouvement unilatéral compte les deux côtés. |
| Muscles ciblés | Présence des groupes reconnus dans les mouvements prescrits, y compris un maximum sans volume connu. La couleur ne mesure pas la fatigue physiologique. |

Les charges suggérées par le Pilotage, les données enregistrées, les XP, les déverrouillages et le classement de jeu restent compatibles. Le score interne de classement des WODs reste séparé du volume affiché.

## Durées : calcul commun et limites explicites

Le total combine effort, repos et transitions. Les repos sont comptés entre les séries et entre les tours, sans repos final ajouté. Les enchaînements partagent leur récupération ; les EMOM enchaînés partagent leur horloge. Les clusters, myo-reps, échelles, exercices par côté et tenues par angle sont pris en compte.

Le texte du repos prime sur la valeur numérique ancienne : « 2 min 30 » vaut bien 150 secondes. Cette correction s’applique aussi au lancement automatique du repos. Les tempos explicites sont utilisés ; à défaut, les cadences sont des hypothèses de calcul, pas des mesures personnelles. Le code prévoit notamment 2–3 secondes pour une répétition générique, 2,5–4 secondes pour plusieurs mouvements de force et 4–6 secondes pour les mouvements plus complexes. Les transitions usuelles sont estimées à 30–60 secondes entre exercices et 3–8 secondes dans les circuits ; les pauses libres et l’échauffement non prescrit sont exclus.

Pour les WODs :

- Repos écrits dans les lignes, décimales, charges alternatives, blocs imbriqués et multiplicateurs sont distingués.
- EMOM/E2MOM : durée fixée par l’horloge, plages et rotations correctement réparties. Un intervalle potentiellement trop court est signalé.
- AMRAP, y compris fractionné ou ascendant : durée imposée ; volume projeté selon la cadence. L’AMRAP 3–4–5 avec deux repos de deux minutes dure 16 minutes.
- Échelles jumelées : la totalité de la progression est comptée, même si le texte utilise une ellipse.
- Le temps limite reste distinct du temps estimé nécessaire pour terminer le volume complet.
- Après au moins trois résultats complets compatibles, la durée utilise l’intervalle des temps des cinq dernières réalisations au maximum. La prescription est mémorisée lors de l’enregistrement ; modifier les mouvements ou le format invalide cette comparaison. Les anciens scores sont conservés mais ne servent pas à cette calibration, faute de prescription mémorisée.

Une tenue maximale sans durée, des répétitions MAX libres ou des pénalités variables ne peuvent pas être déduites avec précision du texte. L’application indique alors un volume partiel et une borne basse de temps, ou « À préciser ». Dans le catalogue fourni, les cas restant partiels concernent les pénalités du WOD IPC 100 bench press et les tractions MAX de l’E5MOM 25 ; le programme comporte aussi des dead-hangs maximaux sans durée. Les options et le partage en équipe sont explicités. Ces estimations ne garantissent pas le temps réellement observé sur le terrain.

Le détail se consulte depuis Programme → Détails/menu, depuis le bouton d’information d’une carte d’exercice, ou depuis l’aperçu d’un WOD. Les lignes WOD détaillent le volume cumulé de chaque mouvement, repos globaux et horloges étant expliqués dans le total.

## Vérification et installation

- **111 tests Flutter et 4 tests Python réussis.** Analyse statique sans anomalie.
- Vérification des 1 954 exercices, des 500 WODs, des petits écrans, des thèmes, des imports/exports et de la calibration après changement de prescription.
- Identité Android et certificat de signature vérifiés ; aucune dépendance ajoutée.
- Version : **1.8.0+32**. Compatible avec le workflow Build APK existant (Flutter 3.29.3).

Remplacer `streetlift_tracker_v33.zip` à la racine du dépôt, puis lancer **Actions → Build APK**. Le workflow actuel n’a pas besoin d’être remplacé. L’APK n’a pas été compilé ici, le SDK Android étant absent : la compilation et le rendu sur appareil restent à confirmer via GitHub Actions et le téléphone. Une exportation des données avant mise à jour reste utile.
