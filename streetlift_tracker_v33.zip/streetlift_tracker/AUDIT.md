# Kalis Track 1.7.0 — refactor de l’interface

Livraison du 13 septembre 2026, à partir de la version 1.6.0. Le programme reste en version 3.3 et l’archive conserve le nom `streetlift_tracker_v33.zip` pour déclencher le workflow GitHub existant.

## Changements livrés

| Écran / parcours | Améliorations |
| --- | --- |
| Ensemble de l’application | Palette, cartes, titres, boutons, champs, espacements et états vides partagés. Thèmes clair et sombre cohérents. Contenu limité à 840 px sur les écrans larges, avec actions alignées. |
| Navigation | Barre à cinq destinations uniformes. Les onglets visités conservent leur état et leur position. Le changement de thème conserve notamment la semaine sélectionnée. |
| Programme | Semaine, dates, bloc et avancement regroupés ; retour à la semaine actuelle ; accès visible aux actions de chaque séance. |
| Séance | Une carte par exercice, contenant prescription, séries et notes. Glissement horizontal conservé. Boutons Précédent/Suivant, liste des exercices et accès direct au bilan. Les exercices enchaînés ont chacun leur carte et leur note sur une page commune. |
| Saisie des séries | Colonnes réparties selon la largeur disponible et la taille du texte. Effort/vitesse passent sur une seconde ligne si nécessaire. Boutons d’ajout/retrait avec compteur de séries. En-têtes alignés sur les champs. |
| Arsenal | Création directe de séances et de WODs, menus d’actions visibles, indications et actions adaptées aux listes vides. |
| Catalogue | Recherche avec effacement, filtres homogènes, cartes espacées, réinitialisation depuis une recherche sans résultat. |
| Aperçu WOD | Mouvements placés avant les estimations de charge et la carte musculaire. Action principale en bas. Message de crédits compact pour conserver l’aperçu visible. |
| Exécution WOD | Chronomètre et commandes prioritaires, mouvements et résultats regroupés en cartes. |
| Éditeurs | Enregistrement explicite, réorganisation des exercices par poignée visible, formulaires adaptés au clavier et à la largeur disponible. |
| Suivi / progression | Même carte de niveau dans l’Arsenal, le Suivi et le parcours. Références, cibles, missions, badges et historique présentés de manière cohérente. |
| Pilotage / réglages | Explications simplifiées, références plus faciles à saisir, préférences regroupées, choix du thème qui revient à la ligne si nécessaire. |
| Écran de secours | Présentation harmonisée, détails techniques repliables et actions de récupération accessibles. |

## Notifications

Les boutons de test immédiat et différé ont été retirés de l’interface, conformément à la confirmation de leur fonctionnement sur le téléphone. Le panneau conserve l’activation des rappels, l’heure, l’exclusion des jours de repos et le prochain rappel. Les options Android sont repliées ; les blocages et erreurs conservent une action de résolution.

Le moteur de notification et les fichiers Android sont inchangés par rapport à la version 1.6. Les tests automatisés du service restent dans le projet.

## Architecture et compatibilité

- `lib/app_theme.dart` centralise les thèmes et leurs couleurs. Les callbacks de thème capturent leur propre palette, indépendamment du thème actif ensuite.
- `lib/ui.dart` regroupe les composants de présentation réutilisables. Les listes utilisent une construction progressive des éléments.
- Les onglets sont initialisés à leur première ouverture, puis conservés ; leurs animations sont désactivées lorsqu’ils sont masqués.
- Moteurs de progression, calculs, chronomètres, sauvegardes et format des données inchangés. Les rangs, missions, badges et crédits introduits en 1.6 sont conservés.
- Assets du programme, base d’exercices, fichiers Android, dépendances verrouillées et clé de signature comparés à la livraison 1.6 : identiques.
- Version de l’application : `1.7.0+24`. Identifiant Android conservé : `fr.tchoupi.streetlift_tracker`.

## Vérifications effectuées

**82 tests Flutter et 4 tests Python passent. L’analyse Flutter ne signale aucune anomalie.** Les journaux sont inclus dans `validation/`.

Les nouvelles régressions couvrent : semaine conservée entre les onglets et après changement de thème ; saisie conservée en naviguant entre cartes ; notes distinctes pour les exercices enchaînés ; bilan accessible par le sélecteur ; aperçu d’un WOD verrouillé visible ; recherche effaçable ; formulaires avec clavier ; parcours à 320 px et texte agrandi à 130 % dans les deux thèmes ; séances et éditeurs à 640 × 360 et 1024 × 768.

Huit écrans ont également été rendus en clair et en sombre pour inspection visuelle. Cette vérification a permis de corriger les commandes de séries trop larges et le panneau de crédits qui pouvait masquer un aperçu WOD.

Programme vérifié : 40 semaines, 280 jours, 1 954 prescriptions et 172 exercices de référence. Vérification du certificat d’origine réussie. Outils de validation : Flutter 3.29.3 et Dart 3.7.2.

Aucun nouvel APK n’a été compilé ni installé sur téléphone dans cet environnement. Le build Android et la vérification finale sur l’appareil restent à effectuer via GitHub Actions et l’APK produit. Les tests locaux vérifient le code et les interfaces ; les appels Android du service de notification sont simulés.

## Installation de cette mise à jour

Remplace `streetlift_tracker_v33.zip` à la racine du dépôt. Le workflow de la livraison 1.6 est compatible sans modification. Le commit déclenche **Actions → Build APK** ; un lancement manuel reste possible. Télécharge ensuite l’artefact **kalis-track-apk**, extrais `kalis-track.apk` et installe-le par-dessus la version existante.

Le README inclus conserve les instructions de sauvegarde, de compilation et les détails du système de progression.
