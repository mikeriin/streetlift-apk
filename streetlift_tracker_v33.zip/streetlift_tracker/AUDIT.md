# Kalis Track 1.7.2 — cartes et saisies compactes

Livraison du 13 septembre 2026, à partir de la version 1.7.1. La direction artistique 1.6 et le principe d’une carte par exercice sont conservés.

## Résultat sur la séance de référence

Mesure locale de la première carte de S8/J1, « Muscle-up lesté », avec cinq séries et une taille de texte normale :

| Mesure | 1.7.1 | 1.7.2 |
| --- | ---: | ---: |
| Hauteur de la carte à 390 × 844 | 689 px logiques | 458 px logiques |
| Défilement vertical nécessaire pour la page initiale | 55 px logiques | 0 |
| Hauteur du bouton de validation | 48 px logiques | 44 px logiques |

La carte occupe **environ 34 % de hauteur en moins**. Cette réduction porte sur son affichage initial : les consignes sont désormais accessibles sur demande et les notes vides sont repliées.

Un test distinct à **360 × 760**, avec 24 px d’espace système en haut et en bas et la colonne RIR activée, vérifie que les cinq séries, leurs champs et leurs boutons de validation restent entièrement visibles sans défilement. Il ouvre aussi les consignes et valide la cinquième série.

## Changements

| Zone | Ajustement |
| --- | --- |
| Saisie des performances | Espacement entre les séries réduit de 8 à 2 px, champs moins hauts, numérotation abrégée, valeurs toujours en taille 15 et boutons de validation de 44 × 44. Colonnes adaptées à la largeur disponible. |
| Prescription | Charge toujours mise en avant, marges et badges plus serrés. Les longues consignes s’ouvrent avec le bouton d’information de l’exercice. |
| Notes | Champ vide replié ; bouton de note dans les commandes de séries. Les notes enregistrées s’affichent dès l’ouverture de l’exercice. Replier et rouvrir une note conserve sa saisie. |
| Navigation de séance | En-tête, barre de progression, actions inférieures et barre de chrono moins hauts. Glissement, sélection des exercices et accès au bilan conservés. |
| Cartes et listes | Marges verticales communes réduites, espacement courant entre cartes de 6 px. Les textes continuent de s’adapter aux grands caractères. |
| Programme | Journées plus compactes et avancement de semaine sur une seule ligne. |
| Arsenal et catalogue | Bandeau de niveau, états vides, badges et lignes de WOD resserrés ; actions toujours accessibles. |
| Pilotage et réglages | Champs et cartes plus courts, explications resserrées, réglages numériques côte à côte lorsque la largeur le permet. |
| Progression | Bandeau compact et progression des missions alignée avec leur compteur. Les quatre objectifs hebdomadaires sont visibles dans le rendu de référence à 390 × 844. |
| Suivi et WOD | Cartes et espaces réduits, illustrations musculaires moins hautes, mouvements et commandes prioritaires. |
| Éditeurs et historique | Application des champs, boutons, listes et espacements communs plus compacts. |

Les écrans conservent le défilement lorsque le contenu le nécessite : exercices enchaînés, nombreuses séries, notes ouvertes, textes agrandis ou petit écran. Aucun contenu enregistré n’est supprimé pour réduire la hauteur.

## Vérifications

**84 tests Flutter et 4 tests Python passent. L’analyse Flutter ne signale aucune anomalie.** Journaux inclus dans `validation/`.

- Nouveau test de visibilité et de validation des cinq séries sans défilement.
- Vérification de la conservation des notes après repli, réouverture, changement d’exercice et sauvegarde automatique.
- Exercices enchaînés : cartes et notes indépendantes, avec accès par défilement.
- Parcours à 320 px avec texte agrandi à 130 %, thèmes clair et sombre, séances et éditeurs en paysage et sur écran large.
- Rendus locaux de neuf écrans dans les deux thèmes, puis vérification de la saisie compacte à 360 × 760 avec RIR.
- Vérification des données du programme et du certificat de signature d’origine.

Les 72 fichiers contrôlés — assets, Android, signature, dépendances verrouillées et moteurs de données, de notifications, de progression et de chronomètres — sont identiques à la version 1.7.1. Les boutons de test de notification restent retirés de l’interface. Le système de niveaux et le format des sauvegardes sont conservés.

## Installation

Version **1.7.2+26**. Validation locale avec Flutter 3.29.3 et Dart 3.7.2.

Remplace **streetlift_tracker_v33.zip** à la racine du dépôt GitHub. Le workflow actuel reste compatible. Lance ou consulte **Actions → Build APK**, télécharge l’artefact **kalis-track-apk**, extrais **kalis-track.apk** et installe-le par-dessus la version existante.

L’APK n’a pas été compilé ni installé dans cet environnement. La compilation Android reste celle de GitHub Actions ; les notifications natives sont simulées dans les tests locaux.
