# Kalis Track 1.6.0 — notifications et progression

Livraison du 13 septembre 2026, à partir de la version 1.5.0 remise dans cette conversation. Le programme streetlifting reste en version 3.3 : le zip conserve donc le nom `streetlift_tracker_v33.zip`.

## Résultat et limite de vérification

**74 tests Flutter et 4 tests Python passent. L'analyse statique Flutter ne signale aucune anomalie.** Les autorisations, receivers Android, assets du programme et certificat de signature ont été contrôlés. Les nouveaux écrans passent les tests à 320 px et avec un texte agrandi à 130 %, dans les deux thèmes.

**Aucun APK n'a été produit ni testé sur un téléphone dans cet environnement, qui ne dispose pas d'un SDK Android configuré.** La planification est testée côté Flutter avec une couche native simulée. Le build release, les appels Android réels et l'affichage en veille doivent être confirmés par GitHub Actions puis sur le téléphone. Les nouveaux boutons de test rendent cette vérification possible sans attendre le lendemain.

## Notifications : problèmes constatés et corrections

Le code précédent avalait les erreurs d'initialisation et de planification, annulait les anciens rappels avant de les recréer et limitait la programmation à sept jours. L'interface ne distinguait pas une autorisation refusée, un canal désactivé, une absence de séance à venir ou une erreur du plugin. Les alarmes étaient exclusivement approximatives. Sans les journaux du téléphone, il n'est pas possible d'attribuer le problème signalé à une seule de ces causes.

| Point | Nouveau comportement |
| --- | --- |
| Initialisation échouée | Erreur visible, diagnostic copiable et nouvelle tentative possible. |
| Autorisation Android | Contrôle de l'autorisation globale et du canal `kalis_daily`, avec lien vers le réglage concerné. Le canal existant est conservé pour respecter les choix du téléphone. |
| Heure du rappel | Autorisation facultative `SCHEDULE_EXACT_ALARM`, puis mode exact en veille si disponible. Repli approximatif si refus ou révocation détectée pendant l'appel natif. |
| Durée de planification | Tous les jours restants du programme sont programmés, au plus 280 alarmes. |
| Dates | Construction dans le fuseau IANA du téléphone et prise en compte du changement d'heure. Repli sur l'heure locale système si l'identifiant de fuseau n'est pas reconnu. |
| Mise à jour des alarmes | Identifiants stables ; seules les alarmes devenues inutiles sont annulées. Réparation forcée possible. Les autres notifications ne sont pas supprimées. |
| Modifications dans l'app | Replanification après changement de réglage, import, validation/annulation/suppression de séance et retour dans l'app. |
| Concurrence | Opérations sérialisées ; une désactivation pendant la programmation finit par retirer les rappels quotidiens. |
| APK release | Règles de conservation des adaptateurs/interfaces Gson complétées pour la minification R8. Leur effet natif reste à confirmer dans le build Android. |
| Redémarrage / mise à jour | Receivers Android existants conservés pour restaurer les alarmes sauvegardées après redémarrage du téléphone et mise à jour du paquet. |
| Appui sur une notification | Ouverture de la bonne séance, y compris après démarrage à froid ; payload invalide ignoré. |
| Diagnostic utilisateur | Tests immédiat et différé, nombre de rappels, prochain horaire, état des autorisations, mode exact/approximatif, aide batterie et canal. |

Les tests couvrent notamment le passage à l'heure d'hiver en Europe/Paris, les autorisations bloquées, la révocation de l'heure précise, la récupération après erreurs natives simulées, les anciennes alarmes, la désactivation concurrente, l'annulation automatique d'un rappel après validation d'une séance et les tests indépendants des dates du programme.

## Niveaux : parcours enrichi

### XP de base et records

La courbe historique est conservée : il faut `150 + 50 × (niveau − 1)` XP pour atteindre le niveau suivant. Une journée du programme validée rapporte toujours 100 XP, une séance personnelle 60 XP et une tentative WOD enregistrée 80 XP.

La première performance WOD valide conserve son bonus de 40 XP. Les résultats sont ensuite parcourus dans l'ordre chronologique : chaque amélioration stricte ajoute 40 XP. Les égalités et résultats inachevés n'ajoutent pas de bonus de record. Pour l'AMRAP/EMOM, les rounds sont comparés avant les répétitions ; pour les WODs chronométrés, le meilleur temps doit être positif et plus court.

### Rangs et crédits

| Rang | Niveau minimum |
| --- | ---: |
| Recrue | 1 |
| Régulier | 5 |
| Challenger | 10 |
| Vétéran | 20 |
| Expert | 30 |
| Élite | 45 |
| Légende | 60 |

Les crédits sont calculés par `niveau + niveau ~/ 5 + niveau ~/ 10`. Le niveau 5 donne donc 2 crédits supplémentaires ; le niveau 10 en donne 3. Ces bonus continuent au-delà du niveau 10. Les achats déjà effectués restent déduits et les WODs déjà débloqués sont conservés.

### Objectifs hebdomadaires

| Objectif | Bonus |
| --- | ---: |
| 2 jours d'entraînement distincts | 75 XP |
| 3 jours d'entraînement distincts | 50 XP supplémentaires |
| 20 séries validées | 50 XP |
| 1 WOD terminé | 40 XP |

Les objectifs se renouvellent le lundi ; les bonus des semaines antérieures restent calculés depuis l'historique. Deux séances le même jour ne créent pas deux jours actifs. Une semaine comprenant au moins deux jours actifs prolonge la série de régularité ; la semaine en cours ne casse pas une série avant d'être terminée. Les jours de récupération du programme n'ajoutent pas de jour d'entraînement à ces objectifs.

### Seize badges

- Séances d'entraînement : 1, 10, 50 et 100.
- WODs terminés : 1, 10 et 50.
- Séries validées : 100, 500 et 2 000.
- WODs différents terminés : 5 et 20.
- Améliorations de records WOD : 1 et 10.
- Régularité : 4 et 12 semaines consécutives.

Chaque badge affiche son avancement et son bonus. Les bonus sont automatiques, sans bouton permettant de les réclamer plusieurs fois. Ils prennent en compte les anciennes séances datées. Les bonus de calendrier n'anticipent pas les activités datées dans le futur. Les anciennes séances sans date utilisent la date prévue du programme lorsqu'elle est disponible ; les séances personnelles sans date ne comptent pas pour la régularité.

**Les XP restent liées aux données : supprimer une séance ou un résultat retire les XP et peut retirer les badges/objectifs associés.** Importer deux fois la même sauvegarde ne double pas les récompenses. Une mise à jour peut augmenter immédiatement le niveau grâce aux bonus rétroactifs.

## Ergonomie et performances

- Écran **Ma progression**, avec parcours, onglet badges, barre de niveau, prochain rang, prochaines récompenses, objectifs, historique de régularité sur huit semaines et ventilation des XP.
- Accès depuis la pastille du niveau sur l'accueil, l'Arsenal et le Suivi.
- Dialogue de passage de niveau enrichi et défilable ; récompense du prochain niveau réellement calculée, y compris aux paliers.
- Réglages de notification regroupés avec actions de diagnostic explicites et boutons adaptés aux petits écrans.
- Sélecteurs de date/heure et composants Material localisés en français.
- Calcul de progression mutualisé et mis en cache. Une saisie de note/charge ne relance pas le parcours de tout l'historique ; les validations et modifications pertinentes l'invalident.
- Planification sérialisée et comparaison des alarmes déjà programmées pour éviter les écritures natives inutiles. La reprise dans l'app et la réparation manuelle permettent de forcer leur restauration.

## Installer et vérifier

1. Exporte une sauvegarde depuis l'application actuelle.
2. Remplace le zip à la racine du dépôt GitHub. Le dossier interne doit rester `streetlift_tracker/`.
3. Place le workflow fourni dans `.github/workflows/build-apk.yml`. Il conserve Flutter 3.29.3, la compilation du zip et l'artefact `kalis-track-apk`. Le délai maximal d'un test est explicité à 60 secondes.
4. Lance **Actions → Build APK**, puis récupère `kalis-track.apk` dans l'artefact.
5. Installe par-dessus l'app actuelle. L'identifiant `fr.tchoupi.streetlift_tracker`, la clé et le certificat d'origine sont conservés.
6. Dans **Réglages → Rappel quotidien**, active les rappels, vérifie le statut et lance **Tester maintenant**.
7. Autorise si souhaité **l'heure précise**, puis lance **Tester en veille** et verrouille l'écran. Avec l'autorisation, le test est prévu dans 15 secondes ; sinon il peut arriver plus tard.
8. Si nécessaire, vérifie le canal, le mode Ne pas déranger et les restrictions de batterie, notamment la veille profonde sur Samsung. Le bouton **Copier le diagnostic** est disponible en cas d'erreur logicielle.

Le programme et les données sportives sont inchangés : 40 semaines, 280 jours, 1 954 prescriptions et 172 exercices de référence. Le format de sauvegarde reste celui de la version 1.5 (format 3), avec lecture des formats antérieurs. Le rapport de la précédente révision est conservé dans `AUDIT_1.5.0.md`.

## Limites restantes

- L'OS et les réglages du constructeur peuvent bloquer la présentation des notifications. Un appel réussi au plugin ne prouve pas qu'une notification a été affichée à l'utilisateur.
- Les rappels concernent les dates du programme existant, pas des rappels génériques indéfinis après sa fin. Un changement de fuseau est repris à la prochaine ouverture/reprise de l'application.
- Les alertes sonores des chronomètres de séance/WOD restent distinctes des rappels quotidiens : il n'y a pas de service permanent garantissant leur sonnerie quand Android suspend ou termine le processus.
- Les nouveaux objectifs sont fondés sur le journal, sans capteur ni validation de l'effort réel. Les rangs expriment la progression dans l'application.

## Vérifications exécutées

```text
Flutter 3.29.3 / Dart 3.7.2
flutter pub get --offline                           dépendances résolues, lockfile actualisé
flutter analyze --no-pub                            No issues found!
TZ=Europe/Paris flutter test --no-pub --timeout 60s   74 tests réussis
python3 -m unittest discover -s tools/tests -v       4 tests réussis
python3 tools/verify_project.py --signing            assets, manifeste et signature vérifiés
```

Les sorties sont livrées dans `validation/`. Les tests de notifications simulent les réponses Android ; ils ne remplacent pas le test physique proposé dans les réglages.

## Références techniques utilisées

- [Documentation du plugin utilisé : flutter_local_notifications 18.0.1](https://pub.dev/packages/flutter_local_notifications/versions/18.0.1) : autorisations, configuration Android, limitations constructeurs et règles de minification.
- [Android — planification des alarmes](https://developer.android.com/develop/background-work/services/alarms) : distinction entre horaires exacts et approximatifs et comportement en veille.
