# Kalis Track 1.7.5 — drapeau français au lancement

Livraison du 19 septembre 2026, à partir de la version 1.7.4.

## Ajout

Un petit drapeau français apparaît au centre de l’écran de lancement, sur le fond sombre `#0E1216` de l’application. Trois bandes verticales égales, dans l’ordre bleu, blanc, rouge ; format 3:2, taille de référence **84 × 56 dp**.

Le drapeau accompagne le chargement réel, avant la première image Flutter. Il laisse place à l’application dès qu’elle est prête. Aucune temporisation supplémentaire, dépendance ou permission n’est ajoutée. La procédure de démarrage existante, son écran de secours en cas d’erreur et l’ouverture des séances depuis les notifications sont conservés.

## Intégration Android

- Jusqu’à Android 11 : image native centrée, avec une densité de référence mdpi ; Android adapte sa taille à la densité de l’écran.
- Android 12 et suivants : dessin vectoriel centré dans une toile transparente de 288 dp. Le drapeau tient entièrement dans la zone protégée du masque système.
- Android 13 et suivants : préférence explicite pour afficher le drapeau lorsque le système pourrait ne montrer que le fond.
- Même lancement sombre dans les modes jour et nuit. La préférence de thème de l’application est appliquée à l’ouverture de l’interface.

Les variantes suivent les mécanismes décrits dans la [documentation Flutter du lancement Android](https://docs.flutter.dev/platform-integration/android/splash-screen) et les [recommandations Android pour les écrans de lancement](https://developer.android.com/develop/ui/views/launch/splash-screen). Un retour à une application déjà active ne rejoue pas ce lancement.

## Vérifications

- Analyse Flutter : aucune anomalie.
- **84 tests Flutter et 4 tests Python réussis.** Journaux dans `validation/`.
- Ressources XML analysées ; références du fond et du drapeau, héritage des thèmes, variantes par API et absence de conflit avec le mode nuit vérifiés.
- Dimensions, ordre des couleurs, égalité des bandes et centrage vérifiés. Le dessin vectoriel reste dans le masque de sécurité Android 12.
- Aperçu de composition examiné à partir des ressources. Il ne s’agit pas d’une capture sur téléphone.
- Assets d’entraînement, données, niveaux, notifications, écrans de séance, contrôles harmonisés, icônes de l’application et clé de signature conservés.
- Configuration Gradle et workflow GitHub Actions inchangés.

**Limite :** l’APK n’a pas été compilé ni lancé dans cet environnement. Le rendu natif final reste à vérifier sur le téléphone après la compilation GitHub Actions.

## Mise à jour

Version **1.7.5+29**, vérifiée avec Flutter 3.29.3 et Dart 3.7.2.

Remplace **streetlift_tracker_v33.zip** à la racine du dépôt, puis lance **Actions → Build APK**. Télécharge l’artefact **kalis-track-apk**, extrais **kalis-track.apk** et installe-le par-dessus la version existante. Ferme complètement l’application puis ouvre-la pour voir le nouvel écran de lancement.
