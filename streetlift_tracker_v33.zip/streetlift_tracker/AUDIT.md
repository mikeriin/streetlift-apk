# Kalis Track 1.7.4 — boutons et saisies harmonisés

Livraison du 19 septembre 2026, à partir de la version 1.7.3.

## Corrections

Les contrôles utilisaient plusieurs hauteurs, formes et espacements selon les écrans. Les champs de performance étaient notamment plus bas que les boutons de validation, les listes déroulantes plus hautes que les autres champs, et certaines barres d’actions mêlaient des commandes de dimensions différentes.

| Zone | Correction |
| --- | --- |
| Composants communs | Hauteur de référence de 44 px logiques pour les boutons et les saisies sur une ligne, rayon de 10 px, icônes de commande de 20 px. Champs et sélecteurs ont le même alignement vertical. |
| Séance | Champs de performance et boutons de validation de même hauteur, commandes de validation rectangulaires arrondies, colonnes et espaces du chrono alignés. Les boutons Précédent et Suivant ont la même largeur. |
| Formulaires | Libellés toujours visibles, marges communes, champs numériques disposés sur une grille de deux colonnes ou une seule lorsque la largeur ou le texte le nécessite. |
| Arsenal | Deux actions de création de même largeur et hauteur, disposées en colonne sur les formats qui le nécessitent. |
| Réglages | Sélecteur de thème en trois segments égaux ; boutons plus et moins uniformes et valeur numérique centrée, avec une largeur adaptée au texte agrandi. |
| Pilotage | Valeurs, unités et champs alignés sur les règles de saisie communes. |
| WOD | Boutons du chrono organisés en grille ; action de réinitialisation explicitement nommée. Formulaire de résultat, aperçu et filtres utilisent les dimensions communes. |
| Éditeur de séance et catalogue | Marges des recherches et des formulaires alignées avec celles des cartes et des actions. |

La hauteur de référence n’est pas un plafond : les champs multilignes, les messages de validation et les grands caractères gardent la place nécessaire. Les formulaires et groupes d’actions s’adaptent à la largeur disponible.

La DA existante, le bouton Programme central, les couleurs des exercices et les petits repères séparés de progression de séance sont conservés. Les données, les notifications et le système de niveaux ne sont pas modifiés.

## Vérifications

- Analyse Flutter : aucune anomalie.
- **84 tests Flutter et 4 tests Python réussis.** Journaux dans `validation/`.
- Rendus de 18 vues dans les deux thèmes : écrans principaux, séance, chrono, formulaires, paramètres d’exercice, résultat WOD et filtres. Les sélecteurs ont été ajustés puis rendus à nouveau.
- Vérification supplémentaire de quatre vues à 320 × 760, texte à 130 %, avec les espaces système.
- Mesure des surfaces : champs sur une ligne, sélecteurs et boutons à 44 px logiques à taille de texte normale.
- La carte de référence S8/J1 garde une hauteur de **458 px logiques**. Les cinq séries restent visibles et validables sans défilement à **360 × 760**, avec RIR et 24 px d’espace système en haut et en bas.
- Navigation, saisies, notes, sauvegardes, thème, recherche, clavier, rotation et affichage large vérifiés par la suite existante.
- Programme et certificat de signature d’origine vérifiés. Les dépendances verrouillées, les assets, le projet Android et les moteurs de données, de notification, de progression et de chronométrage restent identiques à la version 1.7.3.

Les tests de notification restent absents de l’interface. Les services natifs sont simulés dans les tests locaux.

## Mise à jour

Version **1.7.4+28**, vérifiée avec Flutter 3.29.3 et Dart 3.7.2.

Remplace **streetlift_tracker_v33.zip** à la racine du dépôt GitHub puis lance **Actions → Build APK** avec le workflow déjà fourni. Télécharge l’artefact **kalis-track-apk**, extrais **kalis-track.apk** et installe-le par-dessus la version existante.

L’APK n’a pas été compilé ni installé dans cet environnement. La compilation Android reste effectuée par GitHub Actions.
