"""Archive de livraison sous 25 Mo, sans captures des anciennes versions."""
from pathlib import Path
import argparse
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
LIMIT = 25_000_000
CACHE_DIRS = {'.dart_tool', 'build', '.gradle', '__pycache__', '.git', '.idea'}
LOCAL_FILES = {'local.properties', '.flutter-plugins', '.flutter-plugins-dependencies'}
CAPTURE_FORMATS = {'.png', '.jpg', '.jpeg', '.webp', '.gif', '.mp4'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path, help='Chemin du ZIP à produire')
    output = parser.parse_args().output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + '.tmp')
    version = re.search(r'^version:\s*([^+\s]+)',
                        (ROOT / 'pubspec.yaml').read_text(), re.M).group(1)
    files = []
    for path in sorted(ROOT.rglob('*')):
        relative = path.relative_to(ROOT)
        if not path.is_file() or path in {output, temporary}:
            continue
        if set(relative.parts) & CACHE_DIRS or path.name in LOCAL_FILES or path.suffix == '.pyc':
            continue
        if (len(relative.parts) >= 3 and relative.parts[0] == 'validation'
                and relative.parts[1] != version and path.suffix.lower() in CAPTURE_FORMATS):
            continue
        files.append(path)
    expanded = sum(path.stat().st_size for path in files)
    if expanded >= LIMIT:
        raise SystemExit('Le dossier extrait dépasserait 25 Mo. Aucune archive remplacée.')
    try:
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in files:
                archive.write(path, 'streetlift_tracker/' + path.relative_to(ROOT).as_posix())
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise SystemExit('Archive invalide. Aucune archive remplacée.')
        size = temporary.stat().st_size
        if size >= LIMIT:
            raise SystemExit('Le ZIP dépasserait 25 Mo. Aucune archive remplacée.')
        temporary.replace(output)
    finally:
        temporary.unlink(missing_ok=True)
    print(f'{len(files)} fichiers · ZIP {size:,} octets · dossier {expanded:,} octets')


if __name__ == '__main__':
    main()
