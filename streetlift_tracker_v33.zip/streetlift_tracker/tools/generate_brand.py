"""Recrée le monogramme vectoriel et les icônes Android. Dépendance : Pillow."""
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets/icon'
RES = ROOT / 'android/app/src/main/res'
BURGUNDY = '#4F1D2E'
MARK = '<path d="M22 15V85 M78 15L43 48L82 85" fill="none" stroke="#FFFFFF" stroke-width="14" stroke-linecap="round" stroke-linejoin="round"/>'
SVG = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><rect width="1024" height="1024" rx="260" fill="{BURGUNDY}"/><g transform="translate(194.56 194.56) scale(6.3488)">{MARK}</g></svg>\n'

def glyph(size, background=None, adaptive=False):
    # Rendu quatre fois plus grand, puis anticrénelage de tous les traits.
    n = size * 4
    im = Image.new('RGBA', (n, n), background or (0, 0, 0, 0))
    draw = ImageDraw.Draw(im)
    extent = .60 if adaptive else .62
    offset = (1 - extent) / 2
    def point(x, y): return ((offset + extent * x / 100) * n, (offset + extent * y / 100) * n)
    width = round(.14 * extent * n)
    for coords in [[(22, 15), (22, 85)], [(78, 15), (43, 48), (82, 85)]]:
        pts = [point(*p) for p in coords]
        draw.line(pts, fill='white', width=width, joint='curve')
        for x, y in pts:
            r = width / 2
            draw.ellipse((x-r, y-r, x+r, y+r), fill='white')
    return im.resize((size, size), Image.Resampling.LANCZOS)

def main():
    ASSETS.mkdir(exist_ok=True, parents=True)
    (ASSETS / 'logo.svg').write_text(SVG)
    glyph(1024, BURGUNDY).convert('RGB').save(ASSETS / 'icon.png')
    glyph(1024, adaptive=True).save(ASSETS / 'icon_fg.png')
    for density, size, foreground in [('mdpi', 48, 108), ('hdpi', 72, 162), ('xhdpi', 96, 216), ('xxhdpi', 144, 324), ('xxxhdpi', 192, 432)]:
        glyph(size, BURGUNDY).convert('RGB').save(RES / f'mipmap-{density}/ic_launcher.png')
        for name in ['ic_launcher_foreground', 'ic_launcher_monochrome']:
            glyph(foreground, adaptive=True).save(RES / f'drawable-{density}/{name}.png')
    (RES / 'values/colors.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#4F1D2E</color>
    <color name="launch_background_color">#121013</color>
</resources>
''')
    (RES / 'drawable/ic_stat_kalis.xml').write_text('''<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp" android:height="24dp" android:viewportWidth="100" android:viewportHeight="100">
    <path android:fillColor="@android:color/transparent" android:strokeColor="#FFFFFFFF"
        android:strokeWidth="14" android:strokeLineCap="round" android:strokeLineJoin="round"
        android:pathData="M22,15 L22,85 M78,15 L43,48 L82,85"/>
</vector>
''')
    print('Logo SVG, sources PNG et 15 déclinaisons Android générés.')

if __name__ == '__main__':
    main()
