# -*- coding: utf-8 -*-
"""Atlas musculaire v2 (200×420) — anatomie détaillée, silhouette athlétique.
Formes = ancrages lissés (Catmull-Rom fermé) → cubiques → chaîne SVG. Moitié gauche miroitée."""
import json
from PIL import Image, ImageDraw, ImageFilter

W, H = 200, 420

def catmull_closed(pts, tension=0.5):
    n = len(pts); segs = []
    for i in range(n):
        p0, p1, p2, p3 = pts[(i-1) % n], pts[i], pts[(i+1) % n], pts[(i+2) % n]
        c1 = (p1[0] + (p2[0]-p0[0])*tension/3, p1[1] + (p2[1]-p0[1])*tension/3)
        c2 = (p2[0] - (p3[0]-p1[0])*tension/3, p2[1] - (p3[1]-p1[1])*tension/3)
        segs.append((p1, c1, c2, p2))
    return segs

def to_svg(segs):
    f = lambda v: f'{v:.1f}'
    s = f'M {f(segs[0][0][0])} {f(segs[0][0][1])} '
    for p1, c1, c2, p2 in segs:
        s += f'C {f(c1[0])} {f(c1[1])} {f(c2[0])} {f(c2[1])} {f(p2[0])} {f(p2[1])} '
    return s + 'Z'

def flatten(segs, k=12):
    out = []
    for p1, c1, c2, p2 in segs:
        for j in range(k):
            t = j / k
            out.append(((1-t)**3*p1[0] + 3*(1-t)**2*t*c1[0] + 3*(1-t)*t**2*c2[0] + t**3*p2[0],
                        (1-t)**3*p1[1] + 3*(1-t)**2*t*c1[1] + 3*(1-t)*t**2*c2[1] + t**3*p2[1]))
    return out

mirror = lambda pts: [(W - x, y) for (x, y) in pts]

# ------------------------------------------------------------------ silhouette athlétique
half = [(91,52),(89,60),(84,66),(72,70),(58,74),(48,80),(42,90),(40,104),(39,120),(40,138),
        (39,152),(37,170),(35,190),(36,208),(35,222),(41,236),(52,234),(56,220),(57,206),(60,188),
        (62,170),(63,154),(62,136),(64,118),(67,106),(66,120),(67,138),(70,152),(70,168),(67,184),
        (64,200),(63,220),(64,244),(66,266),(67,286),(66,302),(63,322),(63,342),(67,364),(70,384),
        (66,400),(68,412),(86,412),(89,400),(86,384),(84,366),(86,342),(88,320),(88,296),(86,276),
        (89,252),(93,228),(98,212),(100,206)]
silhouette = half + mirror(half)[::-1]
head = [(100,12),(111,15),(118,24),(119,38),(114,50),(106,56),(100,57),(94,56),(86,50),(81,38),(82,24),(89,15)]

# ------------------------------------------------------------------ muscles (moitié gauche)
FRONT = [
 ('gainage',   'sterno-cléido', [(90,54),(96,57),(96,68),(92,70),(88,64),(88,58)]),
 ('dos',       'trapèze (avant)', [(84,55),(93,53),(94,66),(84,71),(72,73),(60,75),(60,70),(70,65)]),
 ('épaules',   'deltoïde antérieur', [(70,72),(62,74),(58,84),(60,98),(66,106),(72,100),(76,88),(74,78)]),
 ('épaules',   'deltoïde latéral', [(60,74),(50,80),(45,92),(46,104),(52,110),(60,104),(58,92),(58,82)]),
 ('pectoraux', 'pectoral claviculaire', [(76,74),(98,76),(98,90),(86,94),(76,90),(72,82)]),
 ('pectoraux', 'pectoral sternal', [(72,90),(86,94),(98,90),(99,118),(92,128),(80,126),(70,116),(68,102)]),
 ('pectoraux', 'dentelé 1', [(66,112),(72,114),(72,120),(66,120)]),
 ('pectoraux', 'dentelé 2', [(67,123),(73,125),(73,131),(67,131)]),
 ('pectoraux', 'dentelé 3', [(68,134),(74,136),(74,142),(68,142)]),
 ('biceps',    'biceps', [(56,110),(64,108),(66,124),(64,142),(60,150),(54,146),(51,130),(52,116)]),
 ('biceps',    'brachial', [(50,124),(54,130),(55,146),(50,150),(46,140)]),
 ('avant-bras','brachio-radial', [(44,154),(56,152),(57,170),(50,186),(42,178),(40,164)]),
 ('avant-bras','fléchisseurs', [(56,154),(63,154),(62,176),(58,196),(52,204),(48,190),(52,172)]),
 ('gainage',   'abdos 1', [(87,128),(93,127),(98,128),(98,142),(93,143),(87,142)]),
 ('gainage',   'abdos 2', [(87,145),(93,144),(98,145),(98,159),(93,160),(87,159)]),
 ('gainage',   'abdos 3', [(87,162),(93,161),(98,162),(98,176),(93,177),(87,176)]),
 ('gainage',   'abdos 4', [(87,179),(93,178),(98,179),(98,196),(92,200),(86,194)]),
 ('gainage',   'oblique externe', [(72,128),(84,130),(85,176),(80,190),(72,186),(69,166),(69,146)]),
 ('quadriceps','droit fémoral', [(76,212),(86,212),(88,240),(86,268),(80,282),(74,278),(70,252),(70,228)]),
 ('quadriceps','vaste latéral', [(64,208),(75,212),(70,232),(69,256),(72,278),(66,272),(62,250),(62,228)]),
 ('quadriceps','vaste médial', [(87,238),(92,250),(93,270),(89,286),(83,286),(84,270),(86,254)]),
 ('quadriceps','adducteurs', [(90,210),(98,212),(98,240),(93,246),(90,232)]),
 ('mollets',   'tibial antérieur', [(72,296),(80,296),(83,320),(82,348),(77,360),(72,350),(68,320)]),
 ('mollets',   'gastrocnémien (face)', [(63,300),(71,300),(70,330),(66,346),(62,330)]),
]
BACK = [
 ('dos',       'trapèze supérieur', [(90,54),(100,54),(100,84),(88,90),(74,84),(62,76),(70,68),(80,62)]),
 ('dos',       'trapèze inférieur', [(88,90),(100,84),(100,140),(94,136),(86,118),(80,100)]),
 ('épaules',   'deltoïde postérieur', [(60,74),(50,80),(45,92),(46,104),(52,110),(62,106),(70,96),(72,82)]),
 ('dos',       'infra-épineux', [(64,86),(80,90),(84,106),(78,116),(66,112),(62,100)]),
 ('dos',       'grand dorsal', [(64,114),(80,118),(88,128),(92,150),(88,176),(76,186),(70,172),(66,148),(64,130)]),
 ('dos',       'lombaires', [(92,140),(100,140),(100,196),(94,200),(91,178),(90,158)]),
 ('triceps',   'triceps long', [(58,112),(66,110),(67,130),(64,148),(58,150),(55,134)]),
 ('triceps',   'triceps latéral', [(50,116),(57,112),(56,132),(56,148),(50,150),(46,138),(46,124)]),
 ('avant-bras','extenseurs', [(44,154),(60,154),(60,176),(54,198),(47,204),(41,184),(40,166)]),
 ('fessiers',  'moyen fessier', [(66,190),(80,192),(82,206),(70,208),(64,200)]),
 ('fessiers',  'grand fessier', [(68,208),(100,204),(100,244),(90,254),(76,250),(66,232)]),
 ('ischios',   'biceps fémoral', [(64,250),(78,252),(80,282),(74,300),(66,296),(62,276)]),
 ('ischios',   'semi-tendineux', [(80,252),(92,254),(94,280),(88,300),(80,300),(80,278)]),
 ('mollets',   'gastrocnémien latéral', [(64,306),(76,306),(77,336),(72,352),(64,346),(61,326)]),
 ('mollets',   'gastrocnémien médial', [(78,308),(90,308),(91,340),(85,360),(78,352),(77,330)]),
 ('mollets',   'soléaire', [(70,354),(84,356),(86,372),(78,380),(70,374)]),
]

def build(side, tension=0.5):
    shapes = []
    for g, name, pts in side:
        shapes.append((g, name, to_svg(catmull_closed(pts, tension)), pts))
        shapes.append((g, name + ' (d)', to_svg(catmull_closed(mirror(pts), tension)), mirror(pts)))
    return shapes

F, B = build(FRONT), build(BACK)
atlas = {'silhouette': to_svg(catmull_closed(silhouette, 0.4)), 'head': to_svg(catmull_closed(head, 0.55)),
         'front': [(g, n, p) for g, n, p, _ in F], 'back': [(g, n, p) for g, n, p, _ in B]}
json.dump(atlas, open('atlas.json', 'w'), ensure_ascii=False)

# ------------------------------------------------------------------ aperçu (rendu proche de l'app)
def heat(t):
    a, b, c = (233,196,106), (232,135,58), (224,100,92)
    if t < 0.5: u = t*2; return tuple(int(a[i]+(b[i]-a[i])*u) for i in range(3))
    u = (t-0.5)*2; return tuple(int(b[i]+(c[i]-b[i])*u) for i in range(3))

def preview(shapes, path, heatmap, S=3):
    bg = (14,18,22); skin = (38,46,54); rest = (60,70,80)
    im = Image.new('RGBA', (W*S, H*S), bg+(255,))
    d = ImageDraw.Draw(im)
    sil = [(x*S, y*S) for x, y in flatten(catmull_closed(silhouette, 0.4))]
    d.polygon(sil, fill=skin+(255,)); d.polygon([(x*S, y*S) for x, y in flatten(catmull_closed(head, 0.55))], fill=skin+(255,))
    glow = Image.new('RGBA', im.size, (0,0,0,0)); dg = ImageDraw.Draw(glow)
    for g, n, svg, pts in shapes:
        t = heatmap.get(g, 0)
        if t > 0.05:
            dg.polygon([(x*S, y*S) for x, y in flatten(catmull_closed(pts))], fill=heat(t)+(int(110*t),))
    glow = glow.filter(ImageFilter.GaussianBlur(9)); im.alpha_composite(glow); d = ImageDraw.Draw(im)
    for g, n, svg, pts in shapes:
        poly = [(x*S, y*S) for x, y in flatten(catmull_closed(pts))]
        t = heatmap.get(g, 0)
        d.polygon(poly, fill=(heat(t) if t > 0 else rest)+(255,), outline=bg+(255,))
    hl = Image.new('RGBA', im.size, (0,0,0,0))
    for g, n, svg, pts in shapes:
        poly = [(x*S, y*S) for x, y in flatten(catmull_closed(pts))]
        ys = [p[1] for p in poly]; y0, y1 = min(ys), max(ys)
        mask = Image.new('L', im.size, 0); ImageDraw.Draw(mask).polygon(poly, fill=255)
        grad = Image.new('RGBA', im.size, (0,0,0,0)); gd = ImageDraw.Draw(grad)
        for yy in range(int(y0), int(y1)+1):
            u = (yy - y0) / max(1, (y1 - y0))
            a = int(70*(1-u)**2) if u < 0.55 else 0
            b = int(40*((u-0.55)/0.45)**2) if u >= 0.55 else 0
            gd.line([(0, yy), (im.size[0], yy)], fill=(255,255,255,a) if a else (0,0,0,b))
        hl.paste(grad, (0,0), mask)
    im.alpha_composite(hl)
    im.convert('RGB').save(path)

heatmap = {'pectoraux':1.0,'épaules':0.6,'biceps':0.35,'gainage':0.5,'quadriceps':0.8,'dos':0.9,'triceps':0.4,
           'fessiers':0.5,'ischios':0.25,'mollets':0.3,'avant-bras':0.2}
preview(F, 'atlas_front.png', heatmap); preview(B, 'atlas_back.png', heatmap)
both = Image.new('RGB', (W*3*2+40, H*3), (14,18,22))
both.paste(Image.open('atlas_front.png'), (0,0)); both.paste(Image.open('atlas_back.png'), (W*3+40,0)); both.save('atlas_preview.png')
print('atlas v2 :', len(F), 'formes face,', len(B), 'formes dos')
