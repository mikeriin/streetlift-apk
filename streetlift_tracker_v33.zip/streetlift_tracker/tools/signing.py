"""Restaure et contrôle la clé existante ; aucune génération de clé."""
import argparse
import base64
import binascii
import hashlib
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
KEY_PATH = Path('signing/kalis_track.p12')
BASE64_NAME = 'KALIS_KEYSTORE_BASE64'
PASSWORD_NAME = 'KALIS_KEYSTORE_PASSWORD'


class SigningError(ValueError):
    pass


def secret_bytes(env):
    for name in (BASE64_NAME, PASSWORD_NAME):
        if not env.get(name):
            raise SigningError(f'Secret obligatoire absent : {name}. Release refusée.')
    encoded = env[BASE64_NAME].strip()
    if len(encoded) > 48_000:
        raise SigningError('KALIS_KEYSTORE_BASE64 dépasse la taille autorisée.')
    try:
        result = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error):
        raise SigningError('KALIS_KEYSTORE_BASE64 invalide : Base64 strict attendu.') from None
    if not result:
        raise SigningError('KALIS_KEYSTORE_BASE64 ne contient aucun keystore.')
    return result


def expected_certificate(root):
    expected = (root / 'signing/certificate.sha256').read_text().strip().lower()
    if not re.fullmatch(r'[0-9a-f]{64}', expected):
        raise SigningError('Référence publique certificate.sha256 invalide.')
    return expected


def keytool(path, env, operation):
    command = ['keytool', *operation, '-keystore', str(path), '-storetype', 'PKCS12',
               '-alias', 'kalis', '-storepass:env', PASSWORD_NAME]
    try:
        result = subprocess.run(command, env=env, capture_output=True, timeout=30)
    except FileNotFoundError:
        raise SigningError('keytool (Java 17) est nécessaire au contrôle de signature.') from None
    except subprocess.TimeoutExpired:
        raise SigningError('Le contrôle keytool a dépassé le délai autorisé.') from None
    if result.returncode:
        # Ne jamais recopier stdout/stderr : les outils tiers peuvent contenir des secrets.
        raise SigningError('Keystore illisible, mot de passe invalide, alias kalis absent '
                           'ou clé privée inaccessible. Release refusée.')
    return result.stdout


def verify_key(root, path, env):
    cert = keytool(path, env, ['-exportcert'])
    if hashlib.sha256(cert).hexdigest() != expected_certificate(root):
        raise SigningError('Certificat différent de la référence locale. Release refusée.')
    # Signer une requête en mémoire prouve l'accès à la clé privée existante.
    # Rien n'est généré comme nouvelle clé, écrit comme CSR ou envoyé à un service.
    keytool(path, env, ['-certreq', '-keypass:env', PASSWORD_NAME])


def verify_restored(root=ROOT, env=None):
    env = dict(os.environ if env is None else env)
    raw = secret_bytes(env)
    path = root / KEY_PATH
    if path.is_symlink() or not path.is_file():
        raise SigningError('Clé locale absente ou lien interdit. Exécuter tools/signing.py restore.')
    if path.read_bytes() != raw:
        raise SigningError('Clé locale différente de KALIS_KEYSTORE_BASE64. Release refusée.')
    verify_key(root, path, env)


def restore(root=ROOT, env=None):
    env = dict(os.environ if env is None else env)
    raw = secret_bytes(env)
    target = root / KEY_PATH
    if target.parent.is_symlink() or target.is_symlink():
        raise SigningError('Restauration refusée : lien symbolique dans le chemin de signature.')
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.restore-', dir=target.parent)
    temporary = Path(name)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw)
        verify_key(root, temporary, env)
        # Une copie locale différente ne doit pas être écrasée, même par un secret valide.
        if target.exists() and target.read_bytes() != raw:
            raise SigningError('Une autre copie locale existe. Conservation de cette copie ; restauration refusée.')
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)


def verify_apk(apk, apksigner, root=ROOT):
    result = subprocess.run([str(apksigner), 'verify', '--print-certs', str(apk)],
                            capture_output=True, text=True, timeout=60)
    if result.returncode:
        raise SigningError('La vérification cryptographique de l’APK a échoué.')
    certificates = re.findall(r'^Signer #\d+ certificate SHA-256 digest: ([0-9a-fA-F]+)\s*$',
                              result.stdout, re.M)
    if len(certificates) != 1 or certificates[0].lower() != expected_certificate(root):
        raise SigningError('Le certificat de l’APK diffère de la référence locale ou est ambigu.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('restore')
    apk = sub.add_parser('apk')
    apk.add_argument('apk', type=Path)
    apk.add_argument('apksigner', type=Path)
    args = parser.parse_args()
    try:
        if args.command == 'restore':
            restore()
            print('OK : clé existante restaurée ; accès privé et certificat local vérifiés.')
        else:
            verify_apk(args.apk, args.apksigner)
            print('OK : signature de l’APK vérifiée et certificat égal à la référence locale.')
    except (SigningError, OSError, subprocess.TimeoutExpired) as error:
        message = str(error) if isinstance(error, SigningError) else 'Échec du contrôle de signature (outil ou fichier inaccessible).'
        parser.exit(1, message + '\n')


if __name__ == '__main__':
    main()
