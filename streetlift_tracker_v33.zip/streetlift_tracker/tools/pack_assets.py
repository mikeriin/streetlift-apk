# -*- coding: utf-8 -*-
"""Compacte les assets : JSON → .json.gz (programme, base d'exercices) et
masques musculaires en PNG niveaux de gris + alpha optimisés."""
import gzip, os, shutil, sys
from PIL import Image
root = os.path.join(os.path.dirname(__file__), '..', 'assets')
for name in ('programme_v33.json', 'exercises_db.json'):
    src = os.path.join(root, name)
    if not os.path.exists(src):
        continue
    with open(src, 'rb') as f, gzip.open(src + '.gz', 'wb', compresslevel=9) as g:
        shutil.copyfileobj(f, g)
    print(f'{name}: {os.path.getsize(src)//1024} KB → {os.path.getsize(src+".gz")//1024} KB')
    os.remove(src)
mdir = os.path.join(root, 'muscles')
tot = 0
for fn in sorted(os.listdir(mdir)):
    if not fn.endswith('.png'):
        continue
    p = os.path.join(mdir, fn)
    Image.open(p).convert('LA').save(p, optimize=True)
    tot += os.path.getsize(p)
print(f'masques : {tot//1024} KB au total')
