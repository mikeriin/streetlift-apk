# -*- coding: utf-8 -*-
"""M2 (mannequin 3D) : sorties de tools/anatomy/build_model.py vérifiées sans
Blender (bibliothèque standard seulement) : SHA-256 de la source, budget de
triangles lu dans le GLB, nœuds du GLB ↔ régions de la carte, groupes,
correspondance avec les muscles du pack, crédits CC BY-SA."""
import hashlib
import json
import struct
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ANATOMY = ROOT / 'tools' / 'anatomy'
sys.path.insert(0, str(ANATOMY))

import anatomy_data  # noqa: E402
import build_model  # noqa: E402  (n'importe bpy que pour fabriquer)

GLB = ROOT / 'assets' / 'anatomy' / 'mannequin.glb'
MAP = ROOT / 'assets' / 'anatomy' / 'muscles_map.json'
ATTRIBUTION = ROOT / 'assets' / 'anatomy' / 'ATTRIBUTION.md'


def read_glb(path):
    data = path.read_bytes()
    magic, version, length = struct.unpack('<4sII', data[:12])
    assert magic == b'glTF' and version == 2 and length == len(data)
    chunk_len, chunk_type = struct.unpack('<I4s', data[12:20])
    assert chunk_type == b'JSON'
    return json.loads(data[20:20 + chunk_len])


def triangles(gltf):
    total = {}
    for node in gltf['nodes']:
        if 'mesh' not in node:
            continue
        count = 0
        for prim in gltf['meshes'][node['mesh']]['primitives']:
            assert prim.get('mode', 4) == 4, 'triangles seulement'
            count += gltf['accessors'][prim['indices']]['count'] // 3
        total[node['name']] = count
    return total


class M2AnatomyTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.gltf = read_glb(GLB)
        cls.map = json.loads(MAP.read_text(encoding='utf-8'))
        cls.tris = triangles(cls.gltf)
        cls.pack = anatomy_data.pack_muscles()

    def test_source_sha256(self):
        self.assertTrue(build_model.check_source())
        for name, expected in build_model.SOURCE_SHA256.items():
            digest = hashlib.sha256((ANATOMY / 'source' / name).read_bytes()).hexdigest()
            self.assertEqual(digest, expected, name)
        self.assertEqual(self.map['source']['sha256'],
                         build_model.SOURCE_SHA256['full-body-male-mobile.glb'])
        self.assertEqual(self.map['source']['commit'], build_model.SOURCE_COMMIT)

    def test_budget_de_triangles(self):
        total = sum(self.tris.values())
        self.assertLessEqual(total, build_model.TRIANGLE_BUDGET)
        self.assertEqual(total, self.map['triangles'])
        # Tous les nœuds ont une géométrie non vide.
        for name, count in self.tris.items():
            self.assertGreater(count, 0, name)

    def test_noeuds_et_regions(self):
        regions = {r['id'] for r in self.map['regions']}
        nodes = set(self.tris)
        self.assertEqual(nodes - regions, {'os', 'contexte', 'head'})
        self.assertEqual(regions - nodes, set())
        self.assertEqual(len(regions), len(self.map['regions']), 'ids uniques')
        removed = {r['id'] for r in self.map['retirees']}
        self.assertFalse(removed & nodes)
        for r in self.map['retirees']:
            self.assertEqual(r['raison'], 'profond, invisible au repos')

    def test_aucune_region_sans_groupe(self):
        self.assertEqual(self.map['groupes'], anatomy_data.APP_GROUPS)
        for r in self.map['regions']:
            self.assertIn(r['groupe'], anatomy_data.APP_GROUPS, r['id'])
            self.assertTrue(r['nom'], r['id'])
            self.assertIn(r['cote'], ('left', 'right'))
        for group in anatomy_data.APP_GROUPS:
            self.assertTrue(any(r['groupe'] == group for r in self.map['regions']), group)

    def test_muscles_du_pack(self):
        covered = {p for r in self.map['regions'] for p in r['pack']}
        self.assertTrue(covered <= set(self.pack), covered - set(self.pack))
        superficial = {k for k, (_, depth) in self.pack.items() if depth == 'superficiel'}
        self.assertEqual(superficial - covered, set(), 'muscle visible sans région')
        # Groupe d'une région = groupe de son (premier) muscle du pack.
        for r in self.map['regions']:
            if r['pack']:
                self.assertEqual(r['groupe'], self.pack[r['pack'][0]][0], r['id'])

    def test_noms_francais(self):
        for key in anatomy_data.model_groups():
            self.assertIn(key, anatomy_data.FR)
            self.assertIn(key, anatomy_data.PACK_OF_KEY)

    def test_credits(self):
        text = ATTRIBUTION.read_text(encoding='utf-8')
        for line in ('"Z-Anatomy - The libre 3D atlas of anatomy - CC-BY-SA 4.0"',
                     '"BodyParts3D - The Database Center for Life Science - CC-BY-SA 2.1 Japan"',
                     'https://creativecommons.org/licenses/by-sa/4.0/',
                     build_model.SOURCE_COMMIT):
            self.assertIn(line, text)
        source = (ANATOMY / 'source' / 'ATTRIBUTION.txt').read_text(encoding='utf-8')
        self.assertIn('Z-Anatomy - The libre 3D atlas of anatomy - CC-BY-SA 4.0', source)
        self.assertTrue((ANATOMY / 'source' / 'LICENSE.txt').is_file())

    def test_pubspec(self):
        pubspec = (ROOT / 'pubspec.yaml').read_text(encoding='utf-8')
        for asset in ('assets/anatomy/muscles_map.json', 'assets/anatomy/ATTRIBUTION.md',
                      'flutter_scene_generated/'):
            self.assertIn(f'    - {asset}\n', pubspec)
        # Le GLB passe par le build hook, pas par la liste des ressources.
        self.assertNotIn('- assets/anatomy/mannequin.glb', pubspec)
        self.assertNotIn('- assets/anatomy/\n', pubspec)
        hook = (ROOT / 'hook' / 'build.dart').read_text(encoding='utf-8')
        self.assertIn("'assets/anatomy/mannequin.glb'", hook)


if __name__ == '__main__':
    unittest.main()
