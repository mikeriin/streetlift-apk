"""Régressions KT-001 ; aucune vraie clé ni mot de passe dans les fixtures."""
import base64
import hashlib
import contextlib
import io
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from package_release import package
from release_security import PackagingError, check_archive, check_content
from signing import (BASE64_NAME, PASSWORD_NAME, SigningError, restore, secret_bytes,
                     apk_certificates, verify_apk, verify_key, verify_restored)


class SigningTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.raw = b'invalid-container-for-isolated-tests'
        self.env = dict(os.environ)
        self.env[BASE64_NAME] = base64.b64encode(self.raw).decode()
        self.env[PASSWORD_NAME] = 'fixture-' + 'only'

    def test_each_secret_required_and_invalid_base64_rejected(self):
        for name in (BASE64_NAME, PASSWORD_NAME):
            env = dict(self.env)
            del env[name]
            with self.assertRaisesRegex(SigningError, name):
                restore(self.root, env)
            self.assertFalse((self.root / 'signing').exists())
        self.env[BASE64_NAME] = '%%%'
        with self.assertRaisesRegex(SigningError, 'Base64 strict'):
            secret_bytes(self.env)

    def test_restoration_creates_directories_and_private_file(self):
        with patch('signing.verify_key') as verify:
            restore(self.root, self.env)
        target = self.root / 'signing/kalis_track.p12'
        self.assertEqual(target.read_bytes(), self.raw)
        self.assertEqual(target.stat().st_mode & 0o777, 0o600)
        verify.assert_called_once()
        self.assertEqual(list(target.parent.glob('.restore-*')), [])

    def test_invalid_secret_keeps_existing_copy_and_removes_temporary(self):
        target = self.root / 'signing/kalis_track.p12'
        target.parent.mkdir()
        target.write_bytes(b'existing-copy')
        with patch('signing.verify_key', side_effect=SigningError('refus')):
            with self.assertRaises(SigningError):
                restore(self.root, self.env)
        self.assertEqual(target.read_bytes(), b'existing-copy')
        self.assertEqual(list(target.parent.glob('.restore-*')), [])
        with patch('signing.verify_key'):
            with self.assertRaisesRegex(SigningError, 'autre copie locale'):
                restore(self.root, self.env)
        self.assertEqual(target.read_bytes(), b'existing-copy')

    def test_stale_file_and_symlink_are_rejected(self):
        target = self.root / 'signing/kalis_track.p12'
        target.parent.mkdir()
        target.write_bytes(b'stale')
        with self.assertRaisesRegex(SigningError, 'différente'):
            verify_restored(self.root, self.env)
        target.unlink()
        source = self.root / 'preserve'
        source.write_bytes(b'source')
        target.symlink_to(source)
        with self.assertRaisesRegex(SigningError, 'lien symbolique'):
            restore(self.root, self.env)
        self.assertEqual(source.read_bytes(), b'source')

    def test_keytool_errors_never_echo_external_output(self):
        failure = subprocess.CompletedProcess([], 1, b'private stdout', b'private stderr')
        with patch('signing.subprocess.run', return_value=failure) as run:
            with self.assertRaises(SigningError) as error:
                verify_key(self.root, self.root / 'key', self.env)
        self.assertNotIn('private stdout', str(error.exception))
        self.assertNotIn('private stderr', str(error.exception))
        self.assertNotIn(self.env[PASSWORD_NAME], run.call_args.args[0])
        self.assertIn('-storepass:env', run.call_args.args[0])

    def test_other_certificate_and_certificate_without_private_key_rejected(self):
        signing = self.root / 'signing'
        signing.mkdir()
        cert = b'public-certificate-fixture'
        (signing / 'certificate.sha256').write_text('0' * 64)
        with patch('signing.keytool', return_value=cert):
            with self.assertRaisesRegex(SigningError, 'Certificat différent'):
                verify_key(self.root, signing / 'key', self.env)
        (signing / 'certificate.sha256').write_text(hashlib.sha256(cert).hexdigest())
        with patch('signing.keytool', side_effect=[cert, SigningError('clé privée inaccessible')]):
            with self.assertRaisesRegex(SigningError, 'privée'):
                verify_key(self.root, signing / 'key', self.env)

    def test_apk_requires_valid_signature_and_exact_single_certificate(self):
        (self.root / 'signing').mkdir()
        expected = 'a' * 64
        (self.root / 'signing/certificate.sha256').write_text(expected)
        for rc, output, valid in [(0, expected, True), (0, 'b' * 64, False),
                                  (1, expected, False), (0, '', False)]:
            result = subprocess.CompletedProcess([], rc, 'Number of signers: 1\nSigner #1 certificate SHA-256 digest: ' + output, '')
            with patch('signing.subprocess.run', return_value=result), contextlib.redirect_stdout(io.StringIO()):
                if valid:
                    verify_apk('fixture.apk', 'apksigner', self.root)
                else:
                    with self.assertRaises(SigningError):
                        verify_apk('fixture.apk', 'apksigner', self.root)


class ApkCertificateTests(unittest.TestCase):
    """Sorties simulées selon les formats AOSP ; ces tests ne signent aucun APK."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root / 'signing').mkdir()
        self.expected = 'a1' * 32
        (self.root / 'signing/certificate.sha256').write_text(self.expected)

    def verify_output(self, output, rc=0):
        result = subprocess.CompletedProcess([], rc, output, 'UNTRUSTED STDERR')
        captured = io.StringIO()
        with patch('signing.subprocess.run', return_value=result), contextlib.redirect_stdout(captured):
            verify_apk('fixture.apk', 'apksigner', self.root)
        return captured.getvalue()

    def line(self, label='Signer #1', digest=None):
        return f'{label} certificate SHA-256 digest: {digest or self.expected}\n'

    def test_standard_output_ignores_public_key_and_source_stamp_digests(self):
        output = ('Verifies\nVerified using v1 scheme (JAR signing): true\n'
                  'Verified using v2 scheme (APK Signature Scheme v2): true\n'
                  'Number of signers: 1\nSigner #1 certificate DN: PUBLIC SUBJECT\n'
                  + self.line()
                  + 'Signer #1 public key SHA-256 digest: ' + 'b' * 64 + '\n'
                  + self.line('Source Stamp Signer', 'c' * 64))
        diagnostic = self.verify_output(output)
        self.assertIn(self.expected, diagnostic)
        self.assertNotIn('PUBLIC SUBJECT', diagnostic)
        self.assertNotIn('UNTRUSTED STDERR', diagnostic)
        self.assertEqual(apk_certificates(output), [self.expected])

    def test_platform_line_endings_whitespace_and_uppercase_digest(self):
        output = '\ufeffNumber of signers: 1\r\n  ' + self.line(digest=self.expected.upper()).rstrip() + '  \r\n'
        self.assertEqual(apk_certificates(output), [self.expected])
        self.verify_output(output)

    def test_sdk_range_labels_require_same_identity_for_every_range(self):
        labels = ['Signer (minSdkVersion=33, maxSdkVersion=2147483647)',
                  'Signer (minSdkVersion=28, maxSdkVersion=32)']
        output = 'Number of signers: 1\n' + ''.join(self.line(label) for label in labels)
        self.verify_output(output)
        self.verify_output('Number of signers: 1\n' + self.line('Signer (minSdkVersion=33 (dev release=true), maxSdkVersion=2147483647)'))
        with self.assertRaisesRegex(SigningError, 'Certificat APK différent'):
            self.verify_output('Number of signers: 1\n' + self.line(labels[0]) + self.line(labels[1], 'b' * 64))

    def test_different_certificate_diagnostic_contains_only_public_digests(self):
        observed = 'b' * 64
        with self.assertRaises(SigningError) as error:
            self.verify_output('Number of signers: 1\n' + self.line(digest=observed) + 'PRIVATE OR UNRELATED OUTPUT\n')
        message = str(error.exception)
        self.assertIn(self.expected, message)
        self.assertIn(observed, message)
        self.assertNotIn('PRIVATE OR UNRELATED OUTPUT', message)
        self.assertNotIn('UNTRUSTED STDERR', message)

    def test_ambiguous_multiple_missing_and_malformed_outputs_fail_closed(self):
        prefix = 'Number of signers: 1\n'
        rejected = [
            '', self.line(), 'Number of signers: unknown\n' + self.line(),
            prefix + prefix + self.line(), 'Number of signers: 0\n' + self.line(),
            'Number of signers: 2\n' + self.line() + self.line('Signer #2'),
            prefix + self.line() + self.line(), prefix + self.line('Signer #2'),
            prefix + self.line() + self.line('Signer #2'),
            prefix + self.line(digest='a' * 63), prefix + self.line(digest='a' * 65),
            prefix + self.line(digest='z' * 64), prefix + self.line('Source Stamp Signer'),
            prefix + self.line('Signer (minSdkVersion=33, maxSdkVersion=28)'),
            prefix + self.line('Signer #1 in unknown format'),
            prefix + self.line() + self.line('Signer (minSdkVersion=28, maxSdkVersion=32)'),
            prefix + self.line() + self.line('Signer #2', 'truncated'),
        ]
        for output in rejected:
            with self.subTest(output=output), self.assertRaises(SigningError):
                self.verify_output(output)

    def test_cryptographic_failure_never_passes_even_with_expected_digest(self):
        with self.assertRaisesRegex(SigningError, 'vérification cryptographique'):
            self.verify_output('Number of signers: 1\n' + self.line(), rc=1)


class PackagingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / 'project'
        self.root.mkdir()
        (self.root / 'pubspec.yaml').write_text('version: 2.5.0+51\n')
        self.output = self.root.parent / 'delivery.zip'

    def put(self, name, data):
        p = self.root / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)

    def test_secrets_artifacts_caches_excluded_public_reference_and_wrapper_preserved(self):
        forbidden = ['signing/kalis_track.p12', 'backup/copy.pfx', 'copy.jks', 'local.key',
                     'key.properties', '.env', '.env.local', 'build/app.apk', 'other.aab',
                     'backup.zip', '.dart_tool/cache', 'nested/__pycache__/cache.pyc']
        for path in forbidden:
            self.put(path, b'fixture')
        allowed = ['signing/certificate.sha256', 'android/gradle/wrapper/gradle-wrapper.jar',
                   'android/gradlew', 'public.pem']
        for path in allowed:
            self.put(path, b'public-fixture')
        package(self.root, self.output)
        check_archive(self.output)
        with zipfile.ZipFile(self.output) as z:
            names = {name.removeprefix('streetlift_tracker/') for name in z.namelist()}
        self.assertFalse(names & set(forbidden))
        self.assertTrue(set(allowed) <= names)
        self.assertTrue((self.root / forbidden[0]).exists())

    def test_private_content_and_plaintext_passwords_rejected_without_echo(self):
        # Entête synthétique, pas une clé ; teste la reconnaissance d'un conteneur renommé.
        container = bytes.fromhex('30820100020103300b06092a864886f70d010701') + b'x' * 90
        pem = ('-----BEGIN ' + 'PRIVATE KEY-----').encode()
        value = b'"fixture-sensitive-value"'
        assignments = [b''.join([b'store', b'Password', b' = ', value]),
                       b''.join([b'KALIS_KEYSTORE_', b'PASSWORD', b': ', value]),
                       b''.join([b'key', b'Password', b' = env ', b'?', b': ', value]),
                       b''.join([b'env.setdefault(', b'"KEYSTORE_', b'PASSWORD", ', value, b')']),
                       b''.join([b'env.get(', b'"KEYSTORE_', b'PASSWORD", ', value, b')'])]
        for data in [container, base64.b64encode(container), pem, *assignments]:
            with self.assertRaises(PackagingError) as error:
                check_content(PurePosixPath('docs/copy.txt'), data)
            self.assertNotIn('fixture-sensitive-value', str(error.exception))

    def test_rejected_delivery_preserves_previous_archive(self):
        self.output.write_bytes(b'previous-delivery')
        self.put('docs/copy.txt', ("-----BEGIN " + "RSA PRIVATE KEY-----").encode())
        with self.assertRaises(PackagingError):
            package(self.root, self.output)
        self.assertEqual(self.output.read_bytes(), b'previous-delivery')
        self.assertFalse(self.output.with_name(self.output.name + '.tmp').exists())

    def test_external_archive_rejects_traversal_secret_and_wrong_root(self):
        for name in ['streetlift_tracker/../escape', 'other/file',
                     'streetlift_tracker/signing/copy.p12']:
            with zipfile.ZipFile(self.output, 'w') as z:
                z.writestr(name, b'fixture')
            with self.assertRaises(PackagingError):
                check_archive(self.output)

    def test_symlink_refused(self):
        (self.root / 'link').symlink_to(self.root / 'pubspec.yaml')
        with self.assertRaises(PackagingError):
            package(self.root, self.output)


if __name__ == '__main__':
    unittest.main()
