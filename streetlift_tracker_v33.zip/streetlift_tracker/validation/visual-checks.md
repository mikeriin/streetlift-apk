# Vérification visuelle 1.7.3

Rendus locaux de la séance S8/J1 en clair et en sombre : première étape, étape suivante et bilan à 390 × 844, puis première étape avec RIR à 360 × 760 et espaces système de 24 px en haut et en bas.

Retour aux repères séparés de la version 1.6 : repère actif plus long et coloré, autres repères discrets. L’état actif se déplace au changement de page et atteint le dernier repère sur le bilan. Les marges compactes de la version 1.7.2 sont conservées.

Dans les deux formats et les deux thèmes, la carte initiale garde une hauteur de 458 px logiques, sans défilement vertical initial. La cinquième série est visible ; les boutons de validation restent à 44 × 44. Le test permanent vérifie également la visibilité complète des champs et la validation de cette cinquième série sur petit écran.

Rendus locaux sans compilation ni installation Android. Le script temporaire de rendu ne fait pas partie de la livraison.
