# Vérification visuelle 1.7.6

18 vues ont été rendues en clair et en sombre, avec Roboto et les icônes Material : Programme, Arsenal, Suivi, séance, progression, réglages, Pilotage, catalogue, aperçu WOD, séance avec RIR, séance avec chrono, éditeur de séance, éditeur WOD, chrono WOD, saisie de résultat, paramètres d’exercice, filtres et réglages des chronos.

Les vues de référence utilisent 390 × 844 avec 24 px d’espace système en haut et en bas. La séance avec RIR utilise 360 × 760. Quatre vues complémentaires (réglages des chronos, chrono WOD, éditeur WOD et paramètres d’exercice) ont également été rendues à 320 × 760 avec texte à 130 %, dans chacun des deux thèmes.

## Dimensions et lisibilité

- Cellules de performance : surface visible mesurée à 36 px ; zone tactile étendue verticalement à 44 px. Chiffres de taille 15, graisse normale et tabulaires.
- Champs de formulaire et listes déroulantes : 40 px à taille de texte normale. Les champs multilignes et textes agrandis grandissent librement.
- Boutons : surface de référence de 36 px, zone tactile de 44 px de haut, alignement sur un axe commun. Les boutons de validation de série ont une cible de 44 × 44.
- Carte initiale « Muscle-up lesté » S8/J1 : 450 px logiques, cinq séries visibles, aucun défilement vertical initial dans les deux vues de référence.
- Repères de progression séparés conservés. Les cellules, icônes de validation et en-têtes de colonne restent centrés sur les mêmes axes.
- Contrôles secondaires moins remplis, fonds des cellules et badges atténués, graisses de textes réduites. Palette et bandeaux précédents conservés.

Les hauteurs des champs sont mesurées via le conteneur de décoration Flutter. Un test d’interaction vérifie qu’un appui dans la marge extérieure de la cellule active le champ, sélectionne la valeur et enregistre la nouvelle saisie. Les tests existants vérifient aussi petits écrans, grands textes, clavier, orientation paysage et conservation de l’état.

Les vues représentatives de séance, réglages, WOD, Arsenal et paramètres ont été inspectées. Les rendus étroits ont motivé le retour à la ligne des aides de formulaire. L’inspection visuelle et les tests Flutter complètent l’analyse statique ; ils ne constituent pas un essai sur téléphone.

## Lancement Android

Les fichiers Android sont identiques à la version 1.7.5 : drapeau bleu, blanc, rouge de 84 × 56 dp centré sur le fond sombre, variantes Android 12 et 13 incluses. La validation des ressources de cette version est conservée dans `launch-resources.json`.

Aucune compilation ni installation APK locale. Les outils temporaires de rendu sont exclus du ZIP.
