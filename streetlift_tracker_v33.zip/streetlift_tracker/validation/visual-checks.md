# Vérification visuelle 1.7.2

Neuf écrans rendus à 390 × 844, en clair et en sombre : Programme, Arsenal, Suivi, séance, progression, Pilotage, réglages, catalogue et aperçu WOD. Saisie vérifiée ensuite à 360 × 760 avec espaces système de 24 px et colonne RIR.

La carte initiale de S8/J1 passe de 689 à 458 px logiques. Le défilement initial de cette page passe de 55 à 0. Mesures prises avec Roboto et une taille de texte normale ; les notes vides sont repliées et les consignes accessibles sur demande en 1.7.2.

La numérotation a été abrégée en « N° » après inspection pour éviter le retour à la ligne de l’en-tête. Les contrôles de série mesurent 44 × 44. Les tests permanents vérifient la visibilité complète et la validation de la cinquième série, ainsi que les petits écrans avec texte agrandi.

Rendus locaux sans compilation ni installation Android.
