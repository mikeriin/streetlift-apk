# Vérification visuelle 1.7.4

18 vues rendues en clair et en sombre avec Roboto et les icônes Material : Programme, Arsenal, Suivi, séance, progression, réglages, Pilotage, catalogue, aperçu WOD, séance avec RIR, séance avec chrono, éditeur de séance, éditeur WOD, chrono WOD, saisie de résultat, paramètres d’exercice, filtres et réglages des chronos.

Les vues utilisent 390 × 844 avec 24 px d’espace système en haut et en bas. La séance avec RIR utilise 360 × 760 avec les mêmes espaces système. Les réglages, le chrono WOD, l’éditeur WOD et les paramètres d’exercice sont également rendus à 320 × 760 avec texte à 130 %.

Les surfaces de saisie sont mesurées via le conteneur de décoration Flutter, pas seulement via la boîte extérieure du widget. Les champs sur une ligne, les listes déroulantes, les segments de thème et les boutons mesurent 44 px logiques à taille de texte normale. Les champs multilignes gardent une hauteur adaptée à leur contenu. Les valeurs et les boutons de validation des séries sont alignés verticalement.

La carte initiale S8/J1 conserve 458 px logiques de haut, avec cinq séries visibles et aucun défilement vertical initial dans les rendus de référence. Les boutons de validation restent à 44 × 44. Les repères séparés de progression sont conservés.

Les formulaires, actions voisines et commandes du chrono sont vérifiés après mise en grille. Les listes déroulantes et le sélecteur de thème ont été ajustés puis rendus à nouveau pour corriger leurs dimensions propres au composant Flutter. Les scripts temporaires de rendu sont exclus du ZIP.

Rendus locaux sans compilation ni installation Android.
