# Vérification visuelle 1.7.1

Rendus Flutter à 390 × 844, thèmes clair et sombre : Programme, Arsenal, Suivi, séance, progression, Pilotage, réglages, catalogue, aperçu WOD.

Corrections après inspection : unités longues abrégées dans le Pilotage, dates du bandeau lisibles et espacements des sections de progression harmonisés. Les écrans concernés ont été rendus à nouveau.

Les tests permanents complètent ces rendus à 320 px avec texte 130 %, en paysage 640 × 360 et sur écran 1024 × 768. Rendus locaux, sans compilation ni installation Android.
