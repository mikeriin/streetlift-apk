# Vérification visuelle 1.7.5

L’écran de lancement est natif Android. Aperçu de composition calculé depuis les ressources à 390 × 844 : drapeau de 84 × 56 centré sur le fond #0E1216, trois bandes égales bleu, blanc, rouge. Il ne s’agit pas d’une capture Android.

Le bitmap mdpi et le vecteur Android 12 portent les mêmes couleurs et proportions. Le vecteur utilise une toile de 288 × 288 avec un drapeau central de 84 × 56, entièrement à l’intérieur du cercle de sécurité de 192 dp. Les versions Android 13 et suivantes demandent l’affichage de l’icône de lancement.

Les modes jour et nuit partagent les mêmes variantes de lancement. Le pipeline d’icônes du workflow conserve la nouvelle couleur dans colors.xml. Le chargement Flutter existant et les écrans de l’application sont inchangés, hormis le numéro de version affiché.

Vérifications détaillées des ressources dans launch-resources.json. Aucun lancement natif ni compilation APK n’a été effectué localement.

---

## Vérifications antérieures conservées pour l’interface inchangée

# Vérification visuelle 1.7.4

18 vues rendues en clair et en sombre avec Roboto et les icônes Material : Programme, Arsenal, Suivi, séance, progression, réglages, Pilotage, catalogue, aperçu WOD, séance avec RIR, séance avec chrono, éditeur de séance, éditeur WOD, chrono WOD, saisie de résultat, paramètres d’exercice, filtres et réglages des chronos.

Les vues utilisent 390 × 844 avec 24 px d’espace système en haut et en bas. La séance avec RIR utilise 360 × 760 avec les mêmes espaces système. Les réglages, le chrono WOD, l’éditeur WOD et les paramètres d’exercice sont également rendus à 320 × 760 avec texte à 130 %.

Les surfaces de saisie sont mesurées via le conteneur de décoration Flutter, pas seulement via la boîte extérieure du widget. Les champs sur une ligne, les listes déroulantes, les segments de thème et les boutons mesurent 44 px logiques à taille de texte normale. Les champs multilignes gardent une hauteur adaptée à leur contenu. Les valeurs et les boutons de validation des séries sont alignés verticalement.

La carte initiale S8/J1 conserve 458 px logiques de haut, avec cinq séries visibles et aucun défilement vertical initial dans les rendus de référence. Les boutons de validation restent à 44 × 44. Les repères séparés de progression sont conservés.

Les formulaires, actions voisines et commandes du chrono sont vérifiés après mise en grille. Les listes déroulantes et le sélecteur de thème ont été ajustés puis rendus à nouveau pour corriger leurs dimensions propres au composant Flutter. Les scripts temporaires de rendu sont exclus du ZIP.

Rendus locaux sans compilation ni installation Android.
