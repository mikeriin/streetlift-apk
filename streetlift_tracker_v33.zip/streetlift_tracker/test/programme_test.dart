import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:streetlift_tracker/main.dart';
import 'package:streetlift_tracker/home_screen.dart';
import 'package:streetlift_tracker/muscle_body.dart';
import 'package:streetlift_tracker/estimate_view.dart';
import 'package:streetlift_tracker/session_history.dart';
import 'package:streetlift_tracker/session_screen.dart';
import 'package:streetlift_tracker/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await store.init();
    store.settings
      ..sound = false
      ..vibration = false
      ..wakelock = false
      ..autoTimer = false;
  });
  setUp(() => store.logs.clear());

  Future<void> open(
    WidgetTester tester, {
    double width = 360,
    double scale = 1,
    bool dark = true,
    int day = 4,
  }) async {
    tester.view.physicalSize = Size(width, 760);
    tester.view.devicePixelRatio = 1;
    tester.view.padding = const FakeViewPadding(top: 24, bottom: 24);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    addTearDown(tester.view.resetPadding);
    await tester.pumpWidget(
      MaterialApp(
        theme: buildTheme(dark),
        locale: const Locale('fr'),
        supportedLocales: const [Locale('fr')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        builder:
            (context, child) => MediaQuery(
              data: MediaQuery.of(
                context,
              ).copyWith(textScaler: TextScaler.linear(scale)),
              child: child!,
            ),
        home: Scaffold(
          body: HomeScreen(referenceDate: store.program.dateFor(8, day)),
          bottomNavigationBar: HeroNavBar(index: 2, onTap: (_) {}),
        ),
      ),
    );
    await tester.pumpAndSettle();
  }

  testWidgets(
    'sept cartes visibles et appui court lance directement la bonne séance',
    (tester) async {
      await open(tester);
      expect(find.text('S8'), findsOneWidget);
      expect(find.textContaining('AUJOURD’HUI'), findsNothing);
      expect(find.byType(PopupMenuButton<String>), findsNothing);
      expect(find.byType(MuscleHeatmap), findsOneWidget);
      for (var j = 1; j <= 7; j++) {
        final card = find.byKey(ValueKey('programme-day-$j'));
        expect(card.hitTestable(), findsOneWidget);
        if (j != 4) expect(tester.getSize(card).height, lessThanOrEqualTo(48));
      }
      expect(
        tester.getSize(find.byKey(const ValueKey('programme-day-4'))).height,
        greaterThan(100),
      );
      expect(
        tester.getRect(find.byKey(const ValueKey('programme-day-7'))).bottom,
        lessThan(tester.getRect(find.byType(HeroNavBar)).top),
      );
      await tester.tap(find.byKey(const ValueKey('programme-day-2')));
      await tester.pumpAndSettle();
      final session = tester.widget<SessionScreen>(find.byType(SessionScreen));
      expect(session.week.n, 8);
      expect(session.day.j, 2);
      expect(tester.takeException(), null);
      await tester.pumpWidget(const SizedBox());
      await tester.pumpAndSettle();
    },
  );

  testWidgets(
    'appui court sur une séance faite ouvre son historique sans modifier les saisies',
    (tester) async {
      final exercise = store.program.week(8).day(2)!.exercises.first;
      final entry = store.exLog(8, 2, exercise);
      entry.sets.first
        ..kg = '12.5'
        ..reps = '7'
        ..done = true;
      entry.note = 'Note conservée';
      final log =
          store.sessionLog(8, 2)
            ..done = true
            ..title = 'S8 · J2';
      final before = jsonEncode(log.toJson());
      await open(tester);
      await tester.tap(find.byKey(const ValueKey('programme-day-2')));
      await tester.pumpAndSettle();
      expect(find.byType(SessionHistoryScreen), findsOneWidget);
      expect(find.byType(SessionScreen), findsNothing);
      expect(find.text('12.5'), findsOneWidget);
      expect(find.text('7'), findsWidgets);
      expect(find.byType(EditableText), findsNothing);
      expect(find.text('Note conservée'), findsOneWidget);
      expect(jsonEncode(log.toJson()), before);
      expect(tester.takeException(), null);
    },
  );

  testWidgets(
    'appui long sur une carte compacte ouvre le résumé sans lancer ni effacer',
    (tester) async {
      final log = store.sessionLog(8, 1)..title = 'À conserver';
      final before = jsonEncode(log.toJson());
      await open(tester);
      await tester.longPress(find.byKey(const ValueKey('programme-day-1')));
      await tester.pumpAndSettle();
      expect(find.text('Résumé · S8 · J1'), findsOneWidget);
      expect(find.byType(EstimateView), findsOneWidget);
      expect(find.byType(SessionScreen), findsNothing);
      expect(find.byType(AlertDialog), findsNothing);
      expect(jsonEncode(store.sessionLog(8, 1).toJson()), before);
      expect(tester.takeException(), null);
    },
  );

  testWidgets(
    'le curseur glisse jusqu’aux bornes ; seul un appui long ouvre le détail',
    (tester) async {
      await open(tester);
      final label = find.byKey(const ValueKey('selected-week'));
      await tester.tapAt(tester.getCenter(label));
      await tester.pumpAndSettle();
      expect(find.byType(DraggableScrollableSheet), findsNothing);
      expect(find.text('S8'), findsOneWidget);
      await tester.longPressAt(tester.getCenter(label));
      await tester.pumpAndSettle();
      expect(find.text('Semaine 8'), findsOneWidget);
      expect(find.textContaining('journées validées'), findsOneWidget);
      Navigator.of(tester.element(find.byType(DraggableScrollableSheet))).pop();
      await tester.pumpAndSettle();
      await tester.dragFrom(tester.getCenter(label), const Offset(500, 0));
      await tester.pumpAndSettle();
      expect(find.text('S40'), findsOneWidget);
      expect(find.byType(DraggableScrollableSheet), findsNothing);
      await tester.longPressAt(tester.getCenter(label));
      await tester.pumpAndSettle();
      expect(find.text('Semaine 40'), findsOneWidget);
      Navigator.of(tester.element(find.byType(DraggableScrollableSheet))).pop();
      await tester.pumpAndSettle();
      await tester.dragFrom(tester.getCenter(label), const Offset(-500, 0));
      await tester.pumpAndSettle();
      expect(find.text('S1'), findsOneWidget);
      await tester.longPressAt(tester.getCenter(label));
      await tester.pumpAndSettle();
      expect(find.text('Semaine 1'), findsOneWidget);
      expect(tester.takeException(), null);
    },
  );

  testWidgets(
    'le calendrier permet de choisir une semaine sans perdre les gestes des cartes',
    (tester) async {
      await open(tester);
      await tester.tap(find.byTooltip('Choisir une semaine'));
      await tester.pumpAndSettle();
      await tester.tap(find.textContaining('Semaine 2 ·'));
      await tester.pumpAndSettle();
      expect(find.text('S2'), findsOneWidget);
      expect(find.byType(MuscleHeatmap), findsNothing);
      await tester.longPress(find.byKey(const ValueKey('programme-day-2')));
      await tester.pumpAndSettle();
      expect(find.text('Résumé · S2 · J2'), findsOneWidget);
      expect(tester.takeException(), null);
    },
  );

  for (final dark in [true, false]) {
    testWidgets('résumé à 320 px avec texte 130 %, thème $dark', (
      tester,
    ) async {
      await open(tester, width: 320, scale: 1.3, dark: dark);
      await tester.longPress(find.byKey(const ValueKey('programme-day-4')));
      await tester.pumpAndSettle();
      expect(find.byType(EstimateView), findsOneWidget);
      expect(find.text('Effort'), findsOneWidget);
      expect(find.text('Repos'), findsOneWidget);
      expect(tester.takeException(), null);
    });
  }

  testWidgets(
    'un jour de récupération garde un résumé lisible et reste ouvrable',
    (tester) async {
      await open(tester, day: 7);
      await tester.longPress(find.byKey(const ValueKey('programme-day-7')));
      await tester.pumpAndSettle();
      expect(find.text('Résumé · S8 · J7'), findsOneWidget);
      expect(find.byType(EstimateView), findsNothing);
      expect(tester.takeException(), null);
      Navigator.of(tester.element(find.text('Résumé · S8 · J7'))).pop();
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('programme-day-7')));
      await tester.pumpAndSettle();
      expect(find.byType(SessionScreen), findsOneWidget);
      expect(tester.takeException(), null);
      await tester.pumpWidget(const SizedBox());
      await tester.pumpAndSettle();
      store.sessionLog(8, 7).done = true;
      await open(tester, day: 7);
      await tester.tap(find.byKey(const ValueKey('programme-day-7')));
      await tester.pumpAndSettle();
      expect(find.byType(SessionHistoryScreen), findsOneWidget);
      expect(
        find.text('Aucune série enregistrée pour cette séance.'),
        findsOneWidget,
      );
      expect(tester.takeException(), null);
    },
  );
}
