import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:streetlift_tracker/main.dart';
import 'package:flutter/services.dart';
import 'package:streetlift_tracker/muscle_body.dart';
import 'package:streetlift_tracker/estimate_view.dart';
import 'package:streetlift_tracker/session_history.dart';
import 'package:streetlift_tracker/session_screen.dart';
import 'package:streetlift_tracker/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await store.init();
    store.settings
      ..sound = false
      ..vibration = false
      ..wakelock = false
      ..autoTimer = false;
  });
  setUp(() => store.logs.clear());

  Future<void> open(
    WidgetTester tester, {
    double width = 360,
    double scale = 1,
    bool dark = true,
    int day = 4,
  }) async {
    tester.view.physicalSize = Size(width, 760);
    tester.view.devicePixelRatio = 1;
    tester.view.padding = const FakeViewPadding(top: 24, bottom: 24);
    tester.view.viewPadding = const FakeViewPadding(top: 24, bottom: 24);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    addTearDown(tester.view.resetPadding);
    addTearDown(tester.view.resetViewPadding);
    store.settings.theme = dark ? 'dark' : 'light';
    await tester.pumpWidget(
      MaterialApp(
        theme: buildTheme(dark),
        locale: const Locale('fr'),
        supportedLocales: const [Locale('fr')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        builder:
            (context, child) => MediaQuery(
              data: MediaQuery.of(
                context,
              ).copyWith(textScaler: TextScaler.linear(scale)),
              child: child!,
            ),
        home: RootNav(referenceDate: store.program.dateFor(8, day)),
      ),
    );
    await tester.pumpAndSettle();
  }

  testWidgets(
    'sept cartes accessibles, séance du jour développée et appui court direct',
    (tester) async {
      await open(tester);
      expect(find.text('S8'), findsOneWidget);
      expect(find.textContaining('AUJOURD’HUI'), findsNothing);
      expect(find.byType(PopupMenuButton<String>), findsNothing);
      expect(find.byType(MuscleHeatmap), findsOneWidget);
      for (final caption in ['AVANT', 'ARRIÈRE', 'ARRIERE', 'FACE', 'DOS']) {
        expect(find.text(caption), findsNothing);
      }
      for (var j = 1; j <= 7; j++) {
        final card = find.byKey(ValueKey('programme-day-$j'));
        expect(card, findsOneWidget);
        if (j != 4) expect(tester.getSize(card).height, lessThanOrEqualTo(48));
      }
      expect(
        tester.getSize(find.byKey(const ValueKey('programme-day-4'))).height,
        greaterThan(100),
      );
      await tester.drag(
        find.byKey(const PageStorageKey('programme-scroll')),
        const Offset(0, -300),
      );
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('programme-day-7')).hitTestable(),
        findsOneWidget,
      );
      expect(
        tester.getRect(find.byKey(const ValueKey('programme-day-7'))).bottom,
        lessThan(tester.getRect(find.byType(HeroNavBar)).top),
      );
      await tester.drag(
        find.byKey(const PageStorageKey('programme-scroll')),
        const Offset(0, 500),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('programme-day-2')));
      await tester.pumpAndSettle();
      final session = tester.widget<SessionScreen>(find.byType(SessionScreen));
      expect(session.week.n, 8);
      expect(session.day.j, 2);
      expect(tester.takeException(), null);
      await tester.pumpWidget(const SizedBox());
      await tester.pumpAndSettle();
    },
  );

  testWidgets(
    'appui court sur une séance faite ouvre son historique sans modifier les saisies',
    (tester) async {
      final exercise = store.program.week(8).day(2)!.exercises.first;
      final entry = store.exLog(8, 2, exercise);
      entry.sets.first
        ..kg = '12.5'
        ..reps = '7'
        ..done = true;
      entry.note = 'Note conservée';
      final log =
          store.sessionLog(8, 2)
            ..done = true
            ..title = 'S8 · J2';
      final before = jsonEncode(log.toJson());
      await open(tester);
      await tester.tap(find.byKey(const ValueKey('programme-day-2')));
      await tester.pumpAndSettle();
      expect(find.byType(SessionHistoryScreen), findsOneWidget);
      expect(find.byType(SessionScreen), findsNothing);
      expect(find.text('12.5'), findsOneWidget);
      expect(find.text('7'), findsWidgets);
      expect(find.byType(EditableText), findsNothing);
      expect(find.text('Note conservée'), findsOneWidget);
      expect(jsonEncode(log.toJson()), before);
      expect(tester.takeException(), null);
    },
  );

  testWidgets(
    'appui long sur une carte compacte ouvre le résumé sans lancer ni effacer',
    (tester) async {
      final log = store.sessionLog(8, 1)..title = 'À conserver';
      final before = jsonEncode(log.toJson());
      await open(tester);
      await tester.longPress(find.byKey(const ValueKey('programme-day-1')));
      await tester.pumpAndSettle();
      expect(find.text('Résumé · S8 · J1'), findsOneWidget);
      expect(find.byType(EstimateView), findsOneWidget);
      expect(find.byType(SessionScreen), findsNothing);
      expect(find.byType(AlertDialog), findsNothing);
      expect(jsonEncode(store.sessionLog(8, 1).toJson()), before);
      expect(tester.takeException(), null);
    },
  );

  testWidgets(
    'appui court ouvre le détail ; glisser atteint les bornes sans ouvrir de fiche',
    (tester) async {
      await open(tester);
      final label = find.byKey(const ValueKey('selected-week'));
      await tester.tapAt(tester.getCenter(label));
      await tester.pumpAndSettle();
      expect(find.text('Semaine 8'), findsOneWidget);
      expect(find.textContaining('journées validées'), findsOneWidget);
      Navigator.of(tester.element(find.byType(DraggableScrollableSheet))).pop();
      await tester.pumpAndSettle();
      await tester.dragFrom(tester.getCenter(label), const Offset(500, 0));
      await tester.pumpAndSettle();
      expect(find.text('S40'), findsOneWidget);
      expect(find.byType(DraggableScrollableSheet), findsNothing);
      await tester.tapAt(tester.getCenter(label));
      await tester.pumpAndSettle();
      expect(find.text('Semaine 40'), findsOneWidget);
      Navigator.of(tester.element(find.byType(DraggableScrollableSheet))).pop();
      await tester.pumpAndSettle();
      await tester.dragFrom(tester.getCenter(label), const Offset(-500, 0));
      await tester.pumpAndSettle();
      expect(find.text('S1'), findsOneWidget);
      await tester.tapAt(tester.getCenter(label));
      await tester.pumpAndSettle();
      expect(find.text('Semaine 1'), findsOneWidget);
      expect(tester.takeException(), null);
    },
  );

  testWidgets(
    'la fiche semaine donne accès au choix de semaine et conserve les gestes des cartes',
    (tester) async {
      await open(tester);
      await tester.tap(find.byKey(const ValueKey('selected-week')));
      await tester.pumpAndSettle();
      await tester.scrollUntilVisible(
        find.text('Choisir une semaine'),
        200,
        scrollable: find.byType(Scrollable).last,
      );
      await tester.tap(find.text('Choisir une semaine'));
      await tester.pumpAndSettle();
      await tester.tap(find.textContaining('Semaine 2 ·'));
      await tester.pumpAndSettle();
      expect(find.text('S2'), findsOneWidget);
      expect(find.byType(MuscleHeatmap), findsNothing);
      await tester.longPress(find.byKey(const ValueKey('programme-day-2')));
      await tester.pumpAndSettle();
      expect(find.text('Résumé · S2 · J2'), findsOneWidget);
      expect(tester.takeException(), null);
    },
  );

  testWidgets(
    'balayage, clavier et conservation de la semaine dans les onglets',
    (tester) async {
      await open(tester);
      final body = find.byKey(const ValueKey('programme-weeks'));
      await tester.drag(body, const Offset(-160, 0));
      await tester.pumpAndSettle();
      expect(find.text('S9'), findsOneWidget);
      await tester.drag(body, const Offset(160, 0));
      await tester.pumpAndSettle();
      expect(find.text('S8'), findsOneWidget);
      final slider = find.byKey(const ValueKey('week-slider'));
      Focus.of(tester.element(slider)).requestFocus();
      await tester.pump();
      await tester.sendKeyEvent(LogicalKeyboardKey.arrowRight);
      await tester.pumpAndSettle();
      expect(find.text('S9'), findsOneWidget);
      await tester.sendKeyEvent(LogicalKeyboardKey.end);
      await tester.pumpAndSettle();
      await tester.drag(body, const Offset(-180, 0));
      await tester.pumpAndSettle();
      expect(find.text('S40'), findsOneWidget);
      await tester.sendKeyEvent(LogicalKeyboardKey.home);
      await tester.pumpAndSettle();
      await tester.drag(body, const Offset(180, 0));
      await tester.pumpAndSettle();
      expect(find.text('S1'), findsOneWidget);
      for (final i in [0, 1, 3, 4, 2]) {
        await tester.tap(find.byKey(ValueKey('nav-$i')));
        await tester.pumpAndSettle();
        expect(tester.takeException(), null);
      }
      expect(find.text('S1'), findsOneWidget);
      final footer = find.byType(HeroNavBar);
      expect(
        find.descendant(of: footer, matching: find.byType(Text)),
        findsNothing,
      );
      expect(
        find.descendant(of: footer, matching: find.byType(BackdropFilter)),
        findsWidgets,
      );
      final bounds = tester.getRect(
        find.byKey(const PageStorageKey('programme-scroll')),
      );
      expect(bounds.bottom, greaterThan(tester.getRect(footer).top));
      // Le focus est volontairement géré par chaque onglet ; réactivation explicite.
      Focus.of(tester.element(slider)).requestFocus();
      await tester.pump();
      await tester.sendKeyEvent(LogicalKeyboardKey.enter);
      await tester.pumpAndSettle();
      expect(find.text('Semaine 1'), findsOneWidget);
    },
  );

  testWidgets('la navigation libère la place du clavier dans Pilotage', (
    tester,
  ) async {
    await open(tester, width: 320, scale: 1.3);
    await tester.tap(find.byKey(const ValueKey('nav-3')));
    await tester.pumpAndSettle();
    tester.view.viewInsets = const FakeViewPadding(bottom: 280);
    addTearDown(tester.view.resetViewInsets);
    await tester.pumpAndSettle();
    expect(find.byType(HeroNavBar), findsNothing);
    expect(tester.takeException(), null);
    tester.view.resetViewInsets();
    await tester.pumpAndSettle();
    expect(find.byType(HeroNavBar), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('nav-2')));
    await tester.pumpAndSettle();
    expect(find.text('S8'), findsOneWidget);
    expect(tester.takeException(), null);
  });

  for (final dark in [true, false]) {
    testWidgets('résumé à 320 px avec texte 130 %, thème $dark', (
      tester,
    ) async {
      await open(tester, width: 320, scale: 1.3, dark: dark);
      await tester.longPress(find.byKey(const ValueKey('programme-day-4')));
      await tester.pumpAndSettle();
      expect(find.byType(EstimateView), findsOneWidget);
      expect(find.text('Effort'), findsOneWidget);
      expect(find.text('Repos'), findsOneWidget);
      expect(tester.takeException(), null);
    });
  }

  testWidgets(
    'un jour de récupération garde un résumé lisible et reste ouvrable',
    (tester) async {
      await open(tester, day: 7);
      await tester.longPress(find.byKey(const ValueKey('programme-day-7')));
      await tester.pumpAndSettle();
      expect(find.text('Résumé · S8 · J7'), findsOneWidget);
      expect(find.byType(EstimateView), findsNothing);
      expect(tester.takeException(), null);
      Navigator.of(tester.element(find.text('Résumé · S8 · J7'))).pop();
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('programme-day-7')));
      await tester.pumpAndSettle();
      expect(find.byType(SessionScreen), findsOneWidget);
      expect(tester.takeException(), null);
      await tester.pumpWidget(const SizedBox());
      await tester.pumpAndSettle();
      store.sessionLog(8, 7).done = true;
      await open(tester, day: 7);
      await tester.tap(find.byKey(const ValueKey('programme-day-7')));
      await tester.pumpAndSettle();
      expect(find.byType(SessionHistoryScreen), findsOneWidget);
      expect(
        find.text('Aucune série enregistrée pour cette séance.'),
        findsOneWidget,
      );
      expect(tester.takeException(), null);
    },
  );
}
