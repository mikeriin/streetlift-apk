import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:streetlift_tracker/main.dart';
import 'package:streetlift_tracker/home_screen.dart';
import 'package:streetlift_tracker/session_screen.dart';
import 'package:streetlift_tracker/store.dart';
import 'package:streetlift_tracker/ui.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await store.init();
    store.settings
      ..theme = 'dark'
      ..sound = false
      ..vibration = false
      ..wakelock = false
      ..autoTimer = false;
  });

  Future<void> open(WidgetTester t, Widget screen) async {
    t.view.physicalSize = const Size(320, 720);
    t.view.devicePixelRatio = 1;
    t.view.padding = const FakeViewPadding(top: 24, bottom: 24);
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
    addTearDown(t.view.resetPadding);
    await t.pumpWidget(
      MaterialApp(
        theme: buildTheme(true),
        locale: const Locale('fr'),
        supportedLocales: const [Locale('fr')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        home: screen,
      ),
    );
    await t.pumpAndSettle();
  }

  testWidgets(
    'le fondu laisse défiler et le dernier jour reste ouvrable hors de la barre',
    (t) async {
      store.logs.clear();
      await open(
        t,
        AppNavigationFrame(
          index: 2,
          onTap: (_) {},
          body: HomeScreen(referenceDate: store.program.dateFor(8, 4)),
        ),
      );
      final scrollable = find.byType(Scrollable).first;
      final position = t.state<ScrollableState>(scrollable).position;
      final nav = t.getRect(find.byType(HeroNavBar));
      expect(
        t.getRect(find.byType(ListView).first).bottom,
        greaterThan(nav.top),
      );
      final before = position.pixels;
      await t.dragFrom(Offset(160, nav.top + 8), const Offset(0, -90));
      await t.pumpAndSettle();
      expect(position.pixels, greaterThan(before));
      position.jumpTo(position.maxScrollExtent);
      await t.pumpAndSettle();
      final last = find.byKey(const ValueKey('programme-day-7'));
      expect(t.getRect(last).bottom, lessThan(nav.top));
      await t.tap(last);
      await t.pumpAndSettle();
      expect(find.byType(SessionScreen), findsOneWidget);
      expect(find.byType(HeroNavBar), findsNothing);
      expect(KBottomOverlay.of(t.element(find.byType(SessionScreen))), 0);
      expect(t.takeException(), null);
      await t.pumpWidget(const SizedBox());
      await t.pumpAndSettle();
    },
  );

  testWidgets(
    'le clavier réserve une seule fois sa hauteur et masque la navigation',
    (t) async {
      await open(t, const RootNav());
      final homeState = t.state(find.byType(HomeScreen));
      await t.tap(find.byKey(const ValueKey('nav-3')));
      await t.pumpAndSettle();
      final field = find.byType(TextField).first;
      await t.tap(field);
      await t.pump();
      t.view.viewInsets = const FakeViewPadding(bottom: 300);
      t.view.padding = const FakeViewPadding(top: 24);
      addTearDown(t.view.resetViewInsets);
      await t.pumpAndSettle();
      expect(find.byType(HeroNavBar), findsNothing);
      final viewport = t.getRect(find.byType(ListView).first);
      expect(viewport.bottom, closeTo(420, 1));
      expect(t.getRect(field).bottom, lessThanOrEqualTo(viewport.bottom));
      expect(t.takeException(), null);
      FocusManager.instance.primaryFocus?.unfocus();
      t.view.viewInsets = const FakeViewPadding();
      t.view.padding = const FakeViewPadding(top: 24, bottom: 24);
      await t.pumpAndSettle();
      expect(find.byType(HeroNavBar), findsOneWidget);
      await t.tap(find.byKey(const ValueKey('nav-2')));
      await t.pumpAndSettle();
      expect(t.state(find.byType(HomeScreen)), same(homeState));
      expect(t.takeException(), null);
      await t.pumpWidget(const SizedBox());
      await t.pumpAndSettle();
    },
  );
}
