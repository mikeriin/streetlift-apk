import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:streetlift_tracker/app_theme.dart';
import 'package:streetlift_tracker/levelup.dart';

void main() {
  testWidgets(
    'les chiffres se remplissent de gauche à droite, sans contour ni dégradé',
    (tester) async {
      final key = GlobalKey();
      Future<({int width, List<int> bytes})> render(double progress) async {
        await tester.pumpWidget(
          MaterialApp(
            theme: buildTheme(true),
            home: Scaffold(
              body: Center(
                child: RepaintBoundary(
                  key: key,
                  child: LevelProgressNumber(level: 10, progress: progress),
                ),
              ),
            ),
          ),
        );
        await tester.pump();
        final boundary =
            key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
        return (await tester.runAsync(() async {
          final image = await boundary.toImage();
          final data = await image.toByteData(
            format: ui.ImageByteFormat.rawRgba,
          );
          final result = (
            width: image.width,
            bytes: data!.buffer.asUint8List().toList(),
          );
          image.dispose();
          return result;
        }))!;
      }

      final empty = await render(0);
      final partial = await render(.6);
      final almost = await render(.99);
      final full = await render(1);
      final gray = const ProgrammeColors(true).levelRest;
      final blue = const ProgrammeColors(true).accent;
      List<int> rgb(Color color) => [
        (color.r * 255).round(),
        (color.g * 255).round(),
        (color.b * 255).round(),
      ];
      var checked = 0;
      for (var i = 0; i < empty.bytes.length; i += 4) {
        // Ignore uniquement l'anticrénelage naturel au bord des glyphes.
        if (empty.bytes[i + 3] != 255 || full.bytes[i + 3] != 255) continue;
        final x = (i ~/ 4) % empty.width;
        if ((x - empty.width * .6).abs() < 2) continue;
        expect(empty.bytes.sublist(i, i + 3), rgb(gray));
        expect(full.bytes.sublist(i, i + 3), rgb(blue));
        expect(
          partial.bytes.sublist(i, i + 3),
          rgb(x < empty.width * .6 ? blue : gray),
        );
        checked++;
      }
      expect(checked, greaterThan(100));
      var bluePixels = 0;
      for (var i = 0; i < almost.bytes.length; i += 4) {
        if (almost.bytes.sublist(i, i + 3).join(',') == rgb(blue).join(','))
          bluePixels++;
      }
      expect(bluePixels, greaterThan(checked * .9));
      expect(find.byType(LinearProgressIndicator), findsNothing);
      expect(find.textContaining('NIV.'), findsNothing);
      expect(tester.takeException(), null);
    },
  );
}
