import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:streetlift_tracker/home_screen.dart';
import 'package:streetlift_tracker/main.dart';
import 'package:streetlift_tracker/estimate_view.dart';
import 'package:streetlift_tracker/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await store.init();
    store.settings
      ..sound = false
      ..vibration = false
      ..wakelock = false;
  });
  Widget page({bool dark = true, double scale = 1, int day = 4}) => MaterialApp(
    theme: buildTheme(dark),
    builder:
        (context, child) => MediaQuery(
          data: MediaQuery.of(
            context,
          ).copyWith(textScaler: TextScaler.linear(scale)),
          child: child!,
        ),
    home: HomeScreen(now: () => store.program.dateFor(10, day)),
  );
  void size(WidgetTester t, double width, double height) {
    t.view.physicalSize = Size(width, height);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
  }

  testWidgets(
    'une seule journée développée, sept jours visibles et logo centré',
    (t) async {
      size(t, 360, 760);
      t.view.padding = const FakeViewPadding(top: 24, bottom: 24);
      addTearDown(t.view.resetPadding);
      await t.pumpWidget(
        MaterialApp(
          theme: buildTheme(true),
          home: RootNav(now: () => store.program.dateFor(10, 4)),
        ),
      );
      await t.pumpAndSettle();
      final today = find.byKey(const ValueKey('programme-day-4'));
      final first = find.byKey(const ValueKey('programme-day-1'));
      final last = find.byKey(const ValueKey('programme-day-7'));
      expect(t.getSize(today).height, greaterThan(t.getSize(first).height * 2));
      expect(t.getSize(first).height, lessThanOrEqualTo(50));
      expect(last.hitTestable(), findsOneWidget);
      expect(
        t.getRect(last).bottom,
        lessThan(t.getRect(find.byKey(const ValueKey('nav-2'))).top),
      );
      final logo = find.byWidgetPredicate(
        (w) => w is Image && w.semanticLabel == 'Kalis Track',
      );
      expect(t.getCenter(logo).dx, closeTo(180, 1));
      expect(find.text('AUJOURD’HUI'), findsOneWidget);
      expect(t.takeException(), null);
    },
  );
  testWidgets('le curseur change de semaine et son libellé ouvre le détail', (
    t,
  ) async {
    size(t, 360, 760);
    await t.pumpWidget(page());
    await t.pumpAndSettle();
    final slider = find.byKey(const ValueKey('week-slider'));
    await t.drag(slider, const Offset(100, 0));
    await t.pumpAndSettle();
    expect(
      t.widget<Text>(find.byKey(const ValueKey('selected-week'))).data,
      isNot('SEMAINE 10'),
    );
    await t.tap(find.byKey(const ValueKey('week-details')));
    await t.pumpAndSettle();
    expect(find.text('Choisir une autre semaine'), findsOneWidget);
    expect(t.takeException(), null);
  });
  for (final dark in [true, false]) {
    testWidgets('programme et détail à 320 px / 130 %, thème $dark', (t) async {
      size(t, 320, 720);
      await t.pumpWidget(page(dark: dark, scale: 1.3));
      await t.pumpAndSettle();
      expect(t.takeException(), null);
      await t.ensureVisible(find.text('Détails'));
      await t.tap(find.text('Détails'));
      await t.pumpAndSettle();
      expect(find.byType(EstimateView), findsOneWidget);
      expect(t.takeException(), null);
    });
  }
  testWidgets('le repos du jour et une séance terminée gardent le bon statut', (
    t,
  ) async {
    size(t, 360, 760);
    await t.pumpWidget(page(day: 7));
    await t.pumpAndSettle();
    expect(find.text('Récupération · GtG suspendu'), findsOneWidget);
    await t.pumpWidget(const SizedBox());
    store.markSessionDone(10, 4, true);
    await t.pumpWidget(page());
    await t.pumpAndSettle();
    expect(find.text('AUJOURD’HUI · TERMINÉE'), findsOneWidget);
    expect(find.text('Consulter'), findsOneWidget);
    expect(t.takeException(), null);
    await t.pumpWidget(const SizedBox());
    store.markSessionDone(10, 4, false);
    await t.pumpAndSettle();
  });
}
