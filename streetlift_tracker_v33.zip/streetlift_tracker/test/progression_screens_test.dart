import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:streetlift_tracker/home_screen.dart';
import 'package:streetlift_tracker/main.dart';
import 'package:streetlift_tracker/notification_settings.dart';
import 'package:streetlift_tracker/notifications.dart';
import 'package:streetlift_tracker/progression_screen.dart';
import 'package:streetlift_tracker/store.dart';
import 'support/fake_notifications.dart';

Widget page(Widget child, {bool dark = true}) => MaterialApp(
  theme: buildTheme(dark),
  locale: const Locale('fr'),
  supportedLocales: const [Locale('fr')],
  localizationsDelegates: GlobalMaterialLocalizations.delegates,
  builder:
      (context, child) => MediaQuery(
        data: MediaQuery.of(
          context,
        ).copyWith(textScaler: const TextScaler.linear(1.3)),
        child: child!,
      ),
  home: child,
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await store.init();
  });
  void narrow(WidgetTester tester) {
    tester.view.physicalSize = const Size(320, 720);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
  }

  testWidgets('la pastille ouvre la progression depuis l’accueil', (
    tester,
  ) async {
    await tester.pumpWidget(page(const HomeScreen()));
    await tester.tap(find.byTooltip('Ouvrir ma progression'));
    await tester.pumpAndSettle();
    expect(find.byType(ProgressionScreen), findsOneWidget);
    expect(find.text('MA PROGRESSION'), findsOneWidget);
    expect(tester.takeException(), null);
  });
  for (final dark in [true, false]) {
    testWidgets(
      'parcours, missions et badges tiennent à 320 px avec texte agrandi, thème $dark',
      (tester) async {
        narrow(tester);
        await tester.pumpWidget(page(const ProgressionScreen(), dark: dark));
        await tester.pumpAndSettle();
        expect(find.textContaining('RECRUE'), findsOneWidget);
        final scroll =
            find
                .descendant(
                  of: find.byType(TabBarView),
                  matching: find.byType(Scrollable),
                )
                .first;
        for (var i = 0; i < 12; i++) {
          await tester.drag(scroll, const Offset(0, -420));
          await tester.pumpAndSettle();
          expect(tester.takeException(), null);
        }
        await tester.tap(find.textContaining('Badges ·'));
        await tester.pumpAndSettle();
        expect(find.textContaining('Chaque badge rapporte'), findsOneWidget);
        for (var i = 0; i < 8; i++) {
          await tester.drag(find.byType(ListView).last, const Offset(0, -420));
          await tester.pumpAndSettle();
          expect(tester.takeException(), null);
        }
        await tester.tap(find.byTooltip('Comprendre les XP'));
        await tester.pumpAndSettle();
        expect(find.text('Comment progresser'), findsOneWidget);
        expect(tester.takeException(), null);
      },
    );
  }
  testWidgets(
    'un canal désactivé est visible et propose le bon réglage Android',
    (tester) async {
      narrow(tester);
      final backend = FakeNotifications()..channelAllowed = false;
      final service = NotificationService(store, backend);
      await tester.pumpWidget(
        page(
          Scaffold(
            body: ListView(
              children: [NotificationSettingsPanel(service: service)],
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text('Canal « Rappel quotidien » désactivé'), findsOneWidget);
      await tester.scrollUntilVisible(
        find.text('Ouvrir les réglages Android'),
        150,
        scrollable: find.byType(Scrollable).first,
      );
      expect(find.text('Ouvrir les réglages Android'), findsOneWidget);
      expect(tester.takeException(), null);
      await tester.pumpWidget(const SizedBox());
      service.dispose();
    },
  );
  testWidgets(
    'le bouton de test déclenche une notification et un retour explicite',
    (tester) async {
      narrow(tester);
      final backend = FakeNotifications()..exact = false;
      final service = NotificationService(store, backend);
      await tester.pumpWidget(
        page(
          Scaffold(
            body: ListView(
              children: [NotificationSettingsPanel(service: service)],
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      await tester.scrollUntilVisible(
        find.text('Tester maintenant'),
        150,
        scrollable: find.byType(Scrollable).first,
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('Tester maintenant'));
      await tester.pumpAndSettle();
      expect(backend.shown, 1);
      expect(find.textContaining('Test envoyé à Android'), findsOneWidget);
      expect(tester.takeException(), null);
      await tester.pumpWidget(const SizedBox());
      service.dispose();
    },
  );
}
