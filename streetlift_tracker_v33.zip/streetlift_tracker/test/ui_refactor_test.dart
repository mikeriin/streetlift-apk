import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:streetlift_tracker/main.dart';
import 'package:streetlift_tracker/arsenal_screen.dart';
import 'package:streetlift_tracker/builder_screen.dart';
import 'package:streetlift_tracker/home_screen.dart';
import 'package:streetlift_tracker/pilotage_screen.dart';
import 'package:streetlift_tracker/records_screen.dart';
import 'package:streetlift_tracker/session_history.dart';
import 'package:streetlift_tracker/session_screen.dart';
import 'package:streetlift_tracker/settings_screen.dart';
import 'package:streetlift_tracker/store.dart';
import 'package:streetlift_tracker/wod_catalog.dart';
import 'package:streetlift_tracker/wod_models.dart';
import 'package:streetlift_tracker/wod_preview.dart';
import 'package:streetlift_tracker/wod_screen.dart';

Widget page(Widget child, {bool dark = true, double textScale = 1.3}) =>
    MaterialApp(
      theme: buildTheme(dark),
      locale: const Locale('fr'),
      supportedLocales: const [Locale('fr')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      builder:
          (context, child) => MediaQuery(
            data: MediaQuery.of(
              context,
            ).copyWith(textScaler: TextScaler.linear(textScale)),
            child: child!,
          ),
      home: child,
    );
void small(WidgetTester tester, {Size size = const Size(320, 720)}) {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await store.init();
    store.settings
      ..sound = false
      ..vibration = false
      ..wakelock = false
      ..autoTimer = false;
  });

  testWidgets(
    'les onglets et le changement de thème conservent la semaine choisie',
    (tester) async {
      small(tester);
      await tester.pumpWidget(const SLApp());
      await tester.pumpAndSettle();
      final initialState = tester.state(find.byType(HomeScreen));
      await tester.tap(find.byTooltip('Semaine précédente'));
      await tester.pumpAndSettle();
      final week =
          tester.widget<Text>(find.byKey(const ValueKey('selected-week'))).data;
      await tester.tap(find.byKey(const ValueKey('nav-0')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('nav-2')));
      await tester.pumpAndSettle();
      expect(find.text(week!), findsOneWidget);
      expect(tester.state(find.byType(HomeScreen)), same(initialState));
      await tester.tap(find.byKey(const ValueKey('nav-4')));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Clair'));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('nav-2')));
      await tester.pumpAndSettle();
      expect(find.text(week), findsOneWidget);
      expect(tester.state(find.byType(HomeScreen)), same(initialState));
      expect(
        Theme.of(tester.element(find.byType(HomeScreen))).brightness,
        Brightness.light,
      );
      expect(tester.takeException(), null);
      await tester.pumpWidget(const SizedBox());
      await tester.pumpAndSettle();
    },
  );

  testWidgets(
    'cartes, notes et saisies survivent aux boutons et au sélecteur d’exercices',
    (tester) async {
      small(tester);
      final custom = CustomSession(
        id: '993',
        name: 'Deux exercices',
        items: [
          CustomExercise(name: 'Pompes', p: {'series': 1, 'reps': 8}),
          CustomExercise(name: 'Squat', p: {'series': 1, 'reps': 10}),
        ],
      );
      final week = custom.toWeekPlan();
      final day = week.days.single;
      await tester.pumpWidget(page(SessionScreen(week: week, day: day)));
      await tester.pumpAndSettle();
      final first = day.exercises.first;
      expect(find.byKey(ValueKey('exercise-card-${first.id}')), findsOneWidget);
      await tester.enterText(find.byType(TextField).first, '14');
      await tester.tap(find.byKey(ValueKey('${first.id}-note-toggle')));
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byKey(ValueKey('${first.id}-note')),
        'Première note',
      );
      await tester.tap(find.byKey(ValueKey('${first.id}-note-toggle')));
      await tester.pumpAndSettle();
      expect(find.byKey(ValueKey('${first.id}-note')), findsNothing);
      await tester.tap(find.byKey(ValueKey('${first.id}-note-toggle')));
      await tester.pumpAndSettle();
      expect(find.text('Première note'), findsOneWidget);
      await tester.tap(find.text('Suivant'));
      await tester.pumpAndSettle();
      final second = day.exercises.last;
      await tester.tap(find.byKey(ValueKey('${second.id}-note-toggle')));
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byKey(ValueKey('${second.id}-note')),
        'Seconde note',
      );
      await tester.tap(find.text('Précédent'));
      await tester.pumpAndSettle();
      expect(find.text('14'), findsOneWidget);
      expect(find.text('Première note'), findsOneWidget);
      await tester.tap(find.text('Exercices'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Bilan de séance').last);
      await tester.pumpAndSettle();
      expect(find.text('Terminer la séance'), findsOneWidget);
      expect(store.exLog(week.n, day.j, first).note, 'Première note');
      expect(store.exLog(week.n, day.j, second).note, 'Seconde note');
      expect(tester.takeException(), null);
      await tester.pumpWidget(const SizedBox());
      await tester.pumpAndSettle();
    },
  );

  testWidgets('les exercices enchaînés ont chacun leur carte et leur note', (
    tester,
  ) async {
    small(tester);
    final week =
        CustomSession(
          id: '995',
          name: 'Enchaînement',
          items: [
            CustomExercise(name: 'Dips', p: {'series': 1, 'reps': 8}),
            CustomExercise(
              name: 'Pompes enchaînées',
              p: {'series': 1, 'reps': 10},
            ),
          ],
        ).toWeekPlan();
    final day = week.days.single;
    expect(store.groups(day).single.length, 2);
    await tester.pumpWidget(page(SessionScreen(week: week, day: day)));
    await tester.pumpAndSettle();
    for (var i = 0; i < day.exercises.length; i++) {
      final note = find.byKey(ValueKey('${day.exercises[i].id}-note'));
      final toggle = find.byKey(ValueKey('${day.exercises[i].id}-note-toggle'));
      await tester.scrollUntilVisible(
        toggle.hitTestable(),
        200,
        scrollable:
            find
                .descendant(
                  of: find.byType(ListView).first,
                  matching: find.byType(Scrollable),
                )
                .first,
      );
      await tester.tap(toggle);
      await tester.pumpAndSettle();
      await tester.enterText(note, 'Note exercice $i');
      await tester.pumpAndSettle();
      expect(
        find.byKey(ValueKey('exercise-card-${day.exercises[i].id}')),
        findsOneWidget,
      );
    }
    await tester.tap(find.text('Bilan'));
    await tester.pumpAndSettle();
    for (var i = 0; i < day.exercises.length; i++) {
      expect(
        store.exLog(week.n, day.j, day.exercises[i]).note,
        'Note exercice $i',
      );
    }
    expect(tester.takeException(), null);
    await tester.pumpWidget(const SizedBox());
    await tester.pumpAndSettle();
  });

  testWidgets(
    'les séances et éditeurs suivent une rotation et une grande largeur',
    (tester) async {
      small(tester, size: const Size(640, 360));
      final custom = CustomSession(
        id: '996',
        name: 'Rotation',
        items: [
          CustomExercise(
            name: 'Gainage',
            mode: 'iso',
            p: {'series': 1, 'hold': 60},
          ),
        ],
      );
      final week = custom.toWeekPlan();
      for (final size in [const Size(640, 360), const Size(1024, 768)]) {
        tester.view.physicalSize = size;
        for (final screen in [
          SessionScreen(week: week, day: week.days.single),
          SessionEditor(session: custom),
          WodEditor(
            wod: Wod(
              id: 'wide_wod',
              name: 'Grand écran',
              lines: ['10 push-ups'],
            ),
          ),
        ]) {
          await tester.pumpWidget(page(screen));
          await tester.pumpAndSettle();
          expect(
            tester.takeException(),
            null,
            reason: '${screen.runtimeType} à $size',
          );
          await tester.pumpWidget(const SizedBox());
          await tester.pumpAndSettle();
        }
      }
    },
  );

  testWidgets(
    'un WOD verrouillé garde ses mouvements visibles au-dessus du message de crédits',
    (tester) async {
      small(tester);
      final wod = store.wods.firstWhere(
        (w) => !store.unlocked(w) && store.wodCost(w) > store.credits,
      );
      await tester.pumpWidget(page(WodPreviewScreen(wodId: wod.id)));
      await tester.pumpAndSettle();
      expect(find.text('MOUVEMENTS').hitTestable(), findsOneWidget);
      expect(tester.getSize(find.byType(ListView)).height, greaterThan(400));
      expect(find.textContaining('Il te manque'), findsOneWidget);
      expect(tester.takeException(), null);
      await tester.pumpWidget(const SizedBox());
      await tester.pumpAndSettle();
    },
  );

  for (final dark in [true, false]) {
    testWidgets('écrans et formulaires à 320 px, texte 130 %, thème $dark', (
      tester,
    ) async {
      small(tester);
      final custom = CustomSession(
        id: '991',
        name: 'Force personnelle',
        items: [
          CustomExercise(
            name: 'Tractions',
            p: {'series': 1, 'reps': 6},
            kg: 12.5,
          ),
        ],
      );
      final week = custom.toWeekPlan();
      final day = week.days.single;
      final log =
          store.exLog(week.n, day.j, day.exercises.first)
            ..showKg = true
            ..showRir = true
            ..showV = true;
      log.note = 'Test des notes';
      final wod = Wod(
        id: 'ui_wod',
        name: 'WOD de vérification',
        lines: ['10 push-ups', '20 air squats'],
      );
      store.upsertWod(wod);
      for (final screen in <Widget>[
        const RootNav(),
        const ArsenalScreen(),
        const PilotageScreen(),
        const SettingsScreen(),
        const RecordsScreen(),
        SessionEditor(session: custom),
        WodEditor(wod: wod),
        const WodCatalogScreen(),
        WodPreviewScreen(wodId: wod.id),
        WodRunScreen(wodId: wod.id),
        SessionScreen(week: week, day: day),
        SessionHistoryScreen(log: store.sessionLog(week.n, day.j)),
      ]) {
        await tester.pumpWidget(page(screen, dark: dark));
        await tester.pumpAndSettle();
        expect(
          tester.takeException(),
          null,
          reason: '${screen.runtimeType}, au chargement',
        );
        final lists = find.byType(ListView);
        if (lists.evaluate().isNotEmpty) {
          for (var i = 0; i < 8; i++) {
            await tester.drag(lists.first, const Offset(0, -360));
            await tester.pumpAndSettle();
            expect(
              tester.takeException(),
              null,
              reason: '${screen.runtimeType}, après défilement',
            );
          }
        }
        await tester.pumpWidget(const SizedBox());
        await tester.pumpAndSettle();
      }
    });
  }

  testWidgets(
    'cinq séries, charge et effort restent visibles sans défilement',
    (tester) async {
      small(tester, size: const Size(360, 760));
      tester.view.padding = const FakeViewPadding(top: 24, bottom: 24);
      addTearDown(tester.view.resetPadding);
      final week = store.program.week(8);
      final day = week.day(1)!;
      store.clearSession(8, 1);
      final exercise = day.exercises.first;
      final log = store.exLog(8, 1, exercise)..showRir = true;
      expect(log.sets.length, 5);
      await tester.pumpWidget(
        page(SessionScreen(week: week, day: day), textScale: 1),
      );
      await tester.pumpAndSettle();
      final list = find.byType(ListView).first;
      final viewport = tester.getRect(list);
      for (var i = 0; i < 5; i++) {
        final row = find.byKey(ValueKey('${exercise.id}-$i-0'));
        final button = find.byTooltip('Valider la série ${i + 1}');
        expect(button.hitTestable(), findsOneWidget);
        expect(tester.getRect(row).top, greaterThanOrEqualTo(viewport.top));
        expect(tester.getRect(row).bottom, lessThanOrEqualTo(viewport.bottom));
        expect(tester.getSize(button).height, greaterThanOrEqualTo(44));
      }
      expect(find.byKey(ValueKey('${exercise.id}-note')), findsNothing);
      expect(
        find.byKey(ValueKey('${exercise.id}-note-toggle')).hitTestable(),
        findsOneWidget,
      );
      final instruction = find.byKey(ValueKey('${exercise.id}-instructions'));
      await tester.tap(instruction);
      await tester.pumpAndSettle();
      expect(find.text(exercise.cue), findsOneWidget);
      await tester.tap(find.text('Fermer'));
      await tester.pumpAndSettle();
      await tester.tap(find.byTooltip('Valider la série 5'));
      await tester.pumpAndSettle();
      expect(log.sets.last.done, isTrue);
      expect(tester.takeException(), null);
      await tester.pumpWidget(const SizedBox());
      await tester.pumpAndSettle();
    },
  );

  testWidgets('les actions de sauvegarde ouvrent l’export et l’import', (
    tester,
  ) async {
    small(tester);
    String? clipboard;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(SystemChannels.platform, (call) async {
          if (call.method == 'Clipboard.setData') {
            clipboard = (call.arguments as Map)['text'] as String;
          }
          return null;
        });
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(SystemChannels.platform, null),
    );
    await tester.pumpWidget(page(const SettingsScreen()));
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(
      find.text('Exporter une sauvegarde'),
      350,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(find.text('Exporter une sauvegarde'));
    await tester.pumpAndSettle();
    expect(clipboard, store.exportCompact());
    expect(
      find.text('Sauvegarde copiée dans le presse-papiers.'),
      findsOneWidget,
    );
    await tester.scrollUntilVisible(
      find.text('Importer une sauvegarde'),
      150,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(find.text('Importer une sauvegarde'));
    await tester.pumpAndSettle();
    expect(find.byType(AlertDialog), findsOneWidget);
    expect(find.text('Colle le texte exporté ici'), findsOneWidget);
    await tester.tap(find.text('Annuler'));
    await tester.pumpAndSettle();
    expect(tester.takeException(), null);
    await tester.pumpWidget(const SizedBox());
    await tester.pumpAndSettle();
  });

  testWidgets('recherche et paramètres restent utilisables avec le clavier', (
    tester,
  ) async {
    small(tester);
    await tester.pumpWidget(
      page(SessionEditor(session: CustomSession(id: '994', name: 'Création'))),
    );
    await tester.tap(find.text('Exercice'));
    await tester.pumpAndSettle();
    await tester.enterText(
      find.byType(TextField).last,
      'ui recherche impossible',
    );
    await tester.pumpAndSettle();
    expect(find.byTooltip('Effacer la recherche'), findsOneWidget);
    tester.view.viewInsets = const FakeViewPadding(bottom: 280);
    addTearDown(tester.view.resetViewInsets);
    await tester.pumpAndSettle();
    expect(tester.takeException(), null);
    await tester.tap(find.byTooltip('Effacer la recherche'));
    await tester.pumpAndSettle();
    await tester.tap(find.byType(ListTile).first);
    await tester.pumpAndSettle();
    expect(find.text('Valider'), findsOneWidget);
    expect(tester.takeException(), null);
    await tester.pumpWidget(const SizedBox());
    await tester.pumpAndSettle();
  });
}
