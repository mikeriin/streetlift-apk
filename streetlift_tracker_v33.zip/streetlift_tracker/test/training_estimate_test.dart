import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:streetlift_tracker/models.dart';
import 'package:streetlift_tracker/store.dart';
import 'package:streetlift_tracker/training_estimate.dart';
import 'package:streetlift_tracker/wod_models.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  TrainingEstimate ex(
    String sets, {
    String name = 'Pompes',
    String rest = '60 s',
    String tempo = '',
    double? kg,
  }) => TrainingEstimator.exercise(
    Exercise.manual(
      id: 'e',
      name: name,
      setsText: sets,
      rest: rest,
      tempo: tempo,
    ),
    prescription: sets,
    kg: kg,
  );
  TrainingEstimate wod(
    List<String> lines, {
    String type = 'fortime',
    int rounds = 0,
    int rest = 0,
    int minutes = 0,
    String scheme = '',
  }) => TrainingEstimator.wod(
    Wod(
      id: 'w',
      name: 'Test',
      lines: lines,
      type: type,
      rounds: rounds,
      restSec: rest,
      minutes: minutes,
      scheme: scheme,
    ),
  );

  test('séries, tempo exact et repos uniquement entre les séries', () {
    final e = ex('3×5', tempo: '3-0-1-0', kg: 10);
    expect(e.volume('rep').low, 15);
    expect(e.work.low, 60);
    expect(e.rest.low, 120);
    expect(e.elapsed.low, 180);
    expect(e.tonnage.low, 150);
  });
  test('repos composé et fourchettes sont conservés', () {
    expect(TrainingEstimator.duration('2 min 30')!.low, 150);
    final e = ex('3×8-12', rest: '2-3 min');
    expect(e.volume('rep').low, 24);
    expect(e.volume('rep').high, 36);
    expect(e.rest.low, 240);
    expect(e.rest.high, 360);
  });
  test('unilatéral : deux côtés ; charge par haltère explicitée', () {
    final e = ex('3×10/jambe', name: 'Fentes marchées (par haltère)', kg: 10);
    expect(e.volume('rep').low, 60);
    expect(e.tonnage.low, 1200);
    expect(
      ex('3×12', name: 'Rowing unilatéral (par haltère)', kg: 10).tonnage.low,
      720,
    );
  });
  test('tenues ne deviennent pas des répétitions', () {
    final e = ex('3×30 s', tempo: 'Isométrie');
    expect(e.volume('s').low, 90);
    expect(e.volume('rep').high, 0);
    expect(e.elapsed.low, 210);
  });
  test('myo et clusters comptent chaque micro-repos', () {
    final myo = ex('1×12-15 puis 4×(4)', rest: '10 s intra');
    expect(myo.volume('rep').low, 28);
    expect(myo.volume('rep').high, 31);
    expect(myo.rest.low, 40);
    final cluster = ex('4×(3×2) · 20 s intra', rest: '2 min');
    expect(cluster.volume('rep').low, 24);
    expect(cluster.rest.low, 520);
  });
  test('HIIT : même durée que le chrono, sans dernier repos', () {
    final e = ex('8× (30 s effort / 30 s repos)');
    expect(e.elapsed.low, 450);
    expect(e.work.low, 240);
    expect(e.rest.low, 210);
  });
  test('WOD : repos inline, durées et charges décimales', () {
    final e = wod(['10 tractions 2,5 kg · 30" rest · 20 s hollow hold']);
    expect(e.volume('rep').low, 10);
    expect(e.volume('s').low, 20);
    expect(e.rest.low, 30);
    expect(e.tonnage.low, 25);
  });
  test('blocs imbriqués et multiplicateurs suffixés', () {
    final e = wod(['10 dips + (1 pull-up + 1 muscle-up) ×4 + 20 pompes']);
    expect(e.volume('rep').low, 38);
    expect(wod(['3 × (10 pompes + 20 squats)']).volume('rep').low, 90);
  });
  test('échelle : distance par tour et somme des répétitions', () {
    final e = wod(['400 m run', 'burpees', 'sit-ups'], scheme: '21-15-9');
    expect(e.volume('m').low, 1200);
    expect(e.volume('rep').low, 90);
    expect(TrainingEstimator.scheme('1-2-3-…-15').reduce((a, b) => a + b), 120);
  });
  test('EMOM : plages, rotation et récupération dans le temps fixe', () {
    final e = wod(
      ['min 1-5 : 10 burpees', 'min 6-10 : 20 pompes'],
      type: 'emom',
      rounds: 10,
    );
    expect(e.volume('rep').low, 150);
    expect(e.elapsed.low, 600);
    final rotated = wod(
      [
        'min 1, 4, 7… : 10 pompes',
        'min 2, 5, 8… : 20 squats',
        'min 3, 6, 9… : repos',
      ],
      type: 'emom',
      rounds: 10,
    );
    expect(rotated.volume('rep').low, 100);
    expect(rotated.elapsed.high, 600);
  });
  test('E2MOM respecte la durée des intervalles', () {
    final e = TrainingEstimator.wod(
      Wod(
        id: 'e2',
        name: 'E2',
        type: 'emom',
        rounds: 6,
        interval: 120,
        lines: ['5 tractions'],
      ),
    );
    expect(e.volume('rep').low, 30);
    expect(e.elapsed.low, 720);
  });
  test('AMRAP fractionné : durée exacte, tous les repos conservés', () {
    final e = wod(
      [
        'AMRAP 3 min : 3 burpees + 3 squats',
        'Repos 2 min',
        'AMRAP 4 min : 6 burpees + 6 squats',
        'Repos 2 min',
        'AMRAP 5 min : 9 burpees + 9 squats',
      ],
      type: 'routine',
      rest: 120,
    );
    expect(e.elapsed.low, closeTo(960, .001));
    expect(e.elapsed.high, closeTo(960, .001));
    expect(e.projected, true);
  });
  test('rounds : n moins un repos ; cap distinct du temps de complétion', () {
    final e = wod(['10 pompes'], type: 'rounds', rounds: 3, rest: 120);
    expect(e.volume('rep').low, 30);
    expect(e.rest.low, 240);
    final capped = wod(['500 burpees'], minutes: 10);
    expect(capped.elapsed.low, greaterThan(600));
    expect(capped.capSeconds, 600);
  });
  test('calories et distances ne sont ni des répétitions ni du tonnage', () {
    final e = wod(['20 cal row', '100 m farmer carry 2×24 kg']);
    expect(e.volume('cal').low, 20);
    expect(e.volume('m').low, 100);
    expect(e.volume('rep').high, 0);
    expect(e.hasTonnage, false);
    expect(TrainingEstimator.externalKg('wall ball 4/6/9 kg'), null);
  });
  test('une prescription inconnue est signalée sans inventer un volume', () {
    final e = wod(['max pull-ups']);
    expect(e.partial, true);
    expect(e.volume('rep').high, 0);
    expect(e.durationLabel, 'À préciser');
  });

  test('échelles jumelées avec ellipse : le programme entier est compté', () {
    final e = wod([
      '20 push-ups · 1 sit-up',
      '19 push-ups · 2 sit-ups',
      '… jusqu’à 1 push-up · 20 sit-ups',
    ], scheme: '20/1 → 1/20');
    expect(e.partial, false);
    expect(e.volume('rep').low, 420);
    expect(e.sets, 40);
    expect(e.transitions.low, 39 * 3);
  });
  test('AMRAP ascendant : durée fixe, volume projeté et deux côtés', () {
    final e = wod([
      'AMRAP 5 min : 2-4-6-8-10… squat jumps · push-ups',
      'Repos 2 min',
      'AMRAP 5 min : 2-4-6-8-10… jumping lunges (par côté) · plank up-downs',
    ], type: 'routine');
    expect(e.partial, false);
    expect(e.elapsed.low, 720);
    expect(e.elapsed.high, 720);
    expect(e.volume('rep').high, greaterThan(e.volume('rep').low));
    final rounds = wod(['10 pompes', '20 squats'], type: 'rounds', rounds: 3);
    expect(rounds.details.first.estimate.volume('rep').low, 30);
    expect(rounds.details.last.estimate.volume('rep').low, 60);
  });

  group('intégration programme', () {
    late AppStore app;
    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      app = AppStore();
      await app.init();
    });
    tearDown(() async {
      await app.flush();
      app.dispose();
    });
    test('les supersets partagent leur repos et les EMOM leur horloge', () {
      DayPlan day(String text) => DayPlan.manual(
        j: 1,
        title: 'Test',
        exercises: [
          Exercise.manual(id: 'a', name: 'Dips', setsText: text, rest: '90 s'),
          Exercise.manual(
            id: 'b',
            name: 'Pompes enchaînées',
            setsText: text,
            rest: '90 s',
          ),
        ],
      );
      expect(app.dayEstimate(day('4×10')).rest.low, 270);
      expect(app.dayEstimate(day('EMOM 12 min × 5 reps')).elapsed.high, 720);
    });
    test('le repos 2 min 30 corrige aussi le chrono automatique', () {
      final e = Exercise.manual(
        id: 'e',
        name: 'Tractions',
        setsText: '3×10',
        rest: '2 min 30',
        restSec: 120,
      );
      expect(app.restAfterSet(e, app.logSpec(e), 0, 3), 150);
      expect(app.exerciseEstimate(e).rest.low, 300);
    });
    test(
      'durée personnalisée seulement après trois résultats de la même prescription',
      () async {
        final w = Wod(id: 'history', name: 'Test', lines: ['10 pompes']);
        app.upsertWod(w);
        for (final sec in [90, 100, 110]) {
          final r = WodResult(
            at: DateTime(2026, 9, sec ~/ 10).toIso8601String(),
            score: '$sec s',
            seconds: sec,
          );
          app.addWodResult(w, r);
          expect(r.prescription, w.prescriptionKey);
        }
        final e = app.wodEstimate(w);
        expect(e.historyCount, 3);
        expect(e.elapsed.low, 90);
        expect(e.elapsed.high, 110);
        expect(await app.importAll(app.exportAll()), true);
        expect(
          app
              .wodEstimate(app.wods.firstWhere((entry) => entry.id == w.id))
              .historyCount,
          3,
        );
        final restored = Wod.fromJson(w.toJson());
        expect(app.wodEstimate(restored).historyCount, 3);
        restored.lines = ['20 pompes'];
        expect(app.wodEstimate(restored).historyCount, 0);
        w.results.first.completed = false;
        expect(app.wodEstimate(w).historyCount, 0);
      },
    );
    test(
      'anciens scores sans prescription ne calibrent pas un WOD modifié',
      () {
        final w = Wod(
          id: 'old',
          name: 'Test',
          lines: ['10 pompes'],
          results: [
            for (var i = 0; i < 5; i++)
              WodResult(at: '2026-09-01', score: '1 min', seconds: 60),
          ],
        );
        expect(app.wodEstimate(w).historyCount, 0);
      },
    );
    test(
      'aucun nombre non fini ou négatif dans les 1954 exercices et 500 WODs',
      () {
        final openEnded = Wod(id: 'max', name: 'Max', lines: ['max pull-ups']);
        expect(app.plannedMuscles(app.wodEstimate(openEnded)), contains('dos'));
        final estimates = [
          for (final w in app.program.weeks)
            for (final d in w.days) app.dayEstimate(d),
          for (final w in app.wods) app.wodEstimate(w),
        ];
        for (final e in estimates) {
          for (final span in [
            e.elapsed,
            e.work,
            e.rest,
            e.transitions,
            e.tonnage,
          ]) {
            expect(span.low.isFinite && span.high.isFinite, true);
            expect(span.low, greaterThanOrEqualTo(0));
            expect(span.high, greaterThanOrEqualTo(span.low));
          }
        }
      },
    );
  });
}
