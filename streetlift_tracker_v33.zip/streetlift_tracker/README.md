# Kalis Track — programme streetlifting v3.3

App Android (Flutter) qui embarque ton programme streetlifting v3.3 complet :
40 semaines · 280 jours · 1954 exercices, avec exécution guidée exercice par
exercice, timer de repos automatique et Pilotage recalculable (mêmes formules
que le classeur Excel).

## Ce que fait l'app

- **Séances** : semaine courante détectée automatiquement (ancrage S8 = 31/08/2026),
  navigation sur les 40 semaines, état fait/à faire par jour.
- **Mode séance** : un exercice par écran (swipe), charge suggérée calculée,
  consignes, logger de séries (kg · reps · RIR · vitesse sur les lifts),
  notes par exercice. Valider une série lance le **timer de repos** (durée de la
  colonne Repos du classeur, ±15 s, alerte sonore + vibration). Les formats
  intervalle (HIIT 8× 30/30) ont leur propre chrono enchaîné. Écran maintenu
  allumé pendant la séance.
- **Pilotage** : PdC, 4 × 1RM, 5 maxima de reps, 21 charges de référence —
  éditables, persistés ; toutes les charges et tous les volumes du programme se
  recalculent instantanément (formules identiques au classeur : % du poids
  système, remise à l'échelle des accessoires selon les reps du jour, volumes
  indexés sur tes maxima).
- **Suivi** : avancement (X/280 séances), actuel vs cible 12 mois par lift et
  par test d'endurance, historique des séances terminées.
- Tout est stocké **en local** (SharedPreferences), hors ligne, zéro compte.

## Mode générique (v1.3)

- **Mes séances** : constructeur de séances personnalisées — base de 170+ exercices
  (recherche + filtres par groupe musculaire, ajout d'exercices perso), 8 modes
  d'exécution paramétrables : classique, myo-reps, cluster, EMOM, AMRAP, isométrie,
  intervalles (HIIT/Tabata), pyramide. Réordonnancement, duplication, édition.
  Chaque mode pilote le chrono adapté dans le runner (EMOM par minute, AMRAP,
  effort/repos, tenues) avec décompte « PRÊT ».
- **Réglages** : repos par défaut, auto-timer, son/vibration, décompte de
  préparation, RIR/RPE, kg/lb, pré-remplissage, écran allumé, **export/import**
  complet des données via presse-papiers (sauvegarde).

## WOD (v1.4)

Sous-onglet **Perso → WOD** : création / modification / duplication / suppression de WODs
en 5 formats — For Time, rounds for time, AMRAP, EMOM, routine libre — avec rounds,
repos inter-rounds, time cap, schéma (21-15-9, 1→15…), mouvements en texte libre
(une ligne par mouvement ou bloc), notes (pénalités, objectifs, team). Exécution avec
chrono adapté (stopwatch + bouton Round + repos automatique, compte à rebours AMRAP,
EMOM minute par minute, alerte time cap), saisie du score et historique avec meilleur
résultat mis en avant. 19 WODs préchargés au premier lancement.

## Identité

Nom affiché : **Kalis Track** (appliqué par le workflow via l'AndroidManifest).
Icône : `assets/icon/` — front lever sous la barre, générée par flutter_launcher_icons
(adaptative + monochrome Android 13). L'applicationId reste `fr.tchoupi.streetlift_tracker`
pour que les mises à jour s'installent par-dessus sans perte de données.

## Compiler

Prérequis : Flutter installé (canal stable ≥ 3.29), Android SDK opérationnel.

```bash
flutter create --org fr.tchoupi --project-name streetlift_tracker streetlift_tracker_build
cd streetlift_tracker_build
# Remplace lib/, ajoute assets/ et pubspec.yaml depuis ce dossier :
rm -rf lib && cp -r ../streetlift_tracker/lib .
cp -r ../streetlift_tracker/assets .
cp ../streetlift_tracker/pubspec.yaml .
flutter pub get
flutter run                # debug sur ton téléphone
flutter build apk --release   # APK final : build/app/outputs/flutter-apk/app-release.apk
```

Aucune permission Android à ajouter (le timer utilise son + vibration système ;
wakelock_plus configure tout seul le FLAG_KEEP_SCREEN_ON).

## Régénérer le JSON quand le programme évolue

Le programme vit dans `assets/programme_v33.json`, généré depuis le classeur :

```bash
pip install openpyxl
python tools/xlsx_to_json.py   # lit Programme_Streetlifting_v3-3.xlsx dans le dossier courant
cp programme_v33.json assets/
```

Le script traduit les formules Excel en « specs » recalculables (system %,
barbell %, accessoire, volume indexé) et vérifie les charges contre les valeurs
du classeur. Nouvelle version du programme → nouveau JSON → rebuild, rien
d'autre à toucher.

## Structure

```
lib/
├── main.dart             # thème sombre « salle », navigation 3 onglets
├── models.dart           # Program / Week / Day / Exercise + specs
├── store.dart            # Pilotage éditable, calculs (répliques Excel), journal, persistance
├── home_screen.dart      # semaine courante + tuiles J1-J7
├── session_screen.dart   # runner exo par exo, logger, timers
├── pilotage_screen.dart  # cellules jaunes
└── records_screen.dart   # cibles vs actuel + historique
```

Code couleur repris du classeur : **jaune** = ce que tu remplis, **vert** = lift
principal, **violet** = prévention, couleur d'onglet = bloc.

## Pistes v2 (quand tu veux)

- Export CSV des logs → réinjection dans l'Excel.
- Notifications de rappel de séance ; timer en foreground service (sonne écran éteint).
- Migration du stockage vers Drift si tu veux requêter l'historique (progression par exercice).
