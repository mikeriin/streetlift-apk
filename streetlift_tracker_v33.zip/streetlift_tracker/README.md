# Kalis Track — 1.5.0

Application Android Flutter hors ligne : programme streetlifting v3.3, séances personnalisées, catalogue de 500 WODs, chronos et suivi local.

Le nom `streetlift_tracker_v33.zip` désigne la version **3.3 du programme**, pas la version de l'application. Il reste identique pour simplifier les mises à jour du dépôt.

## Mise à jour sur GitHub

1. Dans l'application installée, fais **Réglages → Exporter une sauvegarde** et conserve le texte.
2. Remplace `streetlift_tracker_v33.zip` **à la racine du dépôt** par le zip fourni. Ne le décompresse pas dans le dépôt si tu utilises ce workflow.
3. Remplace le contenu du workflow existant par le fichier fourni, à l'emplacement **`.github/workflows/build-apk.yml`**. Son extension doit être `.yml`, sans `.txt`. Garde un seul workflow de compilation.
4. Enregistre les deux changements. Dans **Actions → Build APK**, consulte le run déclenché par le commit, ou lance **Run workflow**.
5. Quand il est terminé, télécharge l'artefact **kalis-track-apk**. Décompresse l'archive téléchargée, puis ouvre **kalis-track.apk** sur le téléphone.
6. Installe la mise à jour par-dessus l'application existante. L'identifiant Android et la clé de signature sont conservés. Si Android refuse la mise à jour, conserve la sauvegarde et relève le message exact avant toute désinstallation.

La compilation exécute d'abord les vérifications de données, l'analyse Flutter et les tests. Un échec bloque la livraison de l'APK. Le fichier `.sha256` joint à l'artefact permet de vérifier son intégrité.

## Ce qui change

- Sauvegardes plus compactes, regroupées dans une écriture unique ; saisies et notes sauvegardées après 600 ms d'inactivité, avec enregistrement lors du passage en arrière-plan et à la sortie de séance.
- Import entièrement validé avant remplacement ; reprise des anciennes préférences et des exports v1/v2, sans supprimer les anciennes clés lors de la migration.
- Séance perso déjà terminée : choix entre consulter et recommencer. Recommencer archive la précédente occurrence ; chaque séance terminée peut ainsi contribuer à l'historique et à l'XP.
- Historique consultable dans Suivi ; compteur d'avancement limité au programme. Carte hebdomadaire fondée sur les dates de validation des nouvelles séries, même si tu exécutes une autre semaine du programme.
- Chronos corrigés : précision pendant les pauses, temps exact au clic Round, rattrapage après arrière-plan, prévention des doublons de score, contrôle des durées et des paramètres.
- Résultat WOD incomplet identifiable ; il est exclu des records chronométrés. Tri AMRAP par rounds, puis répétitions.
- Calcul des niveaux WOD rétabli ; points mieux lus pour les EMOM, blocs multipliés, charges décimales et abréviations MU. Les déciles reposent sur le catalogue complet, indépendamment des suppressions personnelles.
- Carte musculaire corrigée, recherche effaçable, formulaires mieux validés, contrôleurs libérés et adaptations aux petits écrans.
- Rappels quotidiens sérialisés, actualisés au retour dans l'application ; un appui ouvre la séance concernée. Les séances déjà terminées sont ignorées.
- Projet Android complet inclus : plus de génération de squelette ni de réécriture fragile de fichiers Gradle dans le workflow.

Voir **AUDIT.md** pour le détail et les limites de vérification.

## Données et compatibilité

- Programme inchangé : **40 semaines, 280 jours, 1 954 prescriptions**. Base d'exercices inchangée : **172 entrées**.
- Ancrage : lundi **13 juillet 2026**, donc S8 le **31 août 2026**. Les semaines sont calculées par dates civiles, y compris au changement d'heure.
- Identifiant : `fr.tchoupi.streetlift_tracker`.
- Signature : `signing/kalis_track.p12`, alias `kalis`, identique au fichier d'origine.
- Version visible : `1.5.0`. GitHub Actions génère un versionCode fondé sur la date, qui reste croissant même si le workflow est renommé.
- Les nouveaux exports peuvent commencer par `gz:` : c'est une sauvegarde compressée complète à copier **en entier**. Ils s'importent dans cette version ; l'ancien APK ne sait pas lire ce nouveau format.
- Les nouvelles dates de validation n'existent pas dans les anciennes séries : pour ces dernières, la carte utilise la date de fin de séance, ou la date planifiée pour une séance du programme encore ouverte.
- L'option livres (lb) concerne les **charges suggérées** ; le journal et le Pilotage restent explicitement en **kg**.

## Signature et secrets GitHub

La clé d'origine est gardée dans le zip pour assurer la continuité des installations. Le mot de passe historique est utilisé par défaut. Si tu as déjà un secret `KALIS_KEYSTORE_PASSWORD`, il doit correspondre au mot de passe de cette même clé.

Si le dépôt est public, la présence de cette clé et de son mot de passe dans les fichiers permet à des tiers de signer des APK avec cette identité. Le workflow accepte un secret `KALIS_KEYSTORE_BASE64` contenant **la même clé**, encodée en base64 : tu peux alors retirer le fichier `.p12` de tes prochaines archives publiques. Déplacer la clé ne retire toutefois pas les copies déjà publiées dans l'historique. Ne génère pas une autre clé pour cette mise à jour : elle ne serait pas acceptée par l'application installée.

`tools/verify_project.py --signing` compare le certificat à l'empreinte d'origine. Le mot de passe est lu depuis l'environnement, sans être injecté dans du code Gradle.

## Développement local

Environnement fixé pour cette livraison : Flutter **3.29.3**, Dart **3.7.2**, Java **17**. Android : compileSdk **36**, targetSdk **35**, minSdk **21**, AGP **8.12.1**, Gradle **8.13**, Kotlin **2.2.10**.

Après extraction du zip, dans le dossier `streetlift_tracker` :

```bash
flutter pub get --enforce-lockfile
flutter analyze --no-pub
TZ=Europe/Paris flutter test --no-pub
python3 -m unittest discover -s tools/tests -v
python3 tools/verify_project.py --signing
dart run flutter_launcher_icons
flutter build apk --release --no-pub --build-number=NUMERO_SUPERIEUR_A_L_INSTALLE
```

La compilation Android exige un SDK Android configuré et ses licences acceptées. Le workflow s'exécute sur le runner GitHub Ubuntu et laisse Gradle installer les composants Android requis.

Ne remplace pas le projet par un nouveau squelette Flutter : les fichiers `android/` livrés portent les réglages de signature, les notifications et le petit pont natif de fréquence d'affichage.

## Régénérer les données

Le classeur et l'illustration source ne sont pas inclus dans le zip d'origine. Les assets existants suffisent pour compiler ; aucune régénération n'est nécessaire.

```bash
# Nécessite openpyxl et le classeur original.
python3 tools/xlsx_to_json.py Programme_Streetlifting_v3-3.xlsx
python3 tools/pack_assets.py

# Outil optionnel de segmentation : nécessite Pillow, NumPy et SciPy.
python3 tools/muscles_from_reference.py illustration.png --output segmentation
```

Le convertisseur refuse les formules inconnues au lieu de remplacer silencieusement une charge par zéro. Les arrondis Python suivent l'arrondi Excel à mi-distance. La compression est reproductible et conserve les sources JSON. L'outil de segmentation produit des fichiers de travail, pas un remplacement automatique des masques de l'application.

## Limites actuelles

- Les chronos utilisent le temps réel et se recalent au retour. Ils ne sont pas un service Android permanent : si Android suspend ou tue le processus, une alerte sonore à l'instant exact n'est pas garantie. Le maintien de l'écran allumé reste disponible.
- Les rappels sont planifiés pour les sept prochains jours et renouvelés lors des ouvertures/reprises. Android peut décaler une notification inexacte.
- Les points, durées estimées et cartes WOD sont des estimations à partir des textes. Les variantes, pénalités et schémas libres complexes ne constituent pas des données structurées exhaustives.
- Les tests locaux valident le code Flutter et les données. La compilation release Android et le comportement sur téléphone doivent être confirmés par le run GitHub et l'installation.
