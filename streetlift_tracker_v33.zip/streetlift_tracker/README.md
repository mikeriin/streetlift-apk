# Kalis Track — programme streetlifting v3.3

App Android (Flutter) qui embarque ton programme streetlifting v3.3 complet :
40 semaines · 280 jours · 1954 exercices, avec exécution guidée exercice par
exercice, timer de repos automatique et Pilotage recalculable (mêmes formules
que le classeur Excel).

## Ce que fait l'app

- **Séances** : semaine courante détectée automatiquement (ancrage S8 = 31/08/2026),
  navigation sur les 40 semaines, état fait/à faire par jour.
- **Mode séance** : un exercice par écran (swipe), charge suggérée calculée,
  consignes, logger de séries (kg · reps · RIR · vitesse sur les lifts),
  notes par exercice. Valider une série lance le **timer de repos** (durée de la
  colonne Repos du classeur, ±15 s, alerte sonore + vibration). Les formats
  intervalle (HIIT 8× 30/30) ont leur propre chrono enchaîné. Écran maintenu
  allumé pendant la séance.
- **Pilotage** : PdC, 4 × 1RM, 5 maxima de reps, 21 charges de référence —
  éditables, persistés ; toutes les charges et tous les volumes du programme se
  recalculent instantanément (formules identiques au classeur : % du poids
  système, remise à l'échelle des accessoires selon les reps du jour, volumes
  indexés sur tes maxima).
- **Suivi** : avancement (X/280 séances), actuel vs cible 12 mois par lift et
  par test d'endurance, historique des séances terminées.
- Tout est stocké **en local** (SharedPreferences), hors ligne, zéro compte.

## Mode générique (v1.3)

- **Mes séances** : constructeur de séances personnalisées — base de 170+ exercices
  (recherche + filtres par groupe musculaire, ajout d'exercices perso), 8 modes
  d'exécution paramétrables : classique, myo-reps, cluster, EMOM, AMRAP, isométrie,
  intervalles (HIIT/Tabata), pyramide. Réordonnancement, duplication, édition.
  Chaque mode pilote le chrono adapté dans le runner (EMOM par minute, AMRAP,
  effort/repos, tenues) avec décompte « PRÊT ».
- **Réglages** : repos par défaut, auto-timer, son/vibration, décompte de
  préparation, RIR/RPE, kg/lb, pré-remplissage, écran allumé, **export/import**
  complet des données via presse-papiers (sauvegarde).

## WOD (v1.4)

Sous-onglet **Perso → WOD** : création / modification / duplication / suppression de WODs
en 5 formats — For Time, rounds for time, AMRAP, EMOM, routine libre — avec rounds,
repos inter-rounds, time cap, schéma (21-15-9, 1→15…), mouvements en texte libre
(une ligne par mouvement ou bloc), notes (pénalités, objectifs, team). Exécution avec
chrono adapté (stopwatch + bouton Round + repos automatique, compte à rebours AMRAP,
EMOM minute par minute, alerte time cap), saisie du score et historique avec meilleur
résultat mis en avant. 19 WODs préchargés au premier lancement.

## Mises à jour sans perte de données (v1.5)

Jusqu'ici chaque build GitHub signait l'APK avec une clé *debug* générée à la volée
sur le runner : signature différente à chaque run → Android refusait la mise à jour
en place (« App not installed »), d'où désinstallation et perte des données.

Depuis la v1.5 l'APK est signé avec une **clé stable** (`signing/kalis_track.p12`,
alias `kalis`, PKCS12, valable jusqu'en 2054) par le workflow, et le `versionCode`
est **automatiquement** le numéro du run GitHub (toujours croissant). Résultat :
chaque nouvel APK s'installe **par-dessus** le précédent, données et Pilotage conservés.

- Migration unique depuis une version signée en debug : Réglages → **Exporter**
  (copie dans une note) → désinstaller → installer l'APK v1.5 → Réglages → **Importer**.
- Ne perds jamais `signing/kalis_track.p12` : sans cette clé, plus aucune mise à jour
  en place n'est possible. Mot de passe par défaut `kalistrack2026`, remplaçable par
  un secret GitHub `KALIS_KEYSTORE_PASSWORD` (il faut alors régénérer la clé avec ce
  mot de passe).
- Android ne gère pas de « patch » différentiel pour les APK installés manuellement :
  un APK signé de façon cohérente et au versionCode supérieur EST la mise à jour.

## Check-up v1.5 — natures de saisie et cohérence

Chaque exercice est analysé pour adapter le logger et le chrono :
- **Reps** (défaut) : kg · reps · RIR/RPE (+ vitesse sur les lifts principaux).
- **Tenue chronométrée** (« 3×45 s », « 3×6 s par angle », isométries) : kg · **secondes**
  pré-remplies, sablier = compte à rebours de la tenue, bip à la fin.
- **MAX temps** (dead-hang « 3× max effort ») : chrono **montant**, 1er appui fige le temps.
- **MAX reps** (« 1 × maximum », tests) : reps, RIR masqué (0 implicite).
- **Durée** (« 10 min », mobilité, cardio « 30-45 min ») : minutes + compte à rebours.
- **Intervalles** (30/30 avec ou sans mention « effort/repos »), **EMOM** (12 min ×
  N reps/min), **AMRAP** : une ligne de saisie + chrono dédié.
- **Myo-reps** : lignes Act / M1…M4, micro-repos de 10 s automatique entre mini-séries,
  repos complet (réglage « repos par défaut ») après la dernière.
- **Clusters** : lignes C1…C5, bouton intra-cluster 30 s, repos long entre clusters.
- **Échelles / rounds / montées de test** : lignes É1…, R1…, Mo1-3 puis T1-3.
- **Enchaînements** (dips → pompes) : les deux exercices sur la **même page**, aucun repos
  après le premier (rappel « → Enchaîne »), repos après le second.
- Repos informatifs (« ≥ 20 min après les dips », « 12 min au total ») : plus de chrono parasite.
- **+ / − série** sur chaque exercice (tests 1RM, ajustements).
- Timers **basés sur l'horloge murale** : justes même après passage en arrière-plan.
- **Sons réellement audibles** (SystemSound est muet sur Android) : bips et alarme embarqués.
- Champs de série flexibles : plus de débordement sur écrans étroits.
- Identifiants stables pour les exercices des séances perso (les logs survivent au réordonnancement).

## Identité

Nom affiché : **Kalis Track** (appliqué par le workflow via l'AndroidManifest).
Icône : `assets/icon/` — front lever sous la barre, générée par flutter_launcher_icons
(adaptative + monochrome Android 13). L'applicationId reste `fr.tchoupi.streetlift_tracker`
pour que les mises à jour s'installent par-dessus sans perte de données.

## Compiler

Prérequis : Flutter installé (canal stable ≥ 3.29), Android SDK opérationnel.

```bash
flutter create --org fr.tchoupi --project-name streetlift_tracker streetlift_tracker_build
cd streetlift_tracker_build
# Remplace lib/, ajoute assets/ et pubspec.yaml depuis ce dossier :
rm -rf lib && cp -r ../streetlift_tracker/lib .
cp -r ../streetlift_tracker/assets .
cp ../streetlift_tracker/pubspec.yaml .
flutter pub get
flutter run                # debug sur ton téléphone
flutter build apk --release   # APK final : build/app/outputs/flutter-apk/app-release.apk
```

Aucune permission Android à ajouter (le timer utilise son + vibration système ;
wakelock_plus configure tout seul le FLAG_KEEP_SCREEN_ON).

## Régénérer le JSON quand le programme évolue

Le programme vit dans `assets/programme_v33.json`, généré depuis le classeur :

```bash
pip install openpyxl
python tools/xlsx_to_json.py   # lit Programme_Streetlifting_v3-3.xlsx dans le dossier courant
cp programme_v33.json assets/
```

Le script traduit les formules Excel en « specs » recalculables (system %,
barbell %, accessoire, volume indexé) et vérifie les charges contre les valeurs
du classeur. Nouvelle version du programme → nouveau JSON → rebuild, rien
d'autre à toucher.

## Structure

```
lib/
├── main.dart             # thème sombre « salle », navigation 3 onglets
├── models.dart           # Program / Week / Day / Exercise + specs
├── store.dart            # Pilotage éditable, calculs (répliques Excel), journal, persistance
├── home_screen.dart      # semaine courante + tuiles J1-J7
├── session_screen.dart   # runner exo par exo, logger, timers
├── pilotage_screen.dart  # cellules jaunes
└── records_screen.dart   # cibles vs actuel + historique
```

Code couleur repris du classeur : **jaune** = ce que tu remplis, **vert** = lift
principal, **violet** = prévention, couleur d'onglet = bloc.

## Pistes v2 (quand tu veux)

- Export CSV des logs → réinjection dans l'Excel.
- Notifications de rappel de séance ; timer en foreground service (sonne écran éteint).
- Migration du stockage vers Drift si tu veux requêter l'historique (progression par exercice).
