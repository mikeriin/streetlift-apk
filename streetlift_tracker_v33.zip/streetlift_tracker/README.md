# Kalis Track — 1.0.0

Première version « release » : signature stable (mises à jour en place), programme
streetlifting v3.3 embarqué, séances personnalisées, WOD, chronos, Pilotage recalculable,
thème clair/sombre, rappels quotidiens. Logo : ATR en jambe de K, aplat acier sur encre.
La numérotation de version repart à 1.0.0 (le `versionCode`, lui, reste le numéro du run
GitHub, donc toujours croissant : les mises à jour continuent de s'installer par-dessus).

## 1.4.1 — points de charge, filtres multi-sélection, Arsenal épuré

- **Charge de travail en points** : points par répétition selon le type de mouvement
  (muscle-up 3,2 · HSPU 2,6 · traction 1,7 · burpee 1,7 · dip 1,4 · pompe 1,0 · squat 0,5 …),
  distances par 100 m (course 1,0 · rameur 0,9 · ski 1,0 · bike 0,6 · portés 3,0), lest sur un
  mouvement au poids de corps (× 1 + kg/40), **enchaînement** de la même chaîne
  (× 1,15), complexes de 3 mouvements+ (× 1,10), contrainte unbroken (× 1,20), rounds
  sans repos (× 1,08) / repos ≥ 90 s (× 0,95), AMRAP (rounds estimés × 1,10), EMOM
  (rotation ou plages « min a-b », × 1,15). Seul le total (pts) est affiché ; niveaux et prix
  en découlent.
- **Filtres du catalogue** : panneau déroulant, multi-sélection par catégorie (statut,
  format, niveau, durée, matériel, source), compteur live, rappel des filtres actifs.
- **Arsenal** : une bannière (niveau, crédits, progression) ; sections Séances à la carte
  (+ Nouvelle) et Mes WODs (→ Catalogue). Plus de création ni de duplication de WOD.

## 1.4.0 — catalogue de 500 WODs, difficulté automatique

- **Catalogue** : 49 WODs sélectionnés (Caliwod, OnlineWOD, IPC, High Rox, Iron Bound…) +
  **451 WODs générés** par un générateur déterministe (`lib/wod_generator.dart`) : 6 familles
  (rounds, chipper, échelles, AMRAP, EMOM, routines en blocs), pools de mouvements par
  tiers (poids de corps → barre → lest → erg / KB), noms uniques. Zéro donnée stockée :
  le catalogue se recalcule à l'identique à chaque lancement ; seules tes différences
  (créations, suppressions, modifications, résultats, déverrouillages) sont persistées.
- **Difficulté automatique** : score = charge de travail (volume × pondération par
  mouvement et lest, × rounds estimés pour l'AMRAP) × bonus de skill (muscle-ups, HSPU,
  pistols, lest) ; classement par **déciles du catalogue** → niveau 1-10, même barème pour
  tes WODs. **Prix** : niv. 1-3 → 1 crédit, 4-6 → 2, 7-8 → 3, 9-10 → 4.
- **Catalogue filtrable** (Arsenal → Catalogue) : recherche texte, statut, format, niveau,
  durée estimée, matériel (poids de corps seul, barre, lest, erg, KB/wall ball), source.
- 10 nouveaux WODs transcrits (Caliwod erg & box, RURE, AMRAP 8 lesté, hommage
  F. Montorio, E2MOM 12, HYROX 411/414/415/416, Cannonball, 3 rounds OnlineWOD).
- Les WODs de course à pied seule sont retirés du catalogue.

## 1.3.0 — Arsenal, 22 WODs OnlineWOD, stockage compact

- L'onglet **Perso devient Arsenal** : séances à la carte + WODs à débloquer.
- **22 WODs OnlineWOD** (site officiel : 8 séances poids de corps, Murph et sa version
  rounds, 12 séances piste) → 52 WODs préchargés, dont 32 OnlineWOD.
- **Stockage** : le catalogue de WODs vit dans le code, seules les différences sont
  persistées (WODs créés, supprimés, modifiés, résultats) ; journal et résultats
  compressés gzip+base64 au-delà de 1,5 Ko ; programme et base d'exercices embarqués
  en `.json.gz` (826 Ko → ~130 Ko) ; masques musculaires en niveaux de gris + alpha ;
  liste d'exercices fusionnée mise en cache. Migration automatique de l'ancien format.

## 1.2.2 — illustration anatomique

- L'atlas vectoriel laisse place à une **illustration anatomique** (face/dos) : image de base
  grise (muscles dessinés, au repos) + un calque par groupe musculaire, teinté par l'app selon
  la charge (modulation → le modelé du dessin est conservé) avec halo sur les groupes chauds.
- Génération : `tools/muscles_from_reference.py` segmente l'illustration de référence (traits
  sombres = séparations), classe chaque muscle par position et exporte
  `assets/muscles/{face,dos}_{groupe}.png` (600 Ko au total).

## 1.2.1 — atlas v2, tout se débloque

- Atlas v2 : silhouette athlétique et 40 muscles par face (chefs séparés : deltoïde
  antérieur/latéral/postérieur, pectoral claviculaire/sternal, dentelé, biceps + brachial,
  brachio-radial + fléchisseurs/extenseurs, 8 segments abdominaux, obliques, droit fémoral +
  vastes, adducteurs, tibial, trapèze haut/bas, infra-épineux, grand dorsal, lombaires,
  triceps long/latéral, moyen/grand fessier, biceps fémoral/semi-tendineux, gastrocnémiens
  + soléaire), relief et halo.
- Tous les WODs préchargés coûtent des crédits (1-3 selon le niveau) ; 1 crédit de départ
  + 1 par niveau (+1 aux niveaux 5 et 10). Les accès offerts par l'ancienne migration sont
  retirés, les déverrouillages payés sont conservés.

## 1.2.0 — atlas musculaire, crédits, aperçu de WOD

- **Atlas musculaire vectoriel** (tools/atlas.py → lib/muscle_atlas.dart) : silhouette et 44
  muscles individuels (pectoraux, deltoïdes, biceps, avant-bras, abdominaux segmentés,
  obliques, quadriceps, adducteurs, tibial ; trapèzes, haut du dos, dorsaux, lombaires,
  triceps, fessiers, ischios, mollets à deux chefs). Rendu : muscles gris définis au repos,
  chaleur jaune → orange → rouge, halo et relief, séparations fines.
- **Crédits de déverrouillage** : 1 crédit par niveau (+1 aux niveaux 5 et 10) ; coût par
  WOD selon son niveau (1 = gratuit, 2-3 → 1, 4-6 → 2, 7-10 → 3), WODs personnels gratuits.
  Migration douce : ce qui était accessible reste offert.
- **Aperçu de WOD** : volume (reps, distance, durée estimée), charge de travail (indice
  pondéré par mouvement et lest), muscles sollicités sur l'atlas, mouvements, notes,
  bouton Débloquer / Lancer. Accessible depuis un WOD verrouillé, l'appui long, et l'icône
  « aperçu » du chrono.

## 1.1.0 — niveaux, WODs à débloquer, carte musculaire

- **XP & niveaux** dérivés des données (séance programme +100, perso +60, score WOD +80,
  record +40 ; paliers 150, 200, 250… XP). Pastille de niveau sur l'accueil, carte de
  progression dans Suivi, dialogue de passage de niveau avec les WODs déverrouillés.
- **WODs verrouillés par niveau** (1 à 10, modifiable dans l'éditeur) ; les 19 WODs
  d'origine reçoivent un niveau, **11 nouveaux WODs** (onlinewod, caliwod, IPC, HYROX,
  Iron Body, Cindy athlète, E5MOM, partner AMRAP 40…) sont ajoutés sans réimporter ceux
  que tu as supprimés.
- **Carte des groupes musculaires** (Suivi) : silhouettes face/dos colorées selon les séries
  validées depuis le lundi — programme, séances perso et WODs (exercices reconnus par la
  base puis par mots-clés).

# Programme streetlifting v3.3

App Android (Flutter) qui embarque ton programme streetlifting v3.3 complet :
40 semaines · 280 jours · 1954 exercices, avec exécution guidée exercice par
exercice, timer de repos automatique et Pilotage recalculable (mêmes formules
que le classeur Excel).

## Ce que fait l'app

- **Séances** : semaine courante détectée automatiquement (ancrage S8 = 31/08/2026),
  navigation sur les 40 semaines, état fait/à faire par jour.
- **Mode séance** : un exercice par écran (swipe), charge suggérée calculée,
  consignes, logger de séries (kg · reps · RIR · vitesse sur les lifts),
  notes par exercice. Valider une série lance le **timer de repos** (durée de la
  colonne Repos du classeur, ±15 s, alerte sonore + vibration). Les formats
  intervalle (HIIT 8× 30/30) ont leur propre chrono enchaîné. Écran maintenu
  allumé pendant la séance.
- **Pilotage** : PdC, 4 × 1RM, 5 maxima de reps, 21 charges de référence —
  éditables, persistés ; toutes les charges et tous les volumes du programme se
  recalculent instantanément (formules identiques au classeur : % du poids
  système, remise à l'échelle des accessoires selon les reps du jour, volumes
  indexés sur tes maxima).
- **Suivi** : avancement (X/280 séances), actuel vs cible 12 mois par lift et
  par test d'endurance, historique des séances terminées.
- Tout est stocké **en local** (SharedPreferences), hors ligne, zéro compte.

## Mode générique (v1.3)

- **Mes séances** : constructeur de séances personnalisées — base de 170+ exercices
  (recherche + filtres par groupe musculaire, ajout d'exercices perso), 8 modes
  d'exécution paramétrables : classique, myo-reps, cluster, EMOM, AMRAP, isométrie,
  intervalles (HIIT/Tabata), pyramide. Réordonnancement, duplication, édition.
  Chaque mode pilote le chrono adapté dans le runner (EMOM par minute, AMRAP,
  effort/repos, tenues) avec décompte « PRÊT ».
- **Réglages** : repos par défaut, auto-timer, son/vibration, décompte de
  préparation, RIR/RPE, kg/lb, pré-remplissage, écran allumé, **export/import**
  complet des données via presse-papiers (sauvegarde).

## WOD (v1.4)

Sous-onglet **Perso → WOD** : création / modification / duplication / suppression de WODs
en 5 formats — For Time, rounds for time, AMRAP, EMOM, routine libre — avec rounds,
repos inter-rounds, time cap, schéma (21-15-9, 1→15…), mouvements en texte libre
(une ligne par mouvement ou bloc), notes (pénalités, objectifs, team). Exécution avec
chrono adapté (stopwatch + bouton Round + repos automatique, compte à rebours AMRAP,
EMOM minute par minute, alerte time cap), saisie du score et historique avec meilleur
résultat mis en avant. 19 WODs préchargés au premier lancement.

## v1.7 — navigation héros, Perso refondu, rappels quotidiens

- **Barre de navigation** : Programme au centre en bouton héros (cercle acier, halo), Perso ·
  Suivi à gauche, Pilotage · Réglages à droite. L'app s'ouvre sur Programme.
- **Perso** : même grammaire que l'accueil — bannière (compteurs + créer Séance / WOD),
  sections « Séances personnalisées » et « WOD » avec tuiles (badge, titre, sous-titre,
  meilleur score / fait), tap = ouvrir, **appui long = actions** (Lancer, Modifier, Dupliquer,
  Supprimer). Plus de sélecteur ni de FAB.
- **Rappel quotidien** (Réglages → Rappel quotidien) : notification de la séance du jour
  (S8 · J1 — titre, nombre d'exercices, bloc), heure réglable, jours de repos ignorables.
  Les 7 prochains jours sont planifiés à chaque ouverture (contenu exact par jour), sans
  alarme exacte (pas de permission spéciale). Le workflow ajoute permissions, receivers et
  desugaring Java requis par `flutter_local_notifications`.

## Cohérence & ergonomie (v1.6)

- **Thème clair / sombre / système** (Réglages → Apparence). Palette clair dérivée de
  l'identité sombre, accents assombris pour WCAG AA (acier #1C6C8C, vert #3A7D44,
  violet #5E4B9E, rouge #C0392B, champs de saisie #FDF3D0).
- **Logger de séries** : en-tête de colonnes unique (SÉRIE · KG · REPS · ✓), champs sans
  libellé flottant, chiffres tabulaires, sélection auto au focus, cibles 48 dp.
- **Colonnes optionnelles** : RIR/RPE et vitesse masquées par défaut (réglage global ou
  ⚙ par exercice) ; colonne kg masquée sur le poids de corps non lesté.
- **Titre + sous-titre** pour les noms longs ; chips dédoublonnées ; unités avec espace
  insécable ; « Précédent » (dernière perf, semaine antérieure) avec « Reprendre ».
- **Champs de formulaire** neutres partout (éditeurs, recherche, réglages) ; le jaune
  reste réservé à la saisie de séance et au Pilotage.
- **Perso** : un seul Scaffold + sélecteur segmenté (plus de TabBar imbriquée), états vides
  uniformes, FAB contextuel.
- **Réglages** : composants uniformes, toggles thématisés (plus de thumb blanc), sections
  Thème / Saisie / Chrono / Séance / Données / À propos.
- Chrono : pré-signal haptique 3 s avant la fin.

## Mises à jour sans perte de données (v1.5)

Jusqu'ici chaque build GitHub signait l'APK avec une clé *debug* générée à la volée
sur le runner : signature différente à chaque run → Android refusait la mise à jour
en place (« App not installed »), d'où désinstallation et perte des données.

Depuis la v1.5 l'APK est signé avec une **clé stable** (`signing/kalis_track.p12`,
alias `kalis`, PKCS12, valable jusqu'en 2054) par le workflow, et le `versionCode`
est **automatiquement** le numéro du run GitHub (toujours croissant). Résultat :
chaque nouvel APK s'installe **par-dessus** le précédent, données et Pilotage conservés.

- Migration unique depuis une version signée en debug : Réglages → **Exporter**
  (copie dans une note) → désinstaller → installer l'APK v1.5 → Réglages → **Importer**.
- Ne perds jamais `signing/kalis_track.p12` : sans cette clé, plus aucune mise à jour
  en place n'est possible. Mot de passe par défaut `kalistrack2026`, remplaçable par
  un secret GitHub `KALIS_KEYSTORE_PASSWORD` (il faut alors régénérer la clé avec ce
  mot de passe).
- Android ne gère pas de « patch » différentiel pour les APK installés manuellement :
  un APK signé de façon cohérente et au versionCode supérieur EST la mise à jour.

## Check-up v1.5 — natures de saisie et cohérence

Chaque exercice est analysé pour adapter le logger et le chrono :
- **Reps** (défaut) : kg · reps · RIR/RPE (+ vitesse sur les lifts principaux).
- **Tenue chronométrée** (« 3×45 s », « 3×6 s par angle », isométries) : kg · **secondes**
  pré-remplies, sablier = compte à rebours de la tenue, bip à la fin.
- **MAX temps** (dead-hang « 3× max effort ») : chrono **montant**, 1er appui fige le temps.
- **MAX reps** (« 1 × maximum », tests) : reps, RIR masqué (0 implicite).
- **Durée** (« 10 min », mobilité, cardio « 30-45 min ») : minutes + compte à rebours.
- **Intervalles** (30/30 avec ou sans mention « effort/repos »), **EMOM** (12 min ×
  N reps/min), **AMRAP** : une ligne de saisie + chrono dédié.
- **Myo-reps** : lignes Act / M1…M4, micro-repos de 10 s automatique entre mini-séries,
  repos complet (réglage « repos par défaut ») après la dernière.
- **Clusters** : lignes C1…C5, bouton intra-cluster 30 s, repos long entre clusters.
- **Échelles / rounds / montées de test** : lignes É1…, R1…, Mo1-3 puis T1-3.
- **Enchaînements** (dips → pompes) : les deux exercices sur la **même page**, aucun repos
  après le premier (rappel « → Enchaîne »), repos après le second.
- Repos informatifs (« ≥ 20 min après les dips », « 12 min au total ») : plus de chrono parasite.
- **Reps prévues pré-remplies** par série (v1.5.1) : « 5×4 » → 4, « 3×12-15 » → 12, volumes
  indexés, myo-reps (activation puis minis), clusters, pyramides, échelles (somme), EMOM (total).
- **+ / − série** sur chaque exercice (tests 1RM, ajustements).
- Timers **basés sur l'horloge murale** : justes même après passage en arrière-plan.
- **Sons réellement audibles** (SystemSound est muet sur Android) : bips et alarme embarqués.
- Champs de série flexibles : plus de débordement sur écrans étroits.
- Identifiants stables pour les exercices des séances perso (les logs survivent au réordonnancement).

## Identité

Nom affiché : **Kalis Track** (appliqué par le workflow via l'AndroidManifest).
Icône : `assets/icon/` — front lever sous la barre, générée par flutter_launcher_icons
(adaptative + monochrome Android 13). L'applicationId reste `fr.tchoupi.streetlift_tracker`
pour que les mises à jour s'installent par-dessus sans perte de données.

## Compiler

Prérequis : Flutter installé (canal stable ≥ 3.29), Android SDK opérationnel.

```bash
flutter create --org fr.tchoupi --project-name streetlift_tracker streetlift_tracker_build
cd streetlift_tracker_build
# Remplace lib/, ajoute assets/ et pubspec.yaml depuis ce dossier :
rm -rf lib && cp -r ../streetlift_tracker/lib .
cp -r ../streetlift_tracker/assets .
cp ../streetlift_tracker/pubspec.yaml .
flutter pub get
flutter run                # debug sur ton téléphone
flutter build apk --release   # APK final : build/app/outputs/flutter-apk/app-release.apk
```

Aucune permission Android à ajouter (le timer utilise son + vibration système ;
wakelock_plus configure tout seul le FLAG_KEEP_SCREEN_ON).

## Régénérer le JSON quand le programme évolue

Le programme vit dans `assets/programme_v33.json`, généré depuis le classeur :

```bash
pip install openpyxl
python tools/xlsx_to_json.py   # lit Programme_Streetlifting_v3-3.xlsx dans le dossier courant
cp programme_v33.json assets/ && python tools/pack_assets.py   # → assets/programme_v33.json.gz
```

Le script traduit les formules Excel en « specs » recalculables (system %,
barbell %, accessoire, volume indexé) et vérifie les charges contre les valeurs
du classeur. Nouvelle version du programme → nouveau JSON → rebuild, rien
d'autre à toucher.

## Structure

```
lib/
├── main.dart             # thème sombre « salle », navigation 3 onglets
├── models.dart           # Program / Week / Day / Exercise + specs
├── store.dart            # Pilotage éditable, calculs (répliques Excel), journal, persistance
├── home_screen.dart      # semaine courante + tuiles J1-J7
├── session_screen.dart   # runner exo par exo, logger, timers
├── pilotage_screen.dart  # cellules jaunes
└── records_screen.dart   # cibles vs actuel + historique
```

Code couleur repris du classeur : **jaune** = ce que tu remplis, **vert** = lift
principal, **violet** = prévention, couleur d'onglet = bloc.

## Pistes v2 (quand tu veux)

- Export CSV des logs → réinjection dans l'Excel.
- Notifications de rappel de séance ; timer en foreground service (sonne écran éteint).
- Migration du stockage vers Drift si tu veux requêter l'historique (progression par exercice).
