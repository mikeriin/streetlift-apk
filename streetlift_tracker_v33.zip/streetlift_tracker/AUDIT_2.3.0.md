# Audit 2.3.0 — Catalogue élargi, recherche tolérante

Date : 22 septembre 2026. Version 2.3.0+48 (2.2.4+47 précédente).

## Périmètre

- Nouveau : `lib/search.dart` (moteur de recherche partagé), `test/search_test.dart`.
- Modifiés : `lib/wod_generator.dart` (deuxième série, code de la première intact), `lib/store.dart` (`catalogWods`, 7 modes d’exécution, `modeDefaults`, `setsText` / `forcedSets` / `timerSpec` / `toExercise`), `lib/builder_screen.dart` (paramètres de mode, sélecteur d’exercices), `lib/wod_catalog.dart` (réécrit), `lib/ui.dart` (`KSearch` sans autocorrection), `assets/exercises_db.json.gz` (505 exercices).
- Version : `pubspec.yaml`, `lib/settings_screen.dart` (`kAppVersion`), `test/visual_capture_test.dart` (`validation/2.3.0`). README et checklist 2.2.4 archivés dans `docs/`.
- Tests ajustés : `screens_test` (`WODs · 1000`), `store_test` (1 000 WODs, ids uniques, niveaux 1-10, points et minutes > 0), `training_estimate_test` (nom), `tools/tests/test_tools.py` (505 exercices).

## Vérifications effectuées ici

- Port Python du générateur V2 et du parseur du store (`_parseLine`, `_movePoints`, `_computeStats`) : 500 WODs distincts obtenus en 533 tirages, points de 34 à 1 314 (médiane 170), durée ≥ 1 min pour chacun, aucune ligne muette (Tabata, Death by, EMOM par blocs, force + metcon, échelles montantes avec `…` comprises). Les tirages aléatoires diffèrent entre Python et Dart ; les formes des lignes, elles, sont identiques.
- Compatibilité des lignes avec `equipmentOf` (matériel), `_rangeRe` / `_rotRe` (EMOM), `_maxRe` (Tabata) et `_scheme` (échelles `1-2-3-…-10`).
- Compatibilité avec `logSpec` : `3×MAX` → `repsMax` ; `3×MAX tenue` + tempo « Isométrie » → `holdMax` ; `4×6 · tempo 3-1-1-0` → `reps` ; `3×(8 + 2 paliers)` → `reps` (la regex de tenue exige un nombre après ×) ; chronos `hiit` / `emom` / `amrap` lus avant le texte.
- Tests existants relus : `screens_test` (un seul `TextField`, une seule `Icons.close`, `WODs · 0` puis `WODs · 1000`), `wod_acquisition_test` (recherche « Mon ancien défi » → `WODs · 0` : les trois termes doivent tous apparaître), `ui_refactor_test` (catalogue rendu à 320 px et texte 130 % : rangées de puces à 56 / 52 px, listes horizontales sans débordement).
- Équilibre des délimiteurs vérifié sur chaque fichier Dart modifié (analyse lexicale hors chaînes et commentaires).
- `python3 -m unittest discover -s tools/tests` et `python3 tools/verify_project.py --signing` : résultats dans `validation/2.3.0/`.

## Points d’attention

- Les niveaux 1-10 sont recalculés par déciles sur 1 000 WODs : un WOD de la première série peut changer de niveau (et de prix futur) ; les crédits déjà dépensés restent ceux enregistrés à l’achat.
- Le filtre et le tri par durée estiment 1 000 WODs à la première utilisation (`wodEstimate`, cache de 1 024 entrées) : un court délai est possible la première fois.
- Le tri « Pertinence » n’a de sens qu’avec une recherche ; sans recherche il retombe sur « Débloqués puis niveau ».

## Non vérifié dans l’environnement de livraison

- `flutter analyze`, `flutter test` et la compilation Android : pas de SDK Flutter disponible ici. Le workflow `build-apk.yml` les exécute avant de produire l’APK.
- Rendu visuel des nouvelles puces et du menu de tri : pas de capture.
