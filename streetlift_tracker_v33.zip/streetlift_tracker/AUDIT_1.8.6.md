# Kalis Track 1.8.6 — navigation validée

Version de l'application : **1.8.6+38**. Le programme reste en version 3.3 et le fichier à remplacer reste `streetlift_tracker_v33.zip`.

## Changements

- Intégration de la direction validée : cercles pleins fixes, logos agrandis et cinq titres en majuscules de même taille. Les cercles mesurent 46 px, avec 58 px pour Programme ; les icônes mesurent respectivement 36 et 46 px.
- La sélection utilise un halo bleu et un fondu de couleur de 220 ms. Les icônes restent en place. Les symboles natifs et les cinq destinations de l'application sont conservés.
- Les listes passent sous la navigation. Le flou agit sur leurs pixels, progressivement vers le bas de l'écran. Il ne s'agit pas d'un simple bandeau de couleur. La zone haute du fondu laisse passer les gestes de défilement.
- Une marge à la fin des listes permet de dégager entièrement le dernier élément au-dessus de la barre.
- La navigation s'efface à l'ouverture du clavier et revient à sa fermeture. La hauteur du clavier n'est réservée qu'une fois par l'écran de saisie.
- Le réglage système de réduction des animations affiche immédiatement la sélection. Les préférences Clair, Sombre et Système restent disponibles ; les aperçus livrés montrent le sombre validé.

## Vérifications

- **129 tests Flutter réussis**, dont deux nouveaux contrôles : défilement à travers le fondu et ouverture du dernier jour sans superposition sur l'exécution ; saisie au clavier sans double réduction de hauteur, puis retour au Programme avec conservation de son état.
- **4 tests Python réussis** ; programme et identité de signature vérifiés.
- Analyse Flutter : aucun problème signalé, sous Flutter 3.29.3 / Dart 3.7.2, comme dans le workflow GitHub.
- Contrôle séparé des rendus réels en clair et sombre : 390 × 844 px, ainsi que 320 × 720 px avec texte à 130 %. Le dernier jour reste entièrement accessible après défilement.
- Sélection des cinq onglets, appuis rapprochés, positions fixes des icônes et réduction des animations vérifiés. En mode réduit, les pixels après l'appui et après 400 ms sont identiques.
- Le flou a également été vérifié sur un motif alterné placé derrière la barre : net en haut, puis contrastes atténués et fusionnés vers le bas. Il est limité à la zone de navigation.
- Le PNG et le GIF proviennent des widgets Flutter de cette version. Le GIF montre le défilement du Programme derrière les boutons fixes.
- Données, calculs de charge et de durée, sauvegardes, historique, écran d'exécution, en-tête, ouverture animée, identité Android, clé de signature et workflow de compilation conservés.

## Installation et limite de validation

Remplacer `streetlift_tracker_v33.zip` à la racine du dépôt GitHub, puis utiliser **Actions → Build APK** et installer l'APK obtenu par-dessus l'application existante.

L'APK n'a pas été compilé ici : le SDK Android n'est pas installé dans cet environnement. La fluidité du flou et le rendu final sur téléphone restent à confirmer après la compilation GitHub Actions.
